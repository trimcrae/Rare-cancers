# CSPG4 comparative RNA data and code package

This package accompanies the self-contained September 22 manuscript and supplement. It includes the source ledgers, selected measurements, protocols and result tables described there. Reading an earlier preprint is not required. The September 22 change is packaging and documentation only: no scientific measurement, estimate, figure or analysis output was altered or recomputed.

## Executable analyses with embedded inputs

Run `python replay.py` for the expanded primary exact tests and external summaries. Run `python presubmission-20260921/amended_analysis.py` with Python and NumPy 2.3.5 for the two-sample bootstrap estimates and intervals. These entry points and their scientific inputs are unchanged. Consult their included dependency and source manifests. Their outputs include run timestamps, which can differ without changing results.

## Panel comparisons and array measurements

`historical-analysis/` contains the frozen protocol, specimen and probe manifests, effects, shared-assay comparisons and deletion summaries. `original-panel-source/results/selected-values.json` supplies all 12 original gene rows (the 11-gene panel plus CHRNA6) across the 704 Hofvander source specimens. `original-panel-source/replication-results/array-values.json` supplies the 12 gene rows across the 42 original array records. The other per-gene JSON files preserve the individual array deletion results. These files are exact copies of retained original analysis records. Apply the included eligibility manifests rather than treating every source record as part of the reported reference.

The preserved original Python modules document source validation and the panel calculations. Their original entry points also require full primary-source files, including the Hofvander matrix/metadata and GEO SOFT/platform annotations. Those large files can be obtained from the original dataset locations recorded in the manifests; they are not duplicated here. These modules are source-validation provenance, not additional turnkey offline entry points. The old all-files replay wrapper is not included because it also checked superseded draft documents. The calculation definitions needed to interpret the reported scores and sensitivities are given in the present supplement.

## Provenance and limits

`original-panel-source/EXTRACTION-MANIFEST.json` binds each added file to its original path and checksum. Prior package README and manifest records are preserved as historical provenance; their earlier packaging instructions are superseded by this README. `FILE-MANIFEST.json` records every current member except itself. Original primary-source attribution and reuse terms remain in force.

Approximate pointwise bootstrap intervals do not account for retrospective selection or unmeasured confounding. Source-specific measurements are not pooled across assays. This is an author-review data package, not journal submission or acceptance.
