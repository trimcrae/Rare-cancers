EMC junction provenance and normal-parent sequence comparisons

Unzip, enter evidence, and run python analyze.py (Python 3.11 or later).
All eleven result files should reproduce exactly; no extra packages or network are needed.
The archive preserves computational inputs, versioned public sequence references, results,
source receipts and corrections. Source-ledger-and-methods.md links original publications.
Downloaded literature articles, abstracts, figures and supplements are omitted from this
repository upload; this does not remove an input used by the offline sequence analysis.
The journal review supplement retains the larger local source-evidence collection.
Third-party sequence records retain their source attribution and applicable terms.
Original repository software retains Apache-2.0 licensing; see LICENSE.
The negative read-prefix experiment is optional to replay and needs a separate 128 MiB download.
This is sequence evidence, not evidence of RNA cleavage, safety or therapeutic benefit.
