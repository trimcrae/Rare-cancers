# ASO concise resource report — author review

Start with ASO-short-report.pdf or its editable Word version: 671 main-text words, a 150-word abstract, one table and ten references. Seven double-spaced pages include the title, abstract, declarations and references.

Computational Biology and Chemistry describes an Original Research category rather than a separate short-resource category. This concise report is prepared within that category. The required graphical abstract, caption and four highlights are included.

ASO-extended-evidence retains the accepted detailed report, complete screening methods, alternative geometries and cutoffs, artificial-join comparison, model assumptions, controls and experimental proposals. Its section, table, figure and reference numbers are local to that companion. The proposed experiments were not performed.

Supplementary File 1, fusion-junction-aso-sequences.csv, contains 782 non-comment rows across the primary panel, extensions, alternative lengths and controls. The main result concerns 190 designs across 38 NR4A3 exon 3 junctions. Lines beginning with # are comments. Historical do_not_order and orderable fields describe sequence rules, not measured selectivity or safety.

Supplementary File 2, ASO-correction-note, preserves the correction history. Its historical title and Table 1 refer to the extended report. Temperature values remain DNA:RNA model outputs; the patient-derived model correspondence remains unresolved. The archive DOI identifies a historical computational snapshot.

All final pages were visually checked and source preservation verified. Original artifacts and published versions remain preserved. No new analysis, journal submission or provider update occurred.
