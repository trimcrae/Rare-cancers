# Fusion-output short report — author review

Start with FO-short-report.pdf or its editable Word version: 579 main-text words, a 143-word abstract, one table and six references in three pages. The proposed Cancer Genetics Short Communication category permits up to two main figures and tables combined.

FO-extended-evidence retains the detailed accepted report, its three tables and five corrected figures. Sections 1–6, Tables 1–3, Figures 1–5 and references are local to that companion. Detailed chromatin-surrogate and aggregate analyses, including adverse findings, remain supporting results.

FO-supplement-1 retains detailed methods and Tables S1–S8. FO-supplement-2 retains Tables S9–S17, every Table S14 row, correction history and conditional proposals. Their historical references to the main report mean FO-extended-evidence, rather than the new short narrative.

The short report's Table 1 retains all six estimates. Its q-values retain the original testing families: six genes on GPL6244 and five readable genes on GPL3290. PPARG has five readable GPL3290 comparators; ENO3 and SEMA3C have six.

All final pages were visually checked and source preservation verified. Original artifacts and published versions remain preserved. No scientific analysis was rerun and no journal submission or provider update occurred.
