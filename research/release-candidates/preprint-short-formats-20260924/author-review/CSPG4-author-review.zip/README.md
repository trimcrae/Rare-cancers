# CSPG4 Letter revision — author review

Start with CSPG4-letter.pdf or its editable Word version. The Letter has 590 main-text words and five references in a three-page review PDF including title and declarations. It follows the editor's suggestion to present the finding as a Letter.

CSPG4-letter-supplement retains complete methods, specimen details, the original nine-case result, 12-primary and all-13 sensitivities, adverse conditional results, broader comparisons and all four figures. Its 18 pages include all 114 original table rows. Scientific conclusions are unchanged.

CSPG4-response-to-editor is prepared and unsent. CSPG4-retained-abstract.md preserves the preferred 239-word abstract if the portal requires one. The current public guide gives no Letter-specific abstract requirement or numerical word limit; the portal offers Letter to the Editor.

The existing data and code archive remains linked in the Letter's data-availability statement: https://github.com/trimcrae/Rare-cancers/blob/30fa69b2f0c4fce74bc39b9e13edc6fcffaf25c2/research/release-candidates/cspg4-concise-20260922/journal-package/CSPG4-data-code.zip.

All final pages were visually checked and source preservation verified. This revision has not been uploaded or resubmitted. Original drafts, submission receipts and preprints remain preserved.
