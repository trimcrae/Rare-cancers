# CSPG4 Letter revision for author review

The Letter contains 607 main-text words and five references. Its four-page PDF includes the title, declarations, references and the restored Figure 1 on a landscape page. Figure 1 is the exact image from the accepted concise manuscript.

The opening now explains that myxoid liposarcoma, low-grade fibromyxoid sarcoma and synovial sarcoma were chosen within this reanalysis for morphological and diagnostic relevance to EMC. The supplement distinguishes this choice from the source investigators and retains the qualification that no formal ranking established the three closest mimics. The larger references use all eligible source categories.

The 17-page supplement preserves the original methods, specimen details, nine-case result, 12-primary and all-13 sensitivities, adverse conditional results, broader comparisons and every original table cell. The three remaining figures are Figures S1-S3. No scientific values, original figure bytes or conclusions changed.

The response to the editor is prepared and unsent. CSPG4-retained-abstract.md preserves the preferred 239-word abstract if required by the portal. The current Cancer Genetics guide does not specify a Letter figure limit or prohibition, nor a Letter-specific abstract requirement or word limit. The editor may specify final figure placement.

Guide: https://www.sciencedirect.com/journal/cancer-genetics/publish/guide-for-authors

The existing data and code archive remains linked in the Letter: https://github.com/trimcrae/Rare-cancers/blob/30fa69b2f0c4fce74bc39b9e13edc6fcffaf25c2/research/release-candidates/cspg4-concise-20260922/journal-package/CSPG4-data-code.zip.

All 22 document pages were visually checked and source preservation verified. Internal AI checks are not external peer review. This revision has not been resubmitted to the journal or posted as a new provider preprint. Previous documents and receipts remain preserved.
