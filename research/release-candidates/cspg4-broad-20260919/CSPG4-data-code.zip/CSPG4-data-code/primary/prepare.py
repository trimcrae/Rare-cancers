from pathlib import Path
from datetime import datetime, timezone
import collections, csv, hashlib, json, os, sys
import openpyxl

W = Path(__file__).resolve().parent
ROOT = W.parent.parent
AUTO = W.parent / 'autonomous-next-work-20260917'
REPO = Path('C:/Projects/EMC-Research')
SOURCE = Path('C:/Users/mcrae/.codex/worktrees/8010/EMC-Research/.cache/emc-atlas-new-source-20260906')
MANIFEST = REPO / 'research/autonomy/atlas-hofvander-validation-2026-09-06/metadata-manifest.json'
OLD_PROTOCOL = REPO / 'research/autonomy/atlas-hofvander-validation-2026-09-06/protocol.md.original.txt'
OWNER = '01a07c5e-3499-78f3-b3f3-af246bd9347a'
RESOURCE = 'process:EMC-CSPG4-EXPANDED-CHARACTERIZATION-20260919'
EMC = 'Extraskeletal myxoid chondrosarcoma'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def write(name, obj):
    (W/name).write_text(json.dumps(obj, indent=2)+'\n', encoding='utf8')

assert not (W/'FROZEN-DESIGN.json').exists(), 'Do not overwrite frozen design.'
m = json.loads(MANIFEST.read_text(encoding='utf-8-sig'))
inputs = [MANIFEST, OLD_PROTOCOL, SOURCE/'source_data/meta_data.txt', SOURCE/'ccr-25-3740_supplementary_table_s1_suppts1.xlsx', SOURCE/'source_data/tpm_matrix.tsv']
for rel, receipt in m['source_files'].items():
    assert sha(SOURCE/rel) == receipt['sha256'], rel
classes = {}
for row in openpyxl.load_workbook(inputs[3], read_only=True, data_only=True).active.values:
    sid = str(row[0] or '').split('_')[0]
    if sid in {x['sample_id'] for x in m['samples']}:
        classes[sid] = row[4]
deposited = {x['lab_no']:x for x in csv.DictReader(inputs[2].open(), delimiter='\t')}
assert len(classes) == 704
assert all(classes[sid] == deposited[sid]['Class'] for sid in classes)
samples = []
for r in m['samples']:
    x = dict(r)
    x['source_class'] = classes[x['sample_id']]
    x['broad_reference'] = bool(x['eligible'] and x['source_class']=='Malignant' and x['diagnosis'] not in [EMC, 'Melanoma', 'Spindle cell tumor NOS'])
    samples.append(x)
emc = [x for x in samples if x['eligible'] and x['diagnosis']==EMC]
reference = [x for x in samples if x['broad_reference']]
eligible = [x for x in samples if x['eligible']]
assert len(emc)==9 and len(reference)==393 and len(eligible)==644
cells = {year: {'emc': [x['sample_id'] for x in emc if x['sequencing_year']==year], 'reference': [x['sample_id'] for x in reference if x['sequencing_year']==year]} for year in sorted({x['sequencing_year'] for x in emc})}
assert all(x['emc'] and x['reference'] for x in cells.values())
now = datetime.now(timezone.utc).isoformat()
contract = {'utc':now, 'owner':OWNER, 'resource':RESOURCE, 'authorization':'Direct September19 user request for a fresh subagent, broad CSPG4 characterization and evaluation of an extremeness p-value.', 'question':'How does CSPG4 RNA vary across the retained source tumor types, and how extreme are the nine fixed EMC specimens relative to a defined malignant reference under a conditional label-exchangeability model?', 'scope':'New dated exploratory analysis; preserve all original protocols, estimates, adverse results and public packages. No manuscript/publication update or therapeutic claim.', 'deliverable':'Source-bound per-type descriptive atlas, 11-gene conditional reference tests, reproducible code, independent review and plain-language report.', 'stop_condition':'One frozen design, one bounded execution and independent review; report null/adverse outcomes and inference limitations without adapting comparison choices to improve p-values.', 'storage':'Reuse existing sources/runtime; small text/SVG outputs only, no checkout, duplicated matrix or intensive rendering.', 'inputs':[{'path':str(p), 'sha256':sha(p)} for p in inputs]}
write('CONTRACT.json',contract)
os.environ['PATH']='C:/Users/mcrae/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/git/cmd;'+os.environ['PATH']
sys.path.insert(0,str(REPO/'research/autonomy'))
from local_ownership import Coordinator
with Coordinator(REPO) as c:
    c.reserve(OWNER,RESOURCE,OWNER,receipt=str(W/'CONTRACT.json'))
design = {'frozen_utc':now,'source_expression_values_newly_inspected':False,'prior_information':'CSPG4 selected from original11gene panel; previous primary and secondary results are known. This is not preregistration or new independent validation. Full644specimen atlas not previously inspected for this extension.', 'panel':m['panel'], 'samples':samples, 'emc_ids':[x['sample_id'] for x in emc], 'reference_ids':[x['sample_id'] for x in reference], 'year_cells':cells, 'n_eligible':len(eligible),'n_original_diagnosis_labels':len({x['diagnosis'] for x in eligible}),'n_reference':len(reference),'reference_definition':'Eligible primary lesions with original S1 Class=Malignant, excluding EMC, melanoma and diagnostically unclassified Spindle cell tumor NOS. NOS and all benign/intermediate groups remain in descriptive atlas. Original diagnoses primary; no expression-derived reassignment.', 'descriptive':'All644eligible specimens across60originalS1labels; pertype n, zero/positive count, median, quartiles, range and individual CSPG4 TPM; all-year A=P(EMC>reference)+0.5P(tie) for every original label. Tiny groups visible with n. Patient-weighted and equal-histology broad A are distinct descriptive summaries. All nine individual EMC values and leave-one-EMC-out ranges retained.', 'inference':{'family':'11two-sided broad-reference tests, one per frozen panel gene; CSPG4 highlighted, all tests reported. No per-histology p-value screen.','statistic':'T=sum_year(n_EMC_year/9)*A_year; comparison only within exact sequencing year with observed EMC and reference. All9 supported.','null':'Within each included sequencing year, pooled EMC and reference measurements have identical distributions and their labels are exchangeable conditional on the observed counts. Strong distributional assumption, not only A=0.5. Observational benchmark, not randomized experiment.','permutations':199999,'seed':20260919,'tail':'Two-sided abs(T-0.5), with ties at least as extreme included. Independent uniformly selected EMC-label subsets without replacement within year, fixed counts; same label draws across11genes. p=(exceedances+1)/(B+1).','adjustment':'Bonferroni11 across the original gene panel. Does not correct all retrospective choices or confer confirmatory status.','support_warning':'2023has3EMC and1reference;2022has2EMC and4reference. Year is incomplete technical proxy, not a causal batch adjustment. Show per-year contributions.','uncertainty':'Show original individual specimens and deterministic leave-one-EMC-out summaries; no population ranking from n1–4 and no falsely precise bootstrap interval for singleton strata. Monte Carlo tail counts and resolution reported.','claims_excluded':['probability finding is false','probability data caused by chance alone','EMC uniqueness across all cancers','protein localization or therapeutic suitability','independent replication','p-value threshold as criterion of scientific value']},'source_files':contract['inputs']}
write('FROZEN-DESIGN.json',design)
write('START-RECEIPT.json',{'utc':now,'contract_sha256':sha(W/'CONTRACT.json'),'design_sha256':sha(W/'FROZEN-DESIGN.json'),'no_new_expression_values_read':True,'year_support':{y:{k:len(v) for k,v in cell.items()} for y,cell in cells.items()}})
sys.path.insert(0,str(AUTO));from budget_rule import allowance
state=json.loads((AUTO/'CONTINUATION.json').read_text(encoding='utf-8-sig'));prior=state['latest_usage'];reset='2026-09-26T09:39:55+00:00';observed=datetime.fromisoformat('2026-09-19T18:23:45+00:00')
obs={'utc':observed.isoformat(),'source':'actual Codex direct CSPG4 expansion request','bucket':'codex','window_minutes':10080,'used_percent':14,'reset_utc':reset,**allowance(14,reset,observed),'prior_observed_utc':prior['utc'],'prior_used_percent':prior['used_percent'],'delta_percentage_points':14-prior['used_percent'],'account_wide_rounded_not_task_cost':True,'secondary_window':None}
with (W.parent/'zero-cost-journal-packages-20260910/usage-observations.jsonl').open('a',encoding='utf8') as f:f.write(json.dumps(obs)+'\n')
state.update(latest_usage=obs,status='active_cspg4_expanded_characterization',checkpoint=W.name,active_execution=OWNER,background_execution_active=False,selected_pending_contract=str(W/'CONTRACT.json'),updated_utc=now)
(AUTO/'CONTINUATION.json').write_text(json.dumps(state,indent=2)+'\n')
(AUTO/'NEXT-CHECKPOINT.json').write_text(json.dumps({'utc':now,'checkpoint':W.name,'complete':False,'contract':str(W/'CONTRACT.json')},indent=2)+'\n')
print(json.dumps({'reserved':RESOURCE,'eligible':len(eligible),'reference':len(reference),'year_support':{y:{k:len(v) for k,v in cell.items()} for y,cell in cells.items()},'design_sha256':sha(W/'FROZEN-DESIGN.json')}))
