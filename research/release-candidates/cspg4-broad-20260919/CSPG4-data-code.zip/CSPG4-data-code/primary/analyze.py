"""Dated exploratory extension. Original analyses and public artifacts are untouched."""
from pathlib import Path
from datetime import datetime, timezone
import collections, csv, hashlib, html, json, math
import numpy as np

W=Path(__file__).resolve().parent
EMC='Extraskeletal myxoid chondrosarcoma'
SOURCE=Path('C:/Users/mcrae/.codex/worktrees/8010/EMC-Research/.cache/emc-atlas-new-source-20260906')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,v):(W/name).write_text(json.dumps(v,indent=2,allow_nan=False)+'\n',encoding='utf8')
def ranks(x):
    order=np.argsort(x,kind='stable'); out=np.empty(len(x),dtype=float); ordered=x[order]
    i=0
    while i<len(x):
        j=i+1
        while j<len(x) and ordered[j]==ordered[i]:j+=1
        out[order[i:j]]=(i+1+j)/2
        i=j
    return out
def effect(x,y):
    return float(((x[:,None]>y[None,:])+.5*(x[:,None]==y[None,:])).mean())
def sample_rank_sums(rng,rankmatrix,k,count):
    """Uniform k-subsets, via iid draws conditioned on no duplicates; complement if shorter."""
    n=len(rankmatrix); q=min(k,n-k)
    if q==0:return np.zeros((count,rankmatrix.shape[1])) if k==0 else np.broadcast_to(rankmatrix.sum(axis=0),(count,rankmatrix.shape[1])).copy()
    selected=np.empty((count,q),dtype=np.int64); left=np.arange(count)
    while len(left):
        trial=np.sort(rng.integers(n,size=(len(left),q)),axis=1)
        valid=np.all(np.diff(trial,axis=1)!=0,axis=1)
        selected[left[valid]]=trial[valid]; left=left[~valid]
    sums=rankmatrix[selected].sum(axis=1)
    return rankmatrix.sum(axis=0)-sums if k>n/2 else sums
def csvout(name,rows):
    with (W/name).open('w',encoding='utf8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def main():
    assert not (W/'RESULTS.json').exists(),'Retain completed result; do not overwrite.'
    design=json.loads((W/'FROZEN-DESIGN.json').read_text());start=json.loads((W/'START-RECEIPT.json').read_text())
    assert sha(W/'FROZEN-DESIGN.json')==start['design_sha256']
    for source in design['source_files']:assert sha(Path(source['path']))==source['sha256'],source['path']
    panel=design['panel'];raw={};matrixpath=SOURCE/'source_data/tpm_matrix.tsv'
    with matrixpath.open() as f:
        header=next(f).rstrip('\n').split('\t')[1:]
        for line in f:
            items=line.rstrip('\n').split('\t')
            if items[0] in panel:
                assert items[0] not in raw
                assert len(items)==len(header)+1
                raw[items[0]]=items[1:]
    assert set(raw)==set(panel) and len(header)==len(set(header))==704
    values=np.array([[float(raw[g][i]) for g in panel] for i in range(len(header))])
    assert np.all(np.isfinite(values)) and np.all(values>=0)
    index={sid:i for i,sid in enumerate(header)};csp=panel.index('CSPG4')
    samples=[s for s in design['samples'] if s['eligible']]
    emc=design['emc_ids'];refs=design['reference_ids'];e=values[[index[x] for x in emc]];r=values[[index[x] for x in refs]]
    extract=[]
    for s in samples:
        row={'sample_id':s['sample_id'],'original_diagnosis':s['diagnosis'],'source_class':s['source_class'],'sequencing_year':s['sequencing_year'],'broad_reference':s['broad_reference']}
        row.update({g+'_TPM':raw[g][index[s['sample_id']]] for g in panel});extract.append(row)
    csvout('selected-panel-values.csv',extract)
    groups=collections.defaultdict(list)
    for s in samples:groups[s['diagnosis']].append(s)
    atlas=[]
    for label,items in sorted(groups.items()):
        a=values[[index[s['sample_id']] for s in items],csp]
        atlas.append({'original_diagnosis':label,'source_class':';'.join(sorted({s['source_class'] for s in items})),'n':len(a),'reported_positive_n':int((a>0).sum()),'reported_zero_n':int((a==0).sum()),'median_TPM':float(np.median(a)),'q1_TPM':float(np.quantile(a,.25)),'q3_TPM':float(np.quantile(a,.75)),'min_TPM':float(min(a)),'max_TPM':float(max(a)),'A_EMC_vs_type':None if label==EMC else effect(e[:,csp],a),'reference_n':sum(s['broad_reference'] for s in items),'sparse_n_under_5':len(a)<5})
    csvout('CSPG4-by-type.csv',atlas)
    blocks=[];observed=np.zeros(len(panel));byyear=[]
    for year,ids in sorted(design['year_cells'].items()):
        x=values[[index[s] for s in ids['emc']]];y=values[[index[s] for s in ids['reference']]]
        k=len(x);m=len(y);pooled=np.vstack([x,y]);rankmatrix=np.column_stack([ranks(pooled[:,j]) for j in range(len(panel))]);weight=k/9
        a=np.array([effect(x[:,j],y[:,j]) for j in range(len(panel))])
        ranka=(rankmatrix[:k].sum(axis=0)-k*(k+1)/2)/(k*m)
        assert np.allclose(a,ranka,rtol=0,atol=1e-14)
        observed+=weight*a;blocks.append((rankmatrix,k,m,weight))
        byyear.append({'year':year,'n_EMC':k,'n_reference':m,'EMC_weight':weight,'A_CSPG4':float(a[csp]),'weighted_CSPG4_contribution':float(weight*a[csp]),'reference_histology_counts':dict(collections.Counter(s['diagnosis'] for s in samples if s['sample_id'] in ids['reference']))})
    rng=np.random.default_rng(design['inference']['seed']);B=design['inference']['permutations'];exceed=np.zeros(len(panel),dtype=np.int64)
    distribution=[]
    for start_index in range(0,B,2048):
        size=min(2048,B-start_index);permuted=np.zeros((size,len(panel)))
        for rankmatrix,k,m,weight in blocks:
            permuted+=weight*(sample_rank_sums(rng,rankmatrix,k,size)-k*(k+1)/2)/(k*m)
        exceed+=(np.abs(permuted-.5)>=np.abs(observed-.5)-1e-12).sum(axis=0)
        distribution.append(permuted[:,csp])
    null=np.concatenate(distribution)
    tests=[]
    reflabels=sorted({s['diagnosis'] for s in samples if s['broad_reference']})
    for j,gene in enumerate(panel):
        a=effect(e[:,j],r[:,j]);p=(int(exceed[j])+1)/(B+1)
        equal=float(np.mean([effect(e[:,j],values[[index[s['sample_id']] for s in samples if s['broad_reference'] and s['diagnosis']==d],j]) for d in reflabels]))
        tests.append({'gene':gene,'A_all_year_patient_weighted':a,'A_all_year_equal_histology':equal,'T_year_conditional':float(observed[j]),'permutation_exceedances':int(exceed[j]),'draws':B,'p_two_sided':p,'p_bonferroni_11':min(1,11*p)})
    csvout('panel-reference-tests.csv',tests)
    leave=[]
    for omit in emc:
        kept=[sid for sid in emc if sid!=omit];ae=values[[index[s] for s in kept],csp];t=0
        for year,ids in design['year_cells'].items():
            xids=[sid for sid in ids['emc'] if sid!=omit]
            if xids:t+=len(xids)/8*effect(values[[index[s] for s in xids],csp],values[[index[s] for s in ids['reference']],csp])
        leave.append({'omitted_id':omit,'A_all_year':effect(ae,r[:,csp]),'T_year_conditional':t})
    result={'utc':datetime.now(timezone.utc).isoformat(),'status':'executed_pending_independent_verification','design_sha256':sha(W/'FROZEN-DESIGN.json'),'script_sha256':sha(Path(__file__)),'numpy_version':np.__version__,'n_descriptive':len(samples),'n_diagnosis_labels':len(atlas),'n_EMC':9,'n_reference':len(refs),'n_reference_types':len(reflabels),'n_reference_in_EMC_years':sum(len(x['reference']) for x in design['year_cells'].values()),'EMC_CSPG4':[{'sample_id':sid,'TPM':float(values[index[sid],csp]),'sequencing_year':next(s['sequencing_year'] for s in samples if s['sample_id']==sid)} for sid in emc],'atlas':atlas,'tests':tests,'CSPG4_by_year':byyear,'leave_one_EMC_out':leave,'CSPG4_null_distribution_summary':{'draws':B,'min':float(null.min()),'max':float(null.max()),'median':float(np.median(null)),'q025':float(np.quantile(null,.025)),'q975':float(np.quantile(null,.975))},'sources':design['source_files'],'limitations':design['inference']}
    write('RESULTS.json',result)
    write('EXECUTION-RECEIPT.json',{'utc':result['utc'],'read_all_source_rows_only_selected11genes_parsed':True,'original_source_hashes_verified':True,'frozen_design_unchanged':True,'result_sha256':sha(W/'RESULTS.json'),'outputs':{name:sha(W/name) for name in ['selected-panel-values.csv','CSPG4-by-type.csv','panel-reference-tests.csv']},'public_or_journal_documents_changed':False})
    print(json.dumps({'CSPG4':tests[csp],'n_reference':len(refs),'EMC_CSPG4':result['EMC_CSPG4'],'year_support':byyear,'leave_one_EMC_out_T_range':[min(x['T_year_conditional'] for x in leave),max(x['T_year_conditional'] for x in leave)]}))
if __name__=='__main__':main()
