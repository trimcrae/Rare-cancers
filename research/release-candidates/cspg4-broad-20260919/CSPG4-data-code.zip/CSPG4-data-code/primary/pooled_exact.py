"""User-requested all-year comparison; preserve the earlier conditional run."""
from pathlib import Path
from datetime import datetime, timezone
import csv, hashlib, itertools, json, math
import numpy as np
from analyze import ranks, effect

W = Path(__file__).resolve().parent
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def save(name, data):
    p = W / name
    assert not p.exists(), 'Preserve completed evidence: ' + name
    p.write_text(json.dumps(data, indent=2, allow_nan=False) + '\n', encoding='utf8')

def exact_distribution(rank2, k):
    """Count every size-k subset by doubled midrank sum, with exact uint64 counts."""
    N = len(rank2)
    total = math.comb(N, k)
    assert k <= N // 2 and total < 2**64
    maxsum = int(sum(sorted(map(int, rank2))[-k:]))
    counts = np.zeros((k+1, maxsum+1), dtype=np.uint64)
    counts[0, 0] = 1
    for i, r in enumerate(map(int, rank2)):
        for j in range(min(k, i+1), 0, -1):
            counts[j, r:] += counts[j-1, :-r]
    distribution = counts[k]
    assert sum(map(int, distribution)) == total
    return distribution

def controls():
    checks = []
    for values, k in [([0,1,2,3,4,5],2), ([0,0,1,1,1,2],2),
                      ([0,0,0,0,0,0],3), ([0,1,1,2,3,3,8,9],3)]:
        r2 = np.rint(2*ranks(np.array(values))).astype(int)
        got = exact_distribution(r2,k)
        brute = np.zeros_like(got)
        for subset in itertools.combinations(range(len(values)),k):
            brute[sum(int(r2[i]) for i in subset)] += 1
        assert np.array_equal(got,brute)
        checks.append({'values':values,'k':k,'all_subset_counts_match':True,
                       'enumerated_subsets':math.comb(len(values),k)})
    return checks

def main():
    amendment = json.loads((W/'POOLED-AMENDMENT.json').read_text())
    for name, digest in amendment['input_hashes'].items(): assert sha(W/name)==digest
    check = controls()
    d = json.loads((W/'FROZEN-DESIGN.json').read_text())
    rows = {r['sample_id']:r for r in csv.DictReader((W/'selected-panel-values.csv').open())}
    ids = d['emc_ids'] + d['reference_ids']
    k = len(d['emc_ids']); m = len(d['reference_ids']); N = k+m
    assert (k,m,N)==(9,393,402) and len(set(ids))==402
    tests = []
    for gene in d['panel']:
        x = np.array([float(rows[s][gene+'_TPM']) for s in ids])
        rank2 = np.rint(2*ranks(x)).astype(int)
        observed = int(rank2[:k].sum()); center = k*(N+1)
        distribution = exact_distribution(rank2,k)
        keep = np.abs(np.arange(len(distribution),dtype=np.int64)-center)>=abs(observed-center)
        tails = sum(map(int,distribution[keep])); total = math.comb(N,k)
        p = tails/total
        a = (observed/2-k*(k+1)/2)/(k*m)
        assert abs(a-effect(x[:k],x[k:]))<1e-14
        tests.append({'gene':gene,'n_EMC':k,'n_reference':m,'A_patient_weighted':a,
            'EMC_median_TPM':float(np.median(x[:k])), 'reference_median_TPM':float(np.median(x[k:])),
            'observed_doubled_rank_sum':observed,'null_center_doubled_rank_sum':center,
            'two_sided_tail_subsets':str(tails),'total_subsets':str(total),
            'p_exact_two_sided':p,'p_bonferroni_11':min(1.,11*p),
            'observed_tie_groups':int(sum(n>1 for n in np.unique(x,return_counts=True)[1]))})
    result = {'utc':datetime.now(timezone.utc).isoformat(),
        'status':'executed_pending_independent_verification','amendment_sha256':sha(W/'POOLED-AMENDMENT.json'),
        'code_sha256':sha(Path(__file__)), 'numpy_version':np.__version__,
        'method':'Exact label-permutation distribution of doubled midrank sum; inclusive two-sided absolute distance from null center; ties retained; no Monte Carlo error.',
        'null':'EMC labels exchangeable among the402 included specimens under a common expression-distribution null. Inference describes this cohort reference mixture, not every sarcoma population.',
        'tests':tests,'synthetic_controls':check,
        'selection':'User-directed exploratory amendment after prior descriptive and conditional results were known. Bonferroni11 addresses original gene family only; no claim to erase all post-selection decisions.',
        'previous_conditional_run':'RESULTS.json retained unchanged as exploratory sensitivity; its different answer does not establish a sequencing-year effect.',
        'public_or_journal_artifacts_changed':False}
    save('POOLED-RESULTS.json',result)
    with (W/'pooled-panel-tests.csv').open('x',newline='',encoding='utf8') as f:
        writer=csv.DictWriter(f,fieldnames=list(tests[0])); writer.writeheader(); writer.writerows(tests)
    print(json.dumps({'CSPG4':next(t for t in tests if t['gene']=='CSPG4'), 'controls_passed':len(check), 'result_sha256':sha(W/'POOLED-RESULTS.json')}))
if __name__=='__main__': main()
