from pathlib import Path
from datetime import datetime,timezone
from collections import defaultdict,Counter
from itertools import combinations
import csv,hashlib,json,math,re
import numpy as np
import openpyxl
W=Path(__file__).resolve().parent
O=W/'analysis-final';O.mkdir(exist_ok=True)

def label(s):
    s=s.strip().lower()
    mapping={'leiomyosarcoma:n/a':'leiomyosarcoma','lms':'leiomyosarcoma','ulms':'uterine leiomyosarcoma',
      'synovial cell sarcoma':'synovial sarcoma','synovial sarcoma (ss)':'synovial sarcoma',
      'leiomyosarcoma (lms)':'leiomyosarcoma','mfH'.lower():'malignant fibrous histiocytoma',
      'lipo dediff':'dedifferentiated liposarcoma','liposarcoma:dedifferentiated':'dedifferentiated liposarcoma','liposarcoma - dedifferentiated':'dedifferentiated liposarcoma','liposarcoma, dedifferentiated':'dedifferentiated liposarcoma','dedifferentiated liposarcoma (ddls)':'dedifferentiated liposarcoma','ddlps':'dedifferentiated liposarcoma',
      'lipo pleo':'pleomorphic liposarcoma','liposarcoma:pleomorphic':'pleomorphic liposarcoma','liposarcoma, pleomorphic':'pleomorphic liposarcoma','pleomorphic liposarcoma (pls)':'pleomorphic liposarcoma','plps':'pleomorphic liposarcoma',
      'liposarcoma, well-differentiated':'well-differentiated liposarcoma','wdlps':'well-differentiated liposarcoma',
      'liposarcoma:myxoid/rc':'myxoid/round-cell liposarcoma','liposarcoma, myxoid/round cell':'myxoid/round-cell liposarcoma','liposarcoma, myxoid':'myxoid liposarcoma','myxoid liposarcoma (mls)':'myxoid liposarcoma',
      'mfh:myxofibrosarcoma':'myxofibrosarcoma','myxofibrosarcoma (mfs)':'myxofibrosarcoma',
      'malignant peripheral nerve sheath tumor(mpNST)'.lower():'malignant peripheral nerve sheath tumor','mpnst':'malignant peripheral nerve sheath tumor',
      'ups':'undifferentiated pleomorphic sarcoma','gist':'gastrointestinal stromal tumor','dfsp':'dermatofibrosarcoma protuberans','sft':'solitary fibrous tumor','desmoid':'desmoid tumor',
      'liposarcoma nos':'liposarcoma','as':'AS (source abbreviation unresolved)','pls':'PLS (source abbreviation unresolved)'}
    return mapping.get(s,s)

values=[]
original={ (r['assay'],r['th_dataset_id']):r for r in json.loads((W/'TREEHOUSE-VALUES.json').read_text())}
selection=json.loads((W/'TREEHOUSE-SELECTION-CORRECTED.json').read_text())
for r in selection:
    if not r['histology_eligible']:continue
    measured=original[(r['assay'],r['th_dataset_id'])]
    values.append({'resource':'Treehouse25.01','cohort':r['analysis_stratum'],'assay':r['assay'],'sample_id':r['th_dataset_id'],'identity':r['identity_key'],'identity_basis':r['identity_basis'],'original_diagnosis':r['disease'],'diagnosis':label(r['disease']),'scope':r['scope'],'CSPG4':measured['CSPG4_log2_TPM_plus_1'],'units':'log2(TPM+1)','source_record':r['study_dataset_id']})

assert (W/'BOUDIN-SELECTION-ACCEPTANCE.json').exists()
bsel=json.loads((W/'BOUDIN-SELECTION.json').read_text())
wb=openpyxl.load_workbook(W/'sources/Boudin2022-TableS8.xlsx',read_only=True,data_only=True)
sheet=wb.active;headers=list(next(sheet.iter_rows(min_row=3,max_row=3,values_only=True)))
idx=headers.index('CSPG4 mRNA (log2)'); assert idx==47
source_rows={i:r for i,r in enumerate(sheet.iter_rows(min_row=4,values_only=True),4)}
for r in bsel:
    if not r['selected']:continue
    src=source_rows[r['S8_excel_row']];assert str(src[0])==r['record_id'] and src[1]==r['cohort']
    value=src[idx];assert isinstance(value,(float,int)) and math.isfinite(value)
    values.append({'resource':'Boudin2022','cohort':r['cohort'],'assay':r['platform'],'sample_id':r['record_id'],'identity':r['identity_key'],'identity_basis':r['identity_basis'],'original_diagnosis':r['original_diagnosis'],'diagnosis':label(r['analysis_diagnosis']),'scope':'published_STS_source_label','CSPG4':value,'units':'published normalized CSPG4 mRNA (log2) scale; not TPM','source_record':str(r['S8_excel_row'])})
wb.close()
for series in ['GSE213065','GSE234092']:
    data=json.loads((W/f'sources/{series}-CSPG4-extract.json').read_text())
    for r in data['selected_samples']:
        values.append({'resource':series,'cohort':series,'assay':'FFPE total-RNA Salmon' if series=='GSE213065' else 'FFPE transcriptome-capture featureCounts','sample_id':r['matrix_sample_id'],'identity':series+':'+r['patient_id'],'identity_basis':'repository individual field' if series=='GSE213065' else 'repository distinct patient records; no independent global identity proof','original_diagnosis':r['source_diagnosis'],'diagnosis':label(r['source_diagnosis']),'scope':r['scope'],'CSPG4':r['CSPG4_value'],'units':'TPM' if series=='GSE213065' else 'CPM','source_record':r['GSM']})

op_metadata={r['Kids_First_Biospecimen_ID']:r for r in json.loads((W/'sources/OpenPedCan-v15-selected-metadata.json').read_text())}
op_rows=list(csv.DictReader((W/'sources/OpenPedCan-gene/CSPG4.tsv').open(),delimiter='\t'))
assert len(op_rows)==29
for gene in op_rows:
    sid=gene['sample_id'];m=op_metadata[sid]
    if sid=='BS_28GPVQAA':continue # Source-only provenance exclusion documented before root gene collection.
    values.append({'resource':'OpenPedCan-v15','cohort':'PBTA|'+m['RNA_library'],'assay':m['RNA_library'],'sample_id':sid,'identity':m['Kids_First_Participant_ID'],'identity_basis':'source participant ID; known Treehouse aliases excluded','original_diagnosis':m['cancer_group'],'diagnosis':label(m['cancer_group']),'scope':'CNS-enriched clinical context; '+m['tumor_descriptor'],'CSPG4':float(gene['TPM']),'units':'TPM','source_record':m['sample_id']})

groups=defaultdict(list)
for r in values:groups[(r['resource'],r['cohort'],r['units'],r['diagnosis'])].append(r)
summaries=[]
for (resource,cohort,units,diagnosis),items in sorted(groups.items()):
    arr=np.array([r['CSPG4'] for r in items]);q=np.quantile(arr,[0,.25,.5,.75,1])
    summaries.append({'resource':resource,'cohort':cohort,'diagnosis':diagnosis,'original_labels':' | '.join(sorted({r['original_diagnosis'] for r in items})),'n':len(arr),'min':float(q[0]),'q1':float(q[1]),'median':float(q[2]),'q3':float(q[3]),'max':float(q[4]),'units':units,'scope':' | '.join(sorted({r['scope'] for r in items}))})
source_groups=defaultdict(dict)
for (resource,cohort,units,diagnosis),items in groups.items():source_groups[(resource,cohort,units)][diagnosis]=np.array([r['CSPG4'] for r in items])
def superiority(x,y):return float(np.mean((x[:,None]>y[None,:])+.5*(x[:,None]==y[None,:])))
pairs=[]
for (resource,cohort,units),types in sorted(source_groups.items()):
    for a,b in combinations(sorted(types),2):
        x,y=types[a],types[b]
        pairs.append({'resource':resource,'cohort':cohort,'diagnosis_a':a,'diagnosis_b':b,'n_a':len(x),'n_b':len(y),'A_a_above_b':superiority(x,y),'both_n_at_least_5':len(x)>=5 and len(y)>=5,'units':units})
cross=defaultdict(list)
for r in pairs:
    if r['both_n_at_least_5']:cross[(r['diagnosis_a'],r['diagnosis_b'])].append(r)
cross_summary=[]
for (a,b),items in sorted(cross.items()):
    effects=[r['A_a_above_b'] for r in items]
    cross_summary.append({'diagnosis_a':a,'diagnosis_b':b,'n_source_strata':len(items),'min_A':min(effects),'median_A':float(np.median(effects)),'max_A':max(effects),'n_A_above_0_5':sum(v>.5 for v in effects),'n_A_below_0_5':sum(v<.5 for v in effects),'warning':'Descriptive range across source strata, not meta-analysis or independently verified patient sets'})
def write_csv(name,rows):
    with (O/name).open('w',newline='',encoding='utf8') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
write_csv('external-specimen-values.csv',values)
write_csv('external-type-summaries.csv',summaries)
write_csv('external-within-source-pairs.csv',pairs)
write_csv('external-pair-cross-source-ranges.csv',cross_summary)
lms=[]
for p in pairs:
    if not p['both_n_at_least_5'] or 'leiomyosarcoma' not in [p['diagnosis_a'],p['diagnosis_b']]:continue
    reverse=p['diagnosis_a']=='leiomyosarcoma'
    lms.append(dict(resource=p['resource'],cohort=p['cohort'],diagnosis=p['diagnosis_b'] if reverse else p['diagnosis_a'],n_type=p['n_b'] if reverse else p['n_a'],n_LMS=p['n_a'] if reverse else p['n_b'],A_type_above_LMS=1-p['A_a_above_b'] if reverse else p['A_a_above_b']))
write_csv('external-LMS-reference.csv',lms)
out={'utc':datetime.now(timezone.utc).isoformat(),'descriptive_only':True,'resource_profile_counts':dict(Counter(r['resource'] for r in values)),'counts_not_additive_unique_patients':True,'resource_strata':{r:len({v['cohort'] for v in values if v['resource']==r}) for r in sorted({v['resource'] for v in values})},'summary_rows':len(summaries),'pair_rows':len(pairs),'supported_pair_rows':sum(r['both_n_at_least_5'] for r in pairs),'LMS_display_rows':len(lms),'complete_EMC_presence_check':'No explicitly labeled EMC in these selected external cohorts; no added independent EMC comparison.','files':{n:hashlib.sha256((O/n).read_bytes()).hexdigest() for n in ['external-specimen-values.csv','external-type-summaries.csv','external-within-source-pairs.csv','external-pair-cross-source-ranges.csv','external-LMS-reference.csv']}}
(O/'EXTERNAL-RESULTS.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out))
