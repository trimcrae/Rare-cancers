from pathlib import Path
from datetime import datetime,timezone
import csv,gzip,hashlib,io,json,urllib.request,re
import numpy as np
W=Path(__file__).resolve().parent; S=W/'sources'
selection=json.loads((W/'MODERN-GEO-SELECTION.json').read_text())
assert (W/'EXTERNAL-METADATA-AMENDMENT.json').exists()
urls={
'GSE213065':'https://ftp.ncbi.nlm.nih.gov/geo/series/GSE213nnn/GSE213065/suppl/GSE213065_Sarcoma_ecotyper_tpm_bulksamples.txt.gz',
'GSE234092':'https://ftp.ncbi.nlm.nih.gov/geo/series/GSE234nnn/GSE234092/suppl/GSE234092_merged_gene_count.tsv.gz'}
for series,url in urls.items():
    dest=S/f'{series}-CSPG4-extract.json'
    if dest.exists():print(series,'already preserved; no repeat retrieval');continue
    with urllib.request.urlopen(url,timeout=90) as response:
        raw=response.read(20_000_001); assert len(raw)<=20_000_000
        status=response.status
    compressed_sha=hashlib.sha256(raw).hexdigest()
    reader=csv.reader(io.TextIOWrapper(gzip.GzipFile(fileobj=io.BytesIO(raw)),encoding='utf8'),delimiter='\t')
    header=next(reader); print(series,'header',header[:8],'columns',len(header),flush=True)
    data_start=7 if series=='GSE234092' else 1
    symbol_index=5 if series=='GSE234092' else 0
    selected=[r for r in selection if r['series']==series and r['selected']]
    if series=='GSE234092':
        metadata={r['fields']['Sample_title'][0]:r for r in json.loads((W/'ADDITIONAL-GEO-METADATA.json').read_text()) if r['series']==series}
        mapping=[]
        for m in selected:
            title=m['matrix_sample_id']; number=re.fullmatch(r'MSB(\d+)',title).group(1)
            description=metadata[title]['fields']['Sample_description'][0]
            found=[h for h in header[data_start:] if h.startswith(number+'_') and description in h]
            assert len(found)==1,(title,description,found)
            m['source_matrix_name']=found[0]
            mapping.append({'GEO_title':title,'GEO_description':description,'column':found[0],'basis':'matching MSB numeric identifier and complete TA specimen identifier'})
        amendment={'utc':datetime.now(timezone.utc).isoformat(),'timing':'Matrix header and annotation schema inspected; CSPG4 count row not inspected. Mapping frozen before count aggregation.','source_header':header,'matrix_gene_symbol_column':'GeneName','matrix_gene_id_column':'GeneId','numeric_columns':'all 69 columns after the 7 annotation columns','units':'CPM using sum of all supplied gene counts; existing declared design unchanged','mapping':mapping}
        (W/'GSE234092-MATRIX-MAPPING-AMENDMENT.json').write_text(json.dumps(amendment,indent=2)+'\n')
    rows=0; hits=[]; totals=None; feature_ids=set(); duplicate_feature_ids=0
    for record in reader:
        if not record:continue
        if len(record)==len(header)+1 and rows==0:header=['gene']+header
        assert len(record)==len(header),(len(record),len(header))
        gene=record[0]; symbol=record[symbol_index]
        if gene in feature_ids:duplicate_feature_ids+=1
        feature_ids.add(gene)
        if series=='GSE234092':
            values=np.array([float(v) for v in record[data_start:]],dtype=float)
            assert np.isfinite(values).all() and (values>=0).all()
            if totals is None:totals=np.zeros(len(values))
            totals+=values
        if symbol=='CSPG4':hits.append(record)
        rows+=1
    assert len(hits)==1,('gene identity requires source qualification',series,len(hits))
    assert duplicate_feature_ids==0
    record=hits[0]
    # Exact provided symbols constitute identity evidence; an Ensembl-only hit requires a separate mapping receipt.
    assert record[symbol_index]=='CSPG4'
    sample_ids=header[data_start:]; assert len(set(sample_ids))==len(sample_ids)
    samples=[]
    for m in selected:
        sid=m.get('source_matrix_name',m['matrix_sample_id']); assert sid in sample_ids,(series,sid)
        i=sample_ids.index(sid); original=record[i+data_start];value=float(original)
        if totals is not None:assert totals[i]>0;value=value/totals[i]*1e6
        samples.append(dict(m,CSPG4_value=value,original_value_string=original,count_sum_denominator=None if totals is None else float(totals[i])))
    result={'utc':datetime.now(timezone.utc).isoformat(),'url':url,'http_status':status,'compressed_source_sha256':compressed_sha,'compressed_source_bytes':len(raw),'acquisition':'bounded in-memory matrix scan; full matrix not written locally','source_header':header,'source_gene_row':record,'source_gene_rows':rows,'source_gene_ids_unique':True,'all_gene_count_totals':None if totals is None else totals.tolist(),'selection_sha256':hashlib.sha256((W/'MODERN-GEO-SELECTION.json').read_bytes()).hexdigest(),'selected_samples':samples}
    dest.write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
    print(json.dumps({'series':series,'selected':len(samples),'source_rows':rows,'source_gene':record[0],'units':selected[0]['measurement'],'extract_bytes':dest.stat().st_size}),flush=True)
