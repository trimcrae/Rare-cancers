from pathlib import Path
from datetime import datetime, timezone
import json, hashlib, urllib.request

W = Path(__file__).resolve().parent
design = json.loads((W/'EXTERNAL-DESIGN.json').read_text())
selection = json.loads((W/'TREEHOUSE-SELECTION.json').read_text())
sha = lambda data: hashlib.sha256(data).hexdigest()
assert sha((W/'TREEHOUSE-SELECTION.json').read_bytes()) == design['selection_sha256']
rows = []
for assay, dataset in design['Treehouse']['expression_datasets'].items():
    selected = [r for r in selection if r['selected'] and r['assay'] == assay]
    ids = [r['th_dataset_id'] for r in selected]
    qfile = W/f'sources/Treehouse25.01-{assay}-CSPG4-query.txt'
    rfile = W/f'sources/Treehouse25.01-{assay}-CSPG4-response.json'
    query = '(fetch [{:table '+json.dumps(dataset)+' :columns ["CSPG4"] :samples '+json.dumps(ids)+'}])'
    if rfile.exists():
        assert qfile.exists()
        # Original query formatting may differ; its exact requested IDs must match.
        original = qfile.read_text()
        assert dataset in original
        start = original.index(':samples ') + len(':samples ')
        requested, _ = json.JSONDecoder().raw_decode(original[start:])
        assert requested == ids
        raw = rfile.read_bytes()
        status = 'reused preserved actual response; no new request'
    else:
        qfile.write_text(query, encoding='utf8')
        req = urllib.request.Request('https://xena.treehouse.gi.ucsc.edu/data/', data=query.encode(), headers={'Content-Type':'text/plain'})
        with urllib.request.urlopen(req, timeout=60) as response:
            raw = response.read(1000001)
            assert response.status == 200 and len(raw) <= 1000000
        rfile.write_bytes(raw)
        status = 'HTTP 200 read-only gene query'
    result = json.loads(raw)
    assert len(result) == 1 and len(result[0]) == len(ids)
    for metadata, value in zip(selected, result[0]):
        assert isinstance(value, (int, float)) and 0 <= value < 100
        rows.append(dict(metadata, CSPG4_log2_TPM_plus_1=value, expression_dataset=dataset))
    receipt = {'utc':datetime.now(timezone.utc).isoformat(), 'assay':assay, 'endpoint':'https://xena.treehouse.gi.ucsc.edu/data/', 'status':status, 'n_values':len(ids), 'query_sha256':sha(qfile.read_bytes()), 'response_sha256':sha(raw), 'selection_sha256':design['selection_sha256']}
    (W/f'TREEHOUSE-{assay}-GENE-RECEIPT.json').write_text(json.dumps(receipt, indent=2)+'\n')
    print(json.dumps(receipt), flush=True)
(W/'TREEHOUSE-VALUES.json').write_text(json.dumps(rows, indent=2)+'\n', encoding='utf8')
