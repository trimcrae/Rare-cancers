"""Verify a portable release; optionally replay into a NEW user-selected directory."""
from pathlib import Path
import argparse,hashlib,json,shutil,subprocess,sys,csv,math
P=Path(__file__).resolve().parent
parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path);args=parser.parse_args()
manifest=json.loads((P/'FILE-MANIFEST.json').read_text())
for name,digest in manifest.items():assert hashlib.sha256((P/name).read_bytes()).hexdigest()==digest,name
print('Exact portable input and result hashes verified:',len(manifest))
if args.output is None:sys.exit(0)
out=args.output.resolve();assert not out.exists(),'Use a new empty output path; archived results are never overwritten.'
out.mkdir(parents=True)
primary=out/'primary';primary.mkdir()
for name in ['pooled_exact.py','analyze.py','POOLED-AMENDMENT.json','FROZEN-DESIGN.json','selected-panel-values.csv','RESULTS.json']:
    shutil.copyfile(P/'primary'/name,primary/name)
subprocess.run([sys.executable,str(primary/'pooled_exact.py')],check=True)
expected=json.loads((P/'primary/POOLED-RESULTS.json').read_text())['tests'];got=json.loads((primary/'POOLED-RESULTS.json').read_text())['tests']
assert expected==got,'Primary result mismatch'
external=out/'external';shutil.copytree(P/'external',external)
subprocess.run([sys.executable,str(external/'analyze_external.py')],check=True)
for name,digest in json.loads((P/'external/analysis-final/EXTERNAL-RESULTS.json').read_text())['files'].items():
    assert hashlib.sha256((external/'analysis-final'/name).read_bytes()).hexdigest()==digest,name
print('Exact primary results and all external CSVs reproduced in',out)
