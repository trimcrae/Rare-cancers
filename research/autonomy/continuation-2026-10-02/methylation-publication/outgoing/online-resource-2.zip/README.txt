EMC methylation score transport reproducibility archive
Author: Tristan D. McRae
Article: Training support and score weighting alter conclusions in a public sarcoma methylation reanalysis

START: Python 3 standard library, no installation or network required.
  python reproduce.py --out reproduced
The manifest is checked before any export. Compare output CSVs/JSON with expected-tables/.
No forest, temperature fit or bootstrap is run by this entry point.
The original manuscripts/results/review sources are retained in the parent Git repository.

OPTIONAL FIXED-VOTE NUMERICAL REPLAY (not required for table export):
Copy original-code/ into scratch. Install the three observed packages numpy, pandas and scipy
listed in requirements-observed.txt in your own appropriate environment. Use offline_replay.py
from the archive root with --code pointing to that scratch original-code directory.
The wrapper blocks network access and refuses the preserved original-code directory itself.
Historical scripts recompute temperatures from reference OOF votes and overwrite scratch outputs;
they do not fit forests. The ancillary primary-article retrieval fails explicitly offline after
the numerical work. Preserve the log. No numerical replay was newly run to create this package.

FULL REFIT:
Requires author-processed GSE140686 matrices and original-code/methylation_full_geo.py plus
methylation_transfer.py and metadata extraction. See Online Resource 1 and input_receipt in
results/methylation-corrected-full-support-actual.json. Matrix/feature caches are not bundled.
Original code at da49c4e836533253825587f83656675dac4c913b; continuation at
5d2f2e2116f43c0bb56a46120902a1332f27720b in https://github.com/trimcrae/Rare-cancers.
Do not present a table export as full reconstruction of the forests.

SOURCE AND RIGHTS:
Original studies and accessions remain authoritative. Data/source audits retain published sample
identifiers, not a new patient linkage. Cite Koelsche et al (2021), DOI10.1038/s41467-020-20603-4,
and Lyskjær et al (2021), DOI10.1002/cjp2.215. The first article is CC BY4.0; the second is
CC BY4.0 (see their primary licensing statements). Third-party files retain their source terms;
no blanket relicensing is asserted. Original code and metadata retain repository/source provenance.

LIMITATIONS:
EMC is absent from the658-profile grouped panel. The120-profile subset is selected annotation
concordance, not independent diagnostic accuracy. The before-inspection mapping freeze is
unestablished. Fixed-subsample and epsilon sensitivity are retained. Patient independence cannot
be inferred from array nonoverlap. No E-MTAB-9875 predictions were made. The820/821 external
denominator discrepancy remains unresolved. See Online Resource1 for complete interpretation.
