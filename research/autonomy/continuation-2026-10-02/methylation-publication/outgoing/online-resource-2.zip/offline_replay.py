"""Optional unchanged numerical replay in a scratch copy, with network disabled."""
import argparse, pathlib, runpy, urllib.request
p=argparse.ArgumentParser();p.add_argument('--code',required=True,type=pathlib.Path);a=p.parse_args()
code=a.code.resolve(); original=pathlib.Path(__file__).resolve().parent/'original-code'
if code==original.resolve(): raise ValueError('Use a scratch copy; original inputs must remain unchanged')
def blocked(*args,**kwargs): raise RuntimeError('Ancillary network request disabled by offline replay wrapper')
urllib.request.urlopen=blocked
runpy.run_path(str(code/'methylation_final_replay.py'),run_name='__main__')
