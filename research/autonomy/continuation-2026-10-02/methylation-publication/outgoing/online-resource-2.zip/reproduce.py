#!/usr/bin/env python3
"""Verify frozen inputs and export published tables; Python standard library only.

No network, model fitting, temperature optimization, bootstrap or new analysis.
Run from an extracted Online Resource 2: python reproduce.py --out reproduced
"""
import argparse
import csv
import hashlib
import json
import math
import subprocess
import sys
from pathlib import Path


def run(destination):
    root = Path(__file__).resolve().parent
    manifest = json.loads((root / 'input-manifest.json').read_text())
    for item in manifest['files']:
        data = (root / item['path']).read_bytes()
        if len(data) != item['bytes'] or hashlib.sha256(data).hexdigest() != item['sha256']:
            raise ValueError('Frozen input mismatch: ' + item['path'])
    result = root / 'results'
    def read(name):
        return json.loads((result / name).read_text())['result']
    grouped_name = 'methylation-corrected-full-support-actual.json'
    fusion_name = 'methylation-hallmark-fusion-score-transport-final.json'
    g = read(grouped_name)['results']
    f = read(fusion_name)
    assert g['common_panel']['profiles'] == 658
    assert len(g['common_panel']['classes']) == 23 and 'EMCS' not in g['common_panel']['classes']
    assert f['fusion_subset']['profiles'] == 120 and f['fusion_subset']['classes'] == 12
    destination.mkdir(parents=True, exist_ok=True)
    exported = []
    def table(name, rows):
        with (destination / name).open('w', newline='', encoding='utf-8') as stream:
            writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)
        exported.append(name)
    rows = []
    for support, key in [('Original', 'common'), ('Matched 315 per fold', 'equal_budget')]:
        for split in ['sample', 'supplier', 'chip']:
            m = g[key][split]['methylation']
            rows.append(dict(training_support=support, partition=split,
                             profiles=m['n_profiles'], classes=m['n_classes'],
                             agreement_percent=100*m['accuracy'],
                             brier_class_sum=m['multiclass_brier_sum_convention'],
                             source_file=grouped_name,
                             json_pointer='/result/results/'+key+'/'+split+'/methylation'))
    table('table-1.csv', rows)
    rows = []
    for method in ['published_original_classifier', 'raw', 'reference_temperature']:
        m = f['molecular_annotation_concordance'][method]
        rows.append(dict(method=method, profiles=m['n'], threshold=0.9,
                         assigned=m['score_0.9_assigned'], concordant=m['assigned_concordant'],
                         discordant=m['score_0.9_assigned']-m['assigned_concordant'],
                         source_file=fusion_name,
                         json_pointer='/result/molecular_annotation_concordance/'+method))
    table('table-2.csv', rows)
    rows = []
    for cls, methods in f['molecular_by_class'].items():
        for method in ['raw', 'reference_temperature']:
            m = methods[method]
            rows.append(dict(class_code=cls, method=method, n=m['n'],
                             nll=m['NLL_fusion_compatible_label_input_smoothed'],
                             brier=m['Brier_fusion_compatible_label'],
                             source_file=fusion_name,
                             json_pointer='/result/molecular_by_class/'+cls+'/'+method))
    table('online-table-1-class-losses.csv', rows)
    table('online-table-2-epsilon.csv', [dict(row, source_file=fusion_name,
          json_pointer='/result/zero_vote_smoothing_sensitivity/'+str(i))
          for i, row in enumerate(f['zero_vote_smoothing_sensitivity'])])
    rows = []
    for support, key in [('Original', 'paired_brier_comparisons'),
                         ('Matched', 'equal_budget_paired_brier_comparisons')]:
        for i, row in enumerate(g[key]):
            lo, hi = row['descriptive_cluster_bootstrap_95_percentile']
            rows.append(dict(support=support, contrast=row['contrast'], profiles=row['n_profiles'],
                             clusters=row['n_clusters'], cluster_variable=row['cluster_variable'],
                             difference=row['difference'], lower_95=lo, upper_95=hi,
                             draws=row['bootstrap_draws'], source_file=grouped_name,
                             json_pointer='/result/results/'+key+'/'+str(i)))
    table('online-table-3-paired-contrasts.csv', rows)
    table('online-table-4-fusion-rules.csv', [dict(row, source_file=fusion_name,
          json_pointer='/result/rules/'+str(i)) for i, row in enumerate(f['rules'])])
    replay = subprocess.run([sys.executable, str(root/'reaggregation.py'), '--source-dir', str(result)],
                            check=True, capture_output=True, text=True)
    aggregate = json.loads(replay.stdout)
    (destination/'fixed-loss-reaggregation.json').write_text(json.dumps(aggregate, indent=2)+'\n')
    # Independent checks on preserved profile rows prevent a summary-only package.
    tsv = root/'original-code/outputs/methylation-fusion-audit/fusion-supported-profile-predictions.tsv'
    with tsv.open(encoding='utf-8', newline='') as stream:
        profiles = list(csv.DictReader(stream, delimiter='\t'))
    assert len(profiles) == 120 and len({r['ID'] for r in profiles}) == 120
    inventory = root/'original-code/outputs/methylation-fusion-audit/all-428-annotation-inventory.tsv'
    with inventory.open(encoding='utf-8', newline='') as stream:
        annotations = list(csv.DictReader(stream, delimiter='\t'))
    assert len(annotations) == 428 and len({r['ID'] for r in annotations}) == 428
    assert sum(bool(r['fusion_compatible_target']) and r['QC_pass']=='True' for r in annotations) == 120
    counts = f['fusion_subset']['class_support']
    assert sum(sorted(counts.values(), reverse=True)[:4]) == 91
    assert sum(n == 1 for n in counts.values()) == 3
    output_hashes = {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                     for p in sorted(destination.iterdir()) if p.is_file() and p.name != 'verification.json'}
    receipt = dict(status='passed', scope='input integrity, table export, fixed-loss reaggregation and profile inventory',
                   inputs_verified=len(manifest['files']), profiles=120, inventory_profiles=428,
                   model_fits=0, new_bootstraps=0, network_requests=0,
                   outputs=output_hashes, python=sys.version)
    (destination/'verification.json').write_text(json.dumps(receipt, indent=2)+'\n')
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, default=Path('reproduced'))
    args = parser.parse_args()
    run(args.out.resolve())
