# New public atlas source recovered: Hofvander 2026

## Actual usable asset

Hofvander et al., *Transcriptomic Subgroups in Soft Tissue Tumors Correlate with Morphologic Subtype, Genomic Features, and Outcome*, Clinical Cancer Research 32:1825–1834 (2026), DOI https://doi.org/10.1158/1078-0432.CCR-25-3740 , PMID41661217, PMC13133608.

The full primary XML was successfully retrieved from https://www.ebi.ac.uk/europepmc/webservices/rest/PMC13133608/fullTextXML . Its Data Availability section `s5` explicitly links all source data/code to https://doi.org/10.5281/zenodo.17866629 . The actual Zenodo API record links author repository tag v1.0.1; its recursive Git tree and exact downloaded bytes are preserved. The controlled FASTQ deposition does not prevent access to the public processed matrix.

- Exact matrix: https://raw.githubusercontent.com/JakobHofvander/Transcriptomic_subgroups_in_soft_tissue_tumors_correlate_with_morphologic_subtype_genomic_features/v1.0.1/source_data/tpm_matrix.tsv
- Exact metadata: https://raw.githubusercontent.com/JakobHofvander/Transcriptomic_subgroups_in_soft_tissue_tumors_correlate_with_morphologic_subtype_genomic_features/v1.0.1/source_data/meta_data.txt
- Author repository: https://github.com/JakobHofvander/Transcriptomic_subgroups_in_soft_tissue_tumors_correlate_with_morphologic_subtype_genomic_features/tree/v1.0.1
- Genuine supplement archive: https://www.ebi.ac.uk/europepmc/webservices/rest/PMC13133608/supplementaryFiles

`tpm_matrix.tsv` is 65,407,718 bytes, 19,116 distinct gene-symbol rows by 704 distinct sample columns. All row widths are 705 including the symbol field. All 704 column IDs match the 704 metadata rows exactly. SHA256: `b0d665d1bd1d96ace1faf66cc5a4d7ab7e41cb487c8f0f61734f102a1f9a7af3`. Git blob SHA1 matches the API tree exactly: `7bb7d31ac25dc39f6bdff769a1cd8d5553d0c6e1`. The separate 63.8MB TmV_25_Ano.csv was inventoried but not downloaded; no need to substitute the variance-filtered analysis input for the full TPM matrix.

## Cohort and assay provenance, before target outcomes

Primary Methods `s2-1` states 704 tumors from 704 patients, mostly diagnosed and treated in Lund or Stockholm during 1988–2020, with some samples from previous collaborative projects. All are primary lesions unless specified in Table S1. The article does not establish that lab-number suffixes encode collection dates, and newer sequencing years do not establish newer recruitment. Do not infer independence from either.

Methods `s2-2` reports stored frozen tissue at -80 C, paired-end 150 nt RNA-seq, STAR2.7.10b/GRCh38 and RSEM1.3.3/Ensembl104 gene quantification. Gene-level TPM processing is described in the unsupervised analysis section and explicitly used by the deposited boxplot script. Metadata retain sequencing year. Broad year overlap makes cohort contrasts potentially identifiable; year alone is not a complete batch variable. Protocol details refer to Arbajian et al. 2017, Clin Cancer Res23:7426–7434 (reference bib15).

Supplementary Table S1 contains 13 EMC cases at Excel rows189–201, all with relevant-fusion indicator Yes and all present in the public matrix. `emc-provenance.json` preserves lab IDs, specimen flags, prior references and sequencing year, without target expression values.

- Explicit previously reported cases: 104-92_ESMCS → MDB9736:3; 168-97_ESMCS → MDB9736:4; 536-00_ESMCS → MDB9736:7. Reconcile these with the already recovered atlas provenance; these are positive overlap evidence, not just same-institution speculation.
- 5081-14_ESMCS is explicitly a local recurrence. The remaining 12 are primary lesions by the source's default rule; this does not establish independent recruitment from discovery.
- Other IDs: 11881-19, 3371-22, 3372-22, 4716-22, 4840-13, 5149-18, 5241-06, 7931-19, 8102-22. Lack of an MDB citation is not proof of independence.
- EMC sequencing years: 2019 n=6; 2020 n=1; 2021 n=1; 2022 n=2; 2023 n=3.

Candidate relevant comparator labels in the same matrix: LGFMS13; myxoid liposarcoma14; myxofibrosarcoma61; solitary fibrous tumor13; synovial sarcoma19; desmoid12. These are availability counts, not a frozen analysis selection. Exact full diagnosis-by-year counts are in `schema-inventory.json`. The metadata have 60 distinct labels versus the article's 56 tumor types because labels include subdivisions; do not silently collapse or equate these counts. The article itself describes post-analysis LMS and myxoma subdivisions. Table S1 has revised diagnosis fields, which should be considered explicitly before fixing comparator labels.

## Question, utility, validation, and stop condition

Question: do prespecified therapeutic-address RNA enrichment contrasts replicate in a genuinely independent EMC subset versus fixed relevant sarcoma histologies measured within this study? Use the previously adopted per-gene probability-of-superiority estimand; retain cohort-separated estimates and comparator weights fixed before target values. This can strengthen or remove a rationale for tissue validation; it cannot establish normal-organ sparing, surface localization, or treatment efficacy.

The immediately executable next step is metadata-only reconciliation of Table S1 and existing positive overlap evidence, followed by a frozen sample/comparator and gene-mapping contract. Independent reader has received all local paths. No target gene values were selected, printed or analyzed. Matrix processing inspected identifiers and dimensions only. Initial metadata inspection printed source CINSARC/tSNE/clinical fields incidentally; these did not select the atlas cohort or targets.

Validation completed: genuine XML/XLSX parsing, ZIP CRC check, exact Git blob consistency, 704 unique matrix/metadata sample join, 19,116 unique feature labels, uniform row width, exact 13 EMC row extraction and comparison-year availability. Sample independence is not yet validated. Stop biological replication claims if no credibly independent EMC subset or technically interpretable within-study comparator remains. Do not turn absence of universal patient crosswalks into an automatic rejection where primary recruitment provides sufficient evidence.

## Bounded discovery record and inventory

Read current priority memo, atlas comparability decision, Zullow/Ngo source stops and prior atlas manifests before discovery. Exact new searches included `"Transcriptomic Subgroups in Soft Tissue Tumors" data`, the same title with `GSE`, `Supplementary`, `doi`, and `Data availability`. Initial broader primary-source queries searched `site.ncbi.nlm.nih.gov/geo "extraskeletal" "expression"`, `"extraskeletal myxoid" "RNA" "GSE" -GSE24369 -GSE4303 -GSE179720`, and `"extraskeletal myxoid" "RNA-seq" "GSE" -prognostic -chromatin -axon`. The new 2026 title led to PMID41661217 and the explicit Zenodo link. No old failed GEO/ENA routes were retried. A publisher web GET returned403; successful EuropePMC primary XML/supplements provided the legitimate recovery route. A first text-print attempt failed on Windows cp1252; retry changed output encoding only. These are retrieval/extraction facts, not negative dataset findings.

`retrievals.json` preserves EPMC URLs/status/time/size/digests; `github-retrievals.json` preserves exact versioned URLs/time/size/digests and Git blob hashes; `zenodo17866629.json` and `github-tree-v1.0.1.json` preserve original API bodies. The Zenodo archive itself was not downloaded because direct versioned required assets sufficed. `supplement-inventory.json` lists all five XLSX schemas: S1 metadata, S2/S3 fusion calls, S4 fusion summaries and S5 classifier probabilities. S6 DOCX was inspected and only concerns cohort representativeness. None replaces the recovered TPM matrix. Original bytes remain intact. No mail, paid service, tracked edits or background process.
