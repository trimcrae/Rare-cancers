"""Source-only inventory: no target expression values selected or analyzed."""
from pathlib import Path
import csv,json,hashlib,collections,xml.etree.ElementTree as ET,zipfile
import openpyxl
p=Path(__file__).parent
meta=list(csv.DictReader((p/'source_data/meta_data.txt').open(),delimiter='\t'))
with (p/'source_data/tpm_matrix.tsv').open() as f:
    reader=csv.reader(f,delimiter='\t');header=next(reader);features=[];widths=collections.Counter()
    for row in reader:
        features.append(row[0]);widths[len(row)]+=1
assert len(meta)==704 and len(header)==705 and len(features)==19116
assert len(set(features))==19116 and widths=={705:19116}
assert set(header[1:])=={r['lab_no'] for r in meta}
assert len(set(header[1:]))==704
s1=openpyxl.load_workbook(p/'ccr-25-3740_supplementary_table_s1_suppts1.xlsx',read_only=True,data_only=True).active
s1rows=list(s1.iter_rows(values_only=True));cols=s1rows[1]
emc=[]
for i,row in enumerate(s1rows,1):
    if row[1]=='Extraskeletal myxoid chondrosarcoma':
        sid=row[0].removesuffix('_ESMCS');m=next(r for r in meta if r['lab_no']==sid)
        emc.append({'sample_id':sid,'source_sample_label':row[0],'excel_row':i,'diagnosis':row[1],'revised_diagnosis':row[2],'age_at_diagnosis':row[5],'sex':row[6],'site':row[7],'specimen_exception':row[12],'fusion_indicator':row[13],'genomic_features':row[16],'prior_publication':row[21],'unique_mapped_reads_million':row[22],'sequencing_year':m['sequencing_year'],'in_matrix':sid in header,'independence_status':'explicit prior MDB case; reconcile against discovery provenance' if row[21] else 'not established by absence of MDB reference; study recruitment and specimen timing need assessment'})
assert len(emc)==13
diagnoses=collections.Counter(r['Diagnosis'] for r in meta)
yearcounts={d:dict(collections.Counter(r['sequencing_year'] for r in meta if r['Diagnosis']==d)) for d in sorted(diagnoses)}
inventory={'matrix_file':'source_data/tpm_matrix.tsv','units':'TPM per article RNA-seq and deposited plotting script; symbol-indexed; no numeric values analyzed','matrix_rows':len(features),'unique_feature_labels':len(set(features)),'sample_columns':header[1:],'row_width_counts':dict(widths),'metadata_rows':len(meta),'metadata_fields':list(meta[0]),'matrix_metadata_ids_exact_set_match':True,'diagnosis_counts':dict(sorted(diagnoses.items())),'diagnosis_by_sequencing_year':yearcounts,'emc_provenance':emc}
(p/'schema-inventory.json').write_text(json.dumps(inventory,indent=2)+'\n')
(p/'emc-provenance.json').write_text(json.dumps(emc,indent=2)+'\n')
(p/'matrix-feature-identifiers.txt').write_text('\n'.join(features)+'\n')
root=ET.parse(p/'hofvander2026.xml')
sources=[]
for s in root.findall('.//sec'):
    t=s.find('title')
    if t is not None and ''.join(t.itertext()) in ['Tumors','RNA-seq','Data Availability']:
        sources.append({'section_id':s.get('id'),'title':''.join(t.itertext()),'text':' '.join(s.itertext())})
for r in root.findall('.//ref'):
    if r.find('label') is not None and ''.join(r.find('label').itertext()).rstrip('.')=='15':sources.append({'reference_id':r.get('id'),'text':' '.join(r.itertext())})
(p/'primary-methods-locators.json').write_text(json.dumps(sources,indent=2)+'\n')
xl=[]
for f in p.glob('*.xlsx'):
    w=openpyxl.load_workbook(f,read_only=True,data_only=True)
    xl.append({'file':f.name,'sheets':[{'sheet':s.title,'rows':s.max_row,'columns':s.max_column,'header_row2':list(next(s.iter_rows(min_row=2,max_row=2,values_only=True)))} for s in w]})
(p/'supplement-inventory.json').write_text(json.dumps(xl,indent=2)+'\n')
z=zipfile.ZipFile(p/'hofvander2026-supplements.zip');assert z.testzip() is None
(p/'supplement-archive-members.json').write_text(json.dumps([{'name':x.filename,'bytes':x.file_size,'crc':x.CRC} for x in z.infolist()],indent=2)+'\n')
manifest={str(f.relative_to(p)):{'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in p.rglob('*') if f.is_file() and f.name!='file-manifest.json'}
(p/'file-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'counts':dict(diagnoses),'EMC_years':yearcounts['Extraskeletal myxoid chondrosarcoma'],'all704_metadata_columns_match':True,'source_sections':sources},indent=2))
