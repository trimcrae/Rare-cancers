# Root-provided current-state note — 2026-09-09 UTC

This note accompanies the frozen mechanical intake; it does not add an independent inspection of f05e880f. The scope and hashes in `INTAKE-REPORT.md` remain unchanged.

Root reports that its full direct inspection of f05e880f found 924 → 924 JSON leaves, five string changes, no numeric/structural change and normalized-string AST identity. Root also reports that the main's only change is its section 3.5 heading, so the three legacy pin contexts and the section 3.3 Agaram clauses inspected here remain unchanged. These are **root-provided current-state facts**, not additional comparisons performed by this intake.

Root further reports that the f05 parent disposition favors “quantity lost regression.” The frozen evidence here does not establish that disposition. It establishes:

- The old pooled quantity is expressly withdrawn in main line 402, and its 46.7% / 10.3% / 0.0034 figures at lines 403–405 are inside the `Superseded, retained` quotation.
- Main lines 411–415 introduce Agaram as the selected single cohort for the main event analysis, with seven TAF15 and 16 EWSR1 cases.
- The active line 419 table binds disease-specific death to **3/7 = 42.9%** versus **1/16 = 6.2%**, Fisher **0.0672**.
- Main lines 423–426 scope this to crude recorded-event proportions over unequal uncensored observation windows, with marginal intervals and a post-hoc descriptive Fisher value. It does not state a common-horizon survival probability, adjusted effect or prognosis.
- The existing object identity is **`dod_agaram2014`**, beneath `analyses.B_outcome_by_partner.source_verified_recorded_outcomes.disease_specific_death`; its declared cohort is `agaram-2014-outcome`, source `agaram2014` / PMID24746215 / PMC4015728.

For any later root-admitted guard maintenance, these clauses identify a distinct Agaram-only recorded-event quantity. The existing historical pooled pin IDs and their old context regexes cannot be silently reused merely by inserting a nesting segment: that would conflate the withdrawn `dod_pooled_agaram2014_huang2023` quantity with `dod_agaram2014`. A prospective binding needs an explicitly scoped new quantity identity and context tied to the active Agaram row and its recorded-event scope. This is a mechanical identity constraint, not a maintenance action or a scientific acceptance decision.

No f05 file, new author return, producer, test, linter or source was read/run for this note. Root retains current-state adjudication and any authorization to change guard bindings.
