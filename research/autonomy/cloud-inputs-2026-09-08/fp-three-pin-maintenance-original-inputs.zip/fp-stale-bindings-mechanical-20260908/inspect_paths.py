from pathlib import Path
import json,hashlib,re,datetime

W=Path(__file__).resolve().parents[2]
O=Path('C:/Users/mcrae/.codex/review-workspaces/opus-capacity-sprint-20260907/capacity-campaign-20260908/observations')
F=O/'f6107376';N=O/'96812f4f';OUT=Path(__file__).parent
inventory=[]
def read(p,scope):
 p=Path(p).resolve();b=p.read_bytes();r={'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'read_scope':scope};inventory.append(r);return b,r
def js(p,scope):
 b,r=read(p,scope);return json.loads(b),r
fi,fid=js(F/'DELIVERABLE-ENTRYPOINTS.json','Metadata only, scoped FP main/JSON/producer and residual record identities')
ni,nid=js(N/'TD1-SHARED-CURRENT-artifact-locators.json','Metadata only, scoped FP finding/receipts and unchanged-main reference')
finding,fd=read(N/'PARENT-FP-PINNED-FIGURES-2026-09-08/FINDING-fp-headline-figures-unbound.md','Full named parent finding read; narrative interpretation not adopted automatically')
cur,cd=js(F/'research/manuscripts/fusion-partner/emc-fusion-partner-pooling.json','Only B outcome keys, disease-specific-death values, Agaram cohort/source metadata, and their before/current comparisons; no source or whole-science review')
main,md=read(F/'research/manuscripts/fusion-partner/emc-fusion-partner-stratification.md','Only historical pin matches and nearby section3.3 current table/scope lines386–432')
producer,pd=read(F/'research/manuscripts/emc_fusion_partner_pooling.py','Static named B producer field/call sites only, lines930–945,1850–1898,1937–1958; file not imported or executed')
before,bd=js(F/'FP-residual/BEFORE-20260908/emc-fusion-partner-pooling.json','Only same B disease-specific-death paths for pre-residual identity; no full numeric derivation')
numeric,nd=read(F/'FP-residual/checks/04-check-after-regeneration/numeric-leaf-comparison.txt','Full original numeric-leaf receipt read as prior author assertion; full comparison not rerun')
old,od=js(W/'work/fp-final-review-20260908/pinned/research/manuscripts/fusion-partner/emc-fusion-partner-pooling.json','Reused f44 baseline: only historical pooled DOD and retained Agaram single-cohort DOD values/source identifiers')
om,omid=js(W/'work/fp-final-review-20260908/FINAL-REVIEW-MANIFEST.json','Reused metadata only to identify exact earlier JSON pin/bytes/hash')
pins,pinsid=js(O/'236b90a9/I1-executed-artifacts/orig/pinned-figures.json','Reused original guard artifact: only three fusion_partner_dod entries read; not claimed as a newly extracted f610 guard blob')
allpins=[]
def walk(x):
 if isinstance(x,dict):
  if str(x.get('id','')).startswith('fusion_partner_dod'):allpins.append(x)
  else:
   for v in x.values():walk(v)
 elif isinstance(x,list):
  for v in x:walk(v)
walk(pins)
def get(a,path):
 for k in path.split('.'):
  if not isinstance(a,dict) or k not in a:return {'exists':False,'missing_at':k}
  a=a[k]
 return {'exists':True,'value':a}
oldbase='analyses.B_outcome_by_partner.disease_specific_death.'
newbase='analyses.B_outcome_by_partner.source_verified_recorded_outcomes.disease_specific_death.'
singlebase='analyses.B_outcome_by_partner.single_cohort_contrasts_retained.agaram2014.disease_specific_death.'
maps=[]
text=main.decode('utf-8');lines=text.splitlines()
for pin in allpins:
 tail=pin['key'][len(oldbase):]
 maps.append({'pin':pin,'old_path_in_f610':get(cur,pin['key']),'old_path_in_before_f610_residual':get(before,pin['key']),'historical_pooled_value':get(old,pin['key']),'current_semantic_field_path':newbase+tail,'current_value':get(cur,newbase+tail),'same_field_pre_residual':get(before,newbase+tail),'historical_same_agaram_quantity_path':singlebase+tail,'historical_same_agaram_quantity':get(old,singlebase+tail),'same_agaram_value_preserved':get(cur,newbase+tail)==get(before,newbase+tail)==get(old,singlebase+tail),'historical_pooled_equal_current_agaram':get(old,pin['key'])==get(cur,newbase+tail),'regex_count_raw_text':len(re.findall(pin['context'],text)),'regex_count_whitespace_collapsed_for_context_location_only':len(re.findall(pin['context'],re.sub(r'\s+',' ',text))),'mapping_qualification':'Existing field with matching endpoint name but different cohort/quantity from the old pooled pin. Not an automatic repair or equivalence decision.'})
def numbers(x,path=''):
 out={}
 if isinstance(x,dict):
  for k,v in x.items():out.update(numbers(v,path+'.'+k if path else k))
 elif isinstance(x,(int,float)) and not isinstance(x,bool):out[path]=x
 return out
newdod=get(cur,newbase[:-1])['value'];beforedod=get(before,newbase[:-1])['value'];olddod=get(old,singlebase[:-1])['value']
newnumbers=numbers(newdod);beforenumbers=numbers(beforedod);oldnumbers=numbers(olddod)
ag=next(x for x in cur['cohorts'] if x['id']=='agaram-2014-outcome')
expected_current={e['repo_path']:e for g in fi['groups'].values() for e in g['entrypoints']}
currentchecks=[]
for r in [cd,md,pd]:
 rp=Path(r['path']).relative_to(F).as_posix();e=expected_current[rp]
 currentchecks.append({'repo_path':rp,'expected':e,'actual':r,'matches':e['bytes']==r['bytes'] and e['sha256']==r['sha256'] and e['git_blob']==r['git_blob']})
oldbinding=next(e for e in om['retained_inputs'] if e.get('retained_path','').replace('\\','/').endswith('/pinned/research/manuscripts/fusion-partner/emc-fusion-partner-pooling.json'))
unchangedmain=next(e for e in ni['unchanged_fixed_manuscripts_contract_and_original_gate_records'] if e['repo_path']=='research/manuscripts/fusion-partner/emc-fusion-partner-stratification.md')
a={'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Bounded mechanical existing-byte/path/provenance intake only; no linter/tests/producer/source acquisition/Git/scientific review or original/shared edits. Root corrected requested13missing paths to3; no13-error record sought. Freeze f610/968 only, no live author edits.','current_checks':currentchecks,'968_unchanged_main_reference':unchangedmain,'historical_json_binding':oldbinding,'historical_json_binding_matches':od['bytes']==oldbinding['bytes'] and od['sha256']==oldbinding['sha256'] and od['git_blob']==oldbinding['git_blob'],'pin_spec_provenance_limit':'236b90a9 I1 original guard copy reused. Three key/context entries agree with named968 finding and raw errors; complete guard file not extracted at f610/968.','mappings':maps,'current_dod_id':newdod['id'],'historical_pooled_dod_id':get(old,oldbase[:-1])['value']['id'],'agaram_dod_numeric_scope':{'leaf_count':len(newnumbers),'all_equal_pre_residual':newnumbers==beforenumbers,'all_equal_historical_single_cohort':newnumbers==oldnumbers,'current':newnumbers},'current_agaram_source_binding':{'cohort_id':ag['id'],'source_id':ag['sourceId'],'source_metadata':cur['citations'][ag['sourceId']],'cohort_endpoint':ag['endpoint'],'strata':{arm:{'disease_specific_death':ag['strata'][arm]['disease_specific_death']} for arm in ['EWSR1::NR4A3','TAF15::NR4A3']},'source_verified_block_cohort':cur['analyses']['B_outcome_by_partner']['source_verified_recorded_outcomes']['_cohort'],'qualification':'These are artifact-declared source identities and stored cells, not independent inspection of clinical sources.'},'main_exact_scope_excerpt':[{'line':i+1,'text':lines[i]} for i in range(392-1,428)],'producer_scoped_excerpt':[{'line':i+1,'text':producer.decode().splitlines()[i]} for i in list(range(1850-1,1898))+list(range(1937-1,1958))],'read_scope_and_identities':inventory}
(OUT/'path-mapping-evidence.json').write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'current_matches':all(x['matches'] for x in currentchecks),'historical_matches':a['historical_json_binding_matches'],'maps':[{'id':x['pin']['id'],'missing':x['old_path_in_f610'],'old':x['historical_pooled_value'],'current':x['current_value'],'same_agaram_value_preserved':x['same_agaram_value_preserved'],'raw':x['regex_count_raw_text'],'collapsed':x['regex_count_whitespace_collapsed_for_context_location_only']} for x in maps],'agaram_dod_numeric':a['agaram_dod_numeric_scope'],'read_count':len(inventory)},ensure_ascii=False,indent=2))
