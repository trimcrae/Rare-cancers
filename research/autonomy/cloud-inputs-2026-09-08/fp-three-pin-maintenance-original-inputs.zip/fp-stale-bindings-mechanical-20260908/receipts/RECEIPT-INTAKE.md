# FP pinned-figure and original-test receipt intake

**Three missing JSON paths, corrected from the initial request of13 by the parent.** Both968 pinned-figure runs have complete four-file receipts: pooling --check EXIT=0; lint consistency EXIT=1 with3 A-key-missing errors across29 targets. Both stderr streams are empty.

Exact commands:

```text
python3 research/manuscripts/emc_fusion_partner_pooling.py --check
python3 research/manuscripts/lint_consistency.py
```

Exact missing paths:

- `analyses.B_outcome_by_partner.disease_specific_death.fisher_exact_two_sided_p`
- `analyses.B_outcome_by_partner.disease_specific_death.taf15_arm.percent`
- `analyses.B_outcome_by_partner.disease_specific_death.comparator_arm.percent`

The968 finding agrees with those command/exit/error records. Its scientific reading of prose and surviving values is not established by this receipt inspection. It says no producer rerun, while run01 invokes the producer in --check mode; no regeneration or --write execution is recorded.

The earlier f610 preflight repeats these3 missing paths and explicitly skips pytest. The parent therefore supplied the already-retained original FP test stdout and summary; their actual hashes match REVIEW-MANIFEST entries12/13. Those entries identify c6d97dcc/FP-correction/execution as the original source. These are not new tests against968.

**Original stdout line4063: `107 failed, 75 passed in 5.97s`.** The107 short-summary labels comprise5 pooling-check failures,88 prose-matches-artifact failures, and14 prose-relations failures. These are file-name categories only, not an adjudication of their causes.

Twenty original failure sections explicitly terminate in `KeyError: disease_specific_death`. Their labels and precise diagnostic line excerpts are retained in the JSON. Examples directly tied to the requested paths:

| Original stdout lines | Failure |
|---|---|
|5-27|test_check_refuses_a_hand_edited_pooled_event_count: taf15_arm lookup fails before the event mutation.|
|28-50|test_check_refuses_a_hand_edited_confidence_bound: comparator_arm lookup fails before confidence-bound mutation.|
|107-123|test_check_does_not_write_the_artifact: taf15_arm/events setup lookup fails.|
|1995-2030|prose-value parameter for section5 fourth statement of both death rates: taf15_arm.percent and comparator_arm.percent accessor fails.|
|2031-2065|prose-value parameter for section4.8 headline p-value: fisher_exact_two_sided_p accessor fails.|
|3061-3096|prose-value parameter for pooled Fisher p at its historical appendix site fails on the same missing branch.|

These traces demonstrate inability to reach those checks through the old branch; they do not show that every107 failure is stale, that a replacement preserves the scientific meaning, or that the producer should be changed. The other87 failure bodies were not adjudicated.

**Separate original session-finish failure retained:** the summary traceback says the tracked-tree guard detected a changed FO evidence file (`FO-pdf-production/evidence/76-FINAL-squashed-content-diff.txt`) and records `PYTEST_EXIT=1`. This inspection does not attribute that change to a test or concurrent worker.

## Original identity and read scope

- Test stdout: `C:/Users/mcrae/Documents/Codex/2026-09-07/emc-research-orchestrator/work/fp-focused-verification-20260908/provenance-originals/5c1e99f4cf-pytest-fp-checks-stdout.txt`;350,742 B; SHA-256 `0c8160befcb92b5667ee5520e426383a0392f47880ca41c3fe071ee9c2ea31a9`. Full raw original remains at that exact locator; only targeted diagnostic portions and summary labels were inspected.
- Summary: `C:/Users/mcrae/Documents/Codex/2026-09-07/emc-research-orchestrator/work/fp-focused-verification-20260908/provenance-originals/06cc19c593-pytest-fp-checks-summary.txt`;4,451 B; SHA-256 `19989e0716e9972244e7011c7dc20b359717155200093c670604a0ecd42c0cbe`. Full original text is included in the JSON.
- REVIEW-MANIFEST.json:29,130 B; SHA-256 `b866d231ce47974802dda6c59f2dd390bf04d73eb5afb87494e7350690867023`; matching entries12/13 read only.
- Finding plus both968 four-file receipts: full original texts and hashes retained in receipt-intake.json. Earlier f610 gate: full-file hash plus selected3-error/pytest-skipped lines. f610 entrypoint inventory: metadata only.
- No producer/checker/test/script/source/science/code file read or executed; no network, Git, live-file changes or broader107-failure rebaseline. Parent handles the exact before/current JSON values and pinned specification.
