# FP stale bindings — bounded mechanical intake

Frozen to f6107376 / 96812f4f existing bytes. This is path, value-identity, text-context and original-receipt preparation for root; it is not a scientific review or a guard repair. No producer, linter, test, source query, Git operation or shared-state mutation was performed. Current author partial edits and later returns were not read. Previous P-ST outputs remain untouched.

**Root instruction correction:** the requested “13 missing paths” was corrected by root to **three**. The actual named lint has three errors; no distinct 13-error record is established or sought.

## Finding

All three legacy pinned paths are missing. The existing nested fields are **not equal to the old pooled quantity**: they describe the retained Agaram-only contrast, whereas the old pins and their contexts refer to the withdrawn Agaram-plus-Huang pool. Simply inserting one nesting segment would change which quantity is bound.

The frozen main's current table agrees with the nested Agaram values. Its old 46.7% / 10.3% / 0.0034 figures appear inside an explicitly **withdrawn, superseded quotation**. The 968 finding's interpretation that those remain the current headline magnitude is therefore not adopted: the observed text establishes a stale guard reference to historical context, not an active pooled headline.

## Frozen identities and exact paths

`F` = `C:/Users/mcrae/.codex/review-workspaces/opus-capacity-sprint-20260907/capacity-campaign-20260908/observations/f6107376`.

`N` = `C:/Users/mcrae/.codex/review-workspaces/opus-capacity-sprint-20260907/capacity-campaign-20260908/observations/96812f4f`.

`W` = `C:/Users/mcrae/Documents/Codex/2026-09-07/emc-research-orchestrator`.

| Retained file | Bytes | SHA-256 |
|---|---:|---|
| `F/research/manuscripts/fusion-partner/emc-fusion-partner-stratification.md` | 104883 | `ad7fdd709f7d8a74bff4fc45ccc0f52774a6907fbd2d0aabd7516a1ab8a9de01` |
| `F/research/manuscripts/fusion-partner/emc-fusion-partner-pooling.json` | 130554 | `e99df6396b895263dd7c3345da9ceed5d5eedab3af71587940d785e826653e2a` |
| `F/research/manuscripts/emc_fusion_partner_pooling.py` | 177116 | `bdbd7a99fd5a8dd72f22a3431ed557e439271b4886e83f23e376aafbaa8f76f0` |
| `N/PARENT-FP-PINNED-FIGURES-2026-09-08/FINDING-fp-headline-figures-unbound.md` | 4556 | `72ab2502534841e7adfd299b0f3b6957ecc9d84d403b9dc0102941a18a25f1d6` |

All three current file sizes, SHA-256 hashes and blob identities match `F/DELIVERABLE-ENTRYPOINTS.json`. The 968 index also explicitly carries the unchanged main by reference to f610. No live working-tree bytes were substituted.

The historical pooled JSON is reused from `W/work/fp-final-review-20260908/pinned/research/manuscripts/fusion-partner/emc-fusion-partner-pooling.json`: **117419 B**, SHA `aa271fa0355befc23abe30804e09ffd4876799474b93dc18edcd82a47c7c9bb1`. Its existing `FINAL-REVIEW-MANIFEST.json` identifies source `f44b75588fcd9666f8b96b71c2c88ebccb6095ac:research/manuscripts/fusion-partner/emc-fusion-partner-pooling.json` and blob `a3c2b4af1d1fe84436d5775b44dcca7a10796d88`; all measured identities match. Only relevant pooled/single-cohort DOD fields were read, not the review or clinical source anew.

## Exact three-path map

Let:

- `OLD = analyses.B_outcome_by_partner.disease_specific_death`
- `CURRENT = analyses.B_outcome_by_partner.source_verified_recorded_outcomes.disease_specific_death`
- `HISTORICAL_AGARAM = analyses.B_outcome_by_partner.single_cohort_contrasts_retained.agaram2014.disease_specific_death`

These are literal JSON paths, not suggested replacements.

| Pin ID | Missing literal path | Historical pooled value at that path | Existing current field and value |
|---|---|---:|---|
| `fusion_partner_dod_fisher_p` | `OLD.fisher_exact_two_sided_p` | 0.0034 | `CURRENT.fisher_exact_two_sided_p` = **0.0672** |
| `fusion_partner_dod_taf15_percent` | `OLD.taf15_arm.percent` | 46.7 | `CURRENT.taf15_arm.percent` = **42.9** |
| `fusion_partner_dod_comparator_percent` | `OLD.comparator_arm.percent` | 10.3 | `CURRENT.comparator_arm.percent` = **6.2** |

Each lookup fails at `disease_specific_death` immediately beneath `B_outcome_by_partner`, both in current f610 and the preserved pre-residual `F/FP-residual/BEFORE-20260908/emc-fusion-partner-pooling.json`. Thus these missing paths were already missing before this residual batch.

The historical pooled object has ID `dod_pooled_agaram2014_huang2023` and arms **7/15** versus **6/58**. The current nested object has ID `dod_agaram2014` and arms **3/7** versus **1/16**. These are different stored quantities. A missing-path exception does not itself diagnose numerical disagreement, and the old-versus-current numbers are not evidence that the same Agaram counts changed.

For the same Agaram quantity, every one of the **14 numeric DOD leaves** agrees across (a) the historical `HISTORICAL_AGARAM` object, (b) the pre-f610 residual copy's `CURRENT` object and (c) current f610's `CURRENT` object. The three mapped values above, events, denominators, proportions, interval bounds and stored difference are all identical. This is a bounded stored-value comparison; no Fisher test or interval was recomputed. The wider original author receipt `F/FP-residual/checks/04-check-after-regeneration/numeric-leaf-comparison.txt` claims 318 → 331 total numeric leaves, zero changed/removed and 13 ascertainment fields added; that broader comparison was read as an original receipt and was not rerun here.

## Exact contexts: historical quotation versus current table

At main **line 402**:

> The two-cohort pooled prognostic magnitude previously reported in this section is withdrawn.

Lines **403–405** begin `Superseded, retained` and contain the old `7/15 = 46.7 %`, `6/58 = 10.3 %` and `p = 0.0034` quotation. The following text says the Huang inputs were removed rather than re-estimated and labels that removal scoped absence, not proof that published counts are wrong.

Lines **411–415** introduce one cohort chosen for the main event analysis, Agaram 2014, with 16 EWSR1 and seven TAF15 cases. The live table at **line 419** is:

```text
| **disease-specific death** | **3/7 = 42.9 %** (95 % CI 15.8–75.0) | **1/16 = 6.2 %** (95 % CI 1.1–28.3) | 36.6 pts | 0.0672 |
```

Lines **423–426** describe crude recorded-event proportions over unequal, uncensored observation windows, not common-horizon survival, adjustment or prognosis; the intervals are marginal and Fisher values post-hoc/descriptive. The exact numbered excerpt is retained in `path-mapping-evidence.json`.

The three original context regexes are `Fisher p = 0\.0034`, `7/15 = 46\.7 ?%`, and `6/58 = 10\.3 ?%`. Both percentage patterns occur once in raw frozen text. The Fisher phrase wraps between lines 404 and 405; it occurs once after collapsing whitespace for context location, zero times as that raw uninterrupted regex. This was a local text-location operation, not a linter rerun. All three located contexts belong to the superseded passage.

Exact original guard entries were reused from `C:/Users/mcrae/.codex/review-workspaces/opus-capacity-sprint-20260907/capacity-campaign-20260908/observations/236b90a9/I1-executed-artifacts/orig/pinned-figures.json`. Their key/context fields agree with the named 968 finding and raw errors. **The complete guard file was not extracted as a f610/968 blob**, so its overall identity is recorded as a reused earlier original, not asserted to be the current guard's full identity.

## Existing source and producer bindings

Current `B_outcome_by_partner.source_verified_recorded_outcomes._cohort` is `agaram-2014-outcome`. That cohort's `sourceId` is `agaram2014`, endpoint `outcome_by_partner`, population key `mskcc-emc-consecutive`. Its stored strata give disease-specific death 3/7 TAF15 and 1/16 EWSR1. The citation metadata names PMID **24746215**, PMCID **PMC4015728**, DOI **10.1016/j.humpath.2014.01.007**. These are the artifact's recorded source identities; no clinical source was reopened or independently validated here.

Static producer lines **1856–1857** select `by_id["agaram-2014-outcome"]["strata"]`, then its EWSR1 and TAF15 arms. Lines **1871–1884** build `single("dod_agaram2014", "disease_specific_death", ...)`; lines **1937–1956** place that `dod` object under `source_verified_recorded_outcomes.disease_specific_death`. Stored cohort cells at lines **934/941** are 1/16 and 3/7. The producer was not imported or run.

## Original failures and scope limits

The two original 968 runs are preserved at `N/PARENT-FP-PINNED-FIGURES-2026-09-08/checks/`:

1. `01-pooling-check`: `python3 research/manuscripts/emc_fusion_partner_pooling.py --check`, original **EXIT=0**.
2. `02-lint-consistency`: `python3 research/manuscripts/lint_consistency.py`, original **EXIT=1**, exactly the three `A-key-missing` errors listed above, across 29 target files. Its failure is a missing-path diagnosis, not a completed numeric comparison against a surviving field.

All original command/stdout/stderr/exit texts and their identities, together with the narrowly inspected older test evidence, are in `receipts/`. The old FP test output reports **107 failed / 75 passed**; this intake does **not** classify all 107 as stale paths or clear those failures. Only the supplied source-path-related excerpts and original summary categories are part of this mechanical scope. Receipt details and specific provenance limitations are separately recorded by the receipt component.

The original test stdout is `W/work/fp-focused-verification-20260908/provenance-originals/5c1e99f4cf-pytest-fp-checks-stdout.txt`, 350742 B, SHA `0c8160befcb92b5667ee5520e426383a0392f47880ca41c3fe071ee9c2ea31a9`. Its summary is `W/work/fp-focused-verification-20260908/provenance-originals/06cc19c593-pytest-fp-checks-summary.txt`, 4451 B, SHA `19989e0716e9972244e7011c7dc20b359717155200093c670604a0ecd42c0cbe`. Both match the supplied `REVIEW-MANIFEST.json` entries, which identify c6d97dcc/FP-correction/execution as their source. They are historical tests, not tests of 968. Full raw stdout remains at that immutable locator; full summary and targeted excerpts are in the receipt JSON.

The 107 failure labels divide by filename into five pooling-check, 88 prose/artifact and 14 prose-relation tests. **Twenty targeted failure sections explicitly raise `KeyError: disease_specific_death`** before the requested access/mutation/comparison can be reached; the other 87 failure bodies were not adjudicated. Examples include event-count/confidence-bound mutation setup and accesses for the two percentages and Fisher value. A separate session-finish tracked-tree-guard traceback names changed `FO-pdf-production/evidence/76-FINAL-squashed-content-diff.txt` and records `PYTEST_EXIT=1`; this intake makes no test-versus-concurrent-writer attribution. The f610 preflight repeats the three missing paths and skips pytest; it is not the source of the 107/75 run.

No guard, expected value, test, prose or artifact was changed to make a check pass. The material above distinguishes missing paths, preserved same-cohort values and different retired pooled values so root can decide any later maintenance admission. It does not choose a repair or establish a new accepted baseline.

## Saved artifacts

`path-mapping-evidence.json` contains full literal paths, exact old/current values, numbered manuscript/producer excerpts, selected source fields and 11 read/hash scopes. `inspect_paths.py` is the local byte/path comparison script, which never invokes the scientific producer or any checker. `receipts/` holds the independent original-run component. `DELIVERABLE-HASHES.json` and `SHA256SUMS.txt` freeze this bounded return.
