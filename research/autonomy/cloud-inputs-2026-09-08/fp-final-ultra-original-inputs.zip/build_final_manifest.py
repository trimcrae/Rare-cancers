"""Bookkeeping only: verify retained bytes and describe actual review scope.
Does not acquire sources or run scientific code.
"""
from pathlib import Path
import hashlib, json, re
r = Path(__file__).resolve().parent
records = json.loads((r/'retained-inputs.json').read_text(encoding='utf-8'))
scopes = {
 'emc-fusion-partner-stratification.md':'Full manuscript read, lines 1-1036; whole-paper scientific argument, methods, tables, references and source claims reviewed.',
 'emc-fusion-partner-correction-register.md':'Full correction register read; current A1-A42 and historical finding dispositions considered as provenance, not automatic acceptance.',
 'emc-fusion-partner-pooling.json':'All citation and cohort records, scientific analyses, source qualifications, endpoint/pooling definitions and conclusion fields reviewed. Repeated numeric cells compared with producer and limited independent arithmetic; not a claim of semantic auditing every duplicate metadata character.',
 'emc_fusion_partner_pooling.py':'Numerical functions and scientific analysis assembly read (1-242, 1424-2235); cohort/citation input structures considered with matching artifact. Producer not executed. Remaining output/check scaffolding not exhaustively audited.',
 'partner-event-counts-2026-08-08.md':'Clinical extraction/provenance sections including Huang table transcription and registry eligibility inspected; original primary bytes distinguished from author transcription.',
 'OPERATING_PROTOCOL.md':'Review endpoint/scope instructions inspected; unrelated autonomy operations not reviewed.',
 'PUB-FUSION-PARTNER.json':'All nine old blocker summaries and all25 P1 findings reviewed against the current freeze; old snapshot status is provenance, not a current verdict.',
 'POLICY-evidence.md':'Scientific evidence and pooling rules sections1.3 and2.1-2.5 inspected; policy compliance not treated as scientific validity.',
 'gse28866-tumour-vs-normal.json':'Group definitions, design limits and SEMA3C medians/ratios used by FP inspected; other targets/results not independently audited.',
 'gse28866-tumour-vs-normal-reading.md':'Reading companion fully read; only GSE28866 claims carried into FP assessed as dependencies, not the other paper as a separate review.',
 'lit-targets-partner-events.json':'Retained locator metadata; not treated as original clinical evidence or a completed search.',
 'publications.json':'FP entry only, near line237, inspected for propagated scientific/novelty claims; other publication entries outside scope.',
 'HANDOFF-FP-repair-frozen.md':'Current handoff fully read; frozen pin, provenance and claimed repairs checked against actual files.',
 'CORRECTION-BATCH-20260908-R1-R4-FP-PDF.md':'Companion read, FP instruction withdrawing extra commissioning gates applied; other task sections not a scientific review.',
 'HANDOFF-FP-frozen-current.md':'Superseded handoff pin/dependency table, prior findings, workflow and run-evidence sections inspected; not used as current manuscript snapshot.',
 'requested-artifact-locators.json':'FP original-artifact locators inspected; other paper entries outside scope.',
 'QUANTITY-ACCOUNTING.md':'Full read; author accounting of label change assessed against actual sources, including Davis contradiction.',
 'REGENERATION-RECORD.md':'Full read; original vs overwritten run evidence distinguished.',
 'fp-pytest-stdout.txt':'Full original retained second-run stdout read;182passed1warning2.84s. Not rerun and not scientific acceptance.',
 'fp-pytest-stderr.txt':'Exact retained empty stream verified.',
 'fp-pytest-exit.txt':'Actual original PYTEST_EXIT=0 read.',
 'regen-stdout.txt':'Full retained producer stdout read, including intentionally truncated printed analysis sections. Not a new reviewer producer run.',
 'regen-stderr.txt':'Exact retained empty stream verified.',
 'regen-exit.txt':'Actual original EXIT=0 read.',
 'numeric-delta.txt':'Full delta read; unchanged numeric values do not establish validity of classification or estimand.',
 'AFTER-hashes.txt':'Original hash provenance retained/inspected; no scientific inference.',
 'BEFORE-hashes.txt':'Original hash provenance retained/inspected; no scientific inference.',
 'test_fusion_partner_prose_matches_its_artifact.py':'Relevant PMCID ownership/census implementation near2350-2379 inspected; not a full audit of the155k guard corpus and no execution.',
 'test_emc_fusion_partner_pooling_check.py':'Retained dependency for traceability; not executed or exhaustively inspected. No scientific claim based on it.',
 'submission-reference-metadata-2026-08-09.json':'Lenz entry near189-202 checked; other publication records outside scope.',
 'emc-clinical-registry.json':'Relevant Huang/Remiszewski citation identifiers located; not independently audited as a whole clinical registry.',
 'fp-existing-cache-locators-20260908T2003Z.json':'Full source-locator metadata inspected; local absence claims scoped, not source-content evidence.',
 'tcf12-nr4a3-breakpoint-primary-sources.json':'Full record read; Sjogren quoted patient/material selection statements assessed for FP; other breakpoint/ASO conclusions outside this review.',
 'emc_fusion_freq_agaram2014_pmc.txt':'Full scientific article body, Table1 and follow-up paragraphs read (155-738); counts and definitions checked; small table-duration arithmetic confirms reported means. Page navigation irrelevant.',
 'PMC7999686.txt':'EMC section line16 fully read in context; broader sarcoma review not independently assessed.',
 'PMC5400622.txt':'Relevant scientific paragraphs6,12-18,24-34 read, especially introduction14 and discussion26; direct secondary classification of8EWSR1 patients recognized. Other sequencing results not independently recomputed.',
 'PMC12504171.txt':'Relevant molecular/prognostic and EMC therapy paragraphs33,35,71,151,199 inspected; qualitative partner wording checked. Broader diagnostics/treatment guidance not independently assessed, no patient denominator added.',
 'PMC3534218.txt':'Scientific body/case descriptions and ASPS analogy read, lines6-108; treatment-index overlap and source attribution assessed.',
 'ft_sunitinib2014_ejc.txt':'Original cached EuropePMC abstract and identifying metadata read; file is not primary full text despite ft_ filename.',
 'emc_pazopanib_pubmed.txt':'Primary abstract methods/results661-669 and metadata inspected;26treated/23mITT/22evaluable flow distinguished. No primary full text present.',
 'nct02066285_ctgov_v2_full.txt':'Cached JSON study design, eligibility, sites, study dates and results availability inspected; line6 eligibilityModule excludes previous antiangiogenic agents. Registry record not a patient-level audit.',
 'nct02066285_ctgov_results.txt':'Available JSON fields inspected; no partner results section. Filename does not establish posted results.',
 'nct02066285_ctgov_v2_history.txt':'Full198B artifact read; HTTP404 with no historical eligibility content.',
 'huang2023_epmc_core.txt':'Full abstract and citation identity read from cached JSON; confirms prevalence and reported model significance, not Table1 counts, HRs or human extraction.',
 '_manifest.json':'Full retained retrieval manifest read; Huang403 routes are denial records, not actual PDF/fulltext.',
 'MANIFEST.json':'Full original12-source transport manifest read; exact original preserved, including three path-prefix omissions.',
 'local-copy-verification.json':'Companion canonical path mappings and final byte/SHA/Git-blob verification metadata inspected; not clinical source evidence.',
 'PMC6766969.txt':'Scientific text read1-125, especially tumor series, construct/replicate design, SEMA3C results and later response hypothesis. Quoted claims checked; figures, supplement and linked2021correction not separately available/audited.',
 'PMC9813045.txt':'Full retained scientific body read1-78; patient/model provenance,40-agent single-model screen,three-agent two-model validation and quoted observations checked. Full40-agent figure inventory absent from text and not visually verified.',
 'pmc_html_PMC1868116.txt':'Relevant scientific Methods, Table1 patient follow-up, Table3 partner mapping and Discussion read, especially182-294,413-515,745-749. Patient6 deduplicated;3TAF noTRD and5EWSR1 with1TRD directly checked. Unrelated microarray gene table not fully audited.',
 'epmc_core_32572850_multicentre.txt':'Actual primary abstract and citation identity inspected; localized67cohort,50/10/1/1 distribution,follow-up55months and specificDFS/DMFS statements checked. No full text.',
 'pubmed_40828003.txt':'Exact PubMed companion retained for traceability; scientific abstract reading used EPMC companion. No claim of independent second source or full-text review.',
 'epmc_core_40828003.txt':'Actual primary abstract and identity inspected;18patients/20samples,14EWSR1/2TAF15/1TCF12/1FUS and nonsignificantOS-by-fusion statement checked. Overlap/partner death counts not supplied.',
 'pmc_PMC12504171_europepmc_fulltext.txt':'Exact additional raw full-text wrapper retained/hash-verified; relevant scientific inspection used previously retained local text companion. No byte-equivalence or separate fullXML audit claim.',
}
for x in records:
    p=Path(x['retained_path']); data=p.read_bytes()
    assert len(data)==x['bytes'] and hashlib.sha256(data).hexdigest()==x['sha256'], str(p)
    name=p.name
    orig=Path(x['source'].split(':',1)[1] if x['kind']=='git' else x['source']).name
    if 'review-seats' in x['source']:
        scope='Old immutable seat file retained for traceability. All findings were integrated via complete hardening-state summaries, not a separate preparatory or new seat cycle; individual old seat file not exhaustively reread.'
    elif name=='8aac609280-MANIFEST.json':
        scope='Full second transport manifest read;7files for6articles (five required identifiers plus optionalRemiszewski;Suemitsu twice). Explicit scoped Lenz absence retained, not a global absence claim.'
    elif orig=='SKILL.md':
        scope='Full relevant skill read; user standing one-review scientific scope controls, publication gates are later workflow.'
    elif name=='8e07fb929a-PMC7563993.txt':
        scope='Actual prior local text, relevant clinical/molecular review paragraphs read including33,45,61-65; used with distinct encoding from source-cache wrapper.'
    elif orig=='PMC7563993.xml':
        scope='Exact companion XML retained/hash-verified; scientific reading used its local text companion, no claim of separate full XML review.'
    elif orig=='PMC7563993.txt':
        scope='Exact source-cache wrapper scientific paragraphs inspected, especially30,37,47-49; mechanism/clinical integration, cautious DMFS statement and TKI counts checked.'
    else: scope=scopes.get(orig,'Retained input; scope specified in report source audit. Not presumed full-read merely by retention.')
    scope = re.sub(r'(?<=[a-z])(?=\d)|(?<=\d)(?=[A-Za-z])', ' ', scope)
    scope = scope.replace('optionalRemiszewski', 'optional Remiszewski').replace('noTRD', 'no TRD').replace('fullXML', 'full XML').replace('nonsignificantOS', 'nonsignificant OS')
    x['review_scope']=scope

# Map already-transported source copies to canonical fixed cache identities.
for m in [x for x in records if Path(x['source']).name=='MANIFEST.json' and 'FP-final-review-source-copies' in x['source']]:
    source_map=json.loads(Path(m['retained_path']).read_text())['copies']
    for s in source_map:
        match=next(x for x in records if Path(x['source']).parent==Path(m['source']).parent and Path(x['source']).name==s['copy'])
        canonical=s['original_path'] if s['original_path'].startswith('literature/') else 'literature/'+s['original_path']
        match['retained_source_cache_commit']=s['source_commit']
        match['retained_source_cache_path']=canonical
        match['retained_source_cache_git_blob']=s['git_blob']
        assert match['sha256']==s['sha256'] and match['bytes']==s['bytes']
        data=Path(match['retained_path']).read_bytes()
        assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==s['git_blob']

support=[]
for p in sorted(list(r.glob('*.py'))+list((r/'reviewer-checks').glob('*'))):
    b=p.read_bytes()
    support.append(dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),kind='reviewer-created script/result; separate from author originals'))
out=dict(review='Single final scientific review of f44b75588fcd9666f8b96b71c2c88ebccb6095ac',
    snapshot_main_sha256='9a60911deedda62dee9b415ff92610842c3e72b686e03a79dc75a8879084db48',
    scope='Exact retained inputs and honest inspection scope; no network retrieval, producer execution or broad tests by reviewer.',
    retained_inputs=records,reviewer_created_support=support)
(r/'FINAL-REVIEW-MANIFEST.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
lines=['# Final review retained-input manifest','', 'Exact files used or retained for traceability, with actual inspection scope. Source paths and immutable blob identities are in the companion JSON. Retention alone is not a full-read claim.','', '| Retained path relative to review workspace | Bytes | SHA256 | Inspection scope |','|---|---:|---|---|']
for x in records:
    lines.append('| '+str(Path(x['retained_path']).relative_to(r)).replace('\\','/')+' | '+str(x['bytes'])+' | `'+x['sha256']+'` | '+x['review_scope'].replace('|','/')+' |')
lines+=['','## Reviewer-created scripts and original calculation evidence','','These are new review artifacts, not original study or author regeneration evidence.','','| Path | Bytes | SHA256 |','|---|---:|---|']
for x in support: lines.append('| '+str(Path(x['path']).relative_to(r)).replace('\\','/')+' | '+str(x['bytes'])+' | `'+x['sha256']+'` |')
(r/'FINAL-REVIEW-MANIFEST.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
print(json.dumps({'verified_retained_files':len(records),'reviewer_support_files':len(support),'manifest':'FINAL-REVIEW-MANIFEST.json'}))
