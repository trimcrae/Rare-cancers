"""Independent, bounded arithmetic on frozen reported counts, NOT a science producer.

No repository modules are imported. No source records are recreated. Conditional
calculations below test manuscript statements; they do not validate input provenance.
"""
from pathlib import Path
import json, math, hashlib

BASE=Path(__file__).resolve().parent
ART=BASE/'pinned/research/manuscripts/fusion-partner/emc-fusion-partner-pooling.json'
doc=json.loads(ART.read_bytes()); cohorts={c['id']:c for c in doc['cohorts']}
z=1.959963984540054
def wi(x,n):
    p=x/n; d=1+z*z/n
    mid=(p+z*z/(2*n))/d
    half=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/d
    return max(0,mid-half), min(1,mid+half)
def fisher(x,n,y,m):
    total_events=x+y; denominator=math.comb(n+m,total_events)
    prob=lambda k: math.comb(n,k)*math.comb(m,total_events-k)/denominator
    observed=prob(x)
    return sum(prob(k) for k in range(max(0,total_events-m), min(n,total_events)+1) if prob(k)<=observed*(1+1e-12))
def contrast(x,n,y,m):
    p=x/n;q=y/m;l,u=wi(x,n);v,w=wi(y,m)
    diff=p-q
    # Newcombe independent-proportions hybrid Wilson construction, no continuity correction.
    lower=diff-math.sqrt((p-l)**2+(w-q)**2)
    upper=diff+math.sqrt((u-p)**2+(q-v)**2)
    return dict(taf15=dict(events=x,denom=n,percent=100*p,wilson95_percent=[100*l,100*u]),comparator=dict(events=y,denom=m,percent=100*q,wilson95_percent=[100*v,100*w]),taf15_minus_comparator_pp=100*diff,newcombe95_pp=[100*lower,100*upper],fisher_two_sided=fisher(x,n,y,m))
out={'scope':'New reviewer arithmetic only on reported f44b counts; no data extraction validation or producer execution','input_sha256':hashlib.sha256(ART.read_bytes()).hexdigest()}
out['key_contrasts']={
    'pazopanib_assumed_evaluable':contrast(0,3,4,19),
    'sunitinib_secondary_reported':contrast(0,2,6,8),
    'two_TKI_cohorts_assumed_independent':contrast(0,5,10,27),
    'death':contrast(7,15,6,58),
    'local_recurrence':contrast(4,15,13,58),
    'metastasis_as_pooled':contrast(5,15,14,58),
    'pazopanib_one_TAF_unevaluable':contrast(0,2,4,20),
}
hi=wi(6,58)[1];point=6/58
out['zero_death_scenario_fixed_comparator']={
    'k_point_at_or_below_comparator_upper':next(k for k in range(100) if 7/(15+k)<=hi),
    'k_point_at_or_below_comparator_point':next(k for k in range(100) if 7/(15+k)<=point),
    'k_marginal_wilson_intervals_overlap':next(k for k in range(100) if wi(7,15+k)[0]<=hi),
    'k_fisher_two_sided_at_least_0_05':next(k for k in range(100) if fisher(7,15+k,6,58)>=.05),
    'added_7_zero_death_patients':contrast(7,22,6,58),
    'added_8_zero_death_patients':contrast(7,23,6,58),
    'qualification':'Illustrative arithmetic under frozen comparator/event assumptions, not falsification thresholds for prognostic biology; interval-overlap is not a test of the contrast.'
}
out['one_new_case_response']={'from_0_of_3':{'events':1,'denom':4,'percent':25.0},'from_0_of_5':{'events':1,'denom':6,'percent':100/6},'qualification':'New unique patient adds to numerator AND denominator; changing the outcome of an existing patient is a different scenario.'}
out['local_recurrence_comparator_spread']={'from_unrounded_counts_pp':100*(12/42-1/16),'one_decimal':round(100*(12/42-1/16),1),'stored_artifact_pp':doc['analyses']['B_outcome_by_partner']['local_recurrence']['heterogeneity_comparator_arm']['spread_percent']}
out['prevalence']={'assigned':154,'taf15_assigned':28,'taf15_wilson95_percent':[100*v for v in wi(28,154)],'full_reported_series_sizes':[26,58,17,67],'sum_full_reported_series_sizes':26+58+17+67,'assigned_residue':26+58+17+67-154,'recorded_n_tested_sum':sum(cohorts[k]['n_tested'] for k in ['agaram-2014-prevalence','huang-2023-prevalence','lenz-2023-prevalence','paioli-2021-prevalence'])}
out['checks_on_reported_integers']={}
for cohort in ['agaram-2014-outcome','huang-2023-outcome']:
    out['checks_on_reported_integers'][cohort]=cohorts[cohort]['strata']
print(json.dumps(out,indent=2,ensure_ascii=True))
