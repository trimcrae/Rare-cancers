"""Retain byte-exact original stdout/stderr and actual subprocess return code."""
from pathlib import Path
import subprocess, sys, json
r = Path(__file__).resolve().parent
dest = r/'reviewer-checks'
p = subprocess.run([sys.executable,str(r/'reviewer_agaram_followup.py')],capture_output=True)
(dest/'agaram-followup.stdout.json').write_bytes(p.stdout)
(dest/'agaram-followup.stderr.txt').write_bytes(p.stderr)
(dest/'agaram-followup.exit.json').write_text(json.dumps({'argv':[sys.executable,str(r/'reviewer_agaram_followup.py')],'returncode':p.returncode,'source':'actual subprocess returncode','execution_count':1},indent=2)+'\n',encoding='utf-8')
print(p.stdout.decode())
print('ACTUAL_EXIT='+str(p.returncode))
