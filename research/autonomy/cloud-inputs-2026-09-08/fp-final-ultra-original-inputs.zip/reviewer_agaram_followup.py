"""One small reviewer check on Table 1's published duration cells, not a producer.

Manual transcription from retained 7cf6e46c4c-emc_fusion_freq_agaram2014_pmc.txt:
EWSR1 cases 1-16, lines 210-429; TAF15 cases 17-23, lines 431-538.
This tests source-internal consistency only. No survival model or patient prediction.
"""
import json
ews = [88,56,96,11,46,41,25,5,95,4,2,55,66,62,7,34]
taf = [3,18,12,99,11,7,2]
print(json.dumps({
    "scope": "new reviewer arithmetic from manually read published table durations",
    "source_sha256": "2e023e8aeaba388b38a1cf4f8eb7bb31cc1f9f4464e7814bf13208683e618482",
    "EWSR1_table_case_order_1_to_16": ews,
    "EWSR1_table_mean_months": sum(ews)/len(ews),
    "EWSR1_source_prose_reported_mean_months_line_644": 43.3,
    "TAF15_table_case_order_17_to_23": taf,
    "TAF15_table_mean_months": sum(taf)/len(taf),
    "TAF15_source_prose_reported_mean_months_line_646": 21.7,
    "qualification": "Do not silently correct the article or treat a follow-up mean as censoring-adjusted exposure. State table/prose mismatch; retained flattened text may require inspection of an actual table rendering to resolve."
}, indent=2))
