# Final C2 item 5 and Integration3 mechanical intake

Retained pin **f6107376cc41344f2296f2ada46c064d8251a3f8**. The C2 correction changes **exactly one of 29,256 table cells**, and Integration3 carries the description-only assumption into the affected row. Integration3 preserves the 552-row spine and every A/B-side value, moves all 83 single-arm/multiple-results-group flags and eight evidence flags to unresolved registers, and retains **zero** genuine-contradiction entries. These are mechanical propagation findings, not source-level clinical adjudications or endpoint-paper clearance.

Three Integration3 output-manifest hashes and some summaries predate the final propagation. Actual final files match the f610 entrypoint identities. Historical failure records remain preserved.

## Paths and exact scope

`O = C:/Users/mcrae/.codex/review-workspaces/opus-capacity-sprint-20260907/capacity-campaign-20260908/observations`

`C = O/f6107376/C2-correction`; `C0 = O/8f1fe1c5/C2-correction`; `R = C/RESIDUAL-2026-09-08`

`I = O/f6107376/INTEGRATION3-endpoint-ledger`; `I2 = O/01dd5a21/INTEGRATION2-endpoint-ledger`

Read exact `O/f6107376/DELIVERABLE-ENTRYPOINTS.json`, Integration3 contract/change-map/count/input/output manifests, selected builder/checker/negative-control branches, all original ten run command/stream/exit records, final ledger/tension/genuine tables and the two retained I2 comparison tables. Hashed all 71 retained Integration3 files; large coverage/disposition and corrupted negative-control tables received **identity-only** retention, not clinical reading. Compared I2/I3 carried table fields and register keys/codes mechanically.

One bounded delegated comparison read C2's four derive/tests/schema/map files in the final, earlier and residual-BEFORE locations; residual applied/identity/hash/verifier records; all 12 new run files; and hash-only rechecked earlier RUN02's four files. Relevant code and fixture branches were read without importing them. Prior C2 items 1–4 were not reopened. No clinical source/cache/leaf audit, scientific review/calculation, producer/test/gate rerun, Git/network operation or shared-state mutation occurred.

`integration3-evidence.json` records exact per-file identities/scopes, row/field correspondence, current affected fields and complete extracted original commands/exits/failure summaries. This intake's own script performs hashing and retained-table comparisons only. It never imports the returned code.

## C2: exact final change and fixture

`C/CORRECTED-C-arm-attribution-v3-map.tsv:359` is the NCT02994953 Part B BOR / UC Cohort Stage 1 combination row. Its sole changed cell is `registry_type_statement_assumption`:

`ASSUMES_TWO_AGREEING_SOURCE_FIELD_MATCHES_ARE_ARM_IDENTITY_UNPROVED`

→ `ASSUMES_DESCRIPTION_FIELD_CORRESPONDENCE_IS_ARM_IDENTITY_UNPROVED`.

All other **29,255 cells** match C0 exactly: 552 rows, 53 columns, column/key order, all numeric and membership/binding fields, states, roles, flags and other text. The row retains `evaluable_n=15`, bound index **5**, `SOURCE_FIELD_MATCH`, `DESCRIPTION_FIELD_MATCH_ONLY:DESC_BYTE_EXACT`, role `NOT_ESTABLISHED_IN_THIS_CACHE`, empty comparator-role assumption. The relevant partition is **57 two-agreeing / 1 description-only / 132 label-only**. Eight comparator types remain inferred; no additional clinical support is claimed.

Final `decide_comparator` selects the assumption from the actual relation, distinguishing label-only, description-only and two-agreeing matches, with an explicitly unclassified fallback. Schema documentation follows those branches. All four `R/BEFORE/` files are byte-identical to their C0 counterparts.

Existing T5b in final `tests.py:256–279` now calls `decide_comparator`, directly checks the description-only assumption and rejects the two-agreeing token. Its ACTIVE_COMPARATOR fixture reaches the type-inference branch; the suite remains **21 tests**. **Limit:** its role-assumption equality assertion is conditional on that field being nonempty; it does not independently assert nonemptiness or the expected comparator role. The direct registry-assumption assertion does exercise the repaired defect.

| C2 artifact | Earlier bytes / SHA-256 | Final bytes / SHA-256 |
|---|---|---|
| `CORRECTED-C-arm-attribution-v3-derive.py` | 63,777 / `bbad2b85ded62e1cf23cba5deb2d8b819248ee171bc0c051c7b5977e1f0d8d33` | 66,642 / `0abb36c21e3529b4c600c30495d3e0bb60e07fb1021b9ab17377e03a6831de32` |
| `CORRECTED-C-arm-attribution-v3-tests.py` | 26,310 / `3796a11eef13a7c93d5b0c38bec327590926e5c167597fd4ebcf47c9c110b3d6` | 27,256 / `8f729a88f41f1762db08277bcda40f50d2a4fec22573e17b71dd2a5499aa6828` |
| `CORRECTED-C-arm-attribution-v3-schema.json` | 10,446 / `4045910289b403d981ecdccf8d4d25f21247e87d88da1b62a91a844a36a805b0` | 10,918 / `33234d5101c1f5550080be9b46fa65611cc42b3aab7514676a5cbb4dd893bf1e` |
| `CORRECTED-C-arm-attribution-v3-map.tsv` | 872,675 / `7dead1e07fc469a62501ba6b5bdbf0280fb0bdd9ca1331a845d32c2679bf14c7` | 872,673 / `626783a419697ee3e05741aa09558921b4b475f627aaf030a947eb953a4d0e0c` |

`R/APPLIED-RECORD-item5.md`: 6,728 B, SHA-256 `0357b1684dc67b71df57ce194107e369c576eda69cb6437c9260db7fc20a3da3`. `R/verify_item5.py`: 4,984 B, `405e455aa9a49c7e6e6739ab605322c3783ef86b20273eb56f0ad701511a614c`.

## Integration3: current propagation and unchanged record grains

Final row `NCT02994953|OM5|OG000` has the corrected description-only token in both `c_registry_type_statement_assumption` and the `AXIS_ARM_IDENTITY_ASSUMPTION:C_...` portion of `blocking_conditions`. `build_integration3.py:135–136,260` copies those from the C2 field; the current row matches that source. Its role remains `NOT_ESTABLISHED_IN_THIS_CACHE`, genuine contradiction and unresolved-tension cells both `NONE`.

The applied C2 record names the final RUN09/10 propagation and claims these two ledger fields changed. **No separate pre-RUN09 Integration3 ledger or exact final-step diff is retained in the inspected locators**, so a complete two-fields-only before/after claim cannot be independently established here. The current two values, exact C2 one-cell change and static copy branches are verified. The deliberately corrupted NEG-CONTROL ledger was not treated as an original before version.

Actual I2 → final I3 comparison:

- **552 unique keys identical**; 85 → 90 columns, five additions and no removals.
- **Zero A/B-side cell changes**. Changed shared columns are exactly those in the existing change map: `blocking_conditions` 552; `c_component` 552; `c_comparator_role_basis` 378; `c_arm_link_relation` 190; `c_registry_type_statement_assumption` 190; `contradictions_genuine` 91; `c_arm_link_state` 58; `c_disposition_vs_v1` 41; `c_comparator_role` 21; `c_registry_type_statement` 6; `cross_component_status` 5; `integration_state` 2.
- All 83 sole-arm/multiple-results-group row keys exactly match 83 MAPPING-tension row keys. All eight `(row key, contested flag)` entries exactly match the eight EVIDENCE-tension entries. No flag was thinned during reclassification.
- The 91 prior genuine-register row keys exactly equal the 91 current unresolved-register keys. Final genuine TSV retains its header and **zero rows**; all 552 ledger `contradictions_genuine` cells are `NONE`.
- Final census retains 458 B joins, 94 not assessed, 15,658 B-only, 16,116 B observations and 17,314 disposition rows. These are existing recorded counts; this intake did not rederive the B corpus. The 552-spine/A/B-field preservation was directly checked.

The builder's actual branches at :195–212 classify cardinality as an unresolved mapping issue and carry contested flags as evidence issues. The sole remaining genuine-contradiction branch at :213–216 compares A/B readings of the same denominator field and yields zero current entries. This is a component-reading disagreement predicate, not evidence of registry-internal inconsistency. No independent clinical mapping or new mutually exclusive source claims were established by this intake.

`CONTRADICTION-REDERIVATION3.tsv` preserves the nine old-code rows summing to 562 and explicitly marks former genuine labels withdrawn. Historical seven C-contested entries in that v1 rederivation remain distinct from the eight present v2/current flag entries. Neither is an independently validated clinical contradiction count.

## Original execution records, including failures

C2 new residual runs, all beneath `R/checks/`, have empty stderr:

| Directory | Exact command | Original result |
|---|---|---|
| `RUN-R01-tests-20260908T225544Z` | `python3 CORRECTED-C-arm-attribution-v3-tests.py` | Exit 0; 21/21 PASS |
| `RUN-R02-derive-20260908T225551Z` | `python3 CORRECTED-C-arm-attribution-v3-derive.py CORRECTED-C-arm-attribution-v3-map.tsv CORRECTED-C-arm-attribution-v3-checks.json` | Exit 0; 32/32 PASS |
| `RUN-R03-invariance-20260908T225629Z` | `python3 RESIDUAL-2026-09-08/verify_item5.py` | Exit 0; 13/13 PASS |

R01 stdout 1,801 B: `bd0fddc6e5a2f188c5e516d585f869f88325e2f706d530748d52066588845690`; R02 stdout 10,764 B: `45a83618d468018646ed429d57d627fc9169db264d5e99df74deb6ea9b805509`; R03 stdout 1,769 B: `4148902198b326065350a3f03ace80431d660c634de7f5bb6f0fc5044ed624d4`. R02 stdout is byte-identical to the earlier derivation summary; it does not itself expose the corrected 57/1 assumption split. The actual map does.

Earlier C2 RUN02 remains in C0 with **exit 1**, 20/21 PASS and the original T5a failure. Its stdout hash is unchanged (`2ed72ac2583f10bfadf09eb9122c68322ed8b46b09152a68f5e4b96b69fd3acc`), as is the `1\n` exit hash (`4355a46b19d348dc2f57c046f8ef63d4538ebb936000f3c9ee954a27460dd865`). No failed attempt appears among the three new residual directories.

Integration3 has **ten actual run directories** beneath `I/CHECK-RUNS/`:

| Run | Exact command form | Original exit/result |
|---|---|---|
| 01-build | `python3 build_integration3.py` | 0; census retains eight retired-token substrings |
| 02-build | same | 0; retired-token count becomes zero |
| 03-checks | `python3 check_integration3.py` | **1**; empty stdout, 531 B FileNotFoundError for old `LEDGER2-integrated-552.tsv` filename |
| 04-checks | same | **1**; 30 PASS / 1 FAIL, J9 counts C=0 using the old component label |
| 05-checks | same | 0; 31/31 PASS |
| 06-negcontrol | `python3 neg_control3.py && python3 check_integration3.py --dir NEG-CONTROL` | **1**; nine planted defects, 17 PASS / 14 FAIL |
| 07-settled-build | build command | 0 |
| 08-settled-checks | check command | 0; 31/31 PASS |
| 09-c2residual-build | build command | 0; final census has the 57/1 assumption split |
| 10-c2residual-checks | check command | 0; 31/31 PASS |

These are **four build executions, five direct check executions, and one recorded two-command negative-control sequence**, not one execution. Except RUN03's traceback, all stderr files are empty. The negative-control planting stdout is separate; the retained exit belongs to the compound command, not a standalone saved plant exit. Static negative-control code actually plants retired vocabulary (D7), removes a contested flag (D8), strips the arm-attribution block (D9), and promotes a mapping tension into genuine (D5); the original checker rejects the corrupted copy. This intake did not execute it.

Commands provide no exact cwd, runtime/environment or embedded source/output hashes. Separate identity records bind the retained files, but do not reconstruct per-attempt code snapshots. Saved check success remains limited to the checks' stated scope.

## Final identity and documentation limits for root

All inspected f610 entrypoint bytes/SHA/blob identities match. `I/SHA256-INTEGRATION3-OUTPUTS.txt` lists 18 hashes; **15 match and three are stale** after RUN09:

| File | Manifest SHA-256 | Actual final SHA-256 / bytes |
|---|---|---|
| `INPUT-MANIFEST3.json` | `b18e4aef38359a31e1396d8c14630123b4d78382c522f3db56d98ddc3704f46c` | `845ee852106d6435b1fb9efe1c37769838778f86e181c8de2ff35175a355c2a8` / 5,375 |
| `INTEGRATION3-CENSUS.json` | `6300961fad5b57fa2a3fcdcd894c5a75502a36aa9f9f7de60181cb94bf3b54bc` | `a213a472edfa66dca8036a85284e9699c9b08e60d52de21acaa30c0c9cfa5694` / 11,414 |
| `LEDGER3-integrated-552.tsv` | `d048335bede7104e86136458318db5420ede968be5929caaad2d496dfe29c4ce` | `098f855a3b5344ca4e8700241757fd3fa6f4302aefae15c29903035ed7fffd27` / 1,737,655 |

The final input manifest correctly names final C2 map/schema/report identities. Its unchanged earlier C2 checks/field-map/rowdelta/hash-list references remain historical retained inputs; their absence from this changed-file delta is not evidence that they were deleted. In particular the earlier rowdelta's “only substantive” classification still has its original comparison scope; it is not a new final-step field diff.

`CHECK-RUN-RECORD.txt` stops after RUN08 even though RUN09/10 are retained. `CHANGE-MAP-v2-to-v3.md` still describes all 58 as two-agreeing rather than 57 + 1 description-only; the builder comment :88–92 likewise names only the two-agreeing assumption. These are finite summary/identity propagation limits. Preserve old receipts as history and distinguish a final current binding; no scientific rerun or broad gate is needed to explain them. Root decides their disposition.

Endpoint PARKED status, original F1–F10 holds, unconfirmed job2/job3 provenance and the prohibition on derived clinical rates/subsets remain as recorded. Neither zero genuine contradictions nor 31 saved PASS checks is whole-paper scientific acceptance or current CI clearance.
