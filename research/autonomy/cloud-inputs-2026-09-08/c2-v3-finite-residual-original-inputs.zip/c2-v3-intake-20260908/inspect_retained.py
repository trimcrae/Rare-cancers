"""Mechanical file identities, text diffs and carried-table comparison. No imports of C2 code."""
import ast, collections, csv, difflib, hashlib, json, re
from pathlib import Path

OUT=Path(__file__).resolve().parent
OBS=Path('C:/Users/mcrae/.codex/review-workspaces/opus-capacity-sprint-20260907/capacity-campaign-20260908/observations')
V3=OBS/'8f1fe1c5/C2-correction'
V2=OBS/'d5eb86e8/CORRECTED-C-arm-attribution-v2'
manifest=(V3/'SHA256-v3-artifacts.txt').read_text(encoding='utf-8')
declared={name:sha for sha,name in re.findall(r'^([0-9a-f]{64})  (.+)$',manifest,re.M)}
identities=[]
for p in sorted(V3.rglob('*')):
    if not p.is_file(): continue
    b=p.read_bytes(); sha=hashlib.sha256(b).hexdigest()
    identities.append({'path':str(p),'relative_path':p.relative_to(V3).as_posix(),'bytes':len(b),'sha256':sha,'declared_sha256':declared.get(p.name),'declared_match':None if p.name not in declared else sha==declared[p.name]})
oldids=[]
changed_functions={}
for kind in ['derive.py','tests.py','map.tsv','checks.json','schema.json']:
    p=V2/('CORRECTED-C-arm-attribution-v2-'+kind); b=p.read_bytes()
    oldids.append({'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'declared_sha256':declared[p.name],'declared_match':hashlib.sha256(b).hexdigest()==declared[p.name]})
    if kind.endswith('.py'):
        p3=V3/('CORRECTED-C-arm-attribution-v3-'+kind)
        s2=b.decode('utf-8');s3=p3.read_text(encoding='utf-8')
        (OUT/('v2-to-v3-'+kind+'.diff')).write_text(''.join(difflib.unified_diff(s2.splitlines(True),s3.splitlines(True),str(p),str(p3))),encoding='utf-8')
        def funcs(s):
            return {n.name:(n.lineno,n.end_lineno,ast.dump(n,include_attributes=False)) for n in ast.parse(s).body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
        a,bf=funcs(s2),funcs(s3)
        changed_functions[kind]=[{'function':name,'v2_lines':a.get(name,())[:2],'v3_lines':bf.get(name,())[:2]} for name in sorted(a.keys()|bf.keys()) if a.get(name,(None,None,None))[2]!=bf.get(name,(None,None,None))[2]]
def table(p):
    with p.open(encoding='utf-8',newline='') as f:
        reader=csv.DictReader(f,delimiter='\t');rows=list(reader)
    return reader.fieldnames,rows
f2,r2=table(V2/'CORRECTED-C-arm-attribution-v2-map.tsv')
f3,r3=table(V3/'CORRECTED-C-arm-attribution-v3-map.tsv')
fd,rd=table(V3/'ROW-DELTA-v2-to-v3.tsv')
fm,rm=table(V3/'FIELD-MAP-v2-to-v3.tsv')
key=lambda r:(r['nct'],r['om_title'],r['group_title'])
a,b,d={key(r):r for r in r2},{key(r):r for r in r3},{key(r):r for r in rd}
columnmap={r['v2_column']:r['v3_column'] for r in rm if r['status'] in ['CARRIED','RENAMED']}
changed=collections.Counter(); delta_copy_mismatches=[]
for k in sorted(a.keys()&b.keys()&d.keys()):
    for old,new in columnmap.items():
        if a[k][old]!=b[k][new]: changed[old]+=1
    for col in fd:
        if col.startswith('v2_') and col[3:] in f2:
            expected=a[k][col[3:]]
        elif col.startswith('v3_') and col[3:] in f3:
            expected=b[k][col[3:]]
        else: continue
        if d[k][col]!=expected:delta_copy_mismatches.append({'key':k,'column':col,'recorded':d[k][col],'actual':expected})
numeric_cols=['evaluable_n','n_arms_registered','n_results_groups_in_om','n_candidate_arms','bound_arm_index']
numeric_changes=[{'key':k,'column':c,'before':a[k][c],'after':b[k][c]} for k in sorted(a.keys()&b.keys()) for c in numeric_cols if a[k][c]!=b[k][c]]
single=[{k:r[k] for k in ['nct','om_title','group_title','arm_link_state','arm_link_relation','bound_arm_index','registry_type_statement','registry_type_statement_assumption','comparator_role','comparator_role_identity_assumption']} for r in r3 if r['arm_link_relation'].startswith('DESCRIPTION_FIELD_MATCH_ONLY')]
newstats={col:{'nonempty':sum(bool(r[col]) for r in r3),'value_counts':dict(collections.Counter(r[col] for r in r3)) if len(set(r[col] for r in r3))<=10 else None} for col in f3 if col not in columnmap.values()}
summary={'scope':'Read/hash/static code and retained table correspondence only; no C2 code executed','v3_file_count':len(identities),'v3_total_bytes':sum(r['bytes'] for r in identities),'v3_declared_hashes_checked':sum(r['declared_match'] is not None for r in identities),'v3_hash_mismatches':[r for r in identities if r['declared_match'] is False],'v2_compared_hash_mismatches':[r for r in oldids if r['declared_match'] is False],'rows_v2_v3_delta':[len(r2),len(r3),len(rd)],'unique_keys_v2_v3_delta':[len(a),len(b),len(d)],'keysets_equal':a.keys()==b.keys()==d.keys(),'column_counts':[len(f2),len(f3)],'field_map_status_counts':dict(collections.Counter(r['status'] for r in rm)),'exact_carried_column_changed_row_counts':dict(changed),'numeric_field_changes':numeric_changes,'row_delta_copied_field_mismatches':delta_copy_mismatches,'row_delta_dispositions':dict(collections.Counter(r['row_disposition'] for r in rd)),'row_delta_substantive_column_counts':dict(collections.Counter(c for r in rd for c in r['substantively_changed_columns'].split(';') if c)),'row_delta_substantive_row_keys':[key(r) for r in rd if r['row_disposition']=='SUBSTANTIVE'],'state_counts':dict(collections.Counter(r['arm_link_state'] for r in r3)),'description_only_rows':single,'added_column_summary':newstats,'changed_function_locations':changed_functions}
(OUT/'mechanical-evidence.json').write_text(json.dumps({'summary':summary,'v3_identities':identities,'v2_compared_identities':oldids},indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(json.dumps(summary,indent=2,ensure_ascii=False))
