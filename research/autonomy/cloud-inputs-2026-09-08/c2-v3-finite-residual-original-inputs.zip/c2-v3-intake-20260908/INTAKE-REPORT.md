# C2 v3 bounded mechanical intake

The retained component contains **39 files, 1,330,916 bytes**. All **10 v3 hashes** declared in its manifest match the actual files; the five retained v2 files used for comparison also match their declared hashes. The admitted count, downgrade, zero-arm and excerpt/scope repairs are implemented in the inspected branches. **Item 5 retains one material assumption-label defect and associated documentation propagation:** the sole description-only match is labeled as assuming two agreeing field matches. This is not a clinical adjudication or Integration3 intake.

## Exact read scope and identities

Absolute roots:

- `C = C:/Users/mcrae/.codex/review-workspaces/opus-capacity-sprint-20260907/capacity-campaign-20260908/observations/8f1fe1c5/C2-correction`
- `P = C:/Users/mcrae/.codex/review-workspaces/opus-capacity-sprint-20260907/capacity-campaign-20260908/observations/d5eb86e8/CORRECTED-C-arm-attribution-v2`
- `W = C:/Users/mcrae/Documents/Codex/2026-09-07/emc-research-orchestrator/work`

Read the complete `W/C2-Integration2-and-PAB2-root-adjudication-20260908.md`, v3 manifest/schema/checks/field map/delta script, relevant live derive branches and fixture bodies, and all seven original command/stdout/stderr/exit sets plus their wrapper. Compared actual retained v2/v3 derive and test text without importing it; compared both maps and the delivered rowdelta as tables, without rederiving rows. The 16,960 B author report received identity verification here; root separately read it in full. No source cache/leaf clinical audit, source retrieval, producer, tests, scientific calculation, Git command, Integration3 inspection or shared-state mutation occurred.

`mechanical-evidence.json` records all 39 actual file identities and the five compared v2 identities, complete changed-function locations, row/field correspondence results and the sole description-only row. The two saved `.diff` files are local text comparisons of the retained derive/tests, not source edits or an applied patch.

| Actual component artifact | Bytes | SHA-256 |
|---|---:|---|
| `C/SHA256-v3-artifacts.txt` | 3,246 | `329cad55e51afe05c80c4477d93d511b008539f7180cafdf0b699dfced5c1bf5` |
| `C/CORRECTED-C-arm-attribution-v3-derive.py` | 63,777 | `bbad2b85ded62e1cf23cba5deb2d8b819248ee171bc0c051c7b5977e1f0d8d33` |
| `C/CORRECTED-C-arm-attribution-v3-tests.py` | 26,310 | `3796a11eef13a7c93d5b0c38bec327590926e5c167597fd4ebcf47c9c110b3d6` |
| `C/CORRECTED-C-arm-attribution-v3-map.tsv` | 872,675 | `7dead1e07fc469a62501ba6b5bdbf0280fb0bdd9ca1331a845d32c2679bf14c7` |
| `C/CORRECTED-C-arm-attribution-v3-checks.json` | 10,763 | `5dcb1e96760dc1444f60c924f30dd34da27535789e02a9013d176bd4601c159f` |
| `C/CORRECTED-C-arm-attribution-v3-schema.json` | 10,446 | `4045910289b403d981ecdccf8d4d25f21247e87d88da1b62a91a844a36a805b0` |
| `C/C2-v2-to-v3-delta.py` | 6,899 | `741cf8cfeb513254cf6c138d3d48ee79e0303cdbca5f63d24a7246cece38ef4b` |
| `C/FIELD-MAP-v2-to-v3.tsv` | 2,657 | `f75641ff344d11e116345fa90da8497a98f2a32acb19237e4bc1e7acef4eac38` |
| `C/ROW-DELTA-v2-to-v3.tsv` | 286,704 | `8ec36387af41ffc1121c55e1dd99c325a9d155e99cf32c4d4c1629f54d52aba3` |
| `C/C2-CORRECTION-REPORT.md` | 16,960 | `d5bfe32bc43ee37743a5e859b6185159182cd796e4b00d082af0de4df1c9614c` |

The source hash manifest does not itself hash the 28 run files; this intake's inventory does. Its v1 and additional v2 preservation assertions are not expanded into another historical audit.

## Five admitted corrections: actual code and evidence

Locations below refer to `C/CORRECTED-C-arm-attribution-v3-derive.py` unless otherwise stated.

1. **Complement implemented.** `partition_counts`, :598–616, computes total minus the explicitly named state, with a separately computed other-state partition. Summary fields :968–977 are operationally named and retain 362 as the withdrawn four-state subset. Actual table states are 58 `SOURCE_FIELD_MATCH`, 132 `LABEL_MATCH`, 337 `PROPOSED`, 11 `UNRESOLVED`, 13 `UNKNOWN_IN_THIS_CACHE`, 1 `CONTESTED`: **58 + 494 = 552**. Fixture T6 (:328–349 in tests) also checks a different state name and the empty case; it is not solely a literal 552-count assertion. No row-state promotion occurred beyond the admitted vocabulary renaming.

2. **Contrary-description binding cleared.** :406–424 preserves candidate index/count, old relation and exact field locator, stores the contrary description as an explicitly named excerpt, sets `bound_arm_index=""`, and preserves any former leaf agreement/disagreement in its separate pre-downgrade field. `decide_comparator` no longer reads a registered type through that cleared binding; contested link becomes contested role while any all-arms type statement retains its separate membership condition. Existing T2a :75–104 checks binding, candidate, evidence, both locators and comparator propagation; T2e :288–300 checks preserved leaf-verdict history. **Zero delivered rows exercise this downgrade**, so the saved fixtures, not current-row counts, support this edge branch.

3. **Zero-arm precedence implemented.** `decide_link` :300–307 returns unknown first; registry statement :468–471 and comparator role :493–498 handle zero arms before text proposals. Comparator wording remains in `group_text_comparator_wording_unverified` (:448–457), with no assertion that absence of registration means no comparator existed. T2f :303–325 covers placebo wording and a treatment-sequence/control example. The six delivered zero-arm rows were already unknown; their registry statement receives the explicit `UNKNOWN_` prefix. Recorded delivery has zero zero-arm rows carrying comparator wording, so that particular edge shape is fixture-only.

4. **Excerpt representation and ten-file scope implemented.** :560–581 names newline replacement, 400-character clipping, TSV normalization and the original leaf locator; the table renames both leaf narrative and group-description columns and adds transform/original-length metadata. The ten entries are five BOR eras plus five placebo eras, and the saved check correctly describes that scope (:853–867). The 367 delivered leaf excerpts have zero `YES` cap flags. This intake does not reopen the ten source payloads or claim an independently checked twelve-file absence.

5. **Most machine vocabulary repaired; one remaining mismatch.** :327–340 distinguishes `TWO_AGREEING_FIELD_MATCHES` from `DESCRIPTION_FIELD_MATCH_ONLY`; :462–465 adds unproved identity assumptions; :500–505 labels comparator types as inferred and expressly disclaims independent clinical validation. Every row says explicit source-join verification is not established. The eight inferred comparator rows and 132 label-only rows remain separate strengths. However, :462–465 selects `ASSUMES_TWO_AGREEING_SOURCE_FIELD_MATCHES_ARE_ARM_IDENTITY_UNPROVED` for **every** linked `SOURCE_FIELD_MATCH`, including the description-only branch. That exact mismatch exists in the delivered table below.

## One finite remaining item-5 propagation issue

Actual map key:

- `nct`: `NCT02994953`
- `om_title`: `Part B: Number of Participants With Confirmed Best Overall Response (BOR) Assessed by Investigator Using Response Evaluation Criteria in Solid Tumors (RECIST) Version 1.1`
- `group_title`: `Part B Cohort 1: UC Cohort Stage 1 Combination Therapy (Experimental)`

Its actual `arm_link_relation` is `DESCRIPTION_FIELD_MATCH_ONLY:DESC_BYTE_EXACT`, bound index **5**, but `registry_type_statement_assumption` says **TWO_AGREEING_SOURCE_FIELD_MATCHES**. Its type is `BOUND_ARM_REGISTERED_TYPE_IS_EXPERIMENTAL` and role is `NOT_ESTABLISHED_IN_THIS_CACHE`; the comparator-role assumption is empty. This is one description-only row versus 57 two-field rows, not a change to the eight inferred-comparator count.

The finite correction is to name the unproved identity assumption according to the actual relation, preserving states, candidates, bindings and numeric values, and propagate the wording to the schema/current summaries. It should include the same stale documentation: derive docstring :84–88 and comment :327 still say independent exact fields; :334 calls the description-only relation an explicit within-record identity. Tests T5b :256–264 checks the description-only link/path but never calls `decide_comparator`, so it cannot detect the wrong assumption. Its comment/test name also retains stronger identity/confirmation wording. The schema lists only TWO_AGREEING and LABEL assumption alternatives and its `contested_flags` description retains the old `LABEL_AND_DESCRIPTION_SOURCE_IDENTITIES_NAME_DIFFERENT_ARMS` token while code emits `LABEL_AND_DESCRIPTION_FIELD_MATCHES_NAME_DIFFERENT_ARMS`.

These are one coherent relation/assumption/documentation propagation issue within admitted item 5. No new clinical source adjudication, count quota or broad gate follows from it.

## Actual row and field changes

Both retained maps and the delivered rowdelta have **552 unique keys**, with identical key sets. The field map correctly describes **39 → 53 columns: 37 carried, 2 renamed, 14 added, none removed**. All rowdelta copied before/after fields agree with the actual maps.

Across every carried/renamed column, exact changed-row counts are:

| Field | Changed rows |
|---|---:|
| `arm_link_relation` | 190 |
| `registry_type_statement_assumption` | 190 |
| `arm_link_state` | 58 |
| `comparator_role_basis` | 378 |
| `registry_type_statement` | 6 |
| `disposition_vs_v1` | 41 |
| `comparator_role` | 21 |

All other carried/renamed values match exactly. The five numeric/index columns `evaluable_n`, `n_arms_registered`, `n_results_groups_in_om`, `n_candidate_arms`, and `bound_arm_index` have **zero changes**. No rate, patient-total interpretation or clinical comparison was calculated.

The author's rowdelta labels 336 rows IDENTICAL, 158 VOCABULARY_ONLY and 58 SUBSTANTIVE; the last category is the new identity-assumption string replacing an empty field on the 58 source-field matches. **These labels are limited to the compared carried columns:** the script excludes `arm_link_source_locator` and `comparator_role_basis` and does not classify the 14 added columns. Its “only substantive change” wording must not be read as a complete field-level diff. This intake's all-carried-column comparison additionally records the 378 changed comparator-basis strings; the other excluded column is unchanged.

Added fields carry 21 comparator identity assumptions, 20 unverified group-wording entries, 552 source-join-not-established values, 367 leaf transform/length/cap records and 552 group-description transform/length records. The new downgrade/candidate/prior-verdict fields are empty on every delivered row. These are descriptive counts of retained table cells, not new source judgments.

## Original seven command records, with RUN02 preserved

All seven `cmd.txt` files name cwd `/home/user/Rare-cancers/research/autonomy/opus-capacity-campaign-20260908/paper-lane/C2-correction`. Exact command forms are:

- Derive: `python3 CORRECTED-C-arm-attribution-v3-derive.py CORRECTED-C-arm-attribution-v3-map.tsv CORRECTED-C-arm-attribution-v3-checks.json`
- Tests: `python3 CORRECTED-C-arm-attribution-v3-tests.py`
- Delta: `python3 C2-v2-to-v3-delta.py`

| Saved run under `C/CHECKS-RUNS/` | Command | Exit | Original result |
|---|---|---:|---|
| `RUN-01-derive-20260908T220048Z` | Derive | 0 | 32 recorded PASS checks; 552 rows |
| `RUN-02-tests-20260908T220237Z` | Tests | **1** | 21 tests; 20 PASS, 1 not-PASS |
| `RUN-03-tests-20260908T220248Z` | Tests | 0 | 21/21 PASS |
| `RUN-04-delta-20260908T220413Z` | Delta | 0 | Retained 552-row delta summary |
| `RUN-05-settled-derive-20260908T220427Z` | Derive | 0 | 32 recorded PASS checks; 552 rows |
| `RUN-06-settled-tests-20260908T220430Z` | Tests | 0 | 21/21 PASS |
| `RUN-07-settled-delta-20260908T220430Z` | Delta | 0 | Retained 552-row delta summary |

There were **two actual derivation runs, three fixture runs and two delta runs**, within the settled batch. RUN01/05, RUN03/06 and RUN04/07 have byte-identical four-file record contents apart from directory names. They remain separate retained attempts, not additional distinct checks. Every stderr is empty; each command-record exit agrees with its separate exit file.

RUN02's sole failure is `T5a_exact_source_backed_supported_relation_stays_recorded`, with tuple `('PLACEBO_COMPARATOR', 'ASSUMES_TWO_AGREEING_SOURCE_FIELD_MATCHES_ARE_ARM_IDENTITY_UNPROVED')`. Current T5a explicitly asserts the named assumption (:250–252), consistent with the later passing record. **The original failed-attempt executable is not hash-bound by the run records**, so those records do not independently identify the precise between-attempt edit. No failure has been rewritten as a pass.

Important original hashes:

- RUN02 stdout: 1,878 B, `2ed72ac2583f10bfadf09eb9122c68322ed8b46b09152a68f5e4b96b69fd3acc`.
- RUN02 exit (`1\n`): 2 B, `4355a46b19d348dc2f57c046f8ef63d4538ebb936000f3c9ee954a27460dd865`.
- RUN01/05 stdout: 10,764 B, `45a83618d468018646ed429d57d627fc9169db264d5e99df74deb6ea9b805509`.
- RUN03/06 stdout: 1,780 B, `b2d2487574b00353f43febe275afbddce28083544e4f1ff42943b459635d9ac6`.
- RUN04/07 stdout: 805 B, `dbefa0c0e189ab176f24a259d0183f7e741b0dfe2fa51007c773341ccfff9a5a`.

The wrapper directly captures stdout/stderr and `$?`; it does not mask a failure through a pipe. Its flattened `$*` command string loses general argument-boundary information, although these particular invocations use simple filenames. It records no executable/input/output hashes, runtime/environment or internal start/end timestamps. Artifact hashes are a separate manifest. Saved green checks establish their stated scopes and do not close the observed one-row assumption mismatch or any endpoint-paper finding.

The delegated read-only receipt parser initially rejected JSON empty-string keys under PowerShell and succeeded with `-AsHashtable`; the invalid first parse was not a producer result. The local intake script only reads, hashes, parses static ASTs and compares already-retained table cells. It neither imports nor runs any C2 producer or test. Root retains scientific acceptance and propagation ownership; Integration3 is outside this snapshot and report.
