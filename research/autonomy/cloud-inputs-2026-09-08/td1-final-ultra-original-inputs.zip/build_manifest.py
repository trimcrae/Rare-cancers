"""Bookkeeping only: verify retained bytes and document actual reading scope."""
from pathlib import Path
import hashlib,json
B=Path(__file__).resolve().parent
records=json.loads((B/'retained-inputs.json').read_text(encoding='utf-8'))
scopes={
'emc-transcriptional-proteostatic-dependency.md':'Entire frozen manuscript, all 283 lines, read for scientific sufficiency.',
'emc-expression-panels.json':'Both full selected panels (transcriptional_cdk, chaperone_dependency), their repeated read summaries, all14 group/platform summaries, relevant per-gene/group memberships, platform type and complete sample annotation/classification lists, mapping limits and relevant proliferation controls read. One nr2f1_dormancy score (t11.017) inspected solely to check the live largest-t claim. Other large gene sets/raw-like per-sample value arrays not independently reanalyzed; retention is not full13MB semantic audit.',
'census-route-expression-grading.json':'Full RT-TXN-CDK and RT-CHAPERONE records, gene and group summaries, live conclusion fields, and supporting definitions inspected; unrelated routes not independently reviewed.',
'depmap-sarcoma-dependency.json':'Principal definitions/data-source/count fields; complete BET/transcriptional and chaperone records; contextual genes and control/subtype structure inspected. Main five genes compared with manuscript; unrelated target biology not independently audited.',
'fet-ddr-axis-scan.json':'Header/release/screened-count and emc_line record directly read; no full DDR biological review.',
'hemcss-label-priorart.json':'Identity-vs-disease framing, established findings and explicit suggestive-not-definitive limitation read. Not a fresh authentication, source-census or fusion-caller audit.',
'txn-dependency-class-definitions-2026-08-09.json':'Entire retained citation/class-definition record read. Initial source-payload local absence recorded separately; metadata/extraction is not represented as a primary fulltext.',
'fet-fusion-chaperone-clientship-2026-08-27.json':'Entire scientific record read: definitions, retrieval scope, all10 evidence records, all15 query entries, verdicts and unresolved questions. Not independent screening of unavailable query hits or supplements.',
'OPERATING_PROTOCOL.md':'Review-with-endpoint section44-72 read; headings inspected for relevant scope. User standing scientific scope governs this review.',
'emc_expression_panels.py':'Imports and target/platform selection; panel definitions602-647, parsing/reduction1402-1485, group selection1647-1654, z-score1657-1665, gene-list scoring1981-2016, output framing/limits and relevant control references inspected. No execution and no audit of unrelated producers/panels.',
'depmap_sarcoma_dependency.py':'Data-source/threshold/discovery and main lineage selection/missingness/statistics210-265, relevant gene groups, subtype/control logic and output definitions inspected. No network function or producer executed.',
'census_route_expression_grading.py':'Relevant RT-TXN-CDK and RT-CHAPERONE generating definitions/conclusions at393 onward inspected. Unrelated routes outside scientific review.',
'emc_atr_vulnerability.py':'Imported dependency declarations, parser876-919 and sample classifier1608-1628 read; reference-pool mentions and scoring provenance inspected. No raw ATR analysis or producer run.',
'fet_ddr_axis_scan.py':'Imported Welch implementation160-180 directly read; contextual header/definitions inspected. No DDR analysis/producer run.',
'FREEZE-for-final-review.md':'Entire handoff read and main/dependency hash assertions checked; author conclusions assessed independently.',
'HASHES.sha256':'Entire author frozen hash inventory read; used for precise dependency/check retention, not scientific acceptance.',
'ORIGINAL-CHILD-TRANSCRIPT-a3ea9067b5836bf10.jsonl':'Final report at line95: full scientific D1-D14/quantity table, nine proposed edits, caveats and stop condition read; selected source tool-output context inspected. Raw transcript preserved; environment dumps not reproduced as scientific evidence.',
'DIFF-TD1-scope-repair.patch':'Retained exact author provenance; scope withdrawals compared with current full main/handoff, not independently reviewed as an alternate candidate.',
'00-start-state.txt':'Entire original start-state record read.',
'01-preflight-default.txt':'Original retained in full; failure summaries, relevant lines1265-1303 and final section/exit inspected. No claim to full scientific audit of unrelated 486KB gate output.',
'02-baseline-producers-without-TD1-edit.txt':'Entire original captured check summary read; only selected stdout/line counts captured by author, not full original producer stdout.',
'03-producers-after-TD1-edit.txt':'Entire original captured check summary read; digest and actual exits checked, noting different digest from final freeze.',
'04-lint_asymmetry.txt':'Entire original usage error and EXIT2 read.',
'04-lint_citations.txt':'Entire original usage error and EXIT2 read.',
'04-lint_consistency.txt':'Entire original usage error and EXIT2 read.',
'04-lint_claims.txt':'Entire original outcome/EXIT0 read.',
'04-lint_changed_prose.txt':'Entire original outcome/EXIT0 and zero changed passages read.',
'04-lint_style.txt':'Final error count/EXIT1 and representative findings read; full log retained without treating stylistic defects as scientific blockers.',
'05-lint_consistency-repo.txt':'Entire original correct-invocation outcome/EXIT0 read.',
'06-lint_readability.txt':'Final advisory findings and EXIT0 read; full log retained.',
'07-lint_style-before-after.txt':'Entire original rule-count/claimed-status comparison read; discrepancy with actual preflight noted.'
}
extra=json.loads((B/'extra-source-scopes.json').read_text(encoding='utf-8')) if (B/'extra-source-scopes.json').exists() else {}
for rec in records:
    p=Path(rec['retained_path']); data=p.read_bytes()
    assert len(data)==rec['bytes'] and hashlib.sha256(data).hexdigest()==rec['sha256'],str(p)
    if rec.get('git_blob'):
        assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==rec['git_blob'],str(p)
    if p.name=='SKILL.md': scope='Entire paper-hardening or repo-gates skill read; finite scientific review used; no new publication gate run.'
    else: scope=extra.get(rec['source'],scopes.get(p.name))
    if scope is None: raise RuntimeError('Missing honest scope for '+str(p))
    rec['review_scope']=scope
support=[]
paths=list(B.glob('*.py'))+list((B/'reviewer-checks').glob('*'))+list((B/'source-access-records').glob('*'))
paths += [p for p in [B/'SOURCE-BYTE-VERIFICATION.json',B/'extra-source-scopes.json'] if p.exists()]
for p in sorted(paths):
    if not p.is_file(): continue
    data=p.read_bytes()
    support.append(dict(path=str(p),bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),kind='reviewer-created support or exact original reviewer-run stream'))
obj=dict(review='One final whole-paper TD1 scientific review',freeze='9f571e8170fb81dbe4d78515981ccb57c7a78b3e',main_sha256='fe316b44d44b7f16cbb62ea7451dd4c3acff1a8cc2edc0dd73932e98649c9398',retained_inputs=records,reviewer_support_files=support,scope='No producer, raw biological reanalysis, broad tests or new source acquisition. Main fully read; dependency/source scopes are explicit per record.')
(B/'FINAL-REVIEW-MANIFEST.json').write_text(json.dumps(obj,indent=2)+'\n',encoding='utf-8')
lines=['# TD1 final-review retained-file manifest','',f'Freeze `{obj["freeze"]}`. {len(records)} exact retained inputs; {len(support)} reviewer support files. SHA256/bytes verified. See JSON for original Git blob identities and absolute retained paths.','']
for r in records:
    lines += ['## '+Path(r['retained_path']).name,'','Original: `'+r['source']+'`','',f'Retained: `{r["retained_path"]}`','',f'Bytes: {r["bytes"]}; SHA256 `{r["sha256"]}`.','',r['review_scope'],'']
lines+=['## Reviewer support files','','| File | Bytes | SHA256 |','|---|---:|---|']
for r in support: lines.append(f'| `{Path(r["path"]).relative_to(B)}` | {r["bytes"]} | `{r["sha256"]}` |')
(B/'FINAL-REVIEW-MANIFEST.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
print(json.dumps(dict(retained_inputs=len(records),reviewer_support_files=len(support),verified=True)))
