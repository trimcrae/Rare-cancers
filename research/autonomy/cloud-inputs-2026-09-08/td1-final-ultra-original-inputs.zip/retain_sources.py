"""Read exact pre-existing local cache objects with lazy fetching disabled; never fetch."""
from pathlib import Path
import subprocess, json, hashlib, os
BASE=Path(__file__).resolve().parent
REPO='C:/Projects/EMC-Research'
PIN='216bd1b5fb25a56b90ef3cc2373e1fe68322708f'
ENV=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_TERMINAL_PROMPT='0')
paths=['literature/txn-dependency-class-definitions-2026-08-09/'+x for x in ['epmc_cdk7_transcriptional.txt','epmc_hsf1_heat_shock_cancer.txt','epmc_hsp90_client.txt','epmc_transcriptional_addiction.txt']]
ledger=BASE/'retained-inputs.json'
records=json.loads(ledger.read_text())
attempts=[]
for path in paths:
    spec=PIN+':'+path
    proc=subprocess.run(['git','-C',REPO,'show',spec],capture_output=True,env=ENV)
    dest=BASE/'source-access-records'/Path(path).name
    dest.parent.mkdir(exist_ok=True)
    dest.with_suffix('.stderr.txt').write_bytes(proc.stderr)
    if proc.returncode==0:
        target=BASE/'sources'/path
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(proc.stdout)
        blob=hashlib.sha1(b'blob '+str(len(proc.stdout)).encode()+b'\0'+proc.stdout).hexdigest()
        row=dict(source=spec,retained_path=str(target),kind='cache-git',git_blob=blob,bytes=len(proc.stdout),sha256=hashlib.sha256(proc.stdout).hexdigest(),review_scope='retained; scope to be finalized')
        records=[r for r in records if r['source']!=spec]+[row]
    else:
        dest.with_suffix('.stdout.txt').write_bytes(proc.stdout)
    attempts.append(dict(source=spec,returncode=proc.returncode,stdout_bytes=len(proc.stdout),stderr_bytes=len(proc.stderr)))
ledger.write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8')
(BASE/'source-access-records/ATTEMPTS.json').write_text(json.dumps(attempts,indent=2)+'\n')
print(json.dumps(attempts,indent=2))
