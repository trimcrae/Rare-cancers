"""Read-only projection of retained JSON, without running a scientific producer."""
import json, sys
from pathlib import Path
p=Path(sys.argv[1]); obj=json.loads(p.read_text(encoding='utf-8-sig'))
if len(sys.argv)==2:
    print(json.dumps(list(obj) if isinstance(obj,dict) else {'length':len(obj)},indent=2))
for selector in sys.argv[2:]:
    cur=obj
    for key in selector.split('/'):
        cur=cur[int(key)] if isinstance(cur,list) else cur[key]
    print(selector+':')
    print(json.dumps(cur,indent=2,ensure_ascii=True))
