"""Capture the one reviewer arithmetic run without replacing a failed stream."""
from pathlib import Path
import subprocess,sys,json,datetime
B=Path(__file__).resolve().parent
D=B/'reviewer-checks';D.mkdir(exist_ok=True)
for suffix in ['stdout.json','stderr.txt','exit.json']:
    if (D/('summary-arithmetic-attempt2.'+suffix)).exists(): raise RuntimeError('Original run already exists; do not overwrite')
argv=[sys.executable,str(B/'reviewer_checks_v2.py')]
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
p=subprocess.run(argv,capture_output=True)
(D/'summary-arithmetic-attempt2.stdout.json').write_bytes(p.stdout)
(D/'summary-arithmetic-attempt2.stderr.txt').write_bytes(p.stderr)
(D/'summary-arithmetic-attempt2.exit.json').write_text(json.dumps(dict(argv=argv,start_utc=start,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),returncode=p.returncode,stdout_bytes=len(p.stdout),stderr_bytes=len(p.stderr)),indent=2)+'\n')
print('Reviewer arithmetic EXIT='+str(p.returncode))
sys.exit(p.returncode)

