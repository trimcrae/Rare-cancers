"""Verify exact locally supplied source-copy identities; no Git/network calls."""
from pathlib import Path
import hashlib,json
B=Path(__file__).resolve().parent
ledger=B/'retained-inputs.json'; records=json.loads(ledger.read_text(encoding='utf-8'))
mp=B/'provenance-originals/fd79244825-MANIFEST.json'
m=json.loads(mp.read_text(encoding='utf-8'))
scopes={}
for r in records:
    if Path(r['retained_path'])==mp: scopes[r['source']]='Entire original four-source transport manifest read, including scoped absence of optional source filenames. Counts/hashes/Git identities verified locally from actual bytes; transport is not a source fetch.'
descriptions={
'epmc_cdk7_transcriptional.txt':'Actual retained Europe PMC JSON body at line6, resultList.result[0] (PMID25043025) title/publication types/DOI and full abstract read. Other query hits were not independently reviewed; payload is abstract metadata, not a full article.',
'epmc_hsf1_heat_shock_cancer.txt':'Actual retained Europe PMC JSON body at line6, resultList.result[1] (PMID22863008) title/publication types/DOI and full abstract read. Other query hits not independently reviewed; not a full article.',
'epmc_hsp90_client.txt':'Actual retained Europe PMC JSON body at line6, resultList.result[0] (PMID28429788, review) and [2] (PMID9108479, primary article), titles/types/DOIs and full abstracts read. Other query hits not independently reviewed; not full articles.',
'epmc_transcriptional_addiction.txt':'Actual retained Europe PMC JSON body at line6, resultList.result[0] (PMID28187285, review) and [1] (PMID26406377, primary article), titles/types/DOIs and full abstracts read. Other query hits not independently reviewed; not full articles.'}
checks=[]
for item in m['copies']:
    matches=[r for r in records if Path(r['source']).name==Path(item['original_path']).name]
    assert len(matches)==1,item
    r=matches[0];p=Path(r['retained_path']);data=p.read_bytes()
    size=len(data);sha=hashlib.sha256(data).hexdigest();blob=hashlib.sha1(b'blob '+str(size).encode()+b'\0'+data).hexdigest()
    assert (size,sha,blob)==(item['bytes'],item['sha256'],item['git_blob'])
    r['cache_source_commit']=item['source_commit'];r['cache_original_path']=item['original_path'];r['git_blob']=blob
    scopes[r['source']]=descriptions[Path(item['original_path']).name]
    checks.append(dict(retained_path=str(p),bytes=size,sha256=sha,git_blob=blob,verified=True))
ledger.write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8')
(B/'extra-source-scopes.json').write_text(json.dumps(scopes,indent=2)+'\n',encoding='utf-8')
(B/'SOURCE-BYTE-VERIFICATION.json').write_text(json.dumps(dict(method='Hash exact supplied local bytes; no retrieval, Git read or source reconstruction',copies=checks),indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(verified=len(checks),bytes=sum(r['bytes'] for r in checks))))
