# TD1 final-review retained-file manifest

Freeze `9f571e8170fb81dbe4d78515981ccb57c7a78b3e`. 38 exact retained inputs; 29 reviewer support files. SHA256/bytes verified. See JSON for original Git blob identities and absolute retained paths.

## emc-transcriptional-proteostatic-dependency.md

Original: `9f571e8170fb81dbe4d78515981ccb57c7a78b3e:research/manuscripts/dependency/emc-transcriptional-proteostatic-dependency.md`

Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\td1-final-review-20260908\pinned\research\manuscripts\dependency\emc-transcriptional-proteostatic-dependency.md`

Bytes: 20924; SHA256 `fe316b44d44b7f16cbb62ea7451dd4c3acff1a8cc2edc0dd73932e98649c9398`.

Entire frozen manuscript, all 283 lines, read for scientific sufficiency.

## emc-expression-panels.json

Original: `9f571e8170fb81dbe4d78515981ccb57c7a78b3e:research/modalities/emc-expression-panels.json`

Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\td1-final-review-20260908\pinned\research\modalities\emc-expression-panels.json`

Bytes: 13253561; SHA256 `123bd05a9f9f5d08a362df3bd51cdbb72c241b49712123aaf5c5ea914f336bd9`.

Both full selected panels (transcriptional_cdk, chaperone_dependency), their repeated read summaries, all14 group/platform summaries, relevant per-gene/group memberships, platform type and complete sample annotation/classification lists, mapping limits and relevant proliferation controls read. One nr2f1_dormancy score (t11.017) inspected solely to check the live largest-t claim. Other large gene sets/raw-like per-sample value arrays not independently reanalyzed; retention is not full13MB semantic audit.

## census-route-expression-grading.json

Original: `9f571e8170fb81dbe4d78515981ccb57c7a78b3e:research/modalities/census-route-expression-grading.json`

Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\td1-final-review-20260908\pinned\research\modalities\census-route-expression-grading.json`

Bytes: 92757; SHA256 `5bc3c80c034dde7781394554aa3bc18888248ad4cf1aa0153e4c7e4d5e4f07a8`.

Full RT-TXN-CDK and RT-CHAPERONE records, gene and group summaries, live conclusion fields, and supporting definitions inspected; unrelated routes not independently reviewed.

## depmap-sarcoma-dependency.json

Original: `9f571e8170fb81dbe4d78515981ccb57c7a78b3e:research/modalities/depmap-sarcoma-dependency.json`

Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\td1-final-review-20260908\pinned\research\modalities\depmap-sarcoma-dependency.json`

Bytes: 19605; SHA256 `d88bed62a80dcb51675f0f7a5a27771a6c1f732e977200d39fa389cb8dd27546`.

Principal definitions/data-source/count fields; complete BET/transcriptional and chaperone records; contextual genes and control/subtype structure inspected. Main five genes compared with manuscript; unrelated target biology not independently audited.

## fet-ddr-axis-scan.json

Original: `9f571e8170fb81dbe4d78515981ccb57c7a78b3e:research/modalities/fet-ddr-axis-scan.json`

Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\td1-final-review-20260908\pinned\research\modalities\fet-ddr-axis-scan.json`

Bytes: 59970; SHA256 `0737bdef39374f9dfb820b510fa66500659bc510c71188903568531f8079b012`.

Header/release/screened-count and emc_line record directly read; no full DDR biological review.

## hemcss-label-priorart.json

Original: `9f571e8170fb81dbe4d78515981ccb57c7a78b3e:research/modalities/hemcss-label-priorart.json`

Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\td1-final-review-20260908\pinned\research\modalities\hemcss-label-priorart.json`

Bytes: 32035; SHA256 `fcc3d8284eb0cd507cc44872c0dca677b5114af5c5c2ba91e7c243865486a5d7`.

Identity-vs-disease framing, established findings and explicit suggestive-not-definitive limitation read. Not a fresh authentication, source-census or fusion-caller audit.

## txn-dependency-class-definitions-2026-08-09.json

Original: `9f571e8170fb81dbe4d78515981ccb57c7a78b3e:research/literature/txn-dependency-class-definitions-2026-08-09.json`

Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\td1-final-review-20260908\pinned\research\literature\txn-dependency-class-definitions-2026-08-09.json`

Bytes: 7152; SHA256 `7b9944c793d85927c9ea6d7d9db49703e53d39a1305c86eb289b2c215e389628`.

Entire retained citation/class-definition record read. Initial source-payload local absence recorded separately; metadata/extraction is not represented as a primary fulltext.

## fet-fusion-chaperone-clientship-2026-08-27.json

Original: `9f571e8170fb81dbe4d78515981ccb57c7a78b3e:research/literature/fet-fusion-chaperone-clientship-2026-08-27.json`

Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\td1-final-review-20260908\pinned\research\literature\fet-fusion-chaperone-clientship-2026-08-27.json`

Bytes: 30301; SHA256 `4603641f2d342d49d9daa6a9be3f71d968b111872fe89c0b14a9397b9bdbbebe`.

Entire scientific record read: definitions, retrieval scope, all10 evidence records, all15 query entries, verdicts and unresolved questions. Not independent screening of unavailable query hits or supplements.

## OPERATING_PROTOCOL.md

Original: `9f571e8170fb81dbe4d78515981ccb57c7a78b3e:research/autonomy/OPERATING_PROTOCOL.md`

Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\td1-final-review-20260908\pinned\research\autonomy\OPERATING_PROTOCOL.md`

Bytes: 10898; SHA256 `5a0051a18b88b7e0056a98f783ac22fe42099090c17698595715cb021411a9af`.

Review-with-endpoint section44-72 read; headings inspected for relevant scope. User standing scientific scope governs this review.

## SKILL.md

Original: `9f571e8170fb81dbe4d78515981ccb57c7a78b3e:.claude/skills/paper-hardening/SKILL.md`

Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\td1-final-review-20260908\pinned\.claude\skills\paper-hardening\SKILL.md`

Bytes: 1937; SHA256 `497689024cf143920696031f265ddf69d58381ea2cce4a025871d85d38ede4ea`.

Entire paper-hardening or repo-gates skill read; finite scientific review used; no new publication gate run.

## SKILL.md

Original: `9f571e8170fb81dbe4d78515981ccb57c7a78b3e:.claude/skills/repo-gates/SKILL.md`

Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\td1-final-review-20260908\pinned\.claude\skills\repo-gates\SKILL.md`

Bytes: 1794; SHA256 `228e27b07811a027d60e548d88e41e992280d788c2478aa2c7fb467af8cbafa1`.

Entire paper-hardening or repo-gates skill read; finite scientific review used; no new publication gate run.

## emc_expression_panels.py

Original: `9f571e8170fb81dbe4d78515981ccb57c7a78b3e:research/modalities/emc_expression_panels.py`

Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\td1-final-review-20260908\pinned\research\modalities\emc_expression_panels.py`

Bytes: 193150; SHA256 `05c343aa29162ec618539ec81cc2d648db923f21618093d59ae4dbe0eeec9cc5`.

Imports and target/platform selection; panel definitions602-647, parsing/reduction1402-1485, group selection1647-1654, z-score1657-1665, gene-list scoring1981-2016, output framing/limits and relevant control references inspected. No execution and no audit of unrelated producers/panels.

## depmap_sarcoma_dependency.py

Original: `9f571e8170fb81dbe4d78515981ccb57c7a78b3e:research/modalities/depmap_sarcoma_dependency.py`

Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\td1-final-review-20260908\pinned\research\modalities\depmap_sarcoma_dependency.py`

Bytes: 22985; SHA256 `f34707fb39d98971ecc168ac58517f69446ee445cd434d0b6f0077b89530f43f`.

Data-source/threshold/discovery and main lineage selection/missingness/statistics210-265, relevant gene groups, subtype/control logic and output definitions inspected. No network function or producer executed.

## census_route_expression_grading.py

Original: `9f571e8170fb81dbe4d78515981ccb57c7a78b3e:research/modalities/census_route_expression_grading.py`

Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\td1-final-review-20260908\pinned\research\modalities\census_route_expression_grading.py`

Bytes: 51333; SHA256 `99888ede672f1d45b073877b97f3120d40f3ca018a9db8728c5e6e372a1d6838`.

Relevant RT-TXN-CDK and RT-CHAPERONE generating definitions/conclusions at393 onward inspected. Unrelated routes outside scientific review.

## FREEZE-for-final-review.md

Original: `9f571e8170fb81dbe4d78515981ccb57c7a78b3e:research/autonomy/opus-capacity-campaign-20260908/paper-lane/TD1-dependency/FREEZE-for-final-review.md`

Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\td1-final-review-20260908\pinned\research\autonomy\opus-capacity-campaign-20260908\paper-lane\TD1-dependency\FREEZE-for-final-review.md`

Bytes: 10128; SHA256 `4aa7536b034e8b3b2f966b8a82498b3b879342e4ce8ab627381256555cfcf1de`.

Entire handoff read and main/dependency hash assertions checked; author conclusions assessed independently.

## HASHES.sha256

Original: `9f571e8170fb81dbe4d78515981ccb57c7a78b3e:research/autonomy/opus-capacity-campaign-20260908/paper-lane/TD1-dependency/frozen/HASHES.sha256`

Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\td1-final-review-20260908\pinned\research\autonomy\opus-capacity-campaign-20260908\paper-lane\TD1-dependency\frozen\HASHES.sha256`

Bytes: 3795; SHA256 `3cabd014cd64fcb8a148cdd6f520cbaeba4e4bb6657f9204d5b32af2c784cfa6`.

Entire author frozen hash inventory read; used for precise dependency/check retention, not scientific acceptance.

## ORIGINAL-CHILD-TRANSCRIPT-a3ea9067b5836bf10.jsonl

Original: `9f571e8170fb81dbe4d78515981ccb57c7a78b3e:research/autonomy/opus-capacity-campaign-20260908/paper-lane/TD1-executed-artifacts/ORIGINAL-CHILD-TRANSCRIPT-a3ea9067b5836bf10.jsonl`

Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\td1-final-review-20260908\pinned\research\autonomy\opus-capacity-campaign-20260908\paper-lane\TD1-executed-artifacts\ORIGINAL-CHILD-TRANSCRIPT-a3ea9067b5836bf10.jsonl`

Bytes: 281979; SHA256 `2839b627c8bdfeb55896f1a8912341e2674fabda7244e5c933895644a32b22d9`.

Final report at line95: full scientific D1-D14/quantity table, nine proposed edits, caveats and stop condition read; selected source tool-output context inspected. Raw transcript preserved; environment dumps not reproduced as scientific evidence.

## emc_atr_vulnerability.py

Original: `9f571e8170fb81dbe4d78515981ccb57c7a78b3e:research/modalities/emc_atr_vulnerability.py`

Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\td1-final-review-20260908\pinned\research\modalities\emc_atr_vulnerability.py`

Bytes: 186461; SHA256 `52c63c8e6e114c2b94e1f2e45c57fb07222fcf745c393662755e5fcf799d6514`.

Imported dependency declarations, parser876-919 and sample classifier1608-1628 read; reference-pool mentions and scoring provenance inspected. No raw ATR analysis or producer run.

## fet_ddr_axis_scan.py

Original: `9f571e8170fb81dbe4d78515981ccb57c7a78b3e:research/modalities/fet_ddr_axis_scan.py`

Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\td1-final-review-20260908\pinned\research\modalities\fet_ddr_axis_scan.py`

Bytes: 39410; SHA256 `342c0aadd1b0d259b2cfeed3ef801f9a0741d8695946eac1845cab0aacd61bbc`.

Imported Welch implementation160-180 directly read; contextual header/definitions inspected. No DDR analysis/producer run.

## DIFF-TD1-scope-repair.patch

Original: `9f571e8170fb81dbe4d78515981ccb57c7a78b3e:research/autonomy/opus-capacity-campaign-20260908/paper-lane/TD1-dependency/DIFF-TD1-scope-repair.patch`

Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\td1-final-review-20260908\pinned\research\autonomy\opus-capacity-campaign-20260908\paper-lane\TD1-dependency\DIFF-TD1-scope-repair.patch`

Bytes: 12536; SHA256 `0f84910404be51c978672f854aadeb9b3188b0ce2a256c899507d9b055487bb3`.

Retained exact author provenance; scope withdrawals compared with current full main/handoff, not independently reviewed as an alternate candidate.

## 00-start-state.txt

Original: `9f571e8170fb81dbe4d78515981ccb57c7a78b3e:research/autonomy/opus-capacity-campaign-20260908/paper-lane/TD1-dependency/checks/00-start-state.txt`

Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\td1-final-review-20260908\pinned\research\autonomy\opus-capacity-campaign-20260908\paper-lane\TD1-dependency\checks\00-start-state.txt`

Bytes: 802; SHA256 `686b41cdc489fcda4a9ae65e9059c23d5e670d6db917f80ac724a713b57132df`.

Entire original start-state record read.

## 01-preflight-default.txt

Original: `9f571e8170fb81dbe4d78515981ccb57c7a78b3e:research/autonomy/opus-capacity-campaign-20260908/paper-lane/TD1-dependency/checks/01-preflight-default.txt`

Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\td1-final-review-20260908\pinned\research\autonomy\opus-capacity-campaign-20260908\paper-lane\TD1-dependency\checks\01-preflight-default.txt`

Bytes: 486875; SHA256 `231e15a64bdd463f3b2aa0115690621b8614a444692f7ebf5b00dd19931564fa`.

Original retained in full; failure summaries, relevant lines1265-1303 and final section/exit inspected. No claim to full scientific audit of unrelated 486KB gate output.

## 02-baseline-producers-without-TD1-edit.txt

Original: `9f571e8170fb81dbe4d78515981ccb57c7a78b3e:research/autonomy/opus-capacity-campaign-20260908/paper-lane/TD1-dependency/checks/02-baseline-producers-without-TD1-edit.txt`

Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\td1-final-review-20260908\pinned\research\autonomy\opus-capacity-campaign-20260908\paper-lane\TD1-dependency\checks\02-baseline-producers-without-TD1-edit.txt`

Bytes: 1130; SHA256 `443e760ca9e0be7d7d3e4d7af5f0765bca86dfd9c1fff721d2c79bf237c4ba3c`.

Entire original captured check summary read; only selected stdout/line counts captured by author, not full original producer stdout.

## 03-producers-after-TD1-edit.txt

Original: `9f571e8170fb81dbe4d78515981ccb57c7a78b3e:research/autonomy/opus-capacity-campaign-20260908/paper-lane/TD1-dependency/checks/03-producers-after-TD1-edit.txt`

Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\td1-final-review-20260908\pinned\research\autonomy\opus-capacity-campaign-20260908\paper-lane\TD1-dependency\checks\03-producers-after-TD1-edit.txt`

Bytes: 1021; SHA256 `ce9a938bed6955e72243045edcf61b2b9d02da1a4ae47d3fde2b815d4b4c8baf`.

Entire original captured check summary read; digest and actual exits checked, noting different digest from final freeze.

## 04-lint_asymmetry.txt

Original: `9f571e8170fb81dbe4d78515981ccb57c7a78b3e:research/autonomy/opus-capacity-campaign-20260908/paper-lane/TD1-dependency/checks/04-lint_asymmetry.txt`

Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\td1-final-review-20260908\pinned\research\autonomy\opus-capacity-campaign-20260908\paper-lane\TD1-dependency\checks\04-lint_asymmetry.txt`

Bytes: 381; SHA256 `56fd2a4121469e5f8e103b53d8d1275bd5161856c6f6c83cbaa7360ba98c280b`.

Entire original usage error and EXIT2 read.

## 04-lint_changed_prose.txt

Original: `9f571e8170fb81dbe4d78515981ccb57c7a78b3e:research/autonomy/opus-capacity-campaign-20260908/paper-lane/TD1-dependency/checks/04-lint_changed_prose.txt`

Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\td1-final-review-20260908\pinned\research\autonomy\opus-capacity-campaign-20260908\paper-lane\TD1-dependency\checks\04-lint_changed_prose.txt`

Bytes: 270; SHA256 `62f98f6fc11a111b7250d434d7722c0e4cbec1032b6cc8c51ee1ba757981b110`.

Entire original outcome/EXIT0 and zero changed passages read.

## 04-lint_citations.txt

Original: `9f571e8170fb81dbe4d78515981ccb57c7a78b3e:research/autonomy/opus-capacity-campaign-20260908/paper-lane/TD1-dependency/checks/04-lint_citations.txt`

Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\td1-final-review-20260908\pinned\research\autonomy\opus-capacity-campaign-20260908\paper-lane\TD1-dependency\checks\04-lint_citations.txt`

Bytes: 318; SHA256 `fd21f812c35fe533ed4d1549d0b95020c6463b233237d865c1297a64ea4c32b9`.

Entire original usage error and EXIT2 read.

## 04-lint_claims.txt

Original: `9f571e8170fb81dbe4d78515981ccb57c7a78b3e:research/autonomy/opus-capacity-campaign-20260908/paper-lane/TD1-dependency/checks/04-lint_claims.txt`

Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\td1-final-review-20260908\pinned\research\autonomy\opus-capacity-campaign-20260908\paper-lane\TD1-dependency\checks\04-lint_claims.txt`

Bytes: 166; SHA256 `60cb3a09cc224e05132b3a29d0b188a67ac20f875337929f4db85664da36ff54`.

Entire original outcome/EXIT0 read.

## 04-lint_consistency.txt

Original: `9f571e8170fb81dbe4d78515981ccb57c7a78b3e:research/autonomy/opus-capacity-campaign-20260908/paper-lane/TD1-dependency/checks/04-lint_consistency.txt`

Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\td1-final-review-20260908\pinned\research\autonomy\opus-capacity-campaign-20260908\paper-lane\TD1-dependency\checks\04-lint_consistency.txt`

Bytes: 323; SHA256 `3bd4bab46a044d15766d3aa753cc86cac641ce0d439b901742441b4983f5e219`.

Entire original usage error and EXIT2 read.

## 04-lint_style.txt

Original: `9f571e8170fb81dbe4d78515981ccb57c7a78b3e:research/autonomy/opus-capacity-campaign-20260908/paper-lane/TD1-dependency/checks/04-lint_style.txt`

Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\td1-final-review-20260908\pinned\research\autonomy\opus-capacity-campaign-20260908\paper-lane\TD1-dependency\checks\04-lint_style.txt`

Bytes: 10863; SHA256 `2b06e24fb7f96c262e76693fe824203285240fd1e50749d6e980551297580978`.

Final error count/EXIT1 and representative findings read; full log retained without treating stylistic defects as scientific blockers.

## 05-lint_consistency-repo.txt

Original: `9f571e8170fb81dbe4d78515981ccb57c7a78b3e:research/autonomy/opus-capacity-campaign-20260908/paper-lane/TD1-dependency/checks/05-lint_consistency-repo.txt`

Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\td1-final-review-20260908\pinned\research\autonomy\opus-capacity-campaign-20260908\paper-lane\TD1-dependency\checks\05-lint_consistency-repo.txt`

Bytes: 166; SHA256 `de708503909216dec621e179bad2a80d7811336056ba84a4fb4cccceabd1a420`.

Entire original correct-invocation outcome/EXIT0 read.

## 06-lint_readability.txt

Original: `9f571e8170fb81dbe4d78515981ccb57c7a78b3e:research/autonomy/opus-capacity-campaign-20260908/paper-lane/TD1-dependency/checks/06-lint_readability.txt`

Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\td1-final-review-20260908\pinned\research\autonomy\opus-capacity-campaign-20260908\paper-lane\TD1-dependency\checks\06-lint_readability.txt`

Bytes: 2000; SHA256 `fec5f8d231f0d54f3d6bf8133051d826537c4f99b8aea1e65c0d119fe6d8c58e`.

Final advisory findings and EXIT0 read; full log retained.

## 07-lint_style-before-after.txt

Original: `9f571e8170fb81dbe4d78515981ccb57c7a78b3e:research/autonomy/opus-capacity-campaign-20260908/paper-lane/TD1-dependency/checks/07-lint_style-before-after.txt`

Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\td1-final-review-20260908\pinned\research\autonomy\opus-capacity-campaign-20260908\paper-lane\TD1-dependency\checks\07-lint_style-before-after.txt`

Bytes: 495; SHA256 `a01abd2e2a44f627045062a007208323fb7db6046046ff8a61914ba429d4b6a9`.

Entire original rule-count/claimed-status comparison read; discrepancy with actual preflight noted.

## fd79244825-MANIFEST.json

Original: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\d5eb86e8\TD1-reviewer-source-copies\MANIFEST.json`

Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\td1-final-review-20260908\provenance-originals\fd79244825-MANIFEST.json`

Bytes: 2116; SHA256 `67625e2ae854badbbb925ef5f0a46d865c533c9e64112cc7a6b69083bf2b0752`.

Entire original four-source transport manifest read, including scoped absence of optional source filenames. Counts/hashes/Git identities verified locally from actual bytes; transport is not a source fetch.

## c9ee794a84-epmc_cdk7_transcriptional.txt

Original: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\d5eb86e8\TD1-reviewer-source-copies\epmc_cdk7_transcriptional.txt`

Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\td1-final-review-20260908\provenance-originals\c9ee794a84-epmc_cdk7_transcriptional.txt`

Bytes: 276480; SHA256 `112921aec4794ff8387a116b88ead50686295b3037e16e5f2de07f4d0f5faa2a`.

Actual retained Europe PMC JSON body at line6, resultList.result[0] (PMID25043025) title/publication types/DOI and full abstract read. Other query hits were not independently reviewed; payload is abstract metadata, not a full article.

## 885604ac7d-epmc_hsf1_heat_shock_cancer.txt

Original: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\d5eb86e8\TD1-reviewer-source-copies\epmc_hsf1_heat_shock_cancer.txt`

Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\td1-final-review-20260908\provenance-originals\885604ac7d-epmc_hsf1_heat_shock_cancer.txt`

Bytes: 202343; SHA256 `f117dad1a685b808d9906e710941fc2775fef8c3fd64623a49d93c22b3232a83`.

Actual retained Europe PMC JSON body at line6, resultList.result[1] (PMID22863008) title/publication types/DOI and full abstract read. Other query hits not independently reviewed; not a full article.

## 6655400dec-epmc_hsp90_client.txt

Original: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\d5eb86e8\TD1-reviewer-source-copies\epmc_hsp90_client.txt`

Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\td1-final-review-20260908\provenance-originals\6655400dec-epmc_hsp90_client.txt`

Bytes: 170344; SHA256 `88b9c5ac631ab325192e5a7c1382466086126af78d9a9b922651f71b3d4f9d67`.

Actual retained Europe PMC JSON body at line6, resultList.result[0] (PMID28429788, review) and [2] (PMID9108479, primary article), titles/types/DOIs and full abstracts read. Other query hits not independently reviewed; not full articles.

## 63ee02065a-epmc_transcriptional_addiction.txt

Original: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\d5eb86e8\TD1-reviewer-source-copies\epmc_transcriptional_addiction.txt`

Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\td1-final-review-20260908\provenance-originals\63ee02065a-epmc_transcriptional_addiction.txt`

Bytes: 198043; SHA256 `636b40a4bba0db2cd4f600d694712263b58d2840cfa8dbe8cccdcacba6c63adc`.

Actual retained Europe PMC JSON body at line6, resultList.result[0] (PMID28187285, review) and [1] (PMID26406377, primary article), titles/types/DOIs and full abstracts read. Other query hits not independently reviewed; not full articles.

## Reviewer support files

| File | Bytes | SHA256 |
|---|---:|---|
| `build_manifest.py` | 8247 | `b8153fac1c3064e2e39f5997b771090455c22479910d7b912350762d27250303` |
| `extra-source-scopes.json` | 2081 | `fd375cdf8e602086c14d7850e698db954879d0c48bf030889bbc56f2406da0ed` |
| `inspect_json.py` | 529 | `7202f9a540a898820b4a3b98924a412890914c016852ee0c185d5d5301bfbc73` |
| `project_source_records.py` | 1214 | `cb12f4f696c3afec604ec29dba3f96a8d78a1f8db1ef685e6150dc98c94a9592` |
| `read_lines.py` | 304 | `d0bba4808aab7453afbe19ce2a77dabedbb1f4bef743c4d7fe5d55424bf9b60f` |
| `register_source_copies.py` | 2864 | `42c5766ab7822713e1b4f6f76bf6cd1c3f5034ceb1d9f08806af408f1352bb80` |
| `retain.py` | 1894 | `4ce467ff0652ccccb4fa1ba681f8730d182e606d67793038f65db7a5cb17d59c` |
| `retain_sources.py` | 1828 | `506cadcdb4690a48acaa642385909646c6048dd0db17a1e201de377f9928a7e8` |
| `reviewer-checks\README.md` | 2125 | `593daa8a43e4b670f5d4b3791c9b1951778d9cadafbc4364bfb6cf5976fde2f5` |
| `reviewer-checks\summary-arithmetic-attempt2.exit.json` | 437 | `18e0d622032bfd09b48c4d5eec8effa0aaba5d8b835670de42c95b72bad11745` |
| `reviewer-checks\summary-arithmetic-attempt2.stderr.txt` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `reviewer-checks\summary-arithmetic-attempt2.stdout.json` | 11219 | `fc3e45ea3afe83e46683fa3194a6b7262aa49cae5d4d597126d81efac370a558` |
| `reviewer-checks\summary-arithmetic.exit.json` | 432 | `fe1c62f85f297c1f18025e8e7433f2e2a27bef3df1668111642545676c82804c` |
| `reviewer-checks\summary-arithmetic.stderr.txt` | 884 | `d7032bdc0a80acb2c59750eea9ca83455f39a963025e25e32e27883c7e238618` |
| `reviewer-checks\summary-arithmetic.stdout.json` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `reviewer_checks.py` | 3739 | `a89d85986cdd1aa71a1af9f149f837791c0c456a32e78c40a6d7c48f7a95309d` |
| `reviewer_checks_v2.py` | 3789 | `b07d9f4e95d32a9d13b758e547ac2f2986616cb19c0a2e83d87472fad9d692ba` |
| `run_reviewer_checks.py` | 994 | `78fd83aa204f21ae0394efd5be6618ddea0a82fee1160354316887ea006740a7` |
| `run_reviewer_checks_v2.py` | 1035 | `9628f454ae5c03e3f74158471591adc678bbaa82d4e6fae241f16fac419782f2` |
| `source-access-records\ATTEMPTS.json` | 916 | `a85ea087ff9247df65c5dc2a579010bbfe5ebc8b6ba0da1b7d6e390afbf2f2b5` |
| `source-access-records\epmc_cdk7_transcriptional.stderr.txt` | 144 | `b11c78af4b8f4b6ded6aff1bda8c2abdf8afae54c8e140fbdbbfac25cb701efd` |
| `source-access-records\epmc_cdk7_transcriptional.stdout.txt` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `source-access-records\epmc_hsf1_heat_shock_cancer.stderr.txt` | 146 | `b2ba49e2f28338f1e0c65f295cbecba74fb8bb1c29c3f4b59ffe08459ceed0e5` |
| `source-access-records\epmc_hsf1_heat_shock_cancer.stdout.txt` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `source-access-records\epmc_hsp90_client.stderr.txt` | 136 | `ae8c8f30a1e9e6b315af7a983f381a5ed3ff2c68df2936d6ff15365935a951f2` |
| `source-access-records\epmc_hsp90_client.stdout.txt` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `source-access-records\epmc_transcriptional_addiction.stderr.txt` | 149 | `05b1d815a93e9244e8d767b13eaa7a8c22131d02fd8780afc6abd16340f5185a` |
| `source-access-records\epmc_transcriptional_addiction.stdout.txt` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `SOURCE-BYTE-VERIFICATION.json` | 1757 | `b0a3ceba8d98f5133a0e81b4dd9f9a801d8fa8bf242c66cbafb77a0d903bd0e5` |
