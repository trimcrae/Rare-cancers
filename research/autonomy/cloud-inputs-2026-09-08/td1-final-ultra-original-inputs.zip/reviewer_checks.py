"""One deterministic reviewer check of reported summaries; no producer/raw reanalysis."""
from pathlib import Path
import json, math, hashlib
B=Path(__file__).resolve().parent/'pinned/research/modalities'
e=json.loads((B/'emc-expression-panels.json').read_text())
d=json.loads((B/'depmap-sarcoma-dependency.json').read_text())
g=json.loads((B/'census-route-expression-grading.json').read_text())

def cf(a,b,x):
    qab=a+b; qap=a+1; qam=a-1; c=1.; dd=1-qab*x/qap
    if abs(dd)<1e-300: dd=1e-300
    dd=1/dd; h=dd
    for m in range(1,401):
        m2=2*m; aa=m*(b-m)*x/((qam+m2)*(a+m2))
        dd=1+aa*dd; c=1+aa/c
        if abs(dd)<1e-300: dd=1e-300
        if abs(c)<1e-300: c=1e-300
        dd=1/dd; h*=dd*c
        aa=-(a+m)*(qab+m)*x/((a+m2)*(qap+m2))
        dd=1+aa*dd; c=1+aa/c
        if abs(dd)<1e-300: dd=1e-300
        if abs(c)<1e-300: c=1e-300
        dd=1/dd; z=dd*c; h*=z
        if abs(z-1)<3e-14: return h
    raise RuntimeError('continued fraction did not converge')
def ibeta(a,b,x):
    if x<=0: return 0.
    if x>=1: return 1.
    front=math.exp(math.lgamma(a+b)-math.lgamma(a)-math.lgamma(b)+a*math.log(x)+b*math.log1p(-x))
    return front*cf(a,b,x)/a if x<(a+1)/(a+b+2) else 1-front*cf(b,a,1-x)/b
def pvalue(t,df): return ibeta(df/2,.5,df/(df+t*t))
def quantile(df):
    lo,hi=0.,100.
    for _ in range(80):
        mid=(lo+hi)/2
        if pvalue(mid,df)>.05: lo=mid
        else: hi=mid
    return (lo+hi)/2

rows=[]
for panel in ['transcriptional_cdk','chaperone_dependency']:
    for group,v in e['panels'][panel]['groups'].items():
        for platform,rec in v['per_platform'].items():
            s=rec['score']; delta=s['delta_a_minus_b']; se=abs(delta/s['t']); p=pvalue(s['t'],s['df']); q=quantile(s['df'])
            rows.append(dict(panel=panel,group=group,platform=platform,genes=rec['genes_readable'],coverage=rec['coverage'],delta=delta,t=s['t'],df=s['df'],approx_two_sided_p=p,approx_95CI_from_rounded_summaries=[delta-q*se,delta+q*se],nominal_p_lt_05=p<.05,bonferroni_14_p_lt_05=p<.05/14))
dep=[]
for group in d['genes_by_group'].values():
    for rec in group:
        if rec['gene'] in ['CDK7','CDK9','HSP90AA1','HSP90AB1','CDC37']:
            n=rec['n_sarcoma']; frac=rec['sarcoma_frac_dependent']
            dep.append(dict(**rec,integer_counts_compatible_with_rounded_fraction=[k for k in range(n+1) if round(k/n,3)==frac]))
outcontext=[]
for platform,rec in e['panels']['transcriptional_cdk']['groups']['transcriptional_output_context']['per_platform'].items():
    myc=g['routes']['RT-TXN-CDK']['genes']['MYC'][platform]['delta_emc_minus_comparator']
    groupdelta=rec['score']['delta_a_minus_b']
    outcontext.append(dict(platform=platform,group_delta=groupdelta,MYC_delta=myc,mean_delta_other_three_by_algebra=(4*groupdelta-myc)/3,interpretation='Algebra on rounded published summaries, not a rerun or a significance test of a new gene set.'))
result=dict(scope='Conditional arithmetic on frozen rounded summaries only; no raw reanalysis, producer import, source validation, or new biology.',inputs={p.name:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in [B/'emc-expression-panels.json',B/'depmap-sarcoma-dependency.json',B/'census-route-expression-grading.json']},method='Two-sided Student t tail from regularized incomplete beta, continued fraction; intervals use delta/t as SE and rounded df. Bonferroni14 is illustrative, not a justified family definition.',numerical_calibration=dict(cauchy_t1_df1_p=pvalue(1,1),expected=.5,absolute_error=abs(pvalue(1,1)-.5)),expression=rows,dependency=dep,transcriptional_context_algebra=outcontext)
assert result['numerical_calibration']['absolute_error']<1e-12
print(json.dumps(result,indent=2))
