"""Read selected actual abstract records from retained source payloads, without retrieval."""
from pathlib import Path
import json,hashlib
B=Path(__file__).resolve().parent
names=['epmc_cdk7_transcriptional.txt','epmc_hsf1_heat_shock_cancer.txt','epmc_hsp90_client.txt','epmc_transcriptional_addiction.txt']
wanted={'25043025','26406377','28187285','22863008','28429788','9108479','25985210','24388362','36495678','26706127','28383167'}
out=[]
for name in names:
    p=next((B/'provenance-originals').glob('*-'+name))
    raw=p.read_text(encoding='utf-8'); obj=json.loads(raw[raw.index('{'):])
    found=[]
    for i,r in enumerate(obj['resultList']['result']):
        if str(r.get('pmid',r.get('id'))) not in wanted: continue
        found.append(dict(json_path=f'resultList.result[{i}]',pmid=r.get('pmid'),title=r.get('title'),publication_types=r.get('pubTypeList'),abstractText=r.get('abstractText'),doi=r.get('doi')))
    out.append(dict(source=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),wrapper_body_line=raw[:raw.index('{')].count('\n')+1,hitCount=obj.get('hitCount'),returned_records=len(obj['resultList']['result']),selected_records=found))
print(json.dumps(out,indent=2,ensure_ascii=True))
