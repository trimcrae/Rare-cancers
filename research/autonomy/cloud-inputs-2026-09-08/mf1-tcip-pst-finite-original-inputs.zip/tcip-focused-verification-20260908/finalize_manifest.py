"""Finalize exact input identities/read scopes and verify byte preservation, not science."""
from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
records=json.loads((root/'retained-inputs.json').read_text())
def h(b):return hashlib.sha256(b).hexdigest()
def scope(r):
 s=r['source'].replace('\\','/');n=Path(r['retained_path']).name
 if r['kind']=='git':
  rel=s.split(':',1)[1]
  if rel.endswith('tcip-induced-interface-preprint.md'):return 'Full main manuscript, lines 1-722; thirteen-finding focused verification and current-claim consistency.'
  if rel.endswith('tcip-induced-interface-preprint-si.md'):return 'Full SI, lines 1-535; thirteen-finding focused verification and numerical/source interpretation.'
  if rel.endswith('systems/graph/publications.json'):return 'Entire PUB-TCIP entry, lines 518-531 / $[29]; other publication entries not scientifically reviewed. Exact file hashed in full.'
  if rel.endswith('nr4a3_basin_search.py'):return 'Targeted static reading: parameter, CA/centroid query construction (460-475), radial draw and full admission loop (542-622). No execution.'
  if rel.endswith('nr4a3_induced_interface_census.py'):return 'Targeted static reading: query construction, exact score, protein/ligand eligibility and zero filter (433-610), induced class/summary logic as required by unchanged original review, CLI (685-692). No execution or new geometry.'
  if rel.endswith('nr4a3_tcip_reach.py'):return 'Targeted static reading: cross-run criterion (580-608), ablation (611-670), verdict default (870-902), build/grid/seeds (1541-1600), full-build verdict and refresh path (1699, 1704-1769). No sampler/producer execution.'
  if rel.endswith('basin_geom.py'):return 'Targeted static reading: grid-centre distance field, clamp/slack and lookup (259-331); no distance calculation.'
  if rel.endswith('nr4a3-tcip-reach.json'):return 'Existing main/ablation summaries, count inventories and named-arm/cross-check fields compared through retained original calculation and unchanged byte binding; not a new cell-level statistical reanalysis.'
  if rel.endswith('nr4a3-induced-interface-census.json'):return 'Class summaries and 9MZA/7LWG stored records, with original reviewed selected-pair arithmetic; zero-filter reasoning checked against code. No geometry remeasurement.'
  if rel.endswith('nr4a3-orientation-basins.json'):return 'Unchanged original-review dependency identity; relevant 24-cell old-run counts used through the retained original diagnostic. No fresh full artifact audit.'
  if rel.endswith('-arm-registry.json'):return 'Targeted coordinate-result paths and staged-arm metadata supporting reproduction limits; no full registry audit or coordinate loading.'
  if rel.endswith('nr4a3-tcip-reach.md'):return 'Retained unchanged generated view for the existing named-effector erratum; inherited interpretation is not current authority. No full new review.'
  if rel.endswith('nr4a3-tcip-route-memo.md'):return 'Retained unchanged historical quantity/provenance dependency; historical checks and retired ratios evaluated through original review and main corrections, not newly accepted as original execution evidence.'
  if rel.endswith('tcip-interface-floor-sizing.md'):return 'Unchanged historical memo identity and authority scope; carryover map and main/SI supersession read. Later root banner is outside freeze; no second full baseline of this memo.'
  if rel.endswith('selectivity-requirement-sizing.md'):return 'Targeted binary derivation (100-126), assumptions and unsupported ternary transfer (384-398); no new scientific model run.'
  if rel.endswith('SKILL.md'):return 'Full skill read; finite review and honest execution evidence scope, subordinate to standing task authorization.'
  if rel.endswith('OPERATING_PROTOCOL.md'):return 'Review-with-an-endpoint section 44-65 and relevant scope search; not full operating-protocol audit.'
  if 'lint_' in rel:return 'Targeted CLI/default-target/report/return behavior and scientific limits of pattern checks; source inspected only, no linter executed.'
 if '/TCIP-repair/checks/' in s or '/PARENT-SHARED-PATCHES-2026-09-08/checks/' in s:
  if s.endswith('/command.txt') or s.endswith('/exit_code.txt'):return 'Full original command/exit record read; no rerun.'
  if '/08-lint_citations-repo/' in s:return 'Full original bytes retained; TCIP-filename membership scanned in both streams, diagnostic/header/footer scope inspected. Unrelated repository failures not individually adjudicated.'
  if '/03-lint_style-AFTER-check/' in s or '/07-lint_style-BEFORE-check/' in s:return 'Full original bytes retained; error summaries/categories and before/after outcome examined, not every style item independently adjudicated.'
  return 'Full original stream read where short (including empty streams); original outcomes retained, not rerun.'
 if '/source-intake/inputs/' in s:
  if s.endswith('__cif_9MZA.txt'):return 'Material original mmCIF metadata: citation/entity/chain records 80-190, method 1642, resolution 1923, title/alignments/conflicts/assembly 2180-2350; no coordinate remeasurement or visual structural QA.'
  if s.endswith('__rcsb_entry_9MZA.txt'):return 'Original header plus struct/title, citation, accession dates, method/resolution and construct totals; not every ancillary JSON field.'
  if s.endswith('__rcsb_assembly_9MZA.txt'):return 'Complete original assembly response, including A2B2, identity operation, FRET metadata, modeled/unmodeled totals; underlying experiment not inspected.'
  if s.endswith('__epmc_kat_tcip_record.txt'):return 'Full retained response read, including both abstracts, citation/update relation and availability/license metadata. No primary full text acquired/read.'
  if s.endswith('__rcsb_cite_pubmed_42476129.txt'):return 'Full HTTP 400 invalid-attribute original read. Not a negative search or denial. No retry.'
  if s.endswith('___index.json'):return 'All-array metadata schema/inventory inspected plus original reviewed file-pointer inventory. Not a fresh abstract/full-text literature screen or term-count/classification reanalysis.'
  if s.endswith('/MANIFEST.json'):return 'Full original seven-source identity manifest read; each source matched against retained bytes during finalization.'
  return 'Original source-intake provenance retained; self-hash/verification limitations read through original addendum and current SI. Not a new transport audit.'
 if n.endswith('FINAL-SCIENTIFIC-REVIEW-TCIP.md') or n.endswith('SOURCE-INTAKE-ADDENDUM-20260908.md') or n.endswith('TCIP-final-review-root-adjudication-20260908.md'):return 'Full original review/adjudication text read and all thirteen accepted findings used; preserved without edits.'
 if any(n.endswith(x) for x in ['FINDING-MAP.md','IDENTITIES.md','RESIDUAL-LIMITATIONS.md','SIZING-MEMO-CARRYOVER.md','CHECK-RUN-RECORD.txt','CONTRACT-TCIP-F01-F13-author-repair.md','APPLIED-RECORD.md','SETTLED-IDENTITIES-2026-09-08.md']):return 'Full original handoff/response/authority record read; author-applied labels are not assumed scientific closure.'
 if 'PUB-TCIP-narrowed.patch' in n:return 'TCIP graph replacement inspected and compared with actual settled entry; patch alone not treated as applied authority.'
 if 'BEFORE-tcip' in n or '.diff' in n:return 'Retained original BEFORE/diff bytes for repair provenance; no additional full baseline or independent diff-only claim acceptance.'
 if n.endswith('reviewer-calculations.json'):return 'Original deterministic reviewer result sections read: inventory, rungs, ablation, seed design, diagnostic summary, census denominators/omissions, 9MZA, analytic examples, named verdict. No rerun; no new geometry.'
 if n.endswith('reviewer-calculations-stdout.txt'):return 'Original complete stdout retained, byte-identical to original result JSON; interpreted as prior reviewer calculation evidence, not a new execution.'
 if n.endswith('reviewer-calculations-exit.txt'):return 'Full original exit 0 record read; no rerun.'
 if n.endswith('reviewer_calculations.py'):return 'Original script retained; scope/definitions inspected; original calculation outputs reused, script not executed in focused pass.'
 if n.endswith('inspect_source_records.py'):return 'Full final original reading-helper source read (strict=False for retained malformed response strings); no rerun or recreation of its first failure.'
 if n.endswith('source_intake.py'):return 'Original intake script retained for provenance only; not executed in this focused pass.'
 if n.endswith('material-record-excerpts.json'):return 'Original reviewer reading aid retained, used for metadata/file-pointer context only; not an original response.'
 return 'Retained original provenance/identity context; not fully scientifically rereviewed. Scope is limited to the thirteen-finding verification described in the report.'
for r in records:
 b=Path(r['retained_path']).read_bytes()
 if len(b)!=r['bytes'] or h(b)!=r['sha256']:raise ValueError('Input changed: '+r['retained_path'])
 r['review_scope']=scope(r)
 r['file_sha256_rechecked_at_finalization']=True
source_man=[r for r in records if r['source'].replace('\\','/').endswith('/source-intake/inputs/MANIFEST.json')][0]
sm=json.loads(Path(source_man['retained_path']).read_text())
bindings=[]
for m in sm['copies']:
 r=[r for r in records if r['source'].replace('\\','/').endswith('/source-intake/inputs/'+m['copy'])][0]
 b=Path(r['retained_path']).read_bytes();blob=hashlib.sha1(('blob '+str(len(b))+'\0').encode()+b).hexdigest()
 if (len(b),h(b),blob)!=(m['bytes'],m['sha256'],m['git_blob']):raise ValueError('Original-source identity mismatch')
 r['original_source_binding']={k:m[k] for k in ['source_commit','original_path','git_blob','copy']}
 bindings.append({'original_path':m['original_path'],'bytes':len(b),'sha256':h(b),'computed_git_blob':blob,'matches_manifest':True})
result={'review':'ONE TCIP focused post-repair scientific verification','main_si_pin':'f6107376cc41344f2296f2ada46c064d8251a3f8','graph_pin':'806ab2ecd06ff4fdc5d77c3229782d0948126b9f','scope_note':'Retention does not imply full scientific reading; each item specifies actual scope. No new science/network/producer/check execution. Later sizing-memo banner excluded.','input_files':records,'source_bindings':bindings}
(root/'REVIEWED-INPUT-MANIFEST.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
lines=['# TCIP focused verification — exact input manifest','','All inputs are retained under this workspace. Full-file hashes do not imply full scientific review; scopes below are explicit. Main/SI f6107376, PUB-TCIP graph 806ab2ec. Later sizing-memo banner excluded.','']
for i,r in enumerate(records,1):
 lines += [f'## {i}. {Path(r["retained_path"]).name}',f'- Source: `{r["source"]}`',f'- Retained: `{r["retained_path"]}`',f'- Bytes: {r["bytes"]}; SHA256: `{r["sha256"]}`',f'- Git blob: `{r.get("git_blob") or "external original; see original-source binding where applicable"}`',f'- Scope: {r["review_scope"]}','']
 if r.get('original_source_binding'):lines.insert(len(lines)-1,'- Original source binding: `'+json.dumps(r['original_source_binding'],ensure_ascii=False)+'`')
(root/'REVIEWED-INPUT-MANIFEST.md').write_text('\n'.join(lines),encoding='utf-8')
(root/'source-identity-receipt.json').write_text(json.dumps(bindings,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'inputs':len(records),'all_input_bytes_preserved':True,'source_bindings_matched':len(bindings),'scientific_calculations_run':0,'producers_or_linters_run':0}))
