"""Reading/identity receipt only. No scientific calculation or original check is rerun."""
from pathlib import Path
import json, hashlib
import retain
root=retain.ROOT
cap=Path('C:/Users/mcrae/.codex/review-workspaces/opus-capacity-sprint-20260907/capacity-campaign-20260908/observations/806ab2ec/PARENT-SHARED-PATCHES-2026-09-08/checks')
for folder in ['01-tcip-apply-check','02-tcip-apply']:
    for p in sorted((cap/folder).glob('*')):
        if p.is_file():retain.retain(str(p),'external')
for p in ['research/manuscripts/lint_style.py','research/manuscripts/lint_claims.py','research/manuscripts/lint_citations.py','research/manuscripts/lint_consistency.py','research/autonomy/OPERATING_PROTOCOL.md']:
    retain.retain(p)
records=json.loads(retain.MANIFEST.read_text())
def find(s):
    hit=[r for r in records if r['source'].replace('\\','/').endswith(s)]
    if len(hit)!=1:raise ValueError((s,len(hit)))
    return Path(hit[0]['retained_path'])
sources=[]
for suffix in ['induced-proximity-transcription-2026-08-07___index.json','induced-interface-vs-output-2026-08-07___index.json']:
    p=find('/source-intake/inputs/'+suffix)
    a=json.loads(p.read_text(encoding='utf-8'),strict=False)
    sources.append({'source':str(p),'array_records':len(a),'row_keys':sorted(set(k for row in a for k in row)),'first_record':a[0],'last_record':a[-1]})
checks=[]
for rec in records:
    s=rec['source'].replace('\\','/')
    if '/checks/' in s and s.endswith('/command.txt'):
        base=s.rsplit('/',1)[0]
        fields={}
        for name in ['command.txt','stdout.txt','stderr.txt','exit_code.txt']:
            matches=[r for r in records if r['source'].replace('\\','/')==base+'/'+name]
            if not matches:continue
            r=matches[0];p=Path(r['retained_path']);text=p.read_text(encoding='utf-8')
            fields[name]={'path':str(p),'bytes':r['bytes'],'sha256':r['sha256']}
            if name in ('command.txt','exit_code.txt') or r['bytes']<1500:fields[name]['full_text']=text
            else:fields[name]['tcip_filename_present']='tcip-induced-interface-preprint' in text
        checks.append({'original_run':base,'records':fields})
out={'identity':'New local reading receipt; not a linter rerun, source acquisition or new scientific arithmetic','source_index_metadata':sources,'original_execution_records':checks}
(root/'retained-record-reading.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(json.dumps({'receipt':'retained-record-reading.json','original_runs_read':len(checks),'source_index_arrays_read':len(sources)}))
