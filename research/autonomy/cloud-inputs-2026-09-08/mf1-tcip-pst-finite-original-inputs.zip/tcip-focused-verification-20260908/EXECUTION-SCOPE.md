# Execution scope of this focused verification

No new scientific calculation, test suite, linter, sampler, census, producer or source query was executed. The original scientific review's deterministic calculation remains one original run at exit 0; its script, JSON, stdout and exit bytes are retained as original evidence.

Current interpreter used for byte retention and reading helpers:

`C:/Users/mcrae/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe`

Current workspace:

`C:/Users/mcrae/Documents/Codex/2026-09-07/emc-research-orchestrator/work/tcip-focused-verification-20260908`

The following are actual current helper invocations, not scientific verification tests:

| Helper | Actual outcome | Receipt |
|---|---|---|
| `bind_evidence.py` | exit 0; fifteen immutable dependencies byte-identical to original review copies; exact retained source copies added | `evidence-intake.stdout.jsonl`, `evidence-intake.stderr.txt`, `evidence-intake.exit.txt`, `dependency-byte-comparison.json` |
| `inspect_retained_records.py` | exit 0; twelve existing run-record sets and two existing search-index arrays inspected | `reading-receipt.stdout.jsonl`, `reading-receipt.stderr.txt`, `reading-receipt.exit.txt`, `retained-record-reading.json` |
| `finalize_manifest.py` | exit 0; 110 retained inputs still byte-exact; seven source copies match original manifest sizes/SHA256/Git blob IDs | `manifest-finalization.stdout.json`, `manifest-finalization.stderr.txt`, `manifest-finalization.exit.txt`, `source-identity-receipt.json` |

Each helper was run as the named Python interpreter followed by the absolute workspace script path, with `PYTHONIOENCODING=utf-8`; stdout/stderr were redirected to the corresponding receipt paths and PowerShell's actual `$LASTEXITCODE` written to the exit file. The source scripts specify every dependency and pin they read. Git reads set `GIT_NO_LAZY_FETCH=1` and `GIT_TERMINAL_PROMPT=0`; there was no fetch. Source-copy blob identities were computed from local bytes, not retrieved.

`retain.py` and `read_lines.py` support earlier intake and text reading; `main-intake.stdout.jsonl`, `author-intake.stdout.jsonl`, and `review-basis-intake.stdout.jsonl` retain those intake records. Their tool invocations completed at exit 0; separate raw stderr/exit files were not created for those first three intake batches and are not reconstructed here. Two later original reading-helper scripts were retained by direct `retain.py --external` invocation, exit 0 in the tool record. Those additions did not execute either original helper.

Some ordinary reader invocations produced truncated tool displays, and a PowerShell `rg` invocation passed a wildcard in the path rather than as a glob and produced an invalid-path error. Required material was then read with explicit paths and bounded output. These were reading operations, not original source or scientific check failures; none is counted as scientific validation. No absent historical output was recreated.

Original author execution records remain separate under `provenance-originals/`, mapped from their full original `checks/NN-.../` locations in `REVIEWED-INPUT-MANIFEST.json` and `retained-record-reading.json`. The failed style runs (exit 1), wrong citation/consistency CLI attempts (exit 2), and repository citation/consistency failures (exit 1) are preserved. Parent TCIP patch check/apply originals (both `EXIT=0`) are also retained. Full detailed interpretation and limits are in the focused report.
