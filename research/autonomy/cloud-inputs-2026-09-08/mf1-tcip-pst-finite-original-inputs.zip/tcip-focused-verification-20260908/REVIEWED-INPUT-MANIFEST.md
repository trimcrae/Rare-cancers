# TCIP focused verification — exact input manifest

All inputs are retained under this workspace. Full-file hashes do not imply full scientific review; scopes below are explicit. Main/SI f6107376, PUB-TCIP graph 806ab2ec. Later sizing-memo banner excluded.

## 1. tcip-induced-interface-preprint.md
- Source: `f6107376cc41344f2296f2ada46c064d8251a3f8:research/manuscripts/tcip/tcip-induced-interface-preprint.md`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\pinned\research\manuscripts\tcip\tcip-induced-interface-preprint.md`
- Bytes: 51625; SHA256: `d211e11afe565a734282d3830e5223efaf79590add7de36769eb2eac361f0e20`
- Git blob: `39ee3a41c596e541198c0174db9fc59dae6b566d`
- Scope: Full main manuscript, lines 1-722; thirteen-finding focused verification and current-claim consistency.

## 2. tcip-induced-interface-preprint-si.md
- Source: `f6107376cc41344f2296f2ada46c064d8251a3f8:research/manuscripts/tcip/tcip-induced-interface-preprint-si.md`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\pinned\research\manuscripts\tcip\tcip-induced-interface-preprint-si.md`
- Bytes: 35997; SHA256: `72d21e7f4893f3a9103400a64d05304236707aa2e8f27d2057348ea03de2a19e`
- Git blob: `50d221b5835f1947e808b6ef09dc739886ff09ce`
- Scope: Full SI, lines 1-535; thirteen-finding focused verification and numerical/source interpretation.

## 3. d64fb39f23-BEFORE-tcip-induced-interface-preprint-si.md
- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\f6107376\TCIP-repair\BEFORE-tcip-induced-interface-preprint-si.md`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\d64fb39f23-BEFORE-tcip-induced-interface-preprint-si.md`
- Bytes: 16663; SHA256: `3483c0bbcbd94e4faa5b3de38da8010130b189336b79ac27cd08101c56748ba3`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Retained original BEFORE/diff bytes for repair provenance; no additional full baseline or independent diff-only claim acceptance.

## 4. ebcdbd2da0-BEFORE-tcip-induced-interface-preprint.md
- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\f6107376\TCIP-repair\BEFORE-tcip-induced-interface-preprint.md`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\ebcdbd2da0-BEFORE-tcip-induced-interface-preprint.md`
- Bytes: 28068; SHA256: `2e2b7862c3c6412ff4ae9086fd2acca799ae8999511ca607d1a49e416e82d9a9`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Retained original BEFORE/diff bytes for repair provenance; no additional full baseline or independent diff-only claim acceptance.

## 5. 5d80ecf7cd-CHECK-RUN-RECORD.txt
- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\f6107376\TCIP-repair\CHECK-RUN-RECORD.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\5d80ecf7cd-CHECK-RUN-RECORD.txt`
- Bytes: 4729; SHA256: `26353049505f4c6dbe372fd7e44fd649f59fac62286ab229f8b1923cd89fb6b7`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Full original handoff/response/authority record read; author-applied labels are not assumed scientific closure.

## 6. 01860760ec-CONTRACT-TCIP-F01-F13-author-repair.md
- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\f6107376\TCIP-repair\CONTRACT-TCIP-F01-F13-author-repair.md`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\01860760ec-CONTRACT-TCIP-F01-F13-author-repair.md`
- Bytes: 6343; SHA256: `fec3e78701de82f864eb0e9d2f74442cd94c274c4ebb8780dd599befbfe54c8b`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Full original handoff/response/authority record read; author-applied labels are not assumed scientific closure.

## 7. 1952ad9dd4-FINDING-MAP.md
- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\f6107376\TCIP-repair\FINDING-MAP.md`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\1952ad9dd4-FINDING-MAP.md`
- Bytes: 18530; SHA256: `6af091c6fffd2666d848e3d46780c1074b25b2e157d3c6276fc4a5c9db8d9cf7`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Full original handoff/response/authority record read; author-applied labels are not assumed scientific closure.

## 8. a9a672713b-IDENTITIES.md
- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\f6107376\TCIP-repair\IDENTITIES.md`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\a9a672713b-IDENTITIES.md`
- Bytes: 7800; SHA256: `bcf02b0833ae1cdbd940d50aab91f04db8ecda1c0e1107c24d0f01a37192178d`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Full original handoff/response/authority record read; author-applied labels are not assumed scientific closure.

## 9. 3060d152a1-RESIDUAL-LIMITATIONS.md
- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\f6107376\TCIP-repair\RESIDUAL-LIMITATIONS.md`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\3060d152a1-RESIDUAL-LIMITATIONS.md`
- Bytes: 7508; SHA256: `001fdc6fad37f38d78e18bbc45fbe4cb882c12122abf47959fdaa9c963bdf66b`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Full original handoff/response/authority record read; author-applied labels are not assumed scientific closure.

## 10. e6f34b68d1-SIZING-MEMO-CARRYOVER.md
- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\f6107376\TCIP-repair\SIZING-MEMO-CARRYOVER.md`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\e6f34b68d1-SIZING-MEMO-CARRYOVER.md`
- Bytes: 5010; SHA256: `70a954b3e934d53bd68302824f2608318cb32ba2ae8822600e9543850206fb0f`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Full original handoff/response/authority record read; author-applied labels are not assumed scientific closure.

## 11. 4e1b9af943-command.txt
- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\f6107376\TCIP-repair\checks\01-lint_style-BEFORE\command.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\4e1b9af943-command.txt`
- Bytes: 285; SHA256: `a373e1a60aacd6bc1b96d489015565a17528d90dbb7b3d3a3b95630cf268d565`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Full original command/exit record read; no rerun.

## 12. dcf5610c80-exit_code.txt
- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\f6107376\TCIP-repair\checks\01-lint_style-BEFORE\exit_code.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\dcf5610c80-exit_code.txt`
- Bytes: 2; SHA256: `9a271f2a916b0b6ee6cecb2426f0b3206ef074578be55d9bc94f6f3fe3ab86aa`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Full original command/exit record read; no rerun.

## 13. 5c343fad1b-stderr.txt
- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\f6107376\TCIP-repair\checks\01-lint_style-BEFORE\stderr.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\5c343fad1b-stderr.txt`
- Bytes: 0; SHA256: `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Full original stream read where short (including empty streams); original outcomes retained, not rerun.

## 14. 3408a7e0dd-stdout.txt
- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\f6107376\TCIP-repair\checks\01-lint_style-BEFORE\stdout.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\3408a7e0dd-stdout.txt`
- Bytes: 536; SHA256: `e9959b66a2afc3368e0aab07bce173c5641b68be869e2f90808f41dd6ba3dbe9`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Full original stream read where short (including empty streams); original outcomes retained, not rerun.

## 15. 98f7c92925-command.txt
- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\f6107376\TCIP-repair\checks\02-lint_style-AFTER\command.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\98f7c92925-command.txt`
- Bytes: 177; SHA256: `41fca15e5899929824b8d3a9291dd0bf77c5edda667d9416c176d5c6b44c37b1`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Full original command/exit record read; no rerun.

## 16. d4afef0cd7-exit_code.txt
- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\f6107376\TCIP-repair\checks\02-lint_style-AFTER\exit_code.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\d4afef0cd7-exit_code.txt`
- Bytes: 2; SHA256: `9a271f2a916b0b6ee6cecb2426f0b3206ef074578be55d9bc94f6f3fe3ab86aa`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Full original command/exit record read; no rerun.

## 17. 4a54ccdd80-stderr.txt
- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\f6107376\TCIP-repair\checks\02-lint_style-AFTER\stderr.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\4a54ccdd80-stderr.txt`
- Bytes: 0; SHA256: `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Full original stream read where short (including empty streams); original outcomes retained, not rerun.

## 18. 3cee829133-stdout.txt
- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\f6107376\TCIP-repair\checks\02-lint_style-AFTER\stdout.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\3cee829133-stdout.txt`
- Bytes: 390; SHA256: `39b36c795bce1c98d1cef117bbe6f0ae9681369c8af70d0992e0420c371a47dd`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Full original stream read where short (including empty streams); original outcomes retained, not rerun.

## 19. f412b68846-command.txt
- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\f6107376\TCIP-repair\checks\03-lint_style-AFTER-check\command.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\f412b68846-command.txt`
- Bytes: 168; SHA256: `51bdaf208c606946364a58e05dd85ba7cae780aaf986d29ba49040030f603da6`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Full original command/exit record read; no rerun.

## 20. c9076b2dbe-exit_code.txt
- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\f6107376\TCIP-repair\checks\03-lint_style-AFTER-check\exit_code.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\c9076b2dbe-exit_code.txt`
- Bytes: 2; SHA256: `4355a46b19d348dc2f57c046f8ef63d4538ebb936000f3c9ee954a27460dd865`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Full original command/exit record read; no rerun.

## 21. 5b06f719b8-stderr.txt
- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\f6107376\TCIP-repair\checks\03-lint_style-AFTER-check\stderr.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\5b06f719b8-stderr.txt`
- Bytes: 0; SHA256: `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Full original bytes retained; error summaries/categories and before/after outcome examined, not every style item independently adjudicated.

## 22. 5085aaa3b9-stdout.txt
- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\f6107376\TCIP-repair\checks\03-lint_style-AFTER-check\stdout.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\5085aaa3b9-stdout.txt`
- Bytes: 18862; SHA256: `5a73318719e0cbcf709211ded3946be95c95f1ad01b2065b7ec2f2234496af9d`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Full original bytes retained; error summaries/categories and before/after outcome examined, not every style item independently adjudicated.

## 23. 7809e1e860-command.txt
- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\f6107376\TCIP-repair\checks\04-lint_claims-AFTER\command.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\7809e1e860-command.txt`
- Bytes: 169; SHA256: `2e71cee62b7b61bd92de79cef2f3adfd200fdc8e7b7ff4944766c62e8093e664`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Full original command/exit record read; no rerun.

## 24. 0f37e29694-exit_code.txt
- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\f6107376\TCIP-repair\checks\04-lint_claims-AFTER\exit_code.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\0f37e29694-exit_code.txt`
- Bytes: 2; SHA256: `9a271f2a916b0b6ee6cecb2426f0b3206ef074578be55d9bc94f6f3fe3ab86aa`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Full original command/exit record read; no rerun.

## 25. 48fb32441b-stderr.txt
- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\f6107376\TCIP-repair\checks\04-lint_claims-AFTER\stderr.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\48fb32441b-stderr.txt`
- Bytes: 0; SHA256: `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Full original stream read where short (including empty streams); original outcomes retained, not rerun.

## 26. 65de5a76c6-stdout.txt
- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\f6107376\TCIP-repair\checks\04-lint_claims-AFTER\stdout.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\65de5a76c6-stdout.txt`
- Bytes: 892; SHA256: `b0802711d81c6ffdb9f3e53d3c82e4a6aa90d39c7be1c0a91186f404df738e35`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Full original stream read where short (including empty streams); original outcomes retained, not rerun.

## 27. e9a16256fe-command.txt
- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\f6107376\TCIP-repair\checks\05-lint_citations-AFTER\command.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\e9a16256fe-command.txt`
- Bytes: 172; SHA256: `636bb69740ca82617a990b0cb87d17ab01fba3aa7d3da28b213fe11d65b56b3b`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Full original command/exit record read; no rerun.

## 28. 3ae06e42b9-exit_code.txt
- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\f6107376\TCIP-repair\checks\05-lint_citations-AFTER\exit_code.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\3ae06e42b9-exit_code.txt`
- Bytes: 2; SHA256: `53c234e5e8472b6ac51c1ae1cab3fe06fad053beb8ebfd8977b010655bfdd3c3`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Full original command/exit record read; no rerun.

## 29. 1b4a3120d4-stderr.txt
- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\f6107376\TCIP-repair\checks\05-lint_citations-AFTER\stderr.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\1b4a3120d4-stderr.txt`
- Bytes: 229; SHA256: `c8528b839587a7e9cf27a6ce8fff77f90861c4fc1a617decf7a2e888cee7153d`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Full original stream read where short (including empty streams); original outcomes retained, not rerun.

## 30. 77ecd90ba7-stdout.txt
- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\f6107376\TCIP-repair\checks\05-lint_citations-AFTER\stdout.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\77ecd90ba7-stdout.txt`
- Bytes: 0; SHA256: `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Full original stream read where short (including empty streams); original outcomes retained, not rerun.

## 31. 6c032557c9-command.txt
- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\f6107376\TCIP-repair\checks\06-lint_consistency-AFTER\command.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\6c032557c9-command.txt`
- Bytes: 174; SHA256: `ff544b1fb118e00cd1635404f3c753642d8884731bf25ace2ee8f1b5fac06cac`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Full original command/exit record read; no rerun.

## 32. 9e2c6b6cd2-exit_code.txt
- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\f6107376\TCIP-repair\checks\06-lint_consistency-AFTER\exit_code.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\9e2c6b6cd2-exit_code.txt`
- Bytes: 2; SHA256: `53c234e5e8472b6ac51c1ae1cab3fe06fad053beb8ebfd8977b010655bfdd3c3`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Full original command/exit record read; no rerun.

## 33. a2308807a6-stderr.txt
- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\f6107376\TCIP-repair\checks\06-lint_consistency-AFTER\stderr.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\a2308807a6-stderr.txt`
- Bytes: 232; SHA256: `cfedd8b8ea585dd22d46c531da529150629e7bc25a00eea588e0513ef2f98c56`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Full original stream read where short (including empty streams); original outcomes retained, not rerun.

## 34. 417c122146-stdout.txt
- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\f6107376\TCIP-repair\checks\06-lint_consistency-AFTER\stdout.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\417c122146-stdout.txt`
- Bytes: 0; SHA256: `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Full original stream read where short (including empty streams); original outcomes retained, not rerun.

## 35. b90924c21f-command.txt
- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\f6107376\TCIP-repair\checks\07-lint_style-BEFORE-check\command.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\b90924c21f-command.txt`
- Bytes: 276; SHA256: `5f0c653dbe688e0e19e087b980c8573bb2a49c875bc70c1890e94a8ff2de4ef7`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Full original command/exit record read; no rerun.

## 36. 41e29d7123-exit_code.txt
- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\f6107376\TCIP-repair\checks\07-lint_style-BEFORE-check\exit_code.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\41e29d7123-exit_code.txt`
- Bytes: 2; SHA256: `4355a46b19d348dc2f57c046f8ef63d4538ebb936000f3c9ee954a27460dd865`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Full original command/exit record read; no rerun.

## 37. 5acc71c9d7-stderr.txt
- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\f6107376\TCIP-repair\checks\07-lint_style-BEFORE-check\stderr.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\5acc71c9d7-stderr.txt`
- Bytes: 0; SHA256: `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Full original bytes retained; error summaries/categories and before/after outcome examined, not every style item independently adjudicated.

## 38. 904fed84e2-stdout.txt
- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\f6107376\TCIP-repair\checks\07-lint_style-BEFORE-check\stdout.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\904fed84e2-stdout.txt`
- Bytes: 32878; SHA256: `dd47b0798822fa76a16b6f220074a45a3ba3f1e6d3bc7c15f69fa9bf212ce52f`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Full original bytes retained; error summaries/categories and before/after outcome examined, not every style item independently adjudicated.

## 39. 87752f5e70-command.txt
- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\f6107376\TCIP-repair\checks\08-lint_citations-repo\command.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\87752f5e70-command.txt`
- Bytes: 47; SHA256: `81e783cb4330a099779ee15d412e5eb28a3273e10bcd8253ed5b7b3c1f75c880`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Full original command/exit record read; no rerun.

## 40. 199c4f02aa-exit_code.txt
- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\f6107376\TCIP-repair\checks\08-lint_citations-repo\exit_code.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\199c4f02aa-exit_code.txt`
- Bytes: 2; SHA256: `4355a46b19d348dc2f57c046f8ef63d4538ebb936000f3c9ee954a27460dd865`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Full original command/exit record read; no rerun.

## 41. 8d85c50573-stderr.txt
- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\f6107376\TCIP-repair\checks\08-lint_citations-repo\stderr.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\8d85c50573-stderr.txt`
- Bytes: 175441; SHA256: `38cbcb4c9e0287daf8fcf6528b6105011e21990960e40cf78dfe5f3a4d38297a`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Full original bytes retained; TCIP-filename membership scanned in both streams, diagnostic/header/footer scope inspected. Unrelated repository failures not individually adjudicated.

## 42. 46783e00b2-stdout.txt
- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\f6107376\TCIP-repair\checks\08-lint_citations-repo\stdout.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\46783e00b2-stdout.txt`
- Bytes: 303123; SHA256: `a400b16ea7f348353f9175ea3199d2eeabe6ef38b69bd8e03c4f136a778099c0`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Full original bytes retained; TCIP-filename membership scanned in both streams, diagnostic/header/footer scope inspected. Unrelated repository failures not individually adjudicated.

## 43. f2bc18477a-command.txt
- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\f6107376\TCIP-repair\checks\09-lint_consistency-repo\command.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\f2bc18477a-command.txt`
- Bytes: 49; SHA256: `045794f708c3ae673d990198b0f5bbd35376e2cac3395124afcea8f090ee7fb6`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Full original command/exit record read; no rerun.

## 44. 04cae80108-exit_code.txt
- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\f6107376\TCIP-repair\checks\09-lint_consistency-repo\exit_code.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\04cae80108-exit_code.txt`
- Bytes: 2; SHA256: `4355a46b19d348dc2f57c046f8ef63d4538ebb936000f3c9ee954a27460dd865`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Full original command/exit record read; no rerun.

## 45. 742a89b8ad-stderr.txt
- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\f6107376\TCIP-repair\checks\09-lint_consistency-repo\stderr.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\742a89b8ad-stderr.txt`
- Bytes: 0; SHA256: `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Full original stream read where short (including empty streams); original outcomes retained, not rerun.

## 46. 45cdeae1b9-stdout.txt
- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\f6107376\TCIP-repair\checks\09-lint_consistency-repo\stdout.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\45cdeae1b9-stdout.txt`
- Bytes: 1043; SHA256: `0df71748e475108572ad27656fb20eba909236a6669f829e4539c2de1dfa6647`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Full original stream read where short (including empty streams); original outcomes retained, not rerun.

## 47. f6c1cd838a-command.txt
- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\f6107376\TCIP-repair\checks\10-lint_claims-BEFORE\command.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\f6c1cd838a-command.txt`
- Bytes: 277; SHA256: `b760960ebe97ac57421259a906caca24497c2468ed5c441eb67ac457b1866f90`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Full original command/exit record read; no rerun.

## 48. 570dca780d-exit_code.txt
- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\f6107376\TCIP-repair\checks\10-lint_claims-BEFORE\exit_code.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\570dca780d-exit_code.txt`
- Bytes: 2; SHA256: `9a271f2a916b0b6ee6cecb2426f0b3206ef074578be55d9bc94f6f3fe3ab86aa`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Full original command/exit record read; no rerun.

## 49. ef12cec343-stderr.txt
- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\f6107376\TCIP-repair\checks\10-lint_claims-BEFORE\stderr.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\ef12cec343-stderr.txt`
- Bytes: 0; SHA256: `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Full original stream read where short (including empty streams); original outcomes retained, not rerun.

## 50. 667a4367bf-stdout.txt
- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\f6107376\TCIP-repair\checks\10-lint_claims-BEFORE\stdout.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\667a4367bf-stdout.txt`
- Bytes: 34; SHA256: `5eaccda7f0580ca57caee5666e40937a1ef9aecf04acd01804ee9b5130e398f3`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Full original stream read where short (including empty streams); original outcomes retained, not rerun.

## 51. 3f2a318b12-tcip-induced-interface-preprint-si.md.diff
- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\f6107376\TCIP-repair\DIFFS\tcip-induced-interface-preprint-si.md.diff`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\3f2a318b12-tcip-induced-interface-preprint-si.md.diff`
- Bytes: 49162; SHA256: `f47b86975d0dd266ae9f4cac33863e936ca7d59f6e5e1754d8e398190dad88ac`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Retained original BEFORE/diff bytes for repair provenance; no additional full baseline or independent diff-only claim acceptance.

## 52. abe2d40127-tcip-induced-interface-preprint.md.diff
- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\f6107376\TCIP-repair\DIFFS\tcip-induced-interface-preprint.md.diff`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\abe2d40127-tcip-induced-interface-preprint.md.diff`
- Bytes: 79395; SHA256: `f45a0ed499a171efe12155ccaa2f5607414c841792db5e76e88b0ad98c228823`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Retained original BEFORE/diff bytes for repair provenance; no additional full baseline or independent diff-only claim acceptance.

## 53. eaf631462f-0001-systems-graph-publications-PUB-TCIP-narrowed.patch
- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\f6107376\TCIP-repair\patches\0001-systems-graph-publications-PUB-TCIP-narrowed.patch`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\eaf631462f-0001-systems-graph-publications-PUB-TCIP-narrowed.patch`
- Bytes: 5872; SHA256: `f573ed19ffd9a735c95c8742963ea4bf6d30205b04e1b10a2345fba5fb2b7832`
- Git blob: `external original; see original-source binding where applicable`
- Scope: TCIP graph replacement inspected and compared with actual settled entry; patch alone not treated as applied authority.

## 54. b3f5e3deaf-README-patches.md
- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\f6107376\TCIP-repair\patches\README-patches.md`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\b3f5e3deaf-README-patches.md`
- Bytes: 3839; SHA256: `ece591e749e4c784197ff0f9d999ce6541cfc1e7ba741e46da6cce0a94c0f350`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Retained original provenance/identity context; not fully scientifically rereviewed. Scope is limited to the thirteen-finding verification described in the report.

## 55. 7bbfab81d4-FINAL-SCIENTIFIC-REVIEW-TCIP.md
- Source: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-final-review-20260908\FINAL-SCIENTIFIC-REVIEW-TCIP.md`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\7bbfab81d4-FINAL-SCIENTIFIC-REVIEW-TCIP.md`
- Bytes: 52425; SHA256: `a00bec7213282192725722bb84736470868523acaa13766c2dac44ea4da82101`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Full original review/adjudication text read and all thirteen accepted findings used; preserved without edits.

## 56. 61d9ccd9cb-SOURCE-INTAKE-ADDENDUM-20260908.md
- Source: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-final-review-20260908\SOURCE-INTAKE-ADDENDUM-20260908.md`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\61d9ccd9cb-SOURCE-INTAKE-ADDENDUM-20260908.md`
- Bytes: 19411; SHA256: `7d2941dbbd64c080b37ac619ff4532b66134d7eb782b9fdb3377c0c101ff77f6`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Full original review/adjudication text read and all thirteen accepted findings used; preserved without edits.

## 57. 949cbce874-TCIP-final-review-root-adjudication-20260908.md
- Source: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\TCIP-final-review-root-adjudication-20260908.md`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\949cbce874-TCIP-final-review-root-adjudication-20260908.md`
- Bytes: 5859; SHA256: `131a610dcf3b76afad00f53a0aca47020f44864edc56a84174b724c05bb9e13c`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Full original review/adjudication text read and all thirteen accepted findings used; preserved without edits.

## 58. basin_geom.py
- Source: `f6107376cc41344f2296f2ada46c064d8251a3f8:research/modalities/basin_geom.py`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\pinned\research\modalities\basin_geom.py`
- Bytes: 26626; SHA256: `db8cef6b0f34f105154be576734601228cdf2dbb9c857b7e03b92fd458f7f4f2`
- Git blob: `74a63fcc34e8bd6b34ac3bf034b7c848ce78f6c5`
- Scope: Targeted static reading: grid-centre distance field, clamp/slack and lookup (259-331); no distance calculation.

## 59. nr4a3_basin_search.py
- Source: `f6107376cc41344f2296f2ada46c064d8251a3f8:research/modalities/nr4a3_basin_search.py`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\pinned\research\modalities\nr4a3_basin_search.py`
- Bytes: 105384; SHA256: `0d045aeaec7fce3700b0256aba3070616d5238b3d915c75e2b3e6dba7d0fdec0`
- Git blob: `aeea8233be2feb867c45128aca827717afcbeff1`
- Scope: Targeted static reading: parameter, CA/centroid query construction (460-475), radial draw and full admission loop (542-622). No execution.

## 60. nr4a3_induced_interface_census.py
- Source: `f6107376cc41344f2296f2ada46c064d8251a3f8:research/modalities/nr4a3_induced_interface_census.py`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\pinned\research\modalities\nr4a3_induced_interface_census.py`
- Bytes: 37591; SHA256: `3ca36c4d7f840c94c511f6a1c0feea1390b9292c8db8599989b9dcfccf35b391`
- Git blob: `31ec026e05aa336c4e7d4f1f03440306c35aadf2`
- Scope: Targeted static reading: query construction, exact score, protein/ligand eligibility and zero filter (433-610), induced class/summary logic as required by unchanged original review, CLI (685-692). No execution or new geometry.

## 61. nr4a3_tcip_reach.py
- Source: `f6107376cc41344f2296f2ada46c064d8251a3f8:research/modalities/nr4a3_tcip_reach.py`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\pinned\research\modalities\nr4a3_tcip_reach.py`
- Bytes: 111977; SHA256: `6d5908ef1c639fb79010b5f7d489e31a4356e99b2b8ef72cd18d93c0f1f89ce9`
- Git blob: `a051f1cf028d90a0305be255aae309a74c3ca06a`
- Scope: Targeted static reading: cross-run criterion (580-608), ablation (611-670), verdict default (870-902), build/grid/seeds (1541-1600), full-build verdict and refresh path (1699, 1704-1769). No sampler/producer execution.

## 62. nr4a3-e3-arm-registry.json
- Source: `f6107376cc41344f2296f2ada46c064d8251a3f8:research/modalities/nr4a3-e3-arm-registry.json`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\pinned\research\modalities\nr4a3-e3-arm-registry.json`
- Bytes: 79042; SHA256: `04a6b769e7e8659702e59a4a7433a7cd2f7ad4ad6e1ed53828c949e4c1ceefad`
- Git blob: `f60e9bc91084e84065f54942537a3f4109b6d06b`
- Scope: Targeted coordinate-result paths and staged-arm metadata supporting reproduction limits; no full registry audit or coordinate loading.

## 63. nr4a3-effector-arm-registry.json
- Source: `f6107376cc41344f2296f2ada46c064d8251a3f8:research/modalities/nr4a3-effector-arm-registry.json`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\pinned\research\modalities\nr4a3-effector-arm-registry.json`
- Bytes: 58985; SHA256: `03d2c1798404dcd1db097c1ff7d04c5fda135d9c4fda652532bea9d3236a701a`
- Git blob: `d097413aa5458451926955653da47637cadf69fa`
- Scope: Targeted coordinate-result paths and staged-arm metadata supporting reproduction limits; no full registry audit or coordinate loading.

## 64. nr4a3-induced-interface-census.json
- Source: `f6107376cc41344f2296f2ada46c064d8251a3f8:research/modalities/nr4a3-induced-interface-census.json`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\pinned\research\modalities\nr4a3-induced-interface-census.json`
- Bytes: 141666; SHA256: `5804422fdae00e6704c169eab4b92d59970b5ee5499c1e10f58a223c76d59b8d`
- Git blob: `b184a9d23198d7c56a6a69a87d60a2042ba5b67a`
- Scope: Class summaries and 9MZA/7LWG stored records, with original reviewed selected-pair arithmetic; zero-filter reasoning checked against code. No geometry remeasurement.

## 65. nr4a3-orientation-basins.json
- Source: `f6107376cc41344f2296f2ada46c064d8251a3f8:research/modalities/nr4a3-orientation-basins.json`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\pinned\research\modalities\nr4a3-orientation-basins.json`
- Bytes: 5861390; SHA256: `2ea22a0821a4268a8ca6c7e6284f952242d4782916bcad9041cef067fbf97270`
- Git blob: `b3694627efd3e1a007a3509afb64ebe1eba8103e`
- Scope: Unchanged original-review dependency identity; relevant 24-cell old-run counts used through the retained original diagnostic. No fresh full artifact audit.

## 66. nr4a3-tcip-reach.json
- Source: `f6107376cc41344f2296f2ada46c064d8251a3f8:research/modalities/nr4a3-tcip-reach.json`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\pinned\research\modalities\nr4a3-tcip-reach.json`
- Bytes: 332469; SHA256: `d962871998c17a680cf876e1676161a6d2c37f71e02c9ddf0867b68c1cadd604`
- Git blob: `5dc298b3af9c88da783b307aad51a919eb7ceb31`
- Scope: Existing main/ablation summaries, count inventories and named-arm/cross-check fields compared through retained original calculation and unchanged byte binding; not a new cell-level statistical reanalysis.

## 67. nr4a3-tcip-reach.md
- Source: `f6107376cc41344f2296f2ada46c064d8251a3f8:research/modalities/nr4a3-tcip-reach.md`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\pinned\research\modalities\nr4a3-tcip-reach.md`
- Bytes: 17518; SHA256: `499f220fde0274a3bfe26a6a5b91b36ccd3f53d2eaf8faa7e19c71312d67b663`
- Git blob: `7dfb05587f6b17ed83881e4a4fc3877efe1e61cc`
- Scope: Retained unchanged generated view for the existing named-effector erratum; inherited interpretation is not current authority. No full new review.

## 68. nr4a3-tcip-route-memo.md
- Source: `f6107376cc41344f2296f2ada46c064d8251a3f8:research/modalities/nr4a3-tcip-route-memo.md`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\pinned\research\modalities\nr4a3-tcip-route-memo.md`
- Bytes: 35843; SHA256: `5ad3b4d5cf7f405f48dfc8bdc405b5e441460bb2f66310c0bbec1fc5f08e05d1`
- Git blob: `9f9d6251149dafc7b98031fd5c7b3699244ea280`
- Scope: Retained unchanged historical quantity/provenance dependency; historical checks and retired ratios evaluated through original review and main corrections, not newly accepted as original execution evidence.

## 69. tcip-interface-floor-sizing.md
- Source: `f6107376cc41344f2296f2ada46c064d8251a3f8:research/manuscripts/tcip/tcip-interface-floor-sizing.md`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\pinned\research\manuscripts\tcip\tcip-interface-floor-sizing.md`
- Bytes: 21346; SHA256: `f865a51c85a01ad6392d7951492acd48fd8e2a151122063fa6987bf6057ba707`
- Git blob: `71847d43628ebf27a29c91cd578b8e7e5496d228`
- Scope: Unchanged historical memo identity and authority scope; carryover map and main/SI supersession read. Later root banner is outside freeze; no second full baseline of this memo.

## 70. selectivity-requirement-sizing.md
- Source: `f6107376cc41344f2296f2ada46c064d8251a3f8:research/manuscripts/degrader/selectivity-requirement-sizing.md`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\pinned\research\manuscripts\degrader\selectivity-requirement-sizing.md`
- Bytes: 53930; SHA256: `ce9be0baed9f350bc8fee615bdef37f2e091704b9110dd9ce358d5adf49dc648`
- Git blob: `700fb3bea7385c39f87cf539446289a7eaa1b7bc`
- Scope: Targeted binary derivation (100-126), assumptions and unsupported ternary transfer (384-398); no new scientific model run.

## 71. SKILL.md
- Source: `f6107376cc41344f2296f2ada46c064d8251a3f8:.claude/skills/paper-hardening/SKILL.md`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\pinned\.claude\skills\paper-hardening\SKILL.md`
- Bytes: 1937; SHA256: `497689024cf143920696031f265ddf69d58381ea2cce4a025871d85d38ede4ea`
- Git blob: `8818c1e784c3a0f1b0a6600f107b2a0fa3711525`
- Scope: Full skill read; finite review and honest execution evidence scope, subordinate to standing task authorization.

## 72. SKILL.md
- Source: `f6107376cc41344f2296f2ada46c064d8251a3f8:.claude/skills/repo-gates/SKILL.md`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\pinned\.claude\skills\repo-gates\SKILL.md`
- Bytes: 1794; SHA256: `228e27b07811a027d60e548d88e41e992280d788c2478aa2c7fb467af8cbafa1`
- Git blob: `a7f9add83ad42efa2c90b7bc3198721a6f0d8e09`
- Scope: Full skill read; finite review and honest execution evidence scope, subordinate to standing task authorization.

## 73. 2a1214db0a-induced-interface-vs-output-2026-08-07___index.json
- Source: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-final-review-20260908\source-intake\inputs\induced-interface-vs-output-2026-08-07___index.json`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\2a1214db0a-induced-interface-vs-output-2026-08-07___index.json`
- Bytes: 613998; SHA256: `44d8a43d13f1eef4848b1c1d1f2fe4eebe962e269dd8a665f5921c8f801dfb12`
- Git blob: `external original; see original-source binding where applicable`
- Scope: All-array metadata schema/inventory inspected plus original reviewed file-pointer inventory. Not a fresh abstract/full-text literature screen or term-count/classification reanalysis.
- Original source binding: `{"source_commit": "216bd1b5fb25a56b90ef3cc2373e1fe68322708f", "original_path": "literature/induced-interface-vs-output-2026-08-07/_index.json", "git_blob": "80f9e46734265876021e9816887ce22e58af6afc", "copy": "induced-interface-vs-output-2026-08-07___index.json"}`

## 74. 94b042bbcf-induced-proximity-transcription-2026-08-07___index.json
- Source: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-final-review-20260908\source-intake\inputs\induced-proximity-transcription-2026-08-07___index.json`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\94b042bbcf-induced-proximity-transcription-2026-08-07___index.json`
- Bytes: 184617; SHA256: `a9aa10d1e2445c72b492c319c6fc2913e47549dddda07fbf5b06c93b5595dee8`
- Git blob: `external original; see original-source binding where applicable`
- Scope: All-array metadata schema/inventory inspected plus original reviewed file-pointer inventory. Not a fresh abstract/full-text literature screen or term-count/classification reanalysis.
- Original source binding: `{"source_commit": "216bd1b5fb25a56b90ef3cc2373e1fe68322708f", "original_path": "literature/induced-proximity-transcription-2026-08-07/_index.json", "git_blob": "67125a84d72c42989005b60dd403a64add58b147", "copy": "induced-proximity-transcription-2026-08-07___index.json"}`

## 75. cfc1bdada2-MANIFEST.json
- Source: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-final-review-20260908\source-intake\inputs\MANIFEST.json`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\cfc1bdada2-MANIFEST.json`
- Bytes: 3808; SHA256: `7c5ad424f2c347eb28e2ac3d5c9d18b72b46412d4d62fb912383e2a7bc44509e`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Full original seven-source identity manifest read; each source matched against retained bytes during finalization.

## 76. 59e7e41348-SHA256SUMS.txt
- Source: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-final-review-20260908\source-intake\inputs\SHA256SUMS.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\59e7e41348-SHA256SUMS.txt`
- Bytes: 1602; SHA256: `de6eb0e6a8ab04bd83ac7b2b2a85b7693b2b762b2d3f5878d4f96a4ee7ea5610`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Original source-intake provenance retained; self-hash/verification limitations read through original addendum and current SI. Not a new transport audit.

## 77. 59daff1318-tcip-9mza-2026-08-07__cif_9MZA.txt
- Source: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-final-review-20260908\source-intake\inputs\tcip-9mza-2026-08-07__cif_9MZA.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\59daff1318-tcip-9mza-2026-08-07__cif_9MZA.txt`
- Bytes: 505711; SHA256: `b81668a1eaeb1eb40e74c99b65f093f647fd78eec30cecf201aa83006bc75780`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Material original mmCIF metadata: citation/entity/chain records 80-190, method 1642, resolution 1923, title/alignments/conflicts/assembly 2180-2350; no coordinate remeasurement or visual structural QA.
- Original source binding: `{"source_commit": "216bd1b5fb25a56b90ef3cc2373e1fe68322708f", "original_path": "literature/tcip-9mza-2026-08-07/cif_9MZA.txt", "git_blob": "5a28267017322ccdd531f16cf5534278d3c61019", "copy": "tcip-9mza-2026-08-07__cif_9MZA.txt"}`

## 78. ea2f7a3746-tcip-9mza-2026-08-07__rcsb_assembly_9MZA.txt
- Source: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-final-review-20260908\source-intake\inputs\tcip-9mza-2026-08-07__rcsb_assembly_9MZA.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\ea2f7a3746-tcip-9mza-2026-08-07__rcsb_assembly_9MZA.txt`
- Bytes: 3621; SHA256: `59e242396c964ca262928577809f234af5015526530ddcb6071cd04657221e3e`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Complete original assembly response, including A2B2, identity operation, FRET metadata, modeled/unmodeled totals; underlying experiment not inspected.
- Original source binding: `{"source_commit": "216bd1b5fb25a56b90ef3cc2373e1fe68322708f", "original_path": "literature/tcip-9mza-2026-08-07/rcsb_assembly_9MZA.txt", "git_blob": "5b29296c8e377a18ac630833b16ce5564774777d", "copy": "tcip-9mza-2026-08-07__rcsb_assembly_9MZA.txt"}`

## 79. ab6fb2df6c-tcip-9mza-2026-08-07__rcsb_entry_9MZA.txt
- Source: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-final-review-20260908\source-intake\inputs\tcip-9mza-2026-08-07__rcsb_entry_9MZA.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\ab6fb2df6c-tcip-9mza-2026-08-07__rcsb_entry_9MZA.txt`
- Bytes: 14803; SHA256: `5a333017d4fd48e561693c9a47373225abea2f7ff77e0c48d87716d6c10f07ff`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Original header plus struct/title, citation, accession dates, method/resolution and construct totals; not every ancillary JSON field.
- Original source binding: `{"source_commit": "216bd1b5fb25a56b90ef3cc2373e1fe68322708f", "original_path": "literature/tcip-9mza-2026-08-07/rcsb_entry_9MZA.txt", "git_blob": "cb483747c1bf9fc59d98a98d88c73aa96ee81cd9", "copy": "tcip-9mza-2026-08-07__rcsb_entry_9MZA.txt"}`

## 80. 7fa76f87b6-tcip-kat-structure-2026-08-07__epmc_kat_tcip_record.txt
- Source: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-final-review-20260908\source-intake\inputs\tcip-kat-structure-2026-08-07__epmc_kat_tcip_record.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\7fa76f87b6-tcip-kat-structure-2026-08-07__epmc_kat_tcip_record.txt`
- Bytes: 16691; SHA256: `0b3548cbf5eeb0ceca189e0b44fe355ad732d51a1fd6a8b9ca16aa38d4eee957`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Full retained response read, including both abstracts, citation/update relation and availability/license metadata. No primary full text acquired/read.
- Original source binding: `{"source_commit": "216bd1b5fb25a56b90ef3cc2373e1fe68322708f", "original_path": "literature/tcip-kat-structure-2026-08-07/epmc_kat_tcip_record.txt", "git_blob": "72349a3b9b249f1b4dcd678c08f4b4acc06852b4", "copy": "tcip-kat-structure-2026-08-07__epmc_kat_tcip_record.txt"}`

## 81. a37386b807-tcip-kat-structure-2026-08-07__rcsb_cite_pubmed_42476129.txt
- Source: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-final-review-20260908\source-intake\inputs\tcip-kat-structure-2026-08-07__rcsb_cite_pubmed_42476129.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\a37386b807-tcip-kat-structure-2026-08-07__rcsb_cite_pubmed_42476129.txt`
- Bytes: 764; SHA256: `78cbff3e1f58894848d8ff096868f83484d802658eea357c20ee2a2f2444e20e`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Full HTTP 400 invalid-attribute original read. Not a negative search or denial. No retry.
- Original source binding: `{"source_commit": "216bd1b5fb25a56b90ef3cc2373e1fe68322708f", "original_path": "literature/tcip-kat-structure-2026-08-07/rcsb_cite_pubmed_42476129.txt", "git_blob": "a8b2b7b6914e200b200fb0837c4b426a55d8fe44", "copy": "tcip-kat-structure-2026-08-07__rcsb_cite_pubmed_42476129.txt"}`

## 82. 6211b25a6f-TCIP-source-copy-verification.json
- Source: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-final-review-20260908\source-intake\inputs\TCIP-source-copy-verification.json`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\6211b25a6f-TCIP-source-copy-verification.json`
- Bytes: 6189; SHA256: `fe4c198dd5fee71aa6a3d65321d7a6bb7e0ee775ccd72750edeaa9908ec4933c`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Original source-intake provenance retained; self-hash/verification limitations read through original addendum and current SI. Not a new transport audit.

## 83. bba7bf118c-intake-verification.json
- Source: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-final-review-20260908\source-intake\intake-verification.json`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\bba7bf118c-intake-verification.json`
- Bytes: 7502; SHA256: `219220ab3d5dbc0cec23aa7f159a177e4a125b78fcfbb84e7929d435a25322ac`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Retained original provenance/identity context; not fully scientifically rereviewed. Scope is limited to the thirteen-finding verification described in the report.

## 84. e5c77c2f8a-material-record-excerpts.json
- Source: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-final-review-20260908\source-intake\material-record-excerpts.json`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\e5c77c2f8a-material-record-excerpts.json`
- Bytes: 218184; SHA256: `657cd8e925f4244321941dca0c3fff2051779f5bb5af765ea331d792c9757053`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Original reviewer reading aid retained, used for metadata/file-pointer context only; not an original response.

## 85. 3fa7cf93ec-REVIEWED-INPUT-MANIFEST.json
- Source: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-final-review-20260908\REVIEWED-INPUT-MANIFEST.json`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\3fa7cf93ec-REVIEWED-INPUT-MANIFEST.json`
- Bytes: 17890; SHA256: `bcd56cc2f6ba6a9515efe0911e7e42ac78acce74b161847480959ad5116eefc8`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Retained original provenance/identity context; not fully scientifically rereviewed. Scope is limited to the thirteen-finding verification described in the report.

## 86. bd7525b568-SOURCE-INTAKE-SUPPLEMENTAL-MANIFEST.json
- Source: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-final-review-20260908\SOURCE-INTAKE-SUPPLEMENTAL-MANIFEST.json`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\bd7525b568-SOURCE-INTAKE-SUPPLEMENTAL-MANIFEST.json`
- Bytes: 15534; SHA256: `6ab940f3f1f37c37f0c48c478167af95f876b3b96c868c7e10dab2a28dc1a0ee`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Retained original provenance/identity context; not fully scientifically rereviewed. Scope is limited to the thirteen-finding verification described in the report.

## 87. 336a7fc90f-reviewer_calculations.py
- Source: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-final-review-20260908\reviewer_calculations.py`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\336a7fc90f-reviewer_calculations.py`
- Bytes: 12641; SHA256: `647a7de893487ca0fdacfe4dba36591c1705af963a330d4fe96d6f182cd3e5fe`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Original script retained; scope/definitions inspected; original calculation outputs reused, script not executed in focused pass.

## 88. 02810a5df4-reviewer-calculations.json
- Source: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-final-review-20260908\reviewer-calculations.json`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\02810a5df4-reviewer-calculations.json`
- Bytes: 55463; SHA256: `ba6a8ffa3307b725bd4d3868b16b688336d5a71c794bc6cc7d8bc55d4de8bbee`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Original deterministic reviewer result sections read: inventory, rungs, ablation, seed design, diagnostic summary, census denominators/omissions, 9MZA, analytic examples, named verdict. No rerun; no new geometry.

## 89. 99fd3947a0-reviewer-calculations-stdout.txt
- Source: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-final-review-20260908\reviewer-calculations-stdout.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\99fd3947a0-reviewer-calculations-stdout.txt`
- Bytes: 55463; SHA256: `ba6a8ffa3307b725bd4d3868b16b688336d5a71c794bc6cc7d8bc55d4de8bbee`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Original complete stdout retained, byte-identical to original result JSON; interpreted as prior reviewer calculation evidence, not a new execution.

## 90. 0482584707-reviewer-calculations-exit.txt
- Source: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-final-review-20260908\reviewer-calculations-exit.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\0482584707-reviewer-calculations-exit.txt`
- Bytes: 3; SHA256: `13bf7b3039c63bf5a50491fa3cfd8eb4e699d1ba1436315aef9cbe5711530354`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Full original exit 0 record read; no rerun.

## 91. abe0d12dd8-MANIFEST.md
- Source: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-final-review-20260908\inputs\local\MANIFEST.md`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\abe0d12dd8-MANIFEST.md`
- Bytes: 15854; SHA256: `cff7b9317f3393a64e5f096aec0d8bf44ba1377087a395ebd580539484535e88`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Retained original provenance/identity context; not fully scientifically rereviewed. Scope is limited to the thirteen-finding verification described in the report.

## 92. 78a88eb3c1-HASHES.txt
- Source: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-final-review-20260908\inputs\local\HASHES.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\78a88eb3c1-HASHES.txt`
- Bytes: 2186; SHA256: `5f5f03217d265e27f22a3c6d6da3d72bcb304a659c06a38a7a2fc819b9871c93`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Retained original provenance/identity context; not fully scientifically rereviewed. Scope is limited to the thirteen-finding verification described in the report.

## 93. publications.json
- Source: `806ab2ecd06ff4fdc5d77c3229782d0948126b9f:systems/graph/publications.json`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\pinned\systems\graph\publications.json`
- Bytes: 68537; SHA256: `e31fa506bc2fd8ff7e594c0284aa4e30cd2c5c0da65f7e864e1bc05b0d61c6f9`
- Git blob: `d48182cfc4228c85bb7b920114509e80c0d01f26`
- Scope: Entire PUB-TCIP entry, lines 518-531 / $[29]; other publication entries not scientifically reviewed. Exact file hashed in full.

## 94. dcd898efdd-APPLIED-RECORD.md
- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\806ab2ec\PARENT-SHARED-PATCHES-2026-09-08\APPLIED-RECORD.md`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\dcd898efdd-APPLIED-RECORD.md`
- Bytes: 4821; SHA256: `a6d29a923783e793726f87b295fd8bdaabeada53666c8ff5958301a8925654cf`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Full original handoff/response/authority record read; author-applied labels are not assumed scientific closure.

## 95. 8758b1af58-SETTLED-IDENTITIES-2026-09-08.md
- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\806ab2ec\PARENT-SHARED-PATCHES-2026-09-08\SETTLED-IDENTITIES-2026-09-08.md`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\8758b1af58-SETTLED-IDENTITIES-2026-09-08.md`
- Bytes: 3913; SHA256: `7433a5ab6fcbf4c7c8cc39915cf1f5f4ce7beb248f81c43c248258f60601673d`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Full original handoff/response/authority record read; author-applied labels are not assumed scientific closure.

## 96. 1faebba443-command.txt
- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\806ab2ec\PARENT-SHARED-PATCHES-2026-09-08\checks\01-tcip-apply-check\command.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\1faebba443-command.txt`
- Bytes: 159; SHA256: `05702e7f22278b7e8312a226de793fddeb8bb03e5e95097c8cc13f309d00c644`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Full original command/exit record read; no rerun.

## 97. f3ae0074a8-exit_code.txt
- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\806ab2ec\PARENT-SHARED-PATCHES-2026-09-08\checks\01-tcip-apply-check\exit_code.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\f3ae0074a8-exit_code.txt`
- Bytes: 7; SHA256: `418a5c17f33c70e99b0cc0a07fce69191489cfedc94164bfa903785777c5bd4b`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Full original command/exit record read; no rerun.

## 98. 5e2c8c36b5-stderr.txt
- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\806ab2ec\PARENT-SHARED-PATCHES-2026-09-08\checks\01-tcip-apply-check\stderr.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\5e2c8c36b5-stderr.txt`
- Bytes: 0; SHA256: `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Full original stream read where short (including empty streams); original outcomes retained, not rerun.

## 99. ced9441a7b-stdout.txt
- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\806ab2ec\PARENT-SHARED-PATCHES-2026-09-08\checks\01-tcip-apply-check\stdout.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\ced9441a7b-stdout.txt`
- Bytes: 0; SHA256: `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Full original stream read where short (including empty streams); original outcomes retained, not rerun.

## 100. 54a0e549c6-command.txt
- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\806ab2ec\PARENT-SHARED-PATCHES-2026-09-08\checks\02-tcip-apply\command.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\54a0e549c6-command.txt`
- Bytes: 151; SHA256: `798a374183d00c65c36202649caf1177dcd69ee4d11d0beccd6732b481bebeff`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Full original command/exit record read; no rerun.

## 101. 6e4ee059b4-exit_code.txt
- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\806ab2ec\PARENT-SHARED-PATCHES-2026-09-08\checks\02-tcip-apply\exit_code.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\6e4ee059b4-exit_code.txt`
- Bytes: 7; SHA256: `418a5c17f33c70e99b0cc0a07fce69191489cfedc94164bfa903785777c5bd4b`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Full original command/exit record read; no rerun.

## 102. f7b1e02774-stderr.txt
- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\806ab2ec\PARENT-SHARED-PATCHES-2026-09-08\checks\02-tcip-apply\stderr.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\f7b1e02774-stderr.txt`
- Bytes: 0; SHA256: `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Full original stream read where short (including empty streams); original outcomes retained, not rerun.

## 103. 4124d2e61e-stdout.txt
- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\806ab2ec\PARENT-SHARED-PATCHES-2026-09-08\checks\02-tcip-apply\stdout.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\4124d2e61e-stdout.txt`
- Bytes: 0; SHA256: `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Full original stream read where short (including empty streams); original outcomes retained, not rerun.

## 104. lint_style.py
- Source: `f6107376cc41344f2296f2ada46c064d8251a3f8:research/manuscripts/lint_style.py`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\pinned\research\manuscripts\lint_style.py`
- Bytes: 30915; SHA256: `da6128a219630d9b12b298cfc2f55be4851fbeabcc586dfbd56ac8ba8b7fcbc5`
- Git blob: `f738f9ccab348b3ee89a1eeffad17f4eb3fd5905`
- Scope: Targeted CLI/default-target/report/return behavior and scientific limits of pattern checks; source inspected only, no linter executed.

## 105. lint_claims.py
- Source: `f6107376cc41344f2296f2ada46c064d8251a3f8:research/manuscripts/lint_claims.py`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\pinned\research\manuscripts\lint_claims.py`
- Bytes: 54309; SHA256: `49d2ad77b1ced0da659d861a9e9f1e7bcf9e3c5bd30dfd11e00d05b1eaed0a1b`
- Git blob: `a2bbcd714ef5d8dc89d1b89251a01067454b91f2`
- Scope: Targeted CLI/default-target/report/return behavior and scientific limits of pattern checks; source inspected only, no linter executed.

## 106. lint_citations.py
- Source: `f6107376cc41344f2296f2ada46c064d8251a3f8:research/manuscripts/lint_citations.py`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\pinned\research\manuscripts\lint_citations.py`
- Bytes: 39026; SHA256: `879db33f1a56548af8331c0319889fd7dfdb2776848b9fec6fb202cd4447c371`
- Git blob: `b70f80348c83efb8513e30ac69d047319574d446`
- Scope: Targeted CLI/default-target/report/return behavior and scientific limits of pattern checks; source inspected only, no linter executed.

## 107. lint_consistency.py
- Source: `f6107376cc41344f2296f2ada46c064d8251a3f8:research/manuscripts/lint_consistency.py`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\pinned\research\manuscripts\lint_consistency.py`
- Bytes: 36454; SHA256: `b171bdcaa3371269b28a511be26a6f3af7e7a31feb16932a01d302cf862d1657`
- Git blob: `04da92f98a0e77d50c8260329d4f21a6d77bae60`
- Scope: Targeted CLI/default-target/report/return behavior and scientific limits of pattern checks; source inspected only, no linter executed.

## 108. OPERATING_PROTOCOL.md
- Source: `f6107376cc41344f2296f2ada46c064d8251a3f8:research/autonomy/OPERATING_PROTOCOL.md`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\pinned\research\autonomy\OPERATING_PROTOCOL.md`
- Bytes: 10898; SHA256: `5a0051a18b88b7e0056a98f783ac22fe42099090c17698595715cb021411a9af`
- Git blob: `92e7795b7ab5f3e79101d789f451181181c4d33b`
- Scope: Review-with-an-endpoint section 44-65 and relevant scope search; not full operating-protocol audit.

## 109. cc5f0dbb92-inspect_source_records.py
- Source: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-final-review-20260908\inspect_source_records.py`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\cc5f0dbb92-inspect_source_records.py`
- Bytes: 2130; SHA256: `33b253cbe363cef30487a5b5de4ca9eca29adb398a4c6289ddb7d0955bd452bf`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Full final original reading-helper source read (strict=False for retained malformed response strings); no rerun or recreation of its first failure.

## 110. 855680b477-source_intake.py
- Source: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-final-review-20260908\source_intake.py`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\tcip-focused-verification-20260908\provenance-originals\855680b477-source_intake.py`
- Bytes: 2070; SHA256: `7a5d9ae733c90d4d8a1ce9f0f3603b58b7125714f0eb6ef6528fef4ec86ec47a`
- Git blob: `external original; see original-source binding where applicable`
- Scope: Original intake script retained for provenance only; not executed in this focused pass.
