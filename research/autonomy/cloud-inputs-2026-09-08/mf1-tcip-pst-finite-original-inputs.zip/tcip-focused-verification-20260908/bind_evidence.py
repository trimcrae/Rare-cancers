"""Retain existing bytes and compare immutable identities; no scientific execution."""
from pathlib import Path
import json, hashlib
import retain
base=Path('C:/Users/mcrae/Documents/Codex/2026-09-07/emc-research-orchestrator/work/tcip-final-review-20260908')
paths=['research/modalities/'+x for x in ['basin_geom.py','nr4a3_basin_search.py','nr4a3_induced_interface_census.py','nr4a3_tcip_reach.py','nr4a3-e3-arm-registry.json','nr4a3-effector-arm-registry.json','nr4a3-induced-interface-census.json','nr4a3-orientation-basins.json','nr4a3-tcip-reach.json','nr4a3-tcip-reach.md','nr4a3-tcip-route-memo.md']]
paths+=['research/manuscripts/tcip/tcip-interface-floor-sizing.md','research/manuscripts/degrader/selectivity-requirement-sizing.md','.claude/skills/paper-hardening/SKILL.md','.claude/skills/repo-gates/SKILL.md']
comparisons=[]
for p in paths:
    retain.retain(p)
    old=base/'inputs/frozen'/p
    now=retain.ROOT/'pinned'/p
    comparisons.append({'path':p,'current_pin':retain.PIN,'original_review_pin':'f43f1495f40d8aff7b4f34bd385d55aac521a500','byte_identical_to_original_review_copy':now.read_bytes()==old.read_bytes(),'original_copy_sha256':hashlib.sha256(old.read_bytes()).hexdigest()})
for p in [*sorted((base/'source-intake/inputs').glob('*')),base/'source-intake/intake-verification.json',base/'source-intake/material-record-excerpts.json',base/'REVIEWED-INPUT-MANIFEST.json',base/'SOURCE-INTAKE-SUPPLEMENTAL-MANIFEST.json',base/'reviewer_calculations.py',base/'reviewer-calculations.json',base/'reviewer-calculations-stdout.txt',base/'reviewer-calculations-exit.txt',base/'inputs/local/MANIFEST.md',base/'inputs/local/HASHES.txt']:
    retain.retain(str(p),'external')
retain.PIN='806ab2ecd06ff4fdc5d77c3229782d0948126b9f'
retain.retain('systems/graph/publications.json')
cap=Path('C:/Users/mcrae/.codex/review-workspaces/opus-capacity-sprint-20260907/capacity-campaign-20260908/observations/806ab2ec')
for p in sorted((cap/'PARENT-SHARED-PATCHES-2026-09-08').glob('*')):
    if p.is_file():retain.retain(str(p),'external')
(retain.ROOT/'dependency-byte-comparison.json').write_text(json.dumps(comparisons,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'compared_dependencies':len(comparisons),'all_byte_identical':all(x['byte_identical_to_original_review_copy'] for x in comparisons)}))
