#!/usr/bin/env python3
"""Citation PROVENANCE — does every identifier in prose trace to something fetched? ($0, stdlib)

⛔ WHY THIS EXISTS, AND IT IS NOT HYPOTHETICAL (2026-08-07). An agent drafting a manuscript wrote a
citation from RECOLLECTION: a PMID present in **no committed source anywhere in this repository**, on a
sentence attributing the fusion's cloning to a 1995 paper. **It passed `lint_claims.py` twice.** Six
invented titles and author-lists went out in the same pass. They were caught by a human-directed audit of
every identifier against the rest of the tree — by nothing automatic, in a repository whose FIRST golden
rule is "never fabricate medical facts, stats, citations or patient data".

⭐ THE REASON THE EXISTING GUARD CANNOT CATCH IT. `lint_claims.py` checks how strongly a claim is
WORDED — R1–R5 are about selectivity, efficacy, safety, therapeutic window and clinical readiness. A
fabricated PMID attached to a properly-hedged sentence is, to that linter, a perfect sentence. Claim
STRENGTH and citation PROVENANCE are orthogonal, and nothing in preflight's other gates reads an
identifier at all. This closes that, and only that.

⚠ WHAT "PROVENANCE" MEANS HERE, PRECISELY — it is a weaker and more honest test than "is this citation
real", which no offline checker can answer. An identifier is **ANCHORED** when it also appears in a
tracked `.json`/`.jsonl`. That matters because those files are FETCH PRODUCTS and graph records — an
identifier in one got there by a network read, a registry curation or a deliberate graph edit, none of
which a model can do from memory. An identifier that exists ONLY in prose has no such origin: it may be
a perfectly good citation nobody has needed in an artifact yet, or it may be invented, and **this
checker cannot tell those apart.** So it does not try. It requires that the unanchored ones be
ENUMERATED, and it fails on any that is not.

⭐ HENCE A LEDGER, NOT A WALL. On the day it was written 216 identifiers were prose-only. Failing the
build on all 216 would have produced a red gate that the next session turns off, which is worse than no
gate — so those are baselined as `unverified_at_baseline`. **That baseline is not an amnesty; it is the
finding.** It names, for the first time, exactly which citations in this repository nobody has ever
checked. The count is meant to FALL, exactly like `systems_check`'s `last_verified: unverified` count.
⛔ **What is NOT baselined is anything new.** A prose identifier that is neither anchored nor already in
the ledger is an ERROR the moment it is written — which is the case that actually happened.

⚠ AND THE LEDGER IS NOT SELF-SERVICE. Adding an entry by hand records a claim that someone checked it;
`--baseline` refuses to run once the ledger exists, so the only way to grow it is deliberate. Use
`--verify-online` (CI, $0, Europe PMC) to move an entry from `unverified_at_baseline` to `verified` with
the date and the returned title, which is how the count falls honestly rather than by relabelling.

Usage:
  python3 research/manuscripts/lint_citations.py                # check (preflight / CI)
  python3 research/manuscripts/lint_citations.py --baseline     # first-time ledger write, once only
  python3 research/manuscripts/lint_citations.py --report       # counts by kind and status, no exit code
"""
from __future__ import annotations

import argparse
import collections
import json
import os
import re
import subprocess
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import citation_scan_cache as _cache  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))
LEDGER = os.path.join(HERE, "citation-provenance-ledger.json")
#: The type guard's fetch cache — excluded from the anchor scan by `survey()`, see there.
TYPE_CACHE_REL = "research/manuscripts/citation-article-types.json"
#: The retraction sweep's fetch product — excluded from the anchor scan by `survey()` for the same
#: reason and with a measurement, 2026-09-01: this file's `records` map is keyed by EVERY prose
#: identifier in the repository, so leaving it in the scan took the unanchored counts from
#: PMID 30 / PMCID 17 / DOI 38 / NCT 7 / GEO 3 / arXiv 11 straight to **zero across all six kinds**
#: — a perfect green readout produced by adding a file, which is the 2026-08-07 self-anchoring
#: incident to the letter and on a wider blast radius.
SWEEP_ARTIFACT_REL = "research/manuscripts/citation-retraction-sweep.json"

#: ⚠ ANCHORED IS ABOUT ORIGIN, NOT ABOUT FILE TYPE. `.json`/`.jsonl` are what fetches, registry
#: curations and graph edits write; prose is what a model types. That asymmetry is the whole test.
ANCHOR_SUFFIXES = (".json", ".jsonl")

#: ⚠ KNOWN NARROW HOLE, MEASURED 2026-08-08 AND LEFT OPEN DELIBERATELY. A fetch corpus may carry a
#: KNOWN-NEGATIVE CONTROL — an identifier chosen because it must NOT resolve, proving the endpoint
#: can answer "not found" (the degrader audit used `PMID 99999999` this way). The scanner cannot tell
#: a control from a retrieval, so such an identifier ANCHORS ITSELF: cite it in prose and the gate
#: passes it. This is the 2026-08-07 self-anchoring incident's shape — an artifact that lists
#: identifiers as EXAMPLES being read as evidence FOR them — surviving in a corner the ledger fix did
#: not reach, because that fix excluded one named file rather than a class of use.
#: Not closed here because the honest repair is a corpus-side convention (mark control rows so the
#: scanner can skip them), which needs agreement across every `lit-targets-*.json` and is a schema
#: change, not a linter change. Recorded so the next reader finds it before a reviewer does.
PROSE_SUFFIXES = (".md",)

#: ⛔ Each pattern captures the BARE identifier so prose and artifact forms compare equal. A PMID
#: written `PMID: 12345678` and `PMID12345678` is one identifier, and a checker that treats them as
#: two reports fabrications that are not there and misses the one that is.
#: ⚠⚠ THIS COMMENT USED TO CLAIM `"pmid": "12345678"` WAS ALSO RECOGNISED. IT IS NOT, AND THE
#: FALSE CLAIM COST A DRAFTING AGENT A RED GATE (measured 2026-08-09). The `PMID` pattern requires
#: the literal token adjacent to the digits; in a JSON key the intervening `": "` breaks it, so a
#: lowercase `"pmid"` field anchors NOTHING. A prior-art artifact was written storing identifiers
#: that way, four agents were told it anchored them, and the first one to cite a PMID from it hit
#: gate 4. ⛔ THE FIX WENT IN THE ARTIFACT, NOT HERE — every record now also carries a
#: `pubmed_url`, which is the form a real fetch corpus produces and the one the next paragraph is
#: about. Loosening the pattern to match a bare `"pmid"` key would weaken the exact guarantee this
#: gate exists for: an identifier must appear in a context only a retrieval could have produced.
#: The lesson is the one CLAUDE.md keeps recording — a property asserted in a comment about code
#: is not a property, and this comment asserted it for over a day while being read as reassurance.
#: Superseded, retained: the claim that the JSON-key form is one of the recognised spellings.
#: ⛔ AND A FETCH CORPUS NAMES A PAPER BY URL, NOT BY THE STRING "PMID" (measured 2026-08-08).
#: Every `lit-targets-*.json` in this repo is a {name: url} map — that is what `fetch-literature.yml`
#: consumes — so a retrieved paper appears as `pubmed.ncbi.nlm.nih.gov/40828003`, as an Europe PMC
#: `EXT_ID:40828003`, or as a key like `epmc_core_40828003`, and NEVER as `PMID 40828003`. With only
#: the prefixed form recognised, the anchor scan was blind to the repository's own standard evidence
#: of a fetch: 22 distinct PMIDs were reachable ONLY through a URL inside a tracked artifact and every
#: one of them counted as unanchored.
#: ⚠ THE FAILURE DIRECTION IS THE DANGEROUS ONE — it manufactures FALSE fabrication alarms. A real
#: retrieval is reported in the same words as a citation typed from memory, and §7's warning applies
#: exactly: a gate that goes red on honest work gets switched off, taking the case it exists for with
#: it. Recognising the URL form does NOT loosen the test — a fabricated identifier appears in no
#: tracked artifact in ANY form, which is what `test_a_fabricated_pmid_still_fails` pins.
PATTERNS = {
    #: ⚠ EVERY FORM HERE IS ANCHORED TO A LITERAL CONTEXT — a PubMed host, or Europe PMC's `EXT_ID`.
    #: A bare-digit-run pattern (e.g. `_(\d{6,9})`, which WOULD have matched this corpus's
    #: `epmc_core_40828003` key) was written and then deleted before commit: it matches any 6-9 digit
    #: run after an underscore in any tracked JSON, so it could FALSELY ANCHOR a fabricated PMID that
    #: happened to collide with an unrelated number. That is the one direction this gate must never
    #: move, and a looser pattern buys nothing the two precise ones do not already reach.
    "PMID": (r"\bPMID[:\s]*(\d{6,9})\b",
             r"pubmed\.ncbi\.nlm\.nih\.gov/(\d{6,9})",
             r"\bEXT_ID[:=](\d{6,9})\b"),
    "PMCID": (r"\b(PMC\d{6,9})\b",),
    "DOI": (r"\b(10\.\d{4,9}/[^\s\)\]\},;\"'>]+)",),
    "NCT": (r"\b(NCT\d{8})\b",),
    "GEO": (r"\b(GS[EM]\d{3,7})\b",),
    #: ⛔ ADDED 2026-08-28 (AUT-PD-057). BEFORE THIS, EVERY arXiv IDENTIFIER IN THIS REPOSITORY WAS
    #: OUTSIDE THE GATE ENTIRELY — not baselined, not anchored, not counted; simply invisible. The
    #: repository's method-watch documents cite arXiv preprints by the dozen, so a mistyped or
    #: fabricated arXiv id passed every gate the same way the 2026-08-07 PMID did, and for a weaker
    #: reason: nothing was even looking.
    #: ⛔⛔ AND THE BARE FORM IS NOT MATCHED, DELIBERATELY — THIS IS THE WHOLE SAFETY ARGUMENT.
    #: A modern arXiv id is `YYMM.NNNNN`, which is four-to-five digits either side of a dot, and
    #: THAT SHAPE OCCURS INSIDE ORDINARY DOIs. Measured over this corpus on the day the pattern was
    #: written, a bare `\d{4}\.\d{4,5}` matched three prose "identifiers" that are not arXiv ids at
    #: all, every one a fragment of a real DOI: `10.1002/1878-0261.13558` -> `0261.13558`,
    #: `10.1111/j.1349-7006.2012.02370.x` -> `7006.2012`, `10.1111/1759-7714.14613` -> `7714.14613`.
    #: Each would have been reported as an unanchored citation — a fabrication alarm on a correctly
    #: cited paper, which §7 records as the fastest way to get a gate switched off. It also bought
    #: NOTHING: over every prose line in this repository that mentions arXiv, the three contextual
    #: forms below capture every id-shaped token on the line, residue zero. So the bare form adds
    #: only false positives, exactly as the same reasoning already deleted a bare-digit PMID rule.
    #: ⚠ THE OLD (pre-2007) SCHEME `hep-th/9901001`, `math.GT/0309136` IS MATCHED AND THIS
    #: REPOSITORY CONTAINS NONE — measured, zero hits in any tracked file. It costs nothing because
    #: it is context-anchored like the rest, and a citation to a 2003 paper is exactly the case a
    #: reader would assume is covered.
    #: ⚠ THE VERSION SUFFIX IS STRIPPED, NOT CAPTURED. `arXiv:2605.10246v2` in prose and
    #: `arxiv.org/abs/2605.10246` in a fetch product are ONE paper; capturing the version would make
    #: them two and re-create the "one identifier read as three" defect the PMID note above exists
    #: to stop. arXiv itself resolves the unversioned id to the latest version.
    #: ⚠ THE `arxiv` TOKEN IS CASE-INSENSITIVE (`arXiv`, `arxiv`, `ARXIV` all occur in this tree) BUT
    #: THE FLAG IS SCOPED TO IT — a global `(?i)` would also fold the old scheme's `math.GT` archive
    #: suffix, whose case is part of the identifier.
    "ARXIV": (r"(?i:arxiv)[:\s]\s*(\d{4}\.\d{4,5}|[a-z-]+(?:\.[A-Z]{2})?/\d{7})(?:v\d+)?\b",
              r"(?i:arxiv\.org)/(?:abs|pdf|html)/"
              r"(\d{4}\.\d{4,5}|[a-z-]+(?:\.[A-Z]{2})?/\d{7})(?:v\d+)?\b",
              #: arXiv's own DOI prefix. Also matched by the DOI pattern above, which is correct:
              #: the two kinds are independent questions about the same string and both must anchor.
              r"10\.48550/(?i:arxiv)\.(\d{4}\.\d{4,5}|[a-z-]+(?:\.[A-Z]{2})?/\d{7})(?:v\d+)?\b"),
}

#: Trailing punctuation a DOI picks up from prose. Stripped on BOTH sides or the same DOI compares
#: unequal to itself across a sentence break.
#: ⚠ BACKTICK AND ASTERISK WERE MISSING, AND MARKDOWN IS THE PROSE THIS SCANS (measured 2026-08-08).
#: The DOI pattern's character class happily eats them, so `` `10.1002/gcc.23144` `` and
#: **10.1002/gcc.70076.** became identifiers distinct from the bare DOI sitting in the artifact —
#: the same "one identifier read as three" defect the note above says this comparison exists to stop,
#: reintroduced by the strip set rather than by the pattern.
TRAILING = ".,;:)]}\"'`*_"

STATUSES = ("unverified_at_baseline", "verified", "retracted", "known_absent_upstream")


def _tracked():
    """Every path this gate scans: committed **and** untracked-but-not-ignored.

    ⛔ AUT-PD-036, 2026-08-28. A bare `git ls-files` lists only what git already knows about, so a
    brand-new manuscript sat invisible to this scan while uncommitted, passed preflight clean, and
    only went red on the run AFTER it was committed and pushed — "firing after the mistake is
    shared", the exact failure gate 12 was put in the commit loop to prevent. `--cached --others
    --exclude-standard` (the convention already proven in
    `research/autonomy/tests/test_the_clause_count_is_never_typed.py`) adds working-tree files git
    is not ignoring, so a fabricated citation in a not-yet-`git add`ed draft is caught before the
    commit rather than after it. `--exclude-standard` keeps `.gitignore` honoured.
    """
    r = subprocess.run(
        ["git", "-C", ROOT, "ls-files", "--cached", "--others", "--exclude-standard"],
        capture_output=True, text=True,
    )
    if r.returncode != 0:
        return []
    return [p for p in r.stdout.split("\n") if p]


def extract(kind, text):
    """Every identifier of `kind` in `text`, normalised — the ONE place a form becomes an identity.

    ⛔ THIS EXISTS SO THE TESTS CANNOT DRIFT FROM THE SCANNER. `PATTERNS` became a tuple per kind
    when the URL forms were added, and the two tests that had been calling `re.findall(PATTERNS[k])`
    directly broke with a TypeError — they were re-implementing `_scan`'s inner loop against a data
    shape they did not own. Re-implementing the thing under test is how a test ends up passing
    against its own copy of the logic; both now call this.
    """
    out = []
    for pat in PATTERNS[kind]:
        for m in re.findall(pat, text):
            ident = m.strip().rstrip(TRAILING)
            if ident:
                out.append(ident)
    return out


def _is_fetch_record(node):
    """Is `node` shaped like one `venue_policy_browser_fetch.py`-style HTTP fetch record?

    Every corpus of this shape writes `{"url": ..., "attempts": [{"n", "status", ...}, ...],
    "status": ...}` per target — `status` mirrors the outcome of the last attempt (a 2xx int on
    success, `None` if every attempt errored before getting a status, a 4xx/5xx otherwise). The
    three keys together are the signature: `attempts` alone also appears on unrelated records
    (an int retry counter on a ledger row, a GPU launch log) that are not fetch outcomes at all.
    """
    return (isinstance(node, dict) and "url" in node and "status" in node
            and isinstance(node.get("attempts"), list))


def _fetch_succeeded(node):
    status = node.get("status")
    return isinstance(status, int) and 200 <= status < 300


def _redact_failed_fetches(node):
    """`node` with every failed-fetch record's content blanked out before it is text-scanned.

    ⛔⛔ A FETCH THAT FAILED CAN ANCHOR A CITATION, AND ONE DID (AUT-PD-038, 2026-08-27). The
    anchor test used to be "this identifier appears in a tracked .json", which a 403 satisfies as
    easily as a 200: a bot-protection interstitial stored under a failed record's `text` field
    reads as a fetch product exactly like a real one. `fusion-junction-aso-journal-references.md`
    cited a DOI anchored by three straight 403s in `browser-fetch.json`, each one's own note
    reading "not fixable by retrying" — three records saying WE COULD NOT READ THIS, satisfying a
    gate that exists to establish that somebody did (CLAUDE.md §4: presence is never provenance).
    A record only anchors what it actually retrieved, so a failed one is walked down to its
    boring, content-free shell before extraction ever sees it — never deleted outright, because a
    recorded 403 is real evidence a route is closed; it is simply not evidence a CITATION is real.
    """
    if _is_fetch_record(node) and not _fetch_succeeded(node):
        return {"url": None, "status": node.get("status")}
    # ⭐⭐ THE UNCHANGED CASE RETURNS THE NODE ITSELF, AND THAT IS A COST FIX WITH A CORRECTNESS
    # OBLIGATION ATTACHED (measured 2026-09-02). This function ran 13 004 074 times in one gate-6
    # run and rebuilt every dict and list it walked, whether or not anything in it needed redacting
    # — 17.6 s of a 101.6 s profiled run, second only to the duplicate corpus scan beside it. Almost
    # nothing in this corpus is a failed fetch, so almost every one of those rebuilds allocated a
    # copy identical to its input.
    # ⛔ THE OBLIGATION: THE CALLER MUST NOT MUTATE WHAT IT GETS BACK. Before this, the return was
    # always a fresh structure and a caller could scribble on it; now it may BE the parsed document.
    # The one caller (`_scan`) passes the result straight to `json.dumps` and drops both, so the
    # output is byte-identical either way — asserted by
    # `research/manuscripts/tests/test_the_citation_scan_is_not_run_twice.py`, which pins the
    # equality against a fully-rebuilt reference rather than trusting this comment.
    if isinstance(node, dict):
        out = None
        for k, v in node.items():
            r = _redact_failed_fetches(v)
            if r is not v:
                if out is None:
                    out = dict(node)
                out[k] = r
        return node if out is None else out
    if isinstance(node, list):
        out = None
        for i, v in enumerate(node):
            r = _redact_failed_fetches(v)
            if r is not v:
                if out is None:
                    out = list(node)
                out[i] = r
        return node if out is None else out
    return node


def _scan(paths):
    """{kind: {identifier: {files}}} over `paths`.

    ⛔⛔ CACHED PER FILE, ON THE FILE'S BYTES AND THIS MODULE'S OWN SOURCE. Profiled 2026-09-02, this
    function was 48.2 s of a 54.7 s run and gate 12 was 30 % of the whole commit loop: 24.1 s of
    `re.findall`, 17.0 s across 13,028,986 recursive `_redact_failed_fetches` calls, and 5.7 s of
    json round-tripping, over ~4,250 committed fetch products of which an ordinary commit touches
    none. What a file contains is a pure function of its bytes, so re-deriving it every commit
    carries no information.
    ★ THE SCANNER'S OWN DIGEST IS IN THE KEY. `PATTERNS`, `TRAILING`, the redaction and the
    bare-key corpus rule all live in this module, so widening any of them misses every entry —
    without that, tightening the gate would leave it answering with the previous version of itself.
    ⚠ The cache is untracked and disposable (`citation_scan_cache.CACHE`); a miss, an unreadable
    file or a failed write all fall through to the full scan. See that module for the argument.
    """
    found = collections.defaultdict(lambda: collections.defaultdict(set))
    _scanner = None
    try:
        _scanner = _cache.scanner_digest()
    except OSError:
        pass
    _entries = _cache.load()
    _dirty = False
    for rel in paths:
        p = os.path.join(ROOT, rel)
        try:
            raw = open(p, "rb").read()
        except (OSError, IsADirectoryError):
            continue
        _key = _cache.key_for(rel, raw, _scanner)
        _hit = _cache.lookup(_entries, _key)
        if _hit is not None:
            for kind, idents in _hit.items():
                for ident in idents:
                    found[kind][ident].add(rel)
            continue
        text = raw.decode("utf-8", errors="replace")
        _seen = collections.defaultdict(set)
        scan_text = text
        # ⚠ SCOPED TO .json, NOT ANCHOR_SUFFIXES: no tracked .jsonl currently holds a fetch record
        # (measured 2026-08-28 — every `"attempts"` hit among tracked .jsonl is a different shape),
        # and a whole-document `json.loads` cannot parse one anyway. Extend here if that changes.
        if rel.endswith(".json"):
            try:
                parsed = json.loads(text)
            except ValueError:
                parsed = None
            if parsed is not None:
                scan_text = json.dumps(_redact_failed_fetches(parsed), ensure_ascii=False)
        for kind in PATTERNS:
            for ident in extract(kind, scan_text):
                found[kind][ident].add(rel)
                _seen[kind].add(ident)
        # ⛔ A THIRD FORM: A FETCH CORPUS KEYED BY THE BARE IDENTIFIER (measured 2026-08-08).
        # `lit-targets-endpoint-benchmarks.json` stores rows as {"10913809": {...}} — no `PMID`
        # token, no URL, no `EXT_ID`. Nine genuinely fetched-and-quoted identifiers read as
        # unanchored, i.e. as suspected fabrications.
        # ⚠ SCOPED TO THE CORPUS FILENAME ON PURPOSE, AND THE SCOPE IS THE WHOLE SAFETY ARGUMENT.
        # A global bare-digit rule was written and deleted earlier today: 6-9 digit runs appear as
        # object keys all over this repo (vast machine ids, run ids), so it could FALSELY ANCHOR a
        # fabricated PMID that collided with an unrelated number — the one direction this gate must
        # never move. `lit-targets-*.json` is the repo's fetch-corpus convention, so a quoted numeric
        # KEY there means "a paper we retrieved" and means nothing of the sort anywhere else.
        if re.match(r"^lit-targets-[\w.-]+\.jsonl?$", os.path.basename(rel)):
            for m in re.findall(r'"(\d{6,9})"\s*:', text):
                found["PMID"][m].add(rel)
                _seen["PMID"].add(m)
        _cache.record(_entries, _key, _seen)
        _dirty = True
    if _dirty:
        _cache.save(_entries)
    return found


def survey():
    """(prose, anchors) — identifiers in tracked prose, and identifiers in tracked fetch products."""
    files = _tracked()
    prose = _scan([f for f in files if f.endswith(PROSE_SUFFIXES)])
    # ⛔ THE LEDGER MUST NOT ANCHOR ITSELF, AND IT DID FOR ONE COMMIT (caught 2026-08-07, minutes
    # after the gate merged). The ledger is a `.json` listing every unanchored identifier, so once it
    # existed every one of those 215 ids appeared in a "fetch product" and the unanchored count fell
    # from 215 to 0 — the gate reporting a clean tree it had just finished declaring dirty. The pass
    # condition was unaffected (a new fabrication is in neither the ledger nor an artifact, so it
    # still fails), which is exactly what made it dangerous: the guard kept working while its READOUT
    # went vacuous, and a count of 0 is the one number nobody re-examines.
    ledger_rel = os.path.relpath(LEDGER, ROOT).replace(os.sep, "/")
    # ⛔ AND THE SAME EXCLUSION FOR THE PUBLICATION-TYPE CACHE, ADDED 2026-08-27 WITH THE TYPE GUARD
    # AND FOR THE REASON THE PARAGRAPH ABOVE RECORDS. `citation-article-types.json` is a tracked
    # `.json` whose whole content is identifiers, so left in this scan it would ANCHOR every one of
    # them — two of which (PMID 40885991, PMID 41055792) are `unverified_at_baseline` in the ledger
    # right now. The unanchored count would fall because a DIFFERENT gate fetched something, and the
    # only number a reader would see is the smaller one. Provenance is resolved by --verify-online;
    # a fetch performed to answer "what kind of paper is this" is not evidence for "who checked it".
    anchors = _scan([f for f in files
                     if f.endswith(ANCHOR_SUFFIXES)
                     #: ⚠ SWEEP_ARTIFACT_REL IS INSERTED BEFORE `TYPE_CACHE_REL`, NOT APPENDED
                     #: AFTER IT, AND THE ORDER IS LOAD-BEARING FOR A TEST RATHER THAN FOR THE CODE.
                     #: `test_citation_type_guard.py::test_the_cache_is_not_an_anchor_for_the
                     #: _provenance_gate` asserts the literal string `TYPE_CACHE_REL)` appears in
                     #: this file, so appending would have reddened a guard whose property was
                     #: untouched — the "assert the behaviour, not the spelling" defect that the
                     #: neighbouring test in that same file already records having paid for once.
                     and f not in (ledger_rel, SWEEP_ARTIFACT_REL, TYPE_CACHE_REL)])
    return prose, anchors


def unanchored(prose, anchors):
    """[(kind, identifier, sorted files)] for every prose identifier with no fetch-product anchor."""
    out = []
    for kind, ids in sorted(prose.items()):
        for ident, files in sorted(ids.items()):
            if ident not in anchors.get(kind, {}):
                out.append((kind, ident, sorted(files)))
    return out


def load_ledger():
    if not os.path.exists(LEDGER):
        return None
    return json.load(open(LEDGER, encoding="utf-8"))


def _key(kind, ident):
    #: ⛔ NORMALISE THE LEDGER'S KEY, DO NOT REWRITE THE LEDGER (2026-08-08). The 2026-08-07 baseline
    #: was captured before `TRAILING` stripped backticks/asterisks, so 35 rows are stored under a
    #: punctuation-laden form (`10.1002/anie.201806037\``). Widening the strip set re-keys the prose
    #: side, orphaning those rows — and an orphaned baseline row does not fail safe: the identifier
    #: reappears as NEW and unanchored, i.e. the gate accuses honest, already-triaged citations of
    #: being fabrications. Normalising here makes the stored form irrelevant, which is what it always
    #: should have been: the ledger records WHO CHECKED an identifier, and that fact cannot depend on
    #: whether the person who logged it happened to include the closing backtick.
    return "%s:%s" % (kind, str(ident).strip().rstrip(TRAILING))


def _norm_stored_key(key):
    """A ledger key as stored -> the same key under today's TRAILING set.

    Rows written before the strip set widened carry the punctuation; splitting on the FIRST colon
    keeps DOIs intact, which contain no colon but do contain slashes and dots.
    """
    kind, _, ident = str(key).partition(":")
    return _key(kind, ident)


def provenance_check(prose=None, anchors=None):
    """The PROVENANCE axis ALONE: is every prose identifier anchored or enumerated? rc 0 / 1 / 2.

    ⛔⛔ WHY THIS FUNCTION EXISTS, AND IT IS A TESTABILITY DEFECT WITH TEETH (2026-09-08, P-CI).
    This body used to live inside `check()`, whose return is `max(provenance_rc, type_rc)`. Every
    negative control this gate has — a fabricated PMID that must go RED, and its paired anchored
    control that must go GREEN so the red is attributable to the ANCHORING and not to the harness —
    drove `check()`. So the moment the TYPE guard went non-green for an unrelated reason (a prose
    type claim with no cached metadata, which is the tree's state today), `max()` returned 1 for
    BOTH members of the pair: the fabricated control kept "passing" while proving nothing, and the
    anchored control went red on an axis it does not test. Measured on this tree the same day:
    `test_and_that_control_can_actually_pass_when_the_identifier_is_anchored`,
    `test_and_that_control_can_actually_pass_when_the_arxiv_id_is_anchored` and
    `test_a_ledgered_identifier_stays_green` were all red with the provenance logic they test
    working correctly. A control that cannot go green is not a control, it is a constant — the
    exact failure the negative-control discipline in `research/modalities/tests/
    test_lint_citations.py` was written to prevent, reappearing one level up in the call graph.
    ⛔ THIS IS NOT A STANDALONE PRODUCTION ENTRYPOINT AND MUST NEVER BECOME ONE — though it IS a
    component production calls: `check()` invokes it on every run. What must never happen is a
    caller reaching it INSTEAD of `check()`. `check()` — what `preflight.sh` and CI run — still
    scans the ENTIRE corpus and still fails if EITHER axis fails. Splitting the axes
    so each can be OBSERVED alone is the repair; running only one of them in production would be
    the 2026-08-26 defect (real, anchored identifiers cited as the wrong kind of paper) going
    unchecked. `test_the_wrapper_fails_when_either_axis_fails` pins that.
    ⚠ `prose`/`anchors` are the same cost parameter `lint_citation_types.check(prose=...)` carries:
    `None` means "compute it", a caller that already holds `survey()`'s output hands it over. It is
    NOT a way to narrow the corpus in production — `check()` passes what `survey()` returned, whole.
    """
    if prose is None or anchors is None:
        prose, anchors = survey()
    un = unanchored(prose, anchors)
    led = load_ledger()
    if led is None:
        print("::error::no citation-provenance ledger — run --baseline once to create %s"
              % os.path.relpath(LEDGER, ROOT), file=sys.stderr)
        return 2
    known = {_norm_stored_key(e["key"]) for e in led["entries"]}
    # ⛔ THE ONLY FAILING CASE, AND IT IS THE ONE THAT HAPPENED: a prose identifier that is neither
    # anchored in a fetch product nor already enumerated. Everything baselined stays green so the gate
    # survives; anything NEW must be justified at the moment it is written.
    new = [(k, i, f) for k, i, f in un if _key(k, i) not in known]
    for kind, ident, files in new:
        print("::error::UNANCHORED %s %s — appears only in prose (%s) and is not in the "
              "citation-provenance ledger. Either it is cited by an artifact (add the fetch), or it "
              "needs a ledger entry recording who checked it. A citation typed from memory is the "
              "failure this gate exists for." % (kind, ident, ", ".join(files[:3])), file=sys.stderr)
    # A ledger entry whose identifier has since vanished from prose is stale bookkeeping, not a defect.
    live = {_key(k, i) for k, i, _ in un} | {
        _key(k, i) for k in prose for i in prose[k]}
    stale = [e["key"] for e in led["entries"] if _norm_stored_key(e["key"]) not in live]
    by_status = collections.Counter(e["status"] for e in led["entries"])
    print("lint_citations: %d prose identifier(s), %d unanchored, %d in ledger (%s)%s"
          % (sum(len(v) for v in prose.values()), len(un), len(led["entries"]),
             ", ".join("%s=%d" % (s, n) for s, n in sorted(by_status.items())),
             ", %d stale ledger row(s)" % len(stale) if stale else ""))
    rc = 0
    if new:
        print("lint_citations: %d NEW unanchored identifier(s) — see errors above" % len(new),
              file=sys.stderr)
        rc = 1
    return rc


def _type_check(prose):
    """Run the TYPE axis over `prose`. The ONE place `check()` reaches the second guard.

    ⚠ EXTRACTED SO A TEST CAN HOLD THE TYPE AXIS AT A KNOWN VALUE while it varies the provenance
    one — which is what makes "fabricated goes red, anchored goes green, REGARDLESS of an unrelated
    type failure" an assertable statement rather than a hope. ⛔ It changes nothing about what
    production runs: the same module, loaded the same way, over the same unfiltered `prose`.
    """
    # ⭐⭐ THE TYPE GUARD RUNS FROM HERE, AND THE CALL SITE IS THE WIRING (added 2026-08-27,
    # AUT-PROP-007). ⛔ IT IS A THIRD AXIS, NOT A REFINEMENT OF THIS ONE. On 2026-08-26 a national
    # registry cohort and two single-patient case reports were cited as "the review literature";
    # every identifier was real, every one was ANCHORED, and this checker was green — correctly,
    # because ORIGIN was never the question. `lint_citation_types` asks whether the paper behind the
    # identifier is the KIND of paper the sentence says it is, against PubMed's `article_types`.
    # ⚠ WHY IT HANGS OFF THIS FUNCTION RATHER THAN OFF ITS OWN PREFLIGHT HEADING. Gate ordinals are
    # DERIVED from `preflight.sh`'s `== heading ==` lines by `systems_check.check_preflight_gate_list`
    # and hard-coded in four documents besides, so a new heading renumbers every gate below it. This
    # guard does not warrant that churn, and hanging it on a gate that already runs in the commit
    # loop AND in CI wires it more strongly than a heading of its own would. The two rcs are OR-ed
    # so neither can hide the other — the shape preflight's own manuscripts block was fixed into.
    # ⚠ IMPORTED BY PATH, NOT BY NAME. Run as a script, `sys.path[0]` is this directory and a bare
    # `import` works; imported by `spec_from_file_location` — which is how every test in this
    # repository loads a linter — it is NOT, and the bare form raises ImportError from inside a
    # function nothing had reason to re-test. The guard must be reachable both ways or the wiring is
    # only as good as the entry point that happened to be exercised.
    import importlib.util
    _spec = importlib.util.spec_from_file_location(
        "lint_citation_types", os.path.join(HERE, "lint_citation_types.py"))
    _types = importlib.util.module_from_spec(_spec)
    _spec.loader.exec_module(_types)
    # ⭐ `prose` IS HANDED OVER RATHER THAN RECOMPUTED — see that function's own docstring for the
    # measurement (21 s of every commit; the type guard walked the identical corpus a second time).
    # ⛔ IT MUST BE `prose` AS `survey()` RETURNED IT, UNFILTERED: the sweep's coverage claim is that
    # it sees every prose identifier in the repository, and a narrowed dict would shrink the sweep
    # while its printed total went on describing the whole tree.
    return _types.check(prose=prose)


def check():
    """⛔ PRODUCTION. The WHOLE corpus, BOTH axes, and a failure if EITHER of them fails.

    ⚠ The two rcs are OR-ed (via `max`) so neither guard can hide the other — provenance answers
    "is this identifier ANCHORED IN A FETCH PRODUCT OR ENUMERATED IN THE LEDGER" — which is NOT the
    same as "did anybody retrieve it": a ledger row can be inherited or otherwise unverified, and
    such a row passes this axis. The type guard answers "is the paper behind it the KIND
    of paper the sentence says it is", and a green on one is not evidence about the other.
    ⭐ `survey()` is walked ONCE and its prose half is handed to both, which is the 21-s-per-commit
    fix pinned by `test_the_citation_scan_is_not_run_twice.py`.
    """
    prose, anchors = survey()
    rc = provenance_check(prose, anchors)
    # ⛔ A MISSING LEDGER (rc 2) SHORT-CIRCUITS, EXACTLY AS IT DID BEFORE THE SPLIT. Without a
    # ledger the provenance axis cannot answer at all, and 2 is already a failure; running the type
    # guard afterwards could only lower nothing and would change this gate's output on a tree
    # nobody can currently evaluate.
    if rc == 2:
        return rc
    return max(rc, _type_check(prose))


def baseline():
    if os.path.exists(LEDGER):
        # ⛔ REFUSES TO REGENERATE. If --baseline could be re-run, every future fabrication would be
        # one command away from being blessed, and the gate would launder exactly what it exists to
        # catch. Growing the ledger has to be a deliberate, reviewable edit.
        print("::error::ledger already exists at %s — --baseline is a ONE-TIME operation and will "
              "not overwrite it. To add an entry, edit the file deliberately; to resolve one, use "
              "--verify-online." % os.path.relpath(LEDGER, ROOT), file=sys.stderr)
        return 2
    prose, anchors = survey()
    un = unanchored(prose, anchors)
    doc = {
        "_what": ("Every identifier that appears in this repository's PROSE and in none of its fetch "
                  "products. Written once, on 2026-08-07, after a fabricated PMID reached a manuscript "
                  "and passed lint_claims twice."),
        "_what_an_entry_means": (
            "NOT that the citation is wrong. It means NOTHING IN THIS REPOSITORY CORROBORATES IT — no "
            "fetch, no registry curation, no graph record. Most of these are almost certainly real "
            "citations that no artifact has needed yet. The point is that the list exists and is "
            "finite, so the ones that are not real can be found."),
        "_the_count_is_meant_to_fall": (
            "Same idiom as systems_check's `last_verified: unverified` count. Resolve an entry with "
            "--verify-online (CI, $0, Europe PMC), which records the date and the returned title — "
            "never by relabelling it by hand."),
        "_what_this_does_not_prove": (
            "An ANCHORED identifier is not thereby verified either. It means some artifact carries it, "
            "which is evidence of a fetch, not of correctness — an artifact can record an identifier a "
            "human typed into a curated field. This gate raises the floor; it is not a truth oracle."),
        "statuses": list(STATUSES),
        "entries": [
            {"key": _key(k, i), "kind": k, "id": i, "status": "unverified_at_baseline",
             "files": f, "note": ""}
            for k, i, f in un
        ],
    }
    json.dump(doc, open(LEDGER, "w", encoding="utf-8"), indent=2, ensure_ascii=False)
    open(LEDGER, "a", encoding="utf-8").write("\n")
    print("wrote %s with %d entries" % (os.path.relpath(LEDGER, ROOT), len(doc["entries"])))
    return 0


def report():
    prose, anchors = survey()
    un = unanchored(prose, anchors)
    per = collections.Counter(k for k, _, _ in un)
    print("%-6s %10s %10s %10s" % ("kind", "in prose", "anchored", "unanchored"))
    for kind in PATTERNS:
        n = len(prose.get(kind, {}))
        print("%-6s %10d %10d %10d" % (kind, n, n - per[kind], per[kind]))
    led = load_ledger()
    if led:
        by = collections.Counter(e["status"] for e in led["entries"])
        print("\nledger: %d entries — %s" % (len(led["entries"]),
                                             ", ".join("%s=%d" % kv for kv in sorted(by.items()))))
    return 0


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--baseline", action="store_true", help="one-time ledger write")
    ap.add_argument("--report", action="store_true", help="counts only, always exits 0")
    a = ap.parse_args(argv)
    if a.baseline:
        return baseline()
    if a.report:
        return report()
    return check()


if __name__ == "__main__":
    sys.exit(main())
