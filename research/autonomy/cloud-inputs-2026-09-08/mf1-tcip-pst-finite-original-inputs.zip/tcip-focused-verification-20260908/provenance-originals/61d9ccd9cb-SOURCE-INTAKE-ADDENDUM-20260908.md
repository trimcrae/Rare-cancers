# TCIP final scientific review: original-source intake addendum

Date: 2026-09-08. This addendum completes only the previously requested original-source portion of the same independent final scientific review. It is not a second baseline review, changed-manuscript review, new scientific calculation, structural remeasurement or verification of repairs.

The completed report remains immutable: `FINAL-SCIENTIFIC-REVIEW-TCIP.md`, 52,425 bytes, SHA256 `a00bec7213282192725722bb84736470868523acaa13766c2dac44ea4da82101`. Its original input manifests, calculation script and calculation outputs are unchanged. The frozen manuscript remains revision `f43f1495f40d8aff7b4f34bd385d55aac521a500`.

## Disposition after source intake

**The scientific disposition and complete 13-finding repair batch remain in force: HOLD the frozen candidate, admit one coherent narrower toolchain-audit revision, and park the stronger calibrated-floor claims pending the specific evidence identified in the review.** No finding is withdrawn. Several source-provenance limitations are now resolved or narrowed; the original report's source-uninspected statement should henceforth be read together with this addendum.

The newly delivered records establish the identity and original citation of 9MZA, the BCL6/p300 chain assignments, the deposited assembly description, and the primary abstract's account of KAT-TCIP function. The search indexes establish the retained record/file-pointer inventories. They do not establish equivalence between the census and sampler, remeasure any contact count, supply full-text term/classification evidence, or establish field-wide absence. The core predicate, proposal, denominator, uncertainty and algebra findings stand independently.

The coordinator confirmed that all four requested cache directories had already been found and that routine transport of existing bytes was in progress at the original review's closure. The seven originals arrived locally about three minutes later. The issue was **requested bytes not yet delivered or inspected**, not sources not found and not a source denial. No new retrieval, alternate route or retry was made for this intake.

## Exact delivered and retained source scope

Delivery package: `C:/Users/mcrae/.codex/review-workspaces/opus-capacity-sprint-20260907/capacity-campaign-20260908/observations/c6d97dcc/TCIP-reviewer-source-copies/`.

Delivery revision: `c6d97dcc2043bd2a21c749339637286915a29a82`. The source manifest identifies the earlier original-source revision as `216bd1b5fb25a56b90ef3cc2373e1fe68322708f`. Seven original retained source files total 1,340,205 bytes. This reviewer independently matched each delivered file's size, SHA256 and Git blob identity against that manifest by hashing the actual local bytes. No Git command or network operation was necessary. Byte identity to the retained cache is not a claim that its text-fetch pipeline preserved the original HTTP body without normalization.

Exact copies are retained under `source-intake/inputs/` in this review workspace. The supplemental manifest includes all seven sources and three delivery-provenance files. Combined with the immutable original manifest, the review now retains 30 distinct inputs: 20 original-review inputs and 10 supplemental inputs. Read extent is distinguished from file possession.

The delivered `SHA256SUMS.txt` has the already reported stale self-entry: it declares the empty-file digest for itself. Its actual 1,602-byte SHA256 is `de6eb0e6a8ab04bd83ac7b2b2a85b7693b2b762b2d3f5878d4f96a4ee7ea5610`. All seven source entries match their actual bytes and declared Git blobs. This is a self-reference bookkeeping defect, not a hold on the material source inputs. The authoritative mmCIF SHA256 is `b81668a1eaeb1eb40e74c99b65f093f647fd78eec30cecf201aa83006bc75780`; a shorter owner message contained a transcription error, which the actual manifest and bytes resolve.

## Source findings and changes to the existing review

### 1. The structure identity and citation join are now verified from original retained records

The original retained mmCIF, `literature/tcip-9mza-2026-08-07/cif_9MZA.txt`, has an HTTP 200 provenance header (lines 1-5), identifies entry 9MZA (line 8), and gives the title *Chemically Hijacked BCL6-TCIP3-p300 Complex* (line 2184). It records X-ray diffraction (line 1642), refinement high resolution 2.100 A (line 1923), and the bioRxiv primary citation DOI `10.1101/2025.03.14.643404`, PubMed `40166243` (lines 90-94).

The successful RCSB entry response, `literature/tcip-9mza-2026-08-07/rcsb_entry_9MZA.txt`, payload starting at line 6, independently contains `/struct/title`, `/rcsb_primary_citation`, `/rcsb_accession_info` and `/rcsb_entry_info/resolution_combined`. It records deposition on 2025-01-22 and release on 2025-04-16. This verifies the accession-to-preprint join that was previously available to this reviewer only through the sizing memo.

The Europe PMC response, `literature/tcip-kat-structure-2026-08-07/epmc_kat_tcip_record.txt`, contains two results for its explicitly retained DOI query: the Cell article, PMID `42476129`, DOI `10.1016/j.cell.2026.06.037`, and the preprint, DOI `10.1101/2025.03.14.643404`. In `/resultList/result/0/commentCorrectionList`, the Cell record is an update of the earlier PubMed preprint record. The preprint result also links to the later article, with Europe PMC's title/first-author matching qualification. The successful structure-to-preprint citation and the later article's update relationship together support the source lineage; no successful direct RCSB query by the later PMID is needed.

**Effect on F04, F09, F12 and F13:** The review no longer has an uninspected-original-source gap for the structure's identity, resolution, original citation or the article/preprint relationship. These facts can be cited directly in a corrected paper. This does not supply a matching-predicate computation or a calibrated biological floor.

### 2. The file labelled a primary-citation record is actually an invalid search response

`literature/tcip-kat-structure-2026-08-07/rcsb_cite_pubmed_42476129.txt` is not a successful citation object. Its header reports HTTP 400 (line 3); its body explains that search is not enabled on the requested `rcsb_primary_citation.pdbx_database_id_PubMed` attribute (lines 6-10). The delivery manifest's descriptive label must not be used to infer that this query found a structure, found no structures, or verified a citation.

This is an original retained invalid-request outcome. It is not an egress denial, a negative biological result or evidence that the cited publication does not exist. The valid citation join comes from the successful entry response described above. No retry was attempted or is required for the present correction batch.

**Effect on F09/F12/F13:** Add this precise source-status distinction to the provenance repair. It narrows which record supports which statement without creating another scientific review cycle or material-input hold.

### 3. Original assembly and construct metadata strengthen the existing chain-unit and truncation findings

The mmCIF identifies entity 1 as BCL6 and entity 2 as p300 (lines 138-139), assigns BCL6 to chains A/C and p300 to B/D (lines 170, 178 and 2202-2205), and identifies A1BUC as the nonpolymer ligand (lines 180-187). These assignments corroborate the chain interpretation in F03. No contact distances or ligand-atom contact counts were recalculated.

The author-defined assembly is **tetrameric**, assembly 1, with the identity operation and chains A-D plus ligand/solvent asym IDs (mmCIF2327-2345). The original RCSB assembly response, `literature/tcip-9mza-2026-08-07/rcsb_assembly_9MZA.txt`, payload at line 6, describes a hetero 4-mer of stoichiometry A2B2 in `/rcsb_struct_symmetry/0`; `/pdbx_struct_assembly_auth_evidence/0` records fluorescence resonance energy transfer as author-provided assembly support. This is a source metadata assertion of experimental support, not this reviewer's inspection of the underlying FRET experiment.

The corrected paper should describe the reported A/D and B/C interfaces as two related interface instances within the deposited BCL6/p300 assembly. It should not let "two copies of the induced complex" imply two independent functional systems or obscure the common BCL6 dimer. The author-defined assembly supports the multichain-unit concern already raised in F01/F03; it does not by itself determine the appropriate computational scoring unit or measure its contacts.

The mmCIF alignment metadata maps BCL6 to UniProt residues 5-129 and p300 to residues 1040-1161, with construct tags (lines 2249-2252 and 2268-2325). It also reports BCL6 sequence conflicts relative to the reference at positions 8, 67 and 84 (lines 2271-2273 and 2300-2302). These should be described as the deposited sequence annotations; their functional effects were not determined here. The RCSB entry/assembly metadata records 470 modeled and 76 unmodeled polymer monomers out of 546 deposited polymer monomers. Those are source-reported totals, not newly measured values.

These data make the construct scope more precise. They do not prove that omitted residues disrupt the relevant interface, but they also do not justify concluding from resolved residue counts alone that a small interface cannot reflect construct or unresolved-region choices. Tags account for part of the construct context; this review does not equate every unmodeled monomer with a missing native functional residue.

The assembly record also includes a total assembly buried-surface-area value and interface counts. They are a different, whole-assembly descriptor, include the assembly's constituent interfaces, and do not substitute for the manuscript's induced chain-pair point score. I did not recalculate or repurpose them as a new interface measurement.

**Effect on F01/F03/F04:** The chain assignments and assembly context are now directly source-supported, and F04's construct caution can be written with exact boundaries. The census zero-contact-pair omission remains a code/retained-record inference; this intake did not generate the omitted profiles. The predicate-equivalence and calibration blockers are unchanged.

### 4. The original abstract supports the system's functional context, but not this paper's contact-floor calibration

Both original Europe PMC abstracts were read. They describe recruitment of p300/CBP to BCL6-associated repressed gene networks, epigenetic reprogramming and cell-death outcomes, and they attribute functional relevance to interactions visible in the induced p300-BCL6 crystal complex. The Cell abstract additionally discusses different genomic responses from recruiting different activators. This supports the paper's identification of the structure as part of a transcriptional/epigenetic CIP study. It also establishes that the primary work already discusses the induced interface's functional relevance; the audit's novelty must be its specific computational/measurement observation, not discovery of that connection.

The biological roles must stay clear: in the cited KAT-TCIP setting, p300/CBP are the recruited activators and BCL6 is the oncogenic regulator being redirected. The toolchain's separately staged BCL6 recruiter does not become a biologically matched KAT-TCIP effector because the protein name is shared. This is compatible with the original review's restriction of the four-body ablation to proxies.

The abstracts do not state the reviewed CA/centroid shell score, a 12-point operational cutoff, equivalence to the gridded sampler, a minimum necessary interface size, or an interface-size-to-output calibration curve. Abstract-level functional context therefore closes part of the source gap without repairing the central inference.

Both Europe PMC result records have `isOpenAccess: N` and `inEPMC: N`. The preprint nevertheless has a free DOI-link entry and a `cc by` license field. Those flags describe the retained Europe PMC indexing/availability state; they must not be broadened into a claim that the preprint is inaccessible everywhere or lacks an open license. No publisher article, supplementary experiment or full preprint text was delivered or read in this intake. I did not follow the available links or attempt another acquisition route.

**Effect on F04/F09/F13:** The primary abstract and relevant prior-art context are now inspected. A corrected paper may cite what the abstract actually establishes. The quantitative floor and complete functional-experiment claims remain outside that source-read scope. The no-new-function/no-new-biological-measurement ceiling of the audit remains appropriate.

### 5. The original search indexes verify retained inventories, not total search coverage or full-text conclusions

The two delivered `_index.json` files are arrays of bibliographic/abstract records with optional `fullTextFile` and `chars` metadata. Mechanical metadata inspection establishes:

| Original retained index | Records in the array | Rows with a full-text file pointer |
|---|---:|---:|
| `literature/induced-proximity-transcription-2026-08-07/_index.json` | 100 | 20 |
| `literature/induced-interface-vs-output-2026-08-07/_index.json` | 300 | 51 |

These are inventory counts of existing records and pointers, not new scientific statistics or a fresh literature screen. The first index's full-text pointers can be located at, for example, lines 349-350 and subsequent `fullTextFile`/`chars` entries. Every row's metadata was parsed for the inventory; not every abstract in either index was fully read or classified. The KAT-TCIP article and preprint records in the first index were read as material primary records.

Neither index has a top-level query string, request date, total-hit count, requested limit, pagination/cursor history or the original search-response envelope. Accordingly, 100 and 300 are now verified as **retained record counts**; whether they equal the full result totals or a retrieval cap remains unresolved by these bytes. The DOI-specific Europe PMC response's `hitCount: 2` applies only to that separate DOI query, not to either broad sweep.

The 20/51 file pointers support the existence of a named retained-text inventory in the original pipeline. The text files themselves and their term-count or output-classification results are not in this seven-source delivery. Therefore this intake does not independently verify the claimed zero occurrences of interface terms, the one-file/two-occurrence cooperativity statement, the 31 degradation-related and six transcription-shaped classifications, or the six-record exclusion explanations. Metadata pointers and character counts cannot substitute for the relevant text and classification evidence.

The original broad query syntax remains available as the author memo's narrative, not as a reproduced request envelope in these two indexes. Even with a complete envelope and verified text counts, the asymmetric searches and open-access selection would still not establish field-wide absence or matched prevalence. Two failed modality-name RCSB searches and one successful protein-name search also remain author-narrative search outcomes in this delivery; the successful structure entry does not retrospectively verify those query responses or exclusivity of discovery.

**Effect on F09/F12/F13:** Remove the narrower uncertainty about whether an accession-level retained 100/20 and 300/51 inventory exists; it now does and is inspected at metadata level. Retain the uncertainty about total hits/caps, exact executed broad queries, text screening/classification and generalization. No new source request is required to finish this review. The existing repair can label unsupported counts as historical author-reported results with precise scope, or omit them from the narrowed claim.

## Consolidated finding-status update

| Existing finding | Effect of this intake |
|---|---|
| F01 — predicate equivalence | Unchanged. Original coordinates/assembly metadata do not supply a matching-predicate result; no geometry was rerun. |
| F02 — nonuniform proposal/measure | Unchanged; source-code result independent of these originals. |
| F03 — selected pair denominator and topology | Chain assignments and one A2B2 assembly now directly supported. Preserve zero-filter inference as an inference, not a new zero-score profile. |
| F04 — controls/constructs/calibration | Identity and abstract-level functional context verified; exact construct boundaries and deposited assembly metadata sharpen the correction. No calibrated floor established. |
| F05 — paired uncertainty/independence | Unchanged; no new sampling or execution evidence supplied. |
| F06 — disagreement/offset cancellation | Unchanged. |
| F07 — size causality/transfer | Unchanged; precise biological roles reinforce the need for limited transfer claims. |
| F08 — points/residues | Unchanged. |
| F09 — search/prior art | Retained inventory and primary abstract now verified. Broad search coverage, full-text conclusions and field-wide absence remain unsupported; failed citation-query status clarified. |
| F10 — ternary odds transfer | Unchanged. |
| F11 — stale named-effector verdict | Unchanged. |
| F12 — reproduction/provenance | Seven material originals now have exact retained locators/hashes. This partially improves input provenance, but does not supply the entire census/sampler input closure, correct the command, or verify original runs. |
| F13 — standalone communication | Corrected paper can use the directly supported source facts and precise availability/assembly descriptions. Prose/table sufficiency and consistent claim framing remain required. |

The complete repair batch remains one batch. The addendum neither expands it into a new scientific campaign nor supplies acceptance of a repaired paper. No source delivery condition should be described as an irreducible failure now that the relevant bytes have been transported; the remaining scientific blockers are the specific claim-to-method problems identified in the report.

## Intake operations and reproducibility of this addendum

`source_intake.py` copied existing local bytes, verified source-file SHA256/Git-blob identities and verified the original report's immutable digest. `inspect_source_records.py` extracted material metadata and a bibliographic/file-pointer inventory for reading. Its first strict JSON decode exited 1 because retained fetched text includes literal control/newline characters inside strings; the inspection helper was adjusted to tolerate those characters (`strict=False`) and then completed successfully. This was a reading-helper issue, not a source fetch, producer failure or scientific test. The exact delivered inputs were never edited.

The extracted `source-intake/material-record-excerpts.json` is a new reviewer reading aid, not an original response or new measurement. The supplemental manifest records its hash and the exact read scope of each source. The original scientific calculation remained at one run, exit 0; it was not rerun or revised. No atom coordinates were loaded into a geometric calculation, no distances or scientific classifications were generated, and no manuscript bytes were changed.

This completes the pending original-source portion of the same final scientific review.
