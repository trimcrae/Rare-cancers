"""Retain and verify delivered existing TCIP originals; transport/hash verification only."""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parent
SRC=Path('C:/Users/mcrae/.codex/review-workspaces/opus-capacity-sprint-20260907/capacity-campaign-20260908/observations/c6d97dcc/TCIP-reviewer-source-copies')
DEST=ROOT/'source-intake/inputs'
DEST.mkdir(parents=True,exist_ok=True)
report=ROOT/'FINAL-SCIENTIFIC-REVIEW-TCIP.md'
data=report.read_bytes()
assert len(data)==52425 and hashlib.sha256(data).hexdigest()=='a00bec7213282192725722bb84736470868523acaa13766c2dac44ea4da82101'
m=json.loads((SRC/'MANIFEST.json').read_text())
records=[]
for c in m['copies']:
 b=(SRC/c['copy']).read_bytes()
 sha=hashlib.sha256(b).hexdigest()
 blob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
 assert len(b)==c['bytes'] and sha==c['sha256'] and blob==c['git_blob'],c['copy']
 (DEST/c['copy']).write_bytes(b)
 records.append(dict(c,delivered_path=(SRC/c['copy']).as_posix(),retained_path=(DEST/c['copy']).relative_to(ROOT).as_posix(),sha256_and_blob_verified=True))
for p in [SRC/'MANIFEST.json',SRC/'SHA256SUMS.txt',SRC.parent/'TCIP-source-copy-verification.json']:
 b=p.read_bytes();(DEST/p.name).write_bytes(b)
 records.append({'item':'Delivery provenance record','delivered_path':p.as_posix(),'retained_path':(DEST/p.name).relative_to(ROOT).as_posix(),
                 'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
out={'delivery_commit':'c6d97dcc2043bd2a21c749339637286915a29a82','original_source_commit':'216bd1b5fb25a56b90ef3cc2373e1fe68322708f',
 'original_report_unchanged':True,'original_source_files':7,'original_source_total_bytes':sum(c['bytes'] for c in m['copies']),
 'scope':'Existing local bytes copied and independently SHA256/Git-blob hashed. No Git command, network, source retrieval, geometry or scientific computation.',
 'records':records}
(ROOT/'source-intake/intake-verification.json').write_text(json.dumps(out,ensure_ascii=True,indent=2)+'\n',encoding='utf-8')
print(json.dumps(out,ensure_ascii=True))
