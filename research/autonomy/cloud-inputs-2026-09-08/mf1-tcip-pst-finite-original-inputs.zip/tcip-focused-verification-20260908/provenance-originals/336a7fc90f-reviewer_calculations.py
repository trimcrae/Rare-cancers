"""New deterministic reviewer checks on retained summaries and mathematical definitions.

No geometry is loaded, measured or simulated. No producer is imported or executed.
No network, random draws, biological estimation, or file outside this workspace is used.
"""
from pathlib import Path
from collections import Counter, defaultdict
import ast
import hashlib
import json
import math
import zlib

ROOT = Path(__file__).resolve().parent
FROZEN = ROOT / 'inputs/frozen'
def read(rel):
    return json.loads((FROZEN / rel).read_text(encoding='utf-8'))
def literal_assignment(rel, name):
    tree = ast.parse((FROZEN / rel).read_text(encoding='utf-8'))
    for node in tree.body:
        if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == name for t in node.targets):
            return ast.literal_eval(node.value)
    raise ValueError(name)
def wilson(k, n):
    p, z = k / n, 1.96
    d = 1 + z*z/n
    c = (p+z*z/(2*n))/d
    h = z * math.sqrt(p*(1-p)/n+z*z/(4*n*n))/d
    return [c-h, c+h]

reach = read('research/modalities/nr4a3-tcip-reach.json')
census = read('research/modalities/nr4a3-induced-interface-census.json')
basins = read('research/modalities/nr4a3-orientation-basins.json')
classes = literal_assignment('research/modalities/nr4a3_induced_interface_census.py', 'ENTRY_CLASSES')
params = literal_assignment('research/modalities/nr4a3_basin_search.py', 'PARAMS')
out = {'identity': 'New independent deterministic reviewer calculations, TCIP, 2026-09-08',
       'scope': 'Existing summaries, source definitions and illustrative algebra only; no geometry remeasurement or producer execution.'}

integrity = []
for line in (ROOT / 'inputs/local/HASHES.txt').read_text(encoding='utf-8').splitlines():
    bits = line.split()
    if len(bits) == 2 and len(bits[0]) == 64 and bits[1].startswith(('research/modalities/', 'research/manuscripts/')):
        data = (FROZEN / bits[1]).read_bytes()
        digest = hashlib.sha256(data).hexdigest()
        assert digest == bits[0], bits[1]
        integrity.append({'path': bits[1], 'bytes': len(data), 'sha256': digest, 'matches': True})
out['handoff_material_integrity'] = integrity

cells = reach['paired_placement_envelope']['cells']
arms = sorted({c['arm_id'] for c in cells})
poses = sorted({c['pose_id'] for c in cells})
rungs = sorted({c['linker_atoms'] for c in cells})
out['enumeration_inventory'] = {'cells': len(cells), 'arms': arms, 'poses': poses, 'rungs': rungs,
                                'total_draws': sum(c['n_samples'] for c in cells),
                                'sample_counts': sorted({c['n_samples'] for c in cells})}
assert len(cells) == len(arms)*len(poses)*len(rungs) == 576
group_ids = {'single_domain': ['birc2', 'mdm2'], 'multi_subunit': ['crbn', 'vhl']}
by_rung = []
for rung in rungs:
    stored = reach['\u2605_paired_body_size_comparison'][str(rung)]
    row = {'rung': rung, 'groups': {}, 'per_arm': {}}
    for arm in arms:
        seq = [c for c in cells if c['linker_atoms'] == rung and c['arm_id'] == arm]
        row['per_arm'][arm] = sum(c['n_accepted'] for c in seq)/sum(c['n_samples'] for c in seq)
    for group, ids in group_ids.items():
        seq = [c for c in cells if c['linker_atoms'] == rung and c['arm_id'] in ids]
        k, n = sum(c['n_accepted'] for c in seq), sum(c['n_samples'] for c in seq)
        assert k == stored['by_size_class'][group]['n_accepted']
        assert n == stored['by_size_class'][group]['n_samples']
        ci = wilson(k, n)
        assert max(abs(x-y) for x,y in zip(ci, stored['by_size_class'][group]['acceptance_ci95'])) < 1e-8
        rates = [row['per_arm'][arm] for arm in ids]
        row['groups'][group] = {'k': k, 'n': n, 'rate': k/n, 'wilson_ci95_arithmetic': ci,
                                'within_ratio': max(rates)/min(rates)}
    a, b = [row['groups'][g]['rate'] for g in ('single_domain', 'multi_subunit')]
    row['ratio'] = a/b
    row['between_ratio'] = max(a,b)/min(a,b)
    row['within_greater_than_between'] = max(g['within_ratio'] for g in row['groups'].values()) > row['between_ratio']
    row['birc2_exceeds_crbn'] = row['per_arm']['birc2'] > row['per_arm']['crbn']
    by_rung.append(row)
out['rung_summary_arithmetic'] = by_rung

ablation = []
for floor, stored in reach['\u2605_interface_floor_ablation']['by_floor'].items():
    row = {'floor': int(floor), 'groups': {}}
    for group, ids in group_ids.items():
        k = sum(stored['per_arm'][a]['n_accepted'] for a in ids)
        n = sum(stored['per_arm'][a]['n_samples'] for a in ids)
        row['groups'][group] = {'k': k, 'n': n, 'rate': k/n,
                                'stored_wilson_ci95': stored[group+'_ci95']}
    row['exact_ratio_from_counts'] = row['groups']['single_domain']['rate']/row['groups']['multi_subunit']['rate']
    assert round(row['exact_ratio_from_counts'], 3) == stored['ratio_single_over_multi']
    ablation.append(row)
out['ablation_summary_arithmetic'] = ablation
out['ablation_marginal_nesting'] = {arm: [reach['\u2605_interface_floor_ablation']['by_floor'][str(f)]['per_arm'][arm]['n_accepted'] for f in (12,6,0)] for arm in arms}
assert all(v == sorted(v) for v in out['ablation_marginal_nesting'].values())

out['rng_stream_definition'] = {'ablation': 'seed 777 + pose index is reused for all arms and floors; shared random numbers, not independent arm observations.',
                                'main': '20260725 + 1000*rung + crc32(arm)%997 + pose index',
                                'arm_salts': {arm: zlib.crc32(arm.encode('utf-8'))%997 for arm in arms}}
seed_jobs = defaultdict(list)
for arm in arms:
    for rung in rungs:
        for i, pose in enumerate(poses):
            seed_jobs[20260725+1000*rung+zlib.crc32(arm.encode('utf-8'))%997+i].append([arm, rung, pose])
out['rng_stream_definition']['main_seed_collisions'] = {str(k):v for k,v in seed_jobs.items() if len(v)>1}

old = {(a, p['pose_id']): p['stats'] for a, block in basins['arms'].items() for p in block.get('per_pose', [])}
new = {(c['arm_id'], c['pose_id']):c for c in cells if c['linker_atoms']==params['linker_max_atoms']}
comparison = []
for row in reach['cross_checks']['replicates_the_committed_E3_acceptance']['cells']:
    key = (row['arm'], row['pose'])
    x, y = old[key], new[key]
    p0, p1 = x['n_accepted']/x['n_samples'], y['n_accepted']/y['n_samples']
    se = math.sqrt(p0*(1-p0)/x['n_samples'] + p1*(1-p1)/y['n_samples'])
    z = (p1-p0)/se
    comparison.append({'arm': key[0], 'pose': key[1], 'old_k': x['n_accepted'], 'old_n': x['n_samples'],
                       'new_k': y['n_accepted'], 'new_n': y['n_samples'], 'old_rate': p0, 'new_rate': p1,
                       'difference': p1-p0, 'new_over_old': p1/p0,
                       'stored_reference_inside_new_only_interval': row['committed_inside_ci'],
                       'two_estimate_standard_error_diagnostic': se,
                       'two_estimate_z_diagnostic': z, 'absolute_z_above_1_96_diagnostic': abs(z)>1.96})
out['replication_check_diagnostic'] = {'scope': 'Arithmetic uncertainty illustration for two existing Monte Carlo estimates, not a replacement scientific acceptance test; both runs stochastic and pointwise criteria unadjusted.',
                                      'stored_status': reach['cross_checks']['replicates_the_committed_E3_acceptance']['status'],
                                      'n_stored_outside': sum(not r['stored_reference_inside_new_only_interval'] for r in comparison),
                                      'n_two_estimate_abs_z_above_1_96': sum(r['absolute_z_above_1_96_diagnostic'] for r in comparison),
                                      'rows': comparison}

grouped = {}
omitted = []
for entry in census['entries']:
    spec = classes[entry['pdb_id']]
    drops = {tuple(sorted(p)) for p in spec.get('exclude_pairs', [])}
    allosteric = {tuple(sorted(p)) for p in spec.get('allosteric_pairs', [])}
    present = {tuple(sorted(p['pair'])) for p in entry.get('chain_pairs', [])}
    candidates = {tuple(sorted(p)) for p in entry.get('ligand_bridged_chain_pairs', [])} | allosteric
    for pair in sorted(candidates - present - drops):
        omitted.append({'entry':entry['pdb_id'], 'pair': list(pair), 'classes':spec['classes'],
                        'basis': 'Stored ligand-spanning/allosteric candidate omitted from nonzero-contact chain_pairs; no new geometry measured.'})
    for pair in entry.get('chain_pairs', []):
        key=tuple(sorted(pair['pair']))
        if key in drops or (not pair['ligand_bridged_by'] and key not in allosteric):
            continue
        lo, hi = pair['n_contact_points_min'], pair['n_contact_points_max']
        for cls in spec['classes']:
            row = grouped.setdefault(cls, {'pairs':0,'entries':set(),'ligand':0,'curated':0,'fails_one':0,'fails_both':0,'rows':[]})
            row['pairs']+=1; row['entries'].add(entry['pdb_id'])
            row['ligand' if pair['ligand_bridged_by'] else 'curated']+=1
            row['fails_one']+=lo<12; row['fails_both']+=hi<12
            row['rows'].append({'entry':entry['pdb_id'],'pair':pair['pair'],'min':lo,'max':hi})
for cls, row in grouped.items():
    row['entries']=sorted(row['entries'])
    stored=census['summary_over_induced_pairs']['by_class'][cls]
    assert row['pairs']==stored['n_induced_pairs']
    assert row['fails_one']==stored['pairs_below_floor_in_at_least_one_direction']
    assert row['fails_both']==stored['pairs_below_floor_in_both_directions']
out['census_retained_selected_denominators']=grouped
out['census_ligand_or_curated_candidates_omitted_from_chain_pairs']=omitted
out['9MZA_stored_record']=next(e for e in census['entries'] if e['pdb_id']=='9MZA')

lo = params['linker_min_atoms']*params['linker_rise_per_atom_A']
hi = params['linker_gate_atoms']*params['linker_rise_per_atom_A']
mid = (lo+hi)/2
out['analytic_shell_proposal_check']={
    'source':'nr4a3_basin_search.py:569', 'lower_radius':lo, 'upper_radius':hi, 'mid_radius':mid,
    'implemented_quantile':'r=lo+(hi-lo)*u**(1/3)',
    'uniform_volume_shell_quantile':'r=(lo**3+u*(hi**3-lo**3))**(1/3)',
    'implemented_probability_radius_at_or_below_mid':((mid-lo)/(hi-lo))**3,
    'uniform_shell_probability_radius_at_or_below_mid':(mid**3-lo**3)/(hi**3-lo**3),
    'scope':'Analytic distributions only; no placements generated and no acceptance recomputed.'}
slack=math.sqrt(3)*0.9/2
out['analytic_predicate_nonidentity']={
    'grid_cell_A':0.9, 'cell_slack_A':slack,
    'sampler':'d_cell_center - cell_slack; three bands applied to lower bound',
    'census':'exact nearest-atom distance; same numerical radii, no slack',
    'hypothetical_point_at_cell_center_exact_distance_4_A':{'census':'contact', 'sampler_lower_bound':4-slack,'sampler':'soft clash'},
    'scope':'Logical example of two predicates disagreeing, not coordinates from any biological system.'}
out['ratio_offset_algebra']={'a':0.00081,'b':0.00090,'offset':0.00010,
                            'a_over_b':0.00081/0.00090,'after_common_additive_offset':0.00091/0.001,
                            'identity':'(a+c)/(b+c)=a/b only if c=0 or a=b (nonzero denominators). A common multiplicative factor cancels; no such run-bias model was established.'}
out['points_vs_residues']={'points_at_floor':12,'minimum_distinct_residues_for_exactly_12_points':6,
                          'maximum_distinct_residues_for_exactly_12_points':12,'observed_4_over_minimum_6':4/6}
out['odds_identity_scope_example']={
    'scope':'Hypothetical equilibrium algebra, not biological estimates.',
    'binary_identity':'For theta=D/(D+K), Kanti/Kon >= odds(A)/odds(B) is the binary shared-dose condition.',
    'simple_ternary_fraction_at_fixed_free_effector':'f_i=(D/K_i)*(E/K_E)/(1+D/K_i+(D/K_i)*(E/K_E)) for alpha=1.',
    'with_E_over_KE_equal_1':'f_i=D/(K_i+2D), hence f_i<0.5 at every positive D.',
    'Kon':1,'Kanti':100,'A':0.8,'B':0.2,
    'binary_odds_threshold':(0.8/0.2)*(0.8/0.2),
    'binary_Kratio_clears_threshold':True,
    'ternary_on_fraction_can_reach_A':False,
    'meaning':'A binary Langmuir condition cannot simply be relabelled as a sufficient general ternary-fraction requirement.'}
out['named_effector_verdict']=reach['verdict']['\u2605_the_named_effector']
out['notes']=['No raw biology, coordinate distances, source queries, producers, or stochastic reruns used.',
              'Arithmetic agreement is not scientific validation of the proposal, predicate, construct, calibration or inferential claims.']
encoded=json.dumps(out,ensure_ascii=True,indent=2)+'\n'
(ROOT/'reviewer-calculations.json').write_text(encoded,encoding='utf-8')
print(encoded,end='')
