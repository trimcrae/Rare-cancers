"""Read material metadata from delivered originals; no science calculation or corpus rescreening."""
from pathlib import Path
import json,sys
ROOT=Path(__file__).resolve().parent
B=ROOT/'source-intake/inputs'
def response(name):
 text=(B/name).read_text(encoding='utf-8')
 # Retained fetch text contains literal control/newline characters inside JSON strings.
 # Tolerate those for inspection only; exact input bytes remain unchanged.
 return json.loads(text.split('='*70+'\n',1)[1],strict=False)
out={}
for name in ['tcip-9mza-2026-08-07__rcsb_entry_9MZA.txt','tcip-9mza-2026-08-07__rcsb_assembly_9MZA.txt','tcip-kat-structure-2026-08-07__epmc_kat_tcip_record.txt']:
 out[name]=response(name)
for name in ['induced-proximity-transcription-2026-08-07___index.json','induced-interface-vs-output-2026-08-07___index.json']:
 d=json.loads((B/name).read_text(encoding='utf-8'))
 out[name]={'container_type':type(d).__name__,'record_count':len(d),
            'field_names':sorted({k for r in d for k in r}),
            'records_with_fullTextFile':sum(bool(r.get('fullTextFile')) for r in d),
            'scope_of_count':'Mechanical inventory of metadata records and file pointers only; no full-text terms counted or scientific classifications repeated.',
            'record_manifest':[{'index':i,**{k:r[k] for k in ['title','source','id','pmid','pmcid','doi','isOpenAccess','fullTextFile','chars','fulltext_path','file','path'] if k in r},
                               'fulltext_field_present':'fulltext' in r} for i,r in enumerate(d)],
            'selected_primary_records':[r for r in d if r.get('pmid') in ['42476129','40166243'] or r.get('doi') in ['10.1101/2025.03.14.643404','10.1016/j.cell.2026.06.037']]}
(ROOT/'source-intake/material-record-excerpts.json').write_text(json.dumps(out,ensure_ascii=True,indent=2)+'\n',encoding='utf-8')
if len(sys.argv)>1:
 item=out[sys.argv[1]]
 if len(sys.argv)>2:
  for k in sys.argv[2].split('/'): item=item[int(k)] if isinstance(item,list) else item[k]
 print(json.dumps(item,ensure_ascii=True,indent=2))
else:
 print(json.dumps({k:list(v) for k,v in out.items()},ensure_ascii=True))
