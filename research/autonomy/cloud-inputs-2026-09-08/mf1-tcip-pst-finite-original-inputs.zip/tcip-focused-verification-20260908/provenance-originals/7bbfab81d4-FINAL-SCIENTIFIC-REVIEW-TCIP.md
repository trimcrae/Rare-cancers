# TCIP: independent final scientific review of the frozen candidate

Review date: 2026-09-08. Reviewer: the commissioned independent gpt-6-astra/ultra agent. This is the single final scientific review of this TCIP candidate, distinct from earlier reviews of other papers. It is a review, not a submission, publication, producer run, or authorization to reopen a closed scientific program.

Frozen repository revision: `f43f1495f40d8aff7b4f34bd385d55aac521a500`, repository `C:/Projects/EMC-Research`. All Git reads used `GIT_NO_LAZY_FETCH=1`. There was no fetch, checkout, alternate source route, manuscript edit, structural remeasurement, stochastic rerun, new biological analysis, installation, broad test suite, or figure generation.

Main manuscript: `research/manuscripts/tcip/tcip-induced-interface-preprint.md`, 28,068 bytes, SHA256 `2e2b7862c3c6412ff4ae9086fd2acca799ae8999511ca607d1a49e416e82d9a9`.

Supporting information: `research/manuscripts/tcip/tcip-induced-interface-preprint-si.md`, 16,663 bytes, SHA256 `3483c0bbcbd94e4faa5b3de38da8010130b189336b79ac27cd08101c56748ba3`.

## Scientific disposition

**HOLD this frozen candidate. Recommend one coherent major revision as a narrowly framed audit and parameter-sensitivity paper. Park the stronger claim that an actual transcriptional complex calibrates, or demonstrably fails, this sampler's inherited interface floor.** That stronger claim requires matching measurement and admission predicates, with the relevant complex units and original source provenance established. The current record does not provide that equivalence.

The manuscript has a useful, reproducible computational observation: changing one contact-count threshold changes the observed pooled acceptance ordering of four particular staged bodies in one toolchain. The reported ablation ratios reproduce from the retained counts. The code also contains a consequential point-versus-residue naming mismatch. A selected deposited-structure census provides additional descriptive evidence about a separately defined contact-band score. Those are sufficient ingredients for a limited methods/audit contribution. They do not establish a biological interface requirement, a modality-general floor, a physical orientation-volume ratio, or a calibrated false-rejection rate.

The central scientific defect is more specific than insufficient sample size. The census uses exact nearest-atom distances; the placement sampler uses a grid-distance lower bound with a 0.7794-A cell slack. Identical radii and query-point construction do not make these predicates identical. Therefore the frozen paper's repeated claim that the measured crystal complexes "would be rejected by this sampler's predicate" is not established. The census additionally filters out pairs with zero contact-band points before selecting induced pairs. In 9MZA that removes two ligand-bridged BCL6/p300 pairs and leaves the two cross-protomer interfaces reported as 6/7. This does not erase the retained measurements; it changes their scientific interpretation and the completeness of the reported denominator.

A coherent revision can use existing records without any new geometry or sampling. It must separate (1) observed sensitivity of one sampler, (2) a descriptive exact-distance census, and (3) unresolved calibration and biological transfer. The repair batch below is the complete scientific batch from this review. It is not a request for sequential exploratory edits or another baseline review. If the authors require the present headline claim to remain the paper's central merit, **PARK that version** until the source-level reopening conditions below are met.

No hold is imposed merely because this is computation-only work, because there are no rendered figures, because only one TCIP system was located, because a raw execution transcript is absent, or because repository publication machinery was not run. The hold follows from identifiable claim-to-method mismatches.

## Review scope and evidence conventions

The entire main manuscript (lines 1-393) and entire SI (lines 1-277) were read. The settlement, manifest and hash file were read in full. Scientific code branches, retained enumeration counts, selected census records and classifications, original committed E3 comparison counts, arm provenance metadata, and material linked arguments were inspected. This report does not claim that reading derived JSON independently verifies its underlying coordinates or original execution.

In the findings, **M** means the fixed main manuscript; **S** means the fixed SI. **Reach** means `research/modalities/nr4a3_tcip_reach.py`; **Basin** means `research/modalities/nr4a3_basin_search.py`; **Geom** means `research/modalities/basin_geom.py`; **Census** means `research/modalities/nr4a3_induced_interface_census.py`. All source line numbers refer to the fixed revision above. JSON paths identify fields in the exact retained files, not a mutable current checkout. The input manifest gives every retained source, byte count, SHA256, local copy, and actual read scope.

One new deterministic reviewer calculation was run, exit 0. Its script, JSON output, stdout and exit receipt are separate from author records. It performs arithmetic over retained summaries and illustrative algebra only. It does not load atom coordinates, import or execute producers, draw random samples, or create biological estimates. Arithmetic agreement is not validation of a scientific model.

Priority P1 means a scientific correction required before this candidate can be accepted. P2 means a material reproducibility or communication correction that belongs in the same batch. Findings include minimum repairs and distinguish them from stronger claims that need new evidence.

## Findings

### F01 — P1: the census and sampler do not use the same distance predicate

**Outgoing claims:** M61-68, M172-176, M189-190, M205-215, M221-225 and M277-279; S84-100. The paper calls the measurements the sampler's own predicate, says the real TCIP fails its floor, and explicitly defines every such failure as rejection by that sampler.

**Source evidence:** Census467-490 computes an exact nearest-heavy-atom distance through `CellHash.min_dist` and bins it at 3.0, 3.6 and 6.0 A. Basin564-565 and Basin598-607 instead use `field3.min_dist(point) - field3.cell_slack`. Reach1548 constructs the 0.9-A distance grid. Geom259-328 implements cell-center distance lookup and a half-cell-diagonal slack, `sqrt(3)*0.9/2 = 0.7794228634 A`.

This slack is a conservative distance bound for avoiding clashes. It is not an exact distance, and using it in a three-band contact classifier changes the score. An analytic example suffices: a query point at a grid-cell center whose true nearest-atom distance is 4.0 A is a contact under the census, but its sampler lower bound is approximately 3.2206 A, a soft clash. Conversely, some points outside the exact 6-A boundary can enter the sampler contact band. The count is therefore not related by a simple order-preserving correction. I did not remeasure any structure, and this example is not an assertion about a particular 9MZA atom.

The unit of comparison also differs. The census evaluates individual chain pairs. The sampler moves the staged arm, which can be a multichain body, against the target and applies anchor clearance, hard-clash rejection, a soft-clash budget and the contact floor. A chain-pair contact score by itself is not the full placement admission decision.

**Consequence:** The observed exact-distance scores of 6/7, 10/11, etc. can be reported as those scores. They do not establish how the actual gridded sampler would score or admit those complexes. The operational clarification at M221-225 makes the mismatch more consequential: the paper expressly claims a software rejection that has not been demonstrated. A generic statement that both methods use the same thresholds does not repair it.

**Minimum repair with current records:** Define the two predicates separately, including grid spacing/slack, query points, chain/body units and all acceptance conditions. Replace "same predicate," "like-for-like," and "would be rejected by this sampler" with an explicitly hypothetical comparison between a 12-point cutoff and the exact-distance census score. Withdraw the claim that this comparison calibrates or bounds the implemented sampler's floor. Preserve the actual retained values without silently converting them to another metric.

**Reopening the stronger claim:** Provide actual retained original evidence evaluating known-answer complexes with the same grid construction, query construction, target/body units, excluded constitutive contacts and admission rules, together with input identities and outcomes. A formally demonstrated equivalence would also suffice, but the code now inspected is not equivalent. If no such record exists, generating one is new scientific work and requires separate authorization; it is not an implicit instruction from this review.

### F02 — P1: acceptance is probability under a nonuniform proposal, not a measured orientation-space volume

**Outgoing claims:** M55-59, M121-149 and M283-289; S30-37. The paper repeatedly interprets acceptance ratios as fractions of orientation space and calls the floor-zero result "25% more" admissible space.

**Source evidence:** Basin569 labels the radial draw "uniform in the shell VOLUME" but implements

`r = L_min + (L_max - L_min) * U^(1/3)`.

For a nonzero inner radius, uniform shell volume instead requires

`r = (L_min^3 + U*(L_max^3 - L_min^3))^(1/3)`.

The committed 12-atom rung has `L_min=3.75 A` and `L_max=15 A`. At the midpoint radius 9.375 A, the implemented proposal puts probability 0.125 inside that radius; uniform shell volume gives 0.232142857. Direction and quaternion generation are uniform in their respective spaces (Geom134-159), but the joint placement proposal is not uniform in translation volume. The result also averages a fixed selected set of 12 warhead anchors rather than a physically defined ensemble of anchor states.

Reach263-300 and Reach363-379 additionally relate sampler acceptance to a body-free grid-volume denominator. Those quantities use different measures. Their quotient is not automatically a conditional survival probability or a physical body cost.

**Consequence:** The numerical pooled ratios remain arithmetic facts about this proposal. They are not ratios of uniformly measured admissible orientation/translation volume and are not equilibrium probabilities, binding probabilities or linker realizability estimates. Applying the same proposal to every arm does not prove that its radial weighting cancels: different body geometries can accept different radial regions.

**Minimum repair:** State the actual proposal and call the result an observed proposal-acceptance fraction conditional on the fixed inputs. Define precisely what is averaged and weighted. Replace physical volume language and any interpretation of the body-free quotient as a common-measure probability. Record the radial formula discrepancy in the methods audit; do not retrospectively relabel the retained run as having used the corrected formula.

**Stronger reopening:** A uniform-volume or physical-ensemble result would require a correctly defined measure and matching retained computation or a separately authorized new analysis. No such rerun is necessary for the narrower audit paper.

### F03 — P1: the census selection omits zero-contact ligand-bridged pairs and obscures 9MZA's chain topology

**Outgoing claims:** M61-68, M178-203 and M207-210; S105-129, S193-206 and S212-236. The manuscript presents two induced interfaces for 9MZA and describes the ligand as contacting 33-42 atoms' worth of each partner.

**Source evidence:** Census575-576 discards every chain pair for which both directional contact-band counts are zero, before `induced_pairs` chooses ligand-bridged or curated pairs. This is selection on the measured outcome. Other eligibility rules include the protein-chain atom criterion at Census504-512, the minimum ligand size and exclusions at Census515-536, and at least three ligand heavy atoms within the ligand-contact radius for a chain to enter `spans`. The SI does not give a complete denominator flow through those rules.

The retained `nr4a3-induced-interface-census.json`, `/entries/21` (9MZA), lists five ligand-bridged chain pairs: A/B, A/C, A/D, B/C and C/D. A/C is the explicitly excluded constitutive BCL6 dimer. A/B and C/D are absent from `chain_pairs`; given the displayed code and populated query sets, their omission is explained by the zero-contact-band filter. This is a source-logic inference, not a new structural measurement or an independently retained zero-score profile. Their full hard/soft profiles are not retained, so those profiles cannot be invented or reconstructed from the omission.

Chains A and C are BCL6; B and D are p300. The ligand recorded on A contacts 33 BCL6-A atoms, 42 p300-B atoms and 18 BCL6-C atoms. The ligand recorded on C contacts 16 BCL6-A atoms, 33 BCL6-C atoms and 40 p300-D atoms. The displayed 6/7 interfaces are A/D and B/C, the cross-protomer pairs. Thus the prominent 33-42 ligand-contact counts describe the dominant A/B and C/D attachments; they are not the per-partner counts for the displayed A/D and B/C pairs. A ligand spans the BCL6 dimer, so a complete description must explain this multichain arrangement.

The reviewer set comparison found these two omitted 9MZA candidates and no additional omissions among the retained ligand/curated candidates in the other 21 entries. The published selected degrader denominator of 15 pairs and its six below-cutoff rows reproduce. That agreement is conditional on this entry list and selection procedure, not a population false-rejection rate.

**Consequence:** "6-7 points" is a retained measurement of two particular chain interfaces, not a complete account of all ligand-bridged BCL6/p300 pairs in this deposition. Excluding zero-score pairs is especially material in a paper about the minimum contact score. These omitted pairs must not be recoded as absent source, failed parsing, no ligand bridge, or known biological inactivity.

**Minimum repair:** Give a census flow table with entry selection, chain/ligand eligibility, all candidate induced pairs, curated exclusions, zero-contact-band omissions, and retained scored pairs. Explicitly disclose the two omitted pairs and the limits of what their omission demonstrates. Label A/C as the BCL6 dimer and distinguish the dominant ligand attachments from the cross-protomer interfaces. Correct the 33-42 statement or give the actual directional ligand-contact counts for the named pairs. Keep the 6/7 and 4-residue values as chain-pair observations. Do not silently regenerate missing profiles or replace the retained census with a new measurement.

**Stronger reopening:** A claim about the interface of the full induced complex needs a declared complex/assembly unit and an original record scoring that unit with a justified definition. Chain-pair scores cannot be summed or promoted to a full-complex score without accounting for the multichain geometry and score definition.

### F04 — P1: the controls and one-system structure do not establish a calibrated or biological floor

**Outgoing claims:** M3-10, M36-40, M46-53, M88-117, M167-215 and M227-230; S153-155, S210-236 and S274-277. These include a modality-general parameter result, a structural upper bound, the conclusion that the small count belongs to the interface rather than the instrument, and a truncation control based on residue counts.

**Evidence and reasoning:** The code establishes inheritance within this toolchain and the absence of a recorded derivation beside this parameter. M101-105 correctly acknowledges that other samplers were not surveyed. The title, abstract framing and SI nevertheless repeatedly promote that observation to proximity design or the modality generally. One source-code lineage is not evidence of field prevalence or a universal physical requirement.

The reconstruction that a PROTAC requires a cooperative buried target/E3 interface across which ubiquitin is transferred is not derived by the cited source. The sampler has separate transfer-geometry machinery (Basin121-134); its interface-floor comment is not a mechanistic proof. Labelling an unsupported reconstruction as a hypothesis prevents it from becoming an established fact, but it still does not justify the broad inheritance story.

The BCL6 dimer controls show that the chosen score can produce large values and that two depositions produce comparable large-interface scores. They do not establish score accuracy, resolution at small interfaces, biological relevance, or equivalence with the sampler. A coarse CA/centroid shell score can distinguish a large interface while still being a poor descriptor of a small one. Counting only probes in a 3.6-6.0-A shell also deliberately omits closer probes from the contact tally; it is not total atom contacts, buried surface area or a complete interaction network.

Resolved chain sizes of 122-123 and 112-113 residues establish how much of these constructs contributed to the score. They do not establish that the relevant full-length interface is complete, that no unresolved segment matters, or that the structure is free of construct or crystal-context effects. The two copies are valuable within-crystal observations, but are one system and one crystal form, as the paper correctly states elsewhere. Repetition within that form is not an independent functional calibration dataset.

Similarly, six below-cutoff chain-pair observations among 15 selected degrader/glue pairs are a useful descriptive result. Repeated copies and related complexes are dependent. Recruiter clustering of the below-cutoff rows (S153-155) does not itself distinguish an uncalibrated cutoff from structural, construct or score-specific variation, and is not a noise test.

**Minimum repair:** Scope the inheritance claim to this toolchain throughout, including title/front matter. Treat the census as a descriptive selected-structure comparison under its stated score. Describe the dimer checks as dynamic-range/consistency observations and the residue counts as construct coverage, without claiming that they exclude instrument or truncation explanations. Remove the unsupported ubiquitin-interface necessity story or leave only the precisely sourced software provenance. Replace "bounds the floor from above" with the narrower observation actually supported after F01-F03. Keep the existing n=1 and no-activity limitations, but make the affirmative claims consistent with them.

**Stronger reopening:** A counterexample to a specified biological necessity requires a clearly defined necessary property, an appropriate measurement of that property in the relevant functional complex, and original evidence for the pertinent function. A calibrated threshold additionally needs an appropriate positive/negative or outcome-linked dataset and an explicit calibration procedure. Neither a large-interface control nor a literature count supplies that procedure. This review does not commission those experiments or analyses.

### F05 — P1: the paired design and uncertainty claims exceed what the retained summary statistics establish

**Outgoing claims:** M121-160; S35-37, S67-72 and S176-206. The manuscript treats a repeated point-estimate ordering as a robust sign inversion, uses overlapping class intervals to discuss the size contrast, and describes historical reruns as independent support.

**Retained arithmetic:** The main enumeration contains six arms, 12 anchors and eight rungs: 576 cells, each with 300,000 draws, or 172,800,000 draws in total. The four-body pooled comparison uses two arms per class, not six biological replicates. At a single rung each main class aggregates 24 cells and 7,200,000 draws. The 12-atom ablation uses 30,000 draws per arm/anchor, or 720,000 per pooled class per floor.

| Floor | Single-domain accepted / sampled | Multi-subunit accepted / sampled | Ratio from counts |
|---|---:|---:|---:|
| 12 | 583 / 720,000 | 651 / 720,000 | 0.895545 |
| 6 | 6,315 / 720,000 | 5,632 / 720,000 | 1.121271 |
| 0 | 57,657 / 720,000 | 45,990 / 720,000 | 1.253686 |

These support the displayed rounded 0.896, 1.121 and 1.254. The stored floor-12 class intervals overlap: approximately [0.0007466, 0.0008781] and [0.0008374, 0.0009763]. This observation does not by itself test the paired ratio, because that requires its covariance.

**Source evidence:** Reach611-655 reuses `random.Random(777 + pose_index)` across arms and floors in the ablation. This is a common-random-number design. The draw sequence and nested floor criterion can support efficient paired comparisons, but the arms are not independent observations. The stored class Wilson intervals are formed from pooled marginal accepted/sample counts; no cross-arm joint acceptance counts or paired ratio interval is supplied. Counts are also conditional on heterogeneous fixed anchor strata, not biological sampling units. A nominal pooled-binomial interval does not quantify uncertainty across proteins, target conformations, anchors drawn from a biological population, or source structures.

The main enumeration uses a different per-cell seed construction (Reach1575-1587). Its truncated CRC salts also collide: BCL6 and VHL share seven shifted pose streams per rung, 56 seed collisions across the eight rungs. This does **not** contaminate the four-body pooled comparison with BCL6: BCL6 is excluded, and the four pooled arms have distinct streams. It does limit claims that all 576 cells or all six-body comparisons are independent. The collisions are a documented design property, not evidence that any retained count is false.

The 0.894 result at 40,000 draws is asserted in the linked route memo, not demonstrated by a separately retained 40,000-count record inspected here. If runs reuse seeds, a larger run may contain a shorter run's prefix; it would not be an independent replication. The actual relationship cannot be determined from the memo alone. Likewise, a claim of byte-identical full JSON across two processes requires the original compared outputs or a defined normalization of volatile fields, because producer outputs contain runtime/date metadata. Stable seed choice establishes reproducibility of random input, not convergence or biological validity. The old salt-induced swing is not a calibrated estimate of uncertainty.

**Minimum repair:** Identify the sampling unit, proposal, fixed strata, pooling weights, common streams and retained counts. Report the table as observed point estimates under those conditions. If inferential language about the underlying acceptance ratio is retained, provide an uncertainty method that uses the actual paired design and available joint records; otherwise explicitly refrain from treating the rounded sign change as a significance claim. Do not infer independence from identical anchors or byte determinism. Label the 40,000-draw and two-process checks as historical reported checks whose original supporting records are or are not supplied. Preserve the distinction between sample-count arithmetic, numerical Monte Carlo uncertainty and cross-system generalization.

**Stronger reopening:** Existing original joint acceptance summaries or a justified design-aware uncertainty record could support a stronger Monte Carlo claim. Their absence does not require recreating trajectories, rerunning a producer, or abandoning the descriptive sensitivity table.

### F06 — P1: the cross-run disagreement cannot be dismissed by an offset-cancellation argument

**Outgoing claims:** S44-55 reports `DISAGREES`, 5/24 outside a recomputed interval against 1.20 expected by chance, then states that a level offset cancels in every within-run ratio.

**Source evidence:** Reach561-608 compares each old acceptance estimate to the new estimate's confidence interval. The retained original counts in `nr4a3-orientation-basins.json` show that the old values themselves are Monte Carlo estimates, with 1,000,000 draws per compared cell; the new values use 300,000. Treating the old estimate as an exact reference omits its uncertainty. Consequently 24*0.05 is not automatically the expected number of violations of this implemented comparison under equality of the underlying probabilities. The 24 pointwise comparisons also have not been calibrated as one family-level replication test.

The reviewer performed an explicitly labelled arithmetic diagnostic using both retained marginal variances. It changes the count of absolute standardized differences above 1.96 from the original five interval violations to three. This is an illustration of the omitted uncertainty, **not** a replacement acceptance test and not evidence to relabel the artifact `AGREES`. The original `DISAGREES` status must remain identifiable under its original rule.

The differences have mixed directions and magnitudes; no common-offset model is established. Even a common additive offset does not cancel in a ratio: `(a+c)/(b+c) = a/b` only when `c=0` or `a=b`, for nonzero denominators. For example, 0.00081/0.00090 = 0.90, whereas adding 0.00010 to both gives 0.91. A common multiplicative factor would cancel, but its existence is an additional assumption unsupported by this cross-check. A common additive offset can preserve a same-run ordering while still changing the ratio; that narrower algebra does not validate the claimed cancellation.

**Consequence:** The paper appropriately discloses the status, but then supplies an invalid explanation for why it cannot affect any reported relative quantity. Within-run comparisons can still be described. Their portability or numerical replication cannot be established by the cancellation sentence.

**Minimum repair:** Retain the exact original status and 19/5 outcome with a clear account of its comparison rule. State that both runs are estimates and that the check is not a calibrated global replication decision. Remove the ratio-cancellation assurance and the implication that the discrepancy can affect only absolute rates. Keep the current-run arithmetic separate from unresolved cross-run reproducibility. Do not convert this reviewer's illustrative diagnostic into a new author replication result.

### F07 — P1: the four-body comparison does not identify the controlling physical variable or a universal size effect

**Outgoing claims:** M55-59, M141-165 and M231-247; S189-191. These say the entire measured penalty is the floor, that it is monotone in the floor, that body size is not the controlling variable, that shape/exit geometry is, and that an admitting answer is an upper bound on what a nucleus would allow.

**Evidence and reasoning:** Changing only a filter in a fixed computation is a controlled software intervention. The retained ablation therefore supports sensitivity of this particular acceptance ordering to that filter. It does not isolate body size as a causal factor. The four bodies differ in shape, multimeric extent, ligand pivot and exit geometry as well as residue count; there are only two bodies in each category. Within-class spread larger than a between-class contrast does not logically refute a size contribution. It is compatible with a size effect plus stronger other variation. It also does not identify shape or exit geometry as the controlling cause without an isolating comparison.

The three observed ratios are ordered at floors 12, 6 and 0. Each body's acceptance must be monotone as an otherwise identical minimum-count filter is relaxed, but a ratio of two monotone acceptance functions need not be monotone. The reported three points do not establish monotonicity across all intermediate thresholds or other rungs.

The target-side anchors are an additional conditioning choice. Basin329-426 constructs a selected ensemble around a modelled pocket, using geometric eligibility and spacing; it is not an experimentally observed warhead-anchor distribution. The solvent-clearance construction checks specified points along the proposed exit rather than proving all linker paths and chemistry realizable. Matching those anchors between arms is useful internal control; it does not remove the target/model dependence of the numerical comparison.

No tested body having zero accepted placements does not show that the geometric gate cannot fail. A found accepted placement is information about that model's feasibility under its rules, although not about binding or biological productivity. The sentence "a gate that cannot fail carries no information" confuses no observed failures with impossibility of failure. Similarly, omitting domains/DNA/chromatin relaxes particular steric constraints in a fixed-coordinate model; it does not establish a quantitative universal upper bound on nuclear recruitment, where conformational states, anchor geometry and other interactions are not represented.

**Minimum repair:** Describe a fixed-four-body, fixed-target, fixed-proposal sensitivity experiment. Say that the selected ordering is not a size law, without claiming to have disproved a size effect or identified a unique cause. Restrict monotonicity to what the filter mathematically guarantees and the three sampled ratios actually show. Explain anchor selection and its conditional scope. Replace the no-information and universal upper-bound claims with precise statements about model admissibility and omitted constraints. The no-binding/no-function limitations should remain.

**Stronger reopening:** A causal body-size or transferable effector comparison would require a design that separates size from shape, exit geometry, constructs and target context. That is beyond this repair and no new design is authorized here.

### F08 — P1: the residue interpretation reverses the inequality and cannot support "roughly half either way"

**Outgoing claims:** M271-279, especially M278-279; S98-100.

**Source evidence:** The query set contains up to two scoring probes per residue: CA and side-chain centroid, with CA reused for glycine. A count of exactly 12 probes can represent between six and 12 distinct residues. A threshold requiring at least 12 points does not impose a threshold of "at most 6 residues' worth." Six is the minimum number of residues that could supply exactly 12 points. The observed four-residue count divided by six is 2/3, not roughly one half; division by 12 gives 1/3. There is no single residue-count conversion.

**Consequence:** The point-name mismatch is a valid and useful finding, but the attempted alternate residue comparison introduces a second error. Probe count is also not a count of actual interatomic contacts: a side-chain centroid is a geometric proxy, and the same CA position can contribute twice for glycine.

**Minimum repair:** Keep "12 scoring points, potentially supplied by as few as six residues." Delete the "at most six" and "roughly half either way" argument. Report six/seven contact-band points and four distinct residues separately, under the exact-distance census definition. A corrected title should not depend on a residue conversion or the unestablished predicate equivalence in F01.

### F09 — P1: the literature searches do not establish a field-wide absence, comparative prevalence, or discovery exclusivity

**Outgoing claims:** S238-257; M107-117, M260-267 and Appendix B (M387-389). The strongest SI wording says the absence is a property of the field rather than the search, then infers why a floor was inherited. The linked sizing memo makes the same claim and says the structure is findable only by its two proteins.

**Retained source narrative:** `tcip-interface-floor-sizing.md`125-173 records the two Europe PMC sweeps and the RCSB searches. One query selects proximity/transcription terms; the comparison query explicitly selects interface/cooperativity/residence-time terms before examining outputs. These are not matched searches for a comparative prevalence estimate. Their open-access subsets are selected again by availability. Exact-term nonoccurrence is not proof that the underlying concept or an equivalent measurement is absent. A known-positive retrieval check tests that positive, not comprehensive sensitivity.

The reported 100 and 300 records need their original result metadata to distinguish total hits from retrieval/page caps. The reported 20 and 51 full texts need an accession-level inclusion/count record, extraction rule and classification support to be reproducible. The retained author memo is a narrative source for those numbers, not an independent re-count of the original source collection. The original source records available to this review are identified separately in the source-scope supplement below; absent material is not silently treated as reviewed.

Two zero-result modality-name queries followed by a successful protein-name query show the outcome of those queries. They do not show that protein names are the only possible discovery route. M180-181 and M266-267 already use the defensible limited-search formulation; the SI and novelty story must agree with it.

Finally, two or more interface sizes with matched output can help study a relationship, but do not by themselves settle a calibration curve or identify causality. Changes in ligand, construct, cooperativity, exposure, occupancy and readout can confound the relationship. Replication and an appropriate model remain necessary for a predictive calibration claim.

**Minimum repair:** Describe the searches as bounded retrieval observations, with exact query/date/limits and retained-record availability. Remove field-wide absence, matched-prevalence and exclusive-discovery conclusions. Do not use asymmetric term counts to explain a field's design choices or to claim novelty beyond the documented search scope. State that an outcome-linked series would inform calibration, with the relevant controls, rather than automatically settle it. Cite the original TCIP primary record for its actual contribution when available; do not present a memo's quotation as an independently inspected full paper.

**Stronger reopening:** Existing original search responses and screened-record tables could establish what those searches returned and how the counts were made. They still would not prove field-wide absence. A broader literature claim would need a suitable, explicitly bounded evidence strategy, not source-denial retries or a new search campaign commissioned by this review.

### F10 — P1: the selectivity odds identity is transferred beyond the model in which it was derived

**Outgoing claims:** M81-82 and M248-252 say a TCIP's selectivity requirement is not smaller than a degrader's and needs the same odds-product difference in induced-complex-fraction space.

**Actual linked argument:** `research/manuscripts/degrader/selectivity-requirement-sizing.md`100-164 derives the shared-dose condition for binary Langmuir occupancy, `theta_i(D)=D/(D+K_i)`. Its lines 384-394 then transfer the identity to ternary induced-complex fraction and the sum of binary and interface free-energy differences, while also acknowledging a nonmonotone dose axis. No derivation supplied in those passages establishes that general transfer.

For any specified fractions A and B, an odds separation can be defined algebraically. Equating it to an equilibrium binding-energy difference and treating the binary shared-dose condition as a sufficient ternary window criterion requires additional assumptions. Even a simple fixed-free-effector model with equal effector binding and no cooperativity has ternary fraction `f_i=D/(K_i+2D)` when `E/K_E=1`; it never reaches 0.5. Hypothetical `K_on=1`, `K_anti=100`, `A=0.8`, `B=0.2` satisfies the binary selectivity-ratio threshold of 16, yet cannot achieve A in that ternary model. This is an algebraic counterexample to an unrestricted sufficient transfer, not a biological calculation or a claim that these are TCIP parameters. General ternary systems require the species, concentrations, cooperativities, mass balance and dose regime to be specified.

More directly, the paper says the anti-target ceiling lacks a candidate source. Without comparable on-target and anti-target specifications and a valid transfer model, the ordering "not smaller than a degrader's" is not established. Unknown requirements are not evidence of equal or greater requirements.

**Minimum repair:** Remove the quantitative ordering and unsupported ternary identity from this paper. State that selectivity requirements were not estimated and cannot be inferred from the geometric result. If the binary identity is retained for context, label its assumptions and avoid mapping it to a general TCIP requirement. This correction does not reopen the underlying NR4A selectivity program.

**Stronger reopening:** A derivation for the particular ternary model, with its approximation regime and the necessary response specifications, is required for the stronger claim. Neither a linked assertion nor algebra over binary occupancy supplies it.

### F11 — P2: the named-effector contradiction has a specific derived-reporting cause and does not require a scientific rerun

**Outgoing claims:** S57-65 appropriately discloses that the populated named-effector block and the verdict disagree. M242-247 uses only the populated results and keeps them out of the pooled proxy comparison.

**Source evidence:** In `nr4a3-tcip-reach.json`, the populated `★_named_effector`, `body_geometry` and per-arm tables contain the named arms; `verdict/★_the_named_effector` says none were staged. Reach1722-1740's `--refresh-derived` branch calls `verdict` without the named-effector argument; the verdict function defaults that argument to an empty result. The full-build path supplies it. This is a concrete way the contradictory verdict can be produced without losing the sampled cells. The linked generated reach Markdown also retains a no-named-effector statement despite the populated data.

Agreement among three fields derived from one artifact is internal consistency support, not three independent validations. Nonetheless, the retained cell inventory and arm metadata support reporting the named arms as present. There is no basis to discard those data solely because a derived verdict defaulted incorrectly.

**Minimum repair:** Preserve the current explicit disclosure, identify the owner and correct derived reporting from retained data if that code/report repair is admitted. State which fields own the published numbers and which are stale. A producer or named-effector geometry rerun is not scientifically necessary to resolve this inconsistency and is not authorized by this review. If the artifact remains frozen, a precise erratum/interpretation note is sufficient for the narrow paper, provided all published conclusions use the populated fields consistently.

This is not, by itself, an irreducible merit blocker. It belongs in the same repair batch because it affects reproducibility and reader trust in a canonical artifact.

### F12 — P2: the reproduction instructions do not identify an executable, immutable input closure

**Outgoing claims:** M283-289 and M324-331; S259-267. The SI gives two no-argument Python commands and mutable branch names as the reproduction route.

**Source evidence:** Census685-690 requires a corpus-directory argument and otherwise emits usage/returns 2. The displayed no-argument census command therefore does not run the census. This conclusion is from source inspection; the scientific producer was not executed. The reach analysis depends on staged target and arm coordinates, registry files, helper modules and model-derived anchor inputs, not merely the eight main dependencies listed by the settlement hash file. Retained registries point to results paths and record particular source entries/constructs, but those paths alone are not immutable copies of the actual coordinate inputs.

`literature-cache` and `ci-input/tcip-interface-floor-2026-08-07` are branch names, not exact versions of every input. Deterministic/offline analysis is possible only after the correct input corpus has been materialized. Stable seeds are useful but do not alone make full JSON byte-identical when runtime/date fields are written.

The settlement's self-entry for MANIFEST.md is stale, while the actual file is 15,854 bytes with SHA256 `cff7b9317f3393a64e5f096aec0d8bf44ba1377087a395ebd580539484535e88`. This is an administrative self-reference defect already disclosed by the commissioner, not a failure of the main/SI or material dependency hashes. All ten main/SI/dependency hashes checked by the reviewer match the supplied hash file.

**Minimum repair:** Supply correct commands with required arguments, exact code revision, necessary runtime assumptions and an immutable manifest for the inputs needed by each command. Separate reproduction of published tables from retained JSON from reproduction of original geometry/sampling. State which original inputs and execution records are actually included. Do not imply that this review independently reran the geometry. Correct the manifest self-description without changing original evidence records in place.

No broad whole-repository staging, full test suite, original-run reconstruction, source query or producer run is required to write accurate reproduction instructions. Missing original input closure limits the claim of independent reproduction; it does not make the retained arithmetic disappear.

### F13 — P2: standalone communication must expose the material definitions and results rather than rely on planning prose

**Outgoing presentation:** M291 onward gives six figure specifications rather than six rendered figures. The main and SI already contain useful numerical tables. The current paper repeatedly relies on an internal decision memo to define provenance and controls.

**Assessment:** No decorative or mandatory-figure hold is justified. A prose-and-table methods paper can communicate this contribution. The current tables are enough to show the point estimates, but they do not expose the essential mismatches found above. A reader needs the actual proposal/score definitions, the census selection flow and 9MZA chain map, the retained sample counts and uncertainty scope, and exact original-source coverage. Those can be concise tables and text. Figure specifications should either be fulfilled with already authorized source material or removed from the submitted scientific artifact; they must not be counted as existing visual evidence.

The census class totals overlap: 9MZA is both `tcip` and `induced_transcriptional`. The totals cannot be summed as independent observations. The five nuclear-receptor/coactivator entries contribute ten `allosteric_curated` pairs; those are named classifications, not coordinate proof of ligand dependence. The selected class table is appropriately split in S124-129, but the full entry/selection definition should be reader-accessible rather than inferable only by executing a script.

**Minimum repair:** Use actual tables to make the central result self-contained. Include a clear distinction between exact-distance census scores and gridded sampler acceptance, a complete selected-entry/candidate-pair flow, and an explanation of overlapping classes and repeated crystal copies. Resolve the title/abstract/limitations inconsistencies in one rewrite around the final scientific claim. Cite the original primary record for the deposited system and accurately identify the reach of any abstract-only review. A reference list, guard count or figure plan cannot establish scientific provenance.

## Coherent repair batch and exact reopening boundaries

The recommended next step is **one scientific rewrite using existing records**, with these integrated changes:

1. Reframe the paper around sensitivity and measurement definitions in one toolchain. Replace the universal inheritance/floor-calibration headline and all equivalent affirmative claims. Keep the observed ablation ratios and the point/residue discrepancy as the primary findings.
2. Define the actual proposal, grid lower-bound classifier and exact-distance census classifier. Correct the measure language and give the fixed-anchor/body/target conditioning. Do not change the historical computation by prose.
3. Repair census denominators and 9MZA topology, disclose the omitted zero-contact-band pairs, and delimit the scope of repeated copies and curated allosteric classifications. Keep full-complex and functional inferences unresolved.
4. Present retained counts and design-aware uncertainty limits. Correct the cross-run comparison interpretation, remove offset cancellation and unsupported independence/convergence claims, and label historical checks by their actual evidence status.
5. Remove causal size attribution, a universal steric upper bound, the unsupported ternary-selectivity ordering, and field-wide absence/novelty conclusions. Keep the limited-search and no-biological-inference statements consistent with the rest of the paper.
6. Repair derived named-effector reporting or attach a precise frozen-artifact erratum; provide correct reproduction commands and immutable available-input provenance. Replace planning figure text with a finished prose/table presentation sufficient for the narrowed claim.

This is a finite correction batch, not a request to develop a new TCIP program. One focused verification may assess whether this batch addresses these findings and whether changed claims match their retained dependencies. Another whole-paper baseline or broad prepass is not warranted merely because the repair is substantial.

The following stronger claims remain parked unless their **specific** evidence appears:

| Stronger claim | Evidence that would reopen it |
|---|---|
| Real 9MZA/degrader complexes fail the implemented sampler | Retained matching-predicate results, with exact coordinate/assembly/body units, grid parameters, query definition and full admission criteria; or a valid equivalence proof. |
| A biological or transferable TCIP interface floor is bounded/calibrated | An explicit necessary-property definition, appropriate measurement in a relevant functional complex and original function evidence; calibration needs an appropriate outcome-linked or positive/negative dataset and method. |
| The ratio measures uniform admissible volume | Matching results under the specified volume measure, or a valid transformation from retained weighted samples with sufficient records. |
| The size effect, its cause, or its generality is identified | A design separating body size from shape, exit vector, construct and target context; four heterogeneous proxies do not provide it. |
| The numerical comparison is independently replicated | Original supporting outputs/inputs and a comparison accounting for both estimates and the sampling design; reported memo agreement is insufficient. |
| The field lacks a calibration relationship or the work is globally unique | Suitable source-level retrieval/screening evidence with explicit coverage limits; two asymmetric searches cannot establish an unrestricted absence. |
| TCIP selectivity is no easier than degrader selectivity | A valid model-specific derivation and comparable, sourced on/anti-target specifications. |

No row above authorizes new source acquisition, a denial bypass, wet-lab work, a sampler rerun, structural geometry remeasurement or a new NR4A analysis. Existing closed holds remain closed. If the owner declines the narrower audit framing, the efficient disposition is PARK rather than repeated attempts to preserve the current headline through additional caveats.

## What the retained records do support

The central ablation arithmetic matches the manuscript's rounded ratios. All 576 main cells are present with the stated draw count, and the four-body pooled rates, Wilson arithmetic and within/between descriptive comparisons reproduce. The named arms are populated and correctly excluded from the pooled four-body comparison. The selected census denominator/class summaries and the six listed below-12 degrader/glue pairs reproduce from its retained pair records. The 9MZA file record reports the displayed 6/7 points and four residues for the specified retained pairs. The source genuinely counts probes rather than distinct residues. These are positive findings from independent inspection, not acceptance of the author's 28 tests or settlement assertions.

The existing record can therefore support a modest, useful warning: a heuristically named contact filter materially changes one model's ranking, and translating that filter into a structural or biological requirement needs care about the actual predicate, measurement unit and selected denominator. It cannot support the frozen numerical headline as an established calibration of the actual sampler. That distinction is the reason for the recommended major revision.

## Original-source scope supplement

At closure, the 20-file retained local input set contains the exact main/SI, eight settlement dependencies, source helper code, both arm registries, the old E3 summary record, the selectivity-sizing argument and commissioning/guidance files. It does not contain an independently inspected original 9MZA mmCIF/RCSB citation response, primary publication text/abstract response, or original Europe PMC search/count response. The sizing memo records specific accession, citation and search claims; those claims were read as author narrative, not substituted for original source bytes.

A bounded request was sent to the coordinator for already-retained locators for those material sources; none was received before this report closed. No source acquisition was attempted. The source-read limitation therefore remains explicit. Absence from this collected review set is not a finding of global source absence or a claim that a named paper/structure does not exist. Existing originals supplied later could be considered during the focused repair verification; their later availability does not erase the predicate, proposal, selection or algebra findings established here.

## Reviewer computation record

`reviewer_calculations.py` was executed once with the bundled Python and exited 0. Retained outputs are `reviewer-calculations.json`, `reviewer-calculations-stdout.txt` and `reviewer-calculations-exit.txt`. The computation:

- checked the ten main/SI/material-input hashes against the settlement hash file;
- recomputed main cell inventory, per-rung pooled counts/rates and stored Wilson arithmetic;
- recomputed the three ablation ratios from retained counts and checked marginal nesting;
- inspected seed definitions and identified the limited BCL6/VHL stream collisions;
- compared the original cross-run rule with an explicitly illustrative two-estimate uncertainty calculation;
- reconstructed selected census class denominators from retained rows and compared candidate versus retained pair sets;
- preserved the complete retained 9MZA record in its diagnostic output;
- evaluated analytic examples for radial weighting, predicate nonidentity, additive-offset ratios, point/residue units and the scope of a binary-to-ternary odds transfer.

These are new reviewer calculations and logic checks. They are not original execution logs, original structural measurements, new simulations, or replacement producer results. No altered scientific artifact was written back to the repository.

## Input integrity and read-scope record

The companion `REVIEWED-INPUT-MANIFEST.json` and `REVIEWED-INPUT-MANIFEST.md` identify exact retained bytes and read scope. `REVIEW-ARTIFACT-HASHES.txt` identifies the final report, manifests, collection script/log and calculation records. The collection log preserves original locators and Git-read exits. Full-file retention is distinguished from full-file reading, especially for large JSON files and producer modules.

This scientific review does not claim publication readiness, fulfilled journal requirements, full CI, independent reproduction of original geometry, or complete review of unavailable primary source material. Its disposition is based on the evidence and specific repair/reopening boundaries above.
