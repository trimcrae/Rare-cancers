from pathlib import Path
import sys
sys.stdout.reconfigure(encoding='utf-8')
p=Path(sys.argv[1]); a=int(sys.argv[2]) if len(sys.argv)>2 else 1; b=int(sys.argv[3]) if len(sys.argv)>3 else 10**9
for i,line in enumerate(p.read_text(encoding='utf-8').splitlines(),1):
    if a<=i<=b: print(f'{i:5d} {line}')
