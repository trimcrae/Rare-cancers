# P-ST: direct root disposition of residual R1–R8

Date: 2026-09-09 UTC (2026-09-08 local). **The eight finite scientific residuals are accepted as corrected in the narrowed archival comparison.** This closes that correction batch, not publication gates or the stronger claims that were withdrawn. No second focused review or new scientific calculation is needed for these corrections.

Root read the complete residual main and SI diffs, full R1–R8 response, residual limitations, sixteen-panel erratum, current-packet binding, identity record and check-run record. Root also read all eleven actual command/stdout/stderr/exit sets, the full mechanical intake and later addendum, and the full 968 current F03/review-locator binding. The original full scientific review, its adjudication and the one focused review were already read in full. This is finite comparison with their accepted requirements, not a fresh full-paper baseline.

## Exact current scope

The integrated main is research/manuscripts/surface-targets/emc-surface-target-landscape.md, 146,042 B, SHA256 371ec8d92c3238b09f2117e14613184c422db1f094e83f431bad07d46e93179e. The SI is emc-surface-target-landscape-si.md in the same directory, 56,124 B, SHA256 290212776b2f103d64a270f12936245be00bfc6c97f5678b492589bc3680ad16. Both were returned at f6107376cc41344f2296f2ada46c064d8251a3f8 and match their candidate copies exactly. Their old 99,615/41,853 B baseline pair and the later 132,856/54,084 B pre-residual pair remain distinct historical inputs.

The mechanical intake is 13,839 B, SHA256 727a73c03831ad436599b7491d2d464d60417c8c2e005204ee054f5b54456bf7. Its later additive record is 7,261 B, SHA256 fa6fac48d5d0b48acba4d835ef0f3321b255fefb9d83af5db43140aaccc22127. The six saved diffs reproduce their actual after texts. All 100 existing SI table lines are identical; among the main's existing table lines, two historical prose rows change and ten register/header lines are added. This is table-line evidence, not a claim that every numeric token in all prose is unchanged.

## Scientific disposition by residual

- R1: LRRC15's zero expressed fraction is a threshold reading, not a demonstrated stromal cause or calibrated detector floor. FAP's 0.16 expressed/0.56 detectable fractions and the unresolved bulk compartment for CD248/PDGFRB are correctly stated.
- R2: Negative or non-significant contrast results no longer remove route utility, establish equivalence or absolute receptor abundance, turn a median interval width into every gene's interval, prove biological CSPG4 flatness, or infer organ-wide PRAME absence from a pooled zero. The recorded CSPG4 estimate, interval and sensitivity analyses remain; no new protein or clinical conclusion is claimed.
- R3: Classic 18 and retained 47 overlap in 15 and are not nested. Missing retained output is distinguished from whether a gene was ever scanned. The empty intersection is scoped to classic antigens; DLL3 remains in the wider retained intersection. Significant decreases are correctly distinguished from missing evidence.
- R4: Retained final sequencing medians support retrieval and ratio/band arithmetic, not reconstruction of the unavailable two-stage per-library/per-peak reduction. Derived array recalculation is separate. The accession cache is upstream mapping provenance, not a runtime input of the named statistics step.
- R5: Prior-art frequency, novelty and absence language is bounded by the actual retrieval and this programme's chronology.
- R6: Sixteen scored panel contrasts, nine plus seven, is correct. Both GPL3290 unscored panels remain unscored and the existing panel values are unchanged. The original review and root's inherited seventeen-count error is acknowledged; it is not blamed on the later author.
- R7: The current integrated pair and GEO source are bound alongside the unchanged historical manifest. The local source links are not full-paper or probe-audit evidence. The later review-locator correction is accepted.
- R8: The already applied F03 annotation is accepted at its established scope: 669→671 JSON leaves, 244 non-string leaves including 236 numbers unchanged, two keys added and one contrast string changed, with the producer AST unchanged apart from the admitted literal. No producer was run for this correction.

## Provenance corrections and exact remaining housekeeping

The original mechanical report searched the P-ST subtree and stated that a separate later F03 verification receipt was unavailable in the 806 delta. Its dated addendum correctly locates the actual parent receipt outside that subtree: PARENT-SHARED-PATCHES-2026-09-08/checks/12-f03-reverify, with the literal command, nine PASS records, empty stderr and EXIT=0. That qualifies the earlier overbroad absence statement; the original report remains intact. Repeated deterministic stdout is not independent scientific validation.

The 968 packet binding, 6,592 B, SHA256 2ed6930c67e18c43bbc9053ac0142c6fc01ace22a6c4140fed6f899edb2c6bd1, corrects the false claim that the original review had never been transported. Both existing ZIP members match the 53,772 B original review, SHA256 6dd9fd532e853d3ac5b1d8605dad79d585bdd1356598cc407eef8415adc4cf1a. No reacquisition or review retry is warranted.

One documentation statement still exceeds the stated check: CURRENT-PACKET.md section 5 and its repeated RUN08 narrative say the six-gene Table S6 check would move if “any measured value” moved. Its six fixed expectations do not establish whole-payload invariance. Add a dated current-scope correction identifying it as a six-gene spot check and pointing to the already retained full JSON comparison for whole-payload invariance. This is parent-owned documentation housekeeping, explicitly admitted now; do not change historical execution output, checker code, measurements or the manuscript pair, and do not run another check to create this note.

Preserve all eleven residual attempts: seven exit 0 and four exit 1, including the 52-pass/2-fail old checker and the 49-pass/1-fail residual attempt followed by 50/0. RUN06 and RUN07/09 command shorthand is not literal replayable execution text; RUN10's former failing checker snapshot is not retained. The known string-check and Boolean-predicate limitations remain. The six-gene check, current hashes and 50/0 check result are not substitutes for scientific reading.

## Remaining holds and advancement

Validated normal-tissue windows, quantitative transfer, calibrated biological nulls, causal compartment assignments, absolute protein/surface abundance and clinical prioritisation remain unsupported. Reopening each requires the missing design or measurements already named in the original adjudication; existing unavailable sources are not reopened by this closure. The stronger paper remains parked while the narrowed archival comparison can advance to its actual remaining publication preparation requirements.

Existing repository/venue-length/citation/style/archive requirements and failed gates are not waived by this scientific disposition. Record the narrow batch as closed and continue distinct eligible work while those concrete publication tasks are handled; do not spend another baseline or focused review on unchanged evidence. Original campaign deadline remains 2026-09-09T02:37:19Z.
