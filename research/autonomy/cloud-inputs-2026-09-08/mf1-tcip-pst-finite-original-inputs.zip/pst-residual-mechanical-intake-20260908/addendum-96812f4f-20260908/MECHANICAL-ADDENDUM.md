# P-ST mechanical addendum — 2026-09-08

This adds the later 96812f4f binding and the 806 parent RUN12 receipt to the previously frozen intake. It does not overwrite that record. The original `INTAKE-REPORT.md` remains 13839 B, SHA-256 `727a73c03831ad436599b7491d2d464d60417c8c2e005204ee054f5b54456bf7`, verified unchanged. No scientific review, source acquisition, producer/checker/test execution, Git operation or shared-state change occurred.

## Exact binding change

Before: `C:/Users/mcrae/.codex/review-workspaces/opus-capacity-sprint-20260907/capacity-campaign-20260908/observations/806ab2ec/P-ST-correction/annotation-correction/APPLIED-2026-09-08/PACKET-IDENTITY-BINDING-2026-09-08.md` — 4647 B; SHA-256 `d084f541f3015d961c3264bc22c90cb2036d55524208a444d8b808f50bb9dead`.

After: `C:/Users/mcrae/.codex/review-workspaces/opus-capacity-sprint-20260907/capacity-campaign-20260908/observations/96812f4f/P-ST-correction/annotation-correction/APPLIED-2026-09-08/PACKET-IDENTITY-BINDING-2026-09-08.md` — **6592 B**; SHA-256 **`2ed6930c67e18c43bbc9053ac0142c6fc01ace22a6c4140fed6f899edb2c6bd1`**, matching the supplied identity.

Only the review-locator section changes: the 806 heading “One cited identity is NOT resolvable in this worktree” becomes “CURRENT, 2026-09-08 — the cited review IS retained, with two exact locators.” It adds the two ZIP/member identities below, quotes the superseded unavailable-artifact claim, and acknowledges that an absent working-tree path did not establish that the already-delivered capsules lacked the review. The annotation key is explicitly unchanged. The exact prefix and suffix outside this section are identical; current four-file identities, failure preservation and the claimed 9/9 verification paragraph therefore do not change. `806-to-968-binding.diff` retains the full single-hunk before/after difference (`@@ -43,19 +43,41 @@`).

## Existing local capsules and review bytes

Both archives were already present locally. Their full bytes were hashed; only the specified review members were decompressed for byte/hash comparison. No archive was extracted, no scientific text was reread, and no source was fetched.

1. `C:/Users/mcrae/.codex/review-workspaces/opus-capacity-sprint-20260907/capacity-campaign-20260908/pst-final-ultra-original-inputs.zip`
   - 76537 B; SHA-256 `6d3f3e6185069db20862873719e070824d5b0d9eb90592087a631749cc4af99c` — exact binding match.
   - Member: `FINAL-SCIENTIFIC-REVIEW-P-ST.md`.
   - Binding cites input commit `c84baa862fc55bbbd609f433aa06690210c13e9c` and repository path `research/autonomy/cloud-inputs-2026-09-08/pst-final-ultra-original-inputs.zip`.
2. `C:/Users/mcrae/.codex/review-workspaces/opus-capacity-sprint-20260907/capacity-campaign-20260908/pst-focused-residual-original-inputs.zip`
   - 361616 B; SHA-256 `8b99fef7298207b24c43ca48554e22df1464bfd9c7f8d06424e69393b7300174` — exact binding match.
   - Member: `pst-focused-verification-20260908/inputs/baseline/FINAL-SCIENTIFIC-REVIEW-P-ST.md`.
   - Binding cites input commit `92a3ba93c19ab8e4d4c54e87372b49d1f6c67469` and repository path `research/autonomy/cloud-inputs-2026-09-08/pst-focused-residual-original-inputs.zip`.

Both named members are **53772 B**, SHA-256 **`6dd9fd532e853d3ac5b1d8605dad79d585bdd1356598cc407eef8415adc4cf1a`**, byte-identical to each other. Each read passes its stored CRC (`b06e5b67`). This is member CRC validation, not a new all-member archive CRC sweep. Archive directory metadata lists 17 and 44 members respectively; the earlier author's full 44/44 extraction assertion was not repeated.

Both members also equal each of these already-retained local originals exactly:

- `C:/Users/mcrae/Documents/Codex/2026-09-07/emc-research-orchestrator/work/surface-final-review-20260908/FINAL-SCIENTIFIC-REVIEW-P-ST.md`
- `C:/Users/mcrae/Documents/Codex/2026-09-07/emc-research-orchestrator/work/pst-focused-verification-20260908/inputs/baseline/FINAL-SCIENTIFIC-REVIEW-P-ST.md`

The cited review is thus mechanically locatable in these existing local bytes. The input commit/path labels above are recorded in the later binding; no new Git object-store/pin verification was performed.

## Separate later parent execution receipt: RUN12

The exact receipt directory is:

`C:/Users/mcrae/.codex/review-workspaces/opus-capacity-sprint-20260907/capacity-campaign-20260908/observations/806ab2ec/PARENT-SHARED-PATCHES-2026-09-08/checks/12-f03-reverify/`

It is outside the P-ST subtree covered in the prior intake, but present in the 806 delta and its `SETTLED-DELTA-artifact-locators.json`. **This resolves the earlier absence statement:** a separate later receipt exists under the parent's shared-patch records. The prior report remains unchanged as its original scoped record; its broader wording about no triplet in the 806 delta is qualified by this located evidence.

Exact saved command (read, not executed):

```text
python3 research/autonomy/opus-capacity-campaign-20260908/paper-lane/P-ST-correction/annotation-correction/APPLIED-2026-09-08/verify_applied.py
```

| File in that exact directory | Bytes | SHA-256 |
|---|---:|---|
| command.txt | 144 | `8c58463d0fabe76833eff710d86fcba3351ec7b23aea31297eb811af0642af1e` |
| stdout.txt | 1244 | `3aeb09cef310056880e46e3ab0f5cd65b104cf9b1ac970fd9fa63223c0b1c9ff` |
| stderr.txt | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| exit_code.txt | 7 | `418a5c17f33c70e99b0cc0a07fce69191489cfedc94164bfa903785777c5bd4b` |

All four match the locator index. Original stderr is empty; original exit text is `EXIT=0` followed by a newline. Original stdout contains nine `PASS` records, V1–V9, and ends `failed=0`. It reports the before JSON/producer identities; 669 → 671 leaves; two added annotation keys, one changed contrast string and no removed keys; 244 non-string leaves and zero other moved/dropped leaves; preserved order and superseded string; one producer-literal hunk, 3 → 13 lines; and successful `ast.parse` with **NOT executed**. The complete original command/stdout/stderr/exit texts and identities are embedded in `addendum-evidence.json` and the independent `receipt12-independent.json`.

This is a distinct retained later run record. Its stdout hash equals the earlier accepted F03 successful stream, which is compatible with repeating the same deterministic checks; equal output bytes alone are not new independent scientific evidence. The original F03 RUN01 failure and historical manifest failures remain preserved. The accepted whole-JSON/AST result was not rederived in this follow-up.

## Frozen follow-up files

`addendum-evidence.json` gives full absolute read scopes/identities, exact local capsule/member comparison, old/new binding identities, prefix/suffix comparison, and full RUN12 receipt texts. `806-to-968-binding.diff` gives the exact text change. `receipt12-independent.json` is a byte-preserving copy of the independent four-file receipt intake; its original staging copy remains untouched. `DELIVERABLE-HASHES.json` and `SHA256SUMS.txt` identify this addendum separately; previous manifest files are not rewritten.

The follow-up establishes existing locator and execution provenance only. Root retains scientific and current-authority adjudication.
