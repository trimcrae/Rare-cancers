from pathlib import Path
import hashlib,json,zipfile,difflib,datetime

C=Path('C:/Users/mcrae/.codex/review-workspaces/opus-capacity-sprint-20260907/capacity-campaign-20260908')
W=Path('C:/Users/mcrae/Documents/Codex/2026-09-07/emc-research-orchestrator')
OUT=Path(__file__).resolve().parent
scope=[]
def identity(p,note):
 p=Path(p);b=p.read_bytes()
 r={'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'read_scope':note}
 scope.append(r);return b,r
rel=Path('P-ST-correction/annotation-correction/APPLIED-2026-09-08/PACKET-IDENTITY-BINDING-2026-09-08.md')
old,oi=identity(C/'observations/806ab2ec'/rel,'Full original binding text; comparison only')
new,ni=identity(C/'observations/96812f4f'/rel,'Full later binding text; compare against supplied size6592 and SHA2ed6930c67e18c43bbc9053ac0142c6fc01ace22a6c4140fed6f899edb2c6bd1')
diff=''.join(difflib.unified_diff(old.decode().splitlines(keepends=True),new.decode().splitlines(keepends=True),fromfile=str(C/'observations/806ab2ec'/rel),tofile=str(C/'observations/96812f4f'/rel)))
(OUT/'806-to-968-binding.diff').write_text(diff,encoding='utf-8')
oldsplit=old.decode().split('## ⚠ One cited identity is NOT resolvable in this worktree',1)
newsplit=new.decode().split('## ⭐ CURRENT, 2026-09-08 — the cited review IS retained, with two exact locators',1)
suffix='## The second failure is out of this correction\'s scope'
unchanged={'prefix_exact':oldsplit[0]==newsplit[0],'suffix_exact':oldsplit[1].split(suffix,1)[1]==newsplit[1].split(suffix,1)[1]}
capsules=[];member_payloads=[]
for name,member,expected_n,expected_hash in [('pst-final-ultra-original-inputs.zip','FINAL-SCIENTIFIC-REVIEW-P-ST.md',76537,'6d3f3e6185069db20862873719e070824d5b0d9eb90592087a631749cc4af99c'),('pst-focused-residual-original-inputs.zip','pst-focused-verification-20260908/inputs/baseline/FINAL-SCIENTIFIC-REVIEW-P-ST.md',361616,'8b99fef7298207b24c43ca48554e22df1464bfd9c7f8d06424e69393b7300174')]:
 p=C/name;b,r=identity(p,'ZIP bytes/hash and directory metadata only; only exact named review member decompressed/hash-compared, no scientific reading or extraction')
 with zipfile.ZipFile(p) as z:
  data=z.read(member);info=z.getinfo(member)
  capsules.append({'zip_identity':r,'zip_matches_binding':len(b)==expected_n and r['sha256']==expected_hash,'member':member,'member_bytes':len(data),'member_sha256':hashlib.sha256(data).hexdigest(),'stored_crc32':f'{info.CRC:08x}','member_read_crc_valid':True,'archive_member_count_metadata':len(z.infolist()),'scope_limit':'No other member decompressed or scientific content interpreted; full archive CRC sweep not performed.'})
  member_payloads.append(data)
retained=[]
for p in [W/'work/surface-final-review-20260908/FINAL-SCIENTIFIC-REVIEW-P-ST.md',W/'work/pst-focused-verification-20260908/inputs/baseline/FINAL-SCIENTIFIC-REVIEW-P-ST.md']:
 b,r=identity(p,'Previously retained review bytes/hash and equality only; review not reread or adjudicated')
 retained.append({'identity':r,'byte_equal_to_both_zip_members':b==member_payloads[0]==member_payloads[1]})
ib,ir=identity(C/'observations/806ab2ec/SETTLED-DELTA-artifact-locators.json','Index metadata only; exact parent12-f03-reverify entries and hashes')
index=json.loads(ib)
receipt=[]
for e in index['files']:
 if '/checks/12-f03-reverify/' in e['repo_path']:
  p=Path(e['local_path']);b,r=identity(p,'Full original parent RUN12 receipt read; no verifier executed')
  receipt.append({'identity':r,'expected_index':e,'matches_index':r['bytes']==e['bytes'] and r['sha256']==e['sha256'],'text':b.decode()})
old_report,old_report_id=identity(W/'work/pst-residual-mechanical-intake-20260908/INTAKE-REPORT.md','Hash only to confirm prior frozen intake remains unchanged')
a={'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Bounded additive local-byte/source-locator and original parent RUN12 provenance follow-up only. No science/source review, Git, fetch, producer, checker or test execution. Previous frozen report untouched.','old_binding':oi,'new_binding':ni,'new_binding_matches_supplied_identity':len(new)==6592 and ni['sha256']=='2ed6930c67e18c43bbc9053ac0142c6fc01ace22a6c4140fed6f899edb2c6bd1','binding_comparison':unchanged,'zip_members':capsules,'retained_review_copies':retained,'both_zip_members_byte_equal':member_payloads[0]==member_payloads[1],'parent_run12':receipt,'prior_report_preserved':old_report_id['sha256']=='727a73c03831ad436599b7491d2d464d60417c8c2e005204ee054f5b54456bf7','read_scope_and_identities':scope}
(OUT/'addendum-evidence.json').write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'binding_comparison':unchanged,'both_zip_members_byte_equal':a['both_zip_members_byte_equal'],'new_binding_matches':a['new_binding_matches_supplied_identity'],'prior_report_preserved':a['prior_report_preserved'],'receipt_files':len(receipt),'receipt_index_matches':all(r['matches_index'] for r in receipt),'run12':[{k:r[k] for k in ['identity','text']} for r in receipt]},ensure_ascii=False,indent=2))
