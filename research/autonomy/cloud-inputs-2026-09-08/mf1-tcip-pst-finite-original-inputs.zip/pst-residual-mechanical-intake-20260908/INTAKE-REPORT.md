# P-ST residual mechanical intake — frozen 2026-09-08

This records existing bytes, saved text changes, and original execution provenance for root's finite adjudication. It is not an independent scientific review, baseline, or acceptance verdict. No producer, test, checker, renderer, source query, network request, Git operation, or shared-state mutation was performed. The accepted F03 whole-JSON/AST comparison was reused, not repeated. Later cf8 locator corrections and other lanes are outside this freeze.

## Exact retained scope

`CAP` = `C:/Users/mcrae/.codex/review-workspaces/opus-capacity-sprint-20260907/capacity-campaign-20260908`.

`F` = `CAP/observations/f6107376`, pinned `f6107376cc41344f2296f2ada46c064d8251a3f8`.

`A` = `CAP/observations/806ab2ec`, pinned `806ab2ecd06ff4fdc5d77c3229782d0948126b9f`.

`W` = `C:/Users/mcrae/Documents/Codex/2026-09-07/emc-research-orchestrator`.

The intake reads the six named residual author records under `F/PST-residual/`, their six delivered diffs and corresponding before/current texts, current four-file bindings, two metadata indexes, the 806 additive binding, and explicitly reused baseline identities. `mechanical-evidence.json` records 37 exact file identities and each read scope; the independent receipt component records 47 identities, with overlapping records labelled. These are scoped inventories, not a claim to have reviewed all 548 f610 files.

All 13 applicable entrypoint size/SHA bindings and all 27 applicable pinned blob bindings in the selected scope agree. The two index files themselves have no self-entry; absent applicable entries are recorded as null, not as a pass. No applicable mismatch was found.

## Current pair and six exact saved diffs

| File / role | Before bytes and SHA-256 | Current bytes and SHA-256 |
|---|---|---|
| Main, pre-residual candidate | 132856; `ebce0a9db28d3c5a7187a10005fc73b5666232a20a1cd110fa74c59d58bee6e3` | 146042; `371ec8d92c3238b09f2117e14613184c422db1f094e83f431bad07d46e93179e` |
| SI, pre-residual candidate | 54084; `105fc8732dfdb367b6793932b663815f74ae76ea483c1c1daf5a40991794a368` | 56124; `290212776b2f103d64a270f12936245be00bfc6c97f5678b492589bc3680ad16` |
| Main, older canonical baseline | 99615; `8931895d65bf6cc7de0d83b8cbd6c644b3eb664de221b56861a2a0940584df6f` | Same current main |
| SI, older canonical baseline | 41853; `92a7c49fc406a391d519912108fe888dc499c635ec29d1c3f834445665cdafd1` | Same current SI |
| F01-F13-RESPONSE-MAP.md | 16250; `7951619753f7ea87096460fee2a4962eda46edab700c48ebacc66d49c668d4ff` | 18559; `21106f6a14c8e812881ca3931bcf38c0ee430ced125414e9e7209f52ff7eae1d` |
| CORRECTION-RECORD-P-ST.md | 10413; `4f462c3b7f4857cd80aeacd4d8a12de859a327bdf9a31d67b139a5e4b374c143` | 12631; `2f8b2cbd6a8a2617ce8dfe17f8dd76b2ea9a14a08fa9ace64ec9679d7e974d5c` |

Current main/SI exist both at `F/P-ST-correction/revised/emc-surface-target-landscape{,-si}.md` and `F/research/manuscripts/surface-targets/emc-surface-target-landscape{,-si}.md`. Each candidate is byte-identical to its canonical copy. All six before copies are under `F/PST-residual/BEFORE-2026-09-08/`, with `revised--` / `canonical--` prefixes for manuscripts.

All six delivered unified diffs reproduce their actual after text from their exact before text, including unchanged segments, with zero hunk/context/count mismatches. This was an in-memory comparison of existing text, not execution of the author's apply script or writing reconstructed manuscripts.

| Diff in `F/PST-residual/DIFFS/` | Hunks | Added / removed lines |
|---|---:|---:|
| residual--emc-surface-target-landscape.md.diff | 22 | 141 / 73 |
| residual--emc-surface-target-landscape-si.md.diff | 9 | 51 / 32 |
| integration-baseline-to-current--emc-surface-target-landscape.md.diff | 31 | 679 / 344 |
| integration-baseline-to-current--emc-surface-target-landscape-si.md.diff | 20 | 261 / 115 |
| residual--CORRECTION-RECORD-P-ST.md.diff | 1 | 33 / 0 |
| residual--F01-F13-RESPONSE-MAP.md.diff | 2 | 33 / 0 |

The larger integration diffs include earlier F01–F13 changes. They are not all new R1–R8 edits. The correction record is append-only; the response map inserts the dated 16-panel marker beside the historical 17 statement and appends its addendum. Exact hunk boundaries and changed lines are retained in `mechanical-evidence.json`.

## Mechanical change map for root

These are observed text changes, not findings about whether the resulting science is defensible.

- **R1:** Main Methods and FAP Results, plus SI L2, replace demonstrated floor/cause and the CD248/PDGFRB exemption with a threshold reading and unresolved compartment attribution. The text adds the already-reported FAP detectable fraction 0.56. No quantitative table row changes accompany it.
- **R2:** B7-H3/FAP route-level exclusions, absolute SSTR2 signal and decisive-measurement wording, CSPG4 flat/silent interpretation, median-half-width generalization, reference-matched sensitivity inference, and PRAME normal-organ absence language are narrowed. Existing CSPG4 estimates and sensitivity values remain present. The Appendix A2 collaboration row replaces “The decisive missing datum” with “The missing measurements”.
- **R3:** “Two nested sets” becomes overlapping classic 18 / retained 47 with 15 shared; the text names CSPG4, B4GALNT1 and SSTR2. CSPG4 headings and SI selected-output wording no longer assert execution history from a missing retained row. The empty intersection is scoped to the classic subset with DLL3 in the wider retained set. Missing evidence, non-significance and a significant negative contrast are separated.
- **R4:** Blanket offline reproduction and “sequencing reductions” claims become retrieval of final gene-level medians plus ratio/band arithmetic. Missing per-library values and per-peak arm medians are named. The accession cache changes from a statistics-generator dependency to upstream mapping provenance. This intake verifies these prose changes, not a new source/producer analysis.
- **R5:** Field-wide frequency, priority and prior-absence statements are localized to this programme and its bounded retrieval.
- **R6:** Live main/SI 17-panel prose becomes 16 scored contrasts, nine GPL6244 plus seven GPL3290. Historical 17 text remains visibly qualified in the dated registers/response marker. The original RUN02 output reports those stored flag counts; this intake did not recount the scientific JSON.
- **R7:** Canonical pair is replaced by the candidate pair and the exact current bindings are supplied additively; older baseline identities remain historical.
- **R8:** The prior shared F03 application is bound as applied rather than specified. This lane does not deliver another F03 producer change.

Existing Markdown table line content supports a narrower, directly observed numerical-invariance statement: all **100 SI table lines** are identical between the pre-residual candidate and current SI, including the Table S5 rows. The main has **119 → 129** table lines; only the Appendix A2 collaboration prose row and Appendix A7 F10 erratum row change, and ten Appendix A8 register/header lines are added. The other 117 existing main table lines are unchanged. This does not assert that every numeric token in all prose is unchanged: count corrections, repeated measurements and new register entries are explicit additions.

## Historical manifest, current sources, and reused F03 evidence

The reused `W/work/pst-focused-verification-20260908/inputs/correction/packet/PACKET-MANIFEST.json` has 25 entries, **8996 B**, SHA-256 `84ece446c48d9966417e2c4b9be5f743a0da5b92633ac27d4a1fd09f193ec8b4`. It names HEAD a6a21fc5 and the older 99615 / 41853 manuscript pair. Its historical prose also retains the sequencing-reduction promise, grouped-peak wording, helper-dependency label and specified-not-applied F03 status. These fields are not current declarations; `CURRENT-PACKET.md` and the additive binding qualify them rather than rewrite the evidence.

Four historical entries differ from the current retained files: the two manuscripts above and the two F03 files below. The RUN08 checker preserves precisely that four-entry failure.

| Current F03 file at `F/research/modalities/` | Bytes | SHA-256 |
|---|---:|---|
| gse28866-tumour-vs-normal.json | 28606 | `386a035175d94ef8eccd3719d74ef39cff5e93461ed2470983777333a1962cee` |
| gse28866_tumour_vs_normal.py | 31856 | `404fe28582d9891a498b5407dc980e5ce7a16ac94a11eee267f7f6b7d8d4b46a` |

The accepted prior comparison is reused from `W/work/f610-scoped-intake-20260908/INTAKE-REPORT.md` (11836 B; SHA `5aebc0d548e61ac1123d4ea3e8e8f847bdcef5634816540958fb331bbb7a1de6`) and `annotation-evidence.json` (16317 B; SHA `6eb69f28e36984a47a81bcb09d1f3600d977dbfdd8fb77db19e140e464169aab`). It established 669 → 671 JSON leaves, 244 non-string leaves including 236 numbers unchanged, two annotation keys added, one contrast string changed, and normalized producer AST identity for the literal-only change. That comparison was not rerun here. Current hashes agree with its accepted after identities.

Three exact retained source bytes were hash-reverified solely against the reused focused baseline manifest: statistics JSON 90201 B, SHA `3213777eefcea5c62f5cda457ca9e391dc63e7740ed58ec2aadf3cf120f12317`; omitted PNG 128250 B, SHA `130042b6afab8aea28874d37dd684cde96886ab25b488ab65b83dac391c439bd`; GEO summary 30740 B, SHA `1726d018625bd4d4afdadd9364a7447d650ae5c88e9a2c228fe4463845aaac0c`. All match. Exact reused paths are in the inventory. These sources are not newly transported in the f610 delta, and this proves retained-baseline identity, not a new inspection of the author's live checkout or the clinical sources.

## 806 additive binding and concrete provenance limits

The exact 806 addition is `A/P-ST-correction/annotation-correction/APPLIED-2026-09-08/PACKET-IDENTITY-BINDING-2026-09-08.md`, **4647 B**, SHA-256 `d084f541f3015d961c3264bc22c90cb2036d55524208a444d8b808f50bb9dead`. Its size, SHA and Git blob match the 806 locator index. This is the only P-ST entry in that 69-file delta. It binds the same four current hashes and explicitly preserves the failing historical manifest and original failed runs.

It also records that `FINAL-SCIENTIFIC-REVIEW-P-ST.md`, cited with SHA `6dd9fd532e853d3ac5b1d8605dad79d585bdd1356598cc407eef8415adc4cf1a`, was unresolved under that name in the author's checkout. This is the addendum's local provenance limitation, not a claim that the review does not exist elsewhere. No lookup or later cf8 correction was incorporated.

The addendum says `verify_applied.py` was rerun at this state, exit 0 with nine passes. **No new P-ST command/stdout/stderr/exit triplet accompanies that claim in the 806 delta.** The preserved f610 F03 records and accepted numeric/AST comparison remain available, but do not independently establish a distinct later execution. This does not undermine the measured current binding.

`CURRENT-PACKET.md` says the six-gene Table S6 check is “the binding that would move if any measured value had moved.” The actual retained check covers six fixed expectations; that sentence must not substitute for whole-payload invariance. The accepted full F03 comparison above is the whole-payload evidence reused here.

## Original run provenance

`receipts/RECEIPT-INTAKE.md` and `receipts/receipt-intake.json` preserve exact commands, streams, exits and hashes. All 44 expected receipt files exist for 11 attempts: seven exits 0 and four exits 1.

- RUN01: TypeError, empty stdout; RUN03: FileNotFoundError, empty stdout.
- RUN04: 38 edits, 25 main and 13 SI; RUN05: one further main edit. RUN06 prints matching candidate/canonical identities.
- RUN07 and RUN09 outer exits are 0; their six individual diff commands explicitly return 1 because differences exist.
- RUN08: **52 passed / 2 failed, exit 1**, F11 literal plus four-entry packet drift.
- RUN10: **49 passed / 1 failed, exit 1**, R6 occurrence expectation; RUN11: same 50 names, **50 passed / 0 failed, exit 0**. Both attempts remain intact.

Command-fidelity limitations: RUN01's command names a repo-relative script while the traceback names scratchpad; RUN06 abbreviates cp paths and ends in prose `sha256sum + cmp both pairs`; RUN07/RUN09 use `<f>` templates. These are not complete replayable command strings. RUN10's failing checker executable/hash is absent; the final checker and output establish the current expected constants, not an exact before/after executable diff. The old RUN08 checker is absent from this f610 delta, so its two predicates were read only from the explicitly reused baseline copy.

The final integrity checker is a narrow string/stored-field/hash checker. Its unparenthesized `A and B or C` R1 predicate can be satisfied by the single-line SI alternative alone; a pass is not proof of all intended main-text conditions. Table S5 equality uses extracted `splitlines()` strings. These are static limitations of the reported passes, not newly discovered manuscript or scientific failures. The scoped receipts do not prove the absence of unrecorded executions.

## Frozen artifacts

- `INTAKE-REPORT.md`: this compact handoff.
- `mechanical-evidence.json`: exact identities/read scopes, current/before bindings, all saved diff boundaries/changed lines, table-row deltas, historical fields, and scoped index comparisons.
- `inspect_retained.py`: the local deterministic hash/text comparison used for this intake; no original producer/checker is invoked.
- `receipts/RECEIPT-INTAKE.md`, `receipts/receipt-intake.json`, `receipts/SHA256SUMS.txt`: original-run receipt component.
- `DELIVERABLE-HASHES.json`, `SHA256SUMS.txt`: frozen output identities.

Root retains scientific adjudication and current-authority decisions. This intake supplies no publication, submission, baseline, CI or gate clearance.
