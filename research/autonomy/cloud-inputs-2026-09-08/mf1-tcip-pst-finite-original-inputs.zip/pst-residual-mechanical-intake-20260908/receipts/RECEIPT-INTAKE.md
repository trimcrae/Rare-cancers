# P-ST residual original-receipt intake

Source: `C:/Users/mcrae/.codex/review-workspaces/opus-capacity-sprint-20260907/capacity-campaign-20260908/observations/f6107376/PST-residual`. Read-only receipt and static-checker inspection; no original program executed.

**11 attempts; 7 exit 0; 4 exit 1. All 44 required command/stdout/stderr/exit files are present.** The ordered summary agrees with the original exit and printed check counts.

| Attempt | Exit | Original result |
|---|---:|---|
| RUN-01-panel-count-FAILED | 1 | TypeError: string indices must be integers; stdout empty. |
| RUN-02-panel-count | 0 | Stored panel flags: GPL6244 9 scored; GPL3290 7 scored, 2 unscored; total 16. |
| RUN-03-apply-FAILED | 1 | FileNotFoundError at incorrect research/autonomy/paper-lane path; stdout empty. |
| RUN-04-apply | 0 | 38 edit lines: 25 main, 13 SI. |
| RUN-05-apply-part2 | 0 | One additional main-text edit. |
| RUN-06-integrate | 0 | Candidate/canonical hashes and sizes printed as matching. |
| RUN-07-diffs | 0 | Four individual diff exits 1; outer receipt exit 0. |
| RUN-08-pst-checker | 1 | 52 PASS / 2 FAIL: F11-sequencing-not-per-sample and packet-manifest-reproduces. |
| RUN-09-diffs-records | 0 | Two individual diff exits 1; outer receipt exit 0. |
| RUN-10-residual-integrity | 1 | 49 PASS / 1 FAIL: R6-text-says-16, detail main=2 SI=2. |
| RUN-11-residual-integrity | 0 | 50 PASS / 0 FAIL; R6 detail main live=1, main including registers=3, SI=2. |

RUN08 retains both failures. Its packet failure names exactly four changed entries: the gse28866 Python and JSON files, plus the canonical main and SI. The tableS6 sequencing binding reports six genes matching. RUN10 and RUN11 contain the same 50 check names; R6 changes from FAIL to PASS. No earlier failure is overwritten by the later successful receipt.

The supplied reused baseline checker confirms F11 requires both its stored-field predicate and the exact main-text literal `group-level peak summaries and not per-sample values` (lines 113-116). Its packet check compares existence, size and SHA-256 (lines 226-232). This is reused baseline evidence, not a checker newly transported in f610.

The final residual checker states the corrected R6 expectations explicitly: one live-main occurrence of `16 scored panel contrasts`, three complete-main occurrences of `16 scored`, and two SI occurrences of `16 scored panel contrasts`. The original failing executable is not retained in RUN10, so its exact prior predicate is known only from the summary and failure output.

## Command fidelity and limits

- RUN01 and RUN02 command.txt name repo cwd plus python3 count_panels.py, but RUN01 traceback names a scratchpad script. Exact invoked absolute script path is not faithfully captured by these command records.
- RUN06 uses abbreviated cp source paths relative to stated repository cwd and the prose sha256sum + cmp both pairs; RUN07 and RUN09 contain <f> command templates. These are descriptive records, not complete replayable expanded command lines.
- RUN07/RUN09 outer exits are 0 while six individual diff exits are 1 as explicitly retained in stdout.
- No per-attempt executable source hash or source snapshot is retained in RUN10; the final checker and its comment document the current expected constants, but cannot establish a byte-exact change from the failing executable.
- Original RUN08 checker absent at f610/P-ST-correction/execution/check_pst_correction.py. Only the explicitly supplied reused baseline predicates were inspected.
- CHECK-RUN-RECORD claims no test skipped/deselected/loosened and no other producers/preflight run; scoped receipts verify listed attempts, not exhaustive unseen process history. The RUN10 expected-count correction is openly recorded.
- Final checker present/R1/threshold-not-floor uses A and B or C, so the single-line SI substring C alone can satisfy it without proving main-text A. This is a limitation of what a PASS establishes, not an observed manuscript defect.
- Table S5 equality compares extracted strings after splitlines, not byte-for-byte whole-table serialization or line endings. Ten table lines include whatever rows the helper collected, not ten distinct panels.
- The 50 integrity checks are narrow stored-field/string/hash checks. Their passes are not a scientific review.

## Read and hash scope

47 source-file identities are recorded in `receipt-intake.json`: ordered summary, complete final integrity checker, all 44 original receipt files, and one explicitly supplied reused baseline checker hashed in full but read only at the two predicate snippets. No manuscript/SI, numerical artifact, plot, source file, Integration3 content or unrelated metadata was read. Supplementary count scripts and WHY.txt were inventoried by filename only, not opened.

The exact original commands and all stream identities are in the JSON. Important original failure identities:

| Original stream | Bytes | SHA-256 |
|---|---:|---|
| RUN-01-panel-count-FAILED/stderr.txt | 290 | `1e1fb860fb212f1e1c3a0354b80aa5b1f997f64eb5310c0f157646ce478da2ec` |
| RUN-03-apply-FAILED/stderr.txt | 1060 | `9ed03b3def8ecf4c235e493b2a79f666e9ada56120a26fe3e4d1171f3b93cc35` |
| RUN-08-pst-checker/stdout.txt | 2440 | `ea4154c06c7cb217326b3e8a775ff0b42266d9c4367a8ee085ad595a3327856c` |
| RUN-10-residual-integrity/stdout.txt | 3669 | `bbf2a7eebe5bc703f14492af256998dd6a7cfe762e18407bd940f5a7505f29e5` |
| RUN-11-residual-integrity/stdout.txt | 3675 | `df6ad969c4fa33d886bd4369ee91fe6d2c5fb899d08922a818ec2c602c269692` |

Final checker: 11,342 B, SHA-256 `ee1711090907979561d86c3ea881681e36356e6a3098c67a9c12ca3283bda80e`.
Reused baseline checker: `C:/Users/mcrae/Documents/Codex/2026-09-07/emc-research-orchestrator/work/pst-focused-verification-20260908/inputs/correction/execution/check_pst_correction.py`, 13,262 B, SHA-256 `24d8f1b5323c44b2ecf1e80de34375da90d2d4efd89b1ff6174823565b768160`.
