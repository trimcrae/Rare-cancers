from pathlib import Path
import json, hashlib, re, collections

W = Path(__file__).resolve().parents[2]
O = Path('C:/Users/mcrae/.codex/review-workspaces/opus-capacity-sprint-20260907/capacity-campaign-20260908/observations')
F = O/'f6107376'
P = F/'PST-residual'
A = O/'806ab2ec'
OUT = Path(__file__).parent
SCOPE = {}

def read(p, scope):
    p = Path(p).resolve(); b = p.read_bytes()
    rec = SCOPE.setdefault(str(p), {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'read_scope':[]})
    if scope not in rec['read_scope']: rec['read_scope'].append(scope)
    return b
def txt(p,scope): return read(p,scope).decode('utf-8-sig')
def js(p,scope): return json.loads(txt(p,scope))

index = js(F/'DELIVERABLE-ENTRYPOINTS.json','Index metadata only; scoped PST entries')
pin = js(F/'pinned-output-inventory.json','Pinned local inventory metadata only; scoped local blob identities, no Git operation')
pinmap = {e['path']:e for e in pin['files']}
entrymap = {e['repo_path']:e for g in index['groups'].values() for e in g['entrypoints']}
later = js(A/'SETTLED-DELTA-artifact-locators.json','806 index metadata only; additive F03 binding and absence of a new P-ST run receipt in this delta')
for n in ['IDENTITIES.md','CURRENT-PACKET.md','SIXTEEN-PANEL-ERRATUM.md','CHECK-RUN-RECORD.txt','R1-R8-RESPONSE.md','RESIDUAL-LIMITATIONS.md']:
    read(P/n,'Author original record, full text read; claims not treated as an independent verdict')
add = A/'P-ST-correction/annotation-correction/APPLIED-2026-09-08/PACKET-IDENTITY-BINDING-2026-09-08.md'
read(add,'Full dated additive binding read; no later cf8 material read')
for n in ['INTAKE-REPORT.md','annotation-evidence.json']:
    read(W/'work/f610-scoped-intake-20260908'/n,'REUSED accepted F03 numeric/AST comparison evidence; comparison not repeated')

name='emc-surface-target-landscape'
bindings=[]
pairdefs=[]
for suffix in ['.md','-si.md']:
    n=name+suffix
    before=P/'BEFORE-2026-09-08'/('revised--'+n)
    canonical_before=P/'BEFORE-2026-09-08'/('canonical--'+n)
    candidate=F/'P-ST-correction/revised'/n
    canonical=F/'research/manuscripts/surface-targets'/n
    for f in [before,canonical_before,candidate,canonical]: read(f,'Exact byte/hash identity and mechanical saved-diff/table-line comparison; no scientific assessment')
    bindings.append({'name':n,'candidate':str(candidate),'canonical':str(canonical),'byte_identical':candidate.read_bytes()==canonical.read_bytes(),'before_candidate':SCOPE[str(before.resolve())],'before_canonical':SCOPE[str(canonical_before.resolve())],'current':SCOPE[str(canonical.resolve())]})
    pairdefs += [(P/'DIFFS'/('residual--'+n+'.diff'),before,candidate),(P/'DIFFS'/('integration-baseline-to-current--'+n+'.diff'),canonical_before,canonical)]
for n in ['CORRECTION-RECORD-P-ST.md','F01-F13-RESPONSE-MAP.md']:
    pairdefs.append((P/'DIFFS'/('residual--'+n+'.diff'),P/'BEFORE-2026-09-08'/n,F/'P-ST-correction'/n))

def diff_identity(diff,before,after):
    lines=txt(diff,'Saved unified diff read mechanically in full; narrative residual hunks read for exact change map').splitlines(keepends=True)
    old=txt(before,'Saved before text for exact diff boundary and table-line comparison').splitlines(keepends=True)
    new=txt(after,'Actual delivered after text for exact diff boundary and table-line comparison').splitlines(keepends=True)
    result=[]; pos=0; i=2; hunks=[]; problems=[]; adds=removes=0
    while i<len(lines):
        m=re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',lines[i])
        if not m: problems.append({'line':i+1,'unexpected':lines[i]}); break
        os,oc,ns,nc=int(m[1]),int(m[2] or 1),int(m[3]),int(m[4] or 1)
        result.extend(old[pos:os-1]); pos=os-1; i+=1; actual_old=actual_new=0; changed=[]
        while i<len(lines) and not lines[i].startswith('@@ '):
            line=lines[i]; marker=line[:1]; content=line[1:]
            if marker in [' ','-']:
                if pos>=len(old) or old[pos]!=content: problems.append({'old_line':pos+1,'mismatch':line})
                pos+=1; actual_old+=1
            if marker in [' ','+']: result.append(content); actual_new+=1
            if marker=='+': adds+=1; changed.append({'side':'+','text':content.rstrip('\n')})
            if marker=='-': removes+=1; changed.append({'side':'-','text':content.rstrip('\n')})
            i+=1
        if (actual_old,actual_new)!=(oc,nc): problems.append({'count_header': [oc,nc],'actual':[actual_old,actual_new]})
        hunks.append({'old_start':os,'old_count':oc,'new_start':ns,'new_count':nc,'changed_lines':changed})
    result.extend(old[pos:])
    return {'diff_path':str(diff),'before_path':str(before),'after_path':str(after),'hunks':len(hunks),'added_lines':adds,'removed_lines':removes,'context_or_count_problems':problems,'all_hunks_and_untouched_segments_reproduce_actual_after':result==new,'boundaries':hunks}
diffs=[diff_identity(*d) for d in pairdefs]

tables=[]
for suffix in ['.md','-si.md']:
    n=name+suffix; before=P/'BEFORE-2026-09-08'/('revised--'+n); after=F/'P-ST-correction/revised'/n
    b=before.read_text(encoding='utf-8').splitlines(); a=after.read_text(encoding='utf-8').splitlines()
    # Exact Markdown row strings. This is text identity only, not a recalculation or interpretation.
    bc=collections.Counter(x for x in b if x.startswith('|')); ac=collections.Counter(x for x in a if x.startswith('|'))
    removed=list((bc-ac).elements()); added=list((ac-bc).elements())
    tables.append({'name':n,'before_table_line_count':sum(bc.values()),'after_table_line_count':sum(ac.values()),'removed_or_changed_before_rows':removed,'new_or_changed_after_rows':added})

histpath=W/'work/pst-focused-verification-20260908/inputs/correction/packet/PACKET-MANIFEST.json'
hist=js(histpath,'REUSED historical 25-entry manifest; metadata and before/current binding comparison only')
hist_fields={k:hist[k] for k in ['repository_commit_read','helper_dependency','can_be_recalculated_offline_from_these_files','cannot_be_reconstructed_from_anything_released_here','original_execution_artifacts_preserved_separately']}
four=[]
for e in hist['entries']:
    if e['path'] in ['research/modalities/gse28866-tumour-vs-normal.json','research/modalities/gse28866_tumour_vs_normal.py','research/manuscripts/surface-targets/'+name+'.md','research/manuscripts/surface-targets/'+name+'-si.md']:
        p=F/e['path']; read(p,'Current identity only versus reused historical manifest and accepted F03 evidence; no numeric or AST recomparison')
        now=SCOPE[str(p.resolve())]; four.append({'repo_path':e['path'],'historical':e,'current':now,'changed':e['sha256']!=now['sha256']})

focused=js(W/'work/pst-focused-verification-20260908/focused-reviewed-input-manifest.json','REUSED baseline manifest metadata solely to locate unchanged sources and before pair; no new review')
source_ids=[]
source_names={'emc-tissue-read-statistics.json','geo_esummary_emc.txt','emc-surface-prioritization.png'}
for e in focused['baseline_inputs_available_for_reuse']+focused['new_inputs']:
    p=Path(e.get('reused_exact_path',str(W/'work/pst-focused-verification-20260908'/e['retained_path'])))
    if p.name in source_names:
        read(p,'REUSED retained source bytes hash only; no numeric/source content read or reanalysis')
        now=SCOPE[str(p.resolve())]; source_ids.append({'retained':now,'prior_manifest_bytes':e['bytes'],'prior_manifest_sha256':e['sha256'],'matches_prior_retained_binding':e['bytes']==now['bytes'] and e['sha256']==now['sha256'],'transported_at_f610':any(x.endswith('/'+p.name) for x in pinmap)})

identity_comparisons=[]
for pstr,rec in SCOPE.items():
    p=Path(pstr)
    if p.is_relative_to(F):
        rel=p.relative_to(F).as_posix(); rp=rel if rel.startswith('research/') else 'research/autonomy/opus-capacity-campaign-20260908/paper-lane/'+rel
        e=entrymap.get(rp); pv=pinmap.get(rp)
        identity_comparisons.append({'path':pstr,'repo_path':rp,'entrypoint_match':None if e is None else e['bytes']==rec['bytes'] and e['sha256']==rec['sha256'],'pinned_inventory_match':None if pv is None else pv['oid']==rec['git_blob'],'expected_entrypoint':e,'expected_pinned_inventory':pv})
    elif p==add:
        e=next(x for x in later['files'] if x['repo_path'].endswith('/'+add.name))
        identity_comparisons.append({'path':pstr,'entrypoint_match':e['bytes']==rec['bytes'] and e['sha256']==rec['sha256'],'pinned_inventory_match':e['git_blob']==rec['git_blob'],'expected_entrypoint':e})

summary={'scope':'Bounded mechanical local-byte intake only. No producer, test, checker, source acquisition, Git operation, source/scientific review, or shared state mutation. Historical F03 numeric/AST result reused without recomparison. cf8 and other lanes excluded.',
 'f610_pin':index['commit'],'806_pin':later['commit'],'bindings':bindings,'diff_results':diffs,'markdown_table_line_identity':tables,'historical_packet_entry_count':len(hist['entries']),'historical_packet_fields':hist_fields,'four_historical_to_current_changes':four,'reused_source_identity_only':source_ids,'scoped_index_matches':identity_comparisons,'806_pst_delta_entries':[e for e in later['files'] if '/P-ST-' in e['repo_path'] or '/PST-' in e['repo_path']],'read_scope_and_identities':list(SCOPE.values())}
(OUT/'mechanical-evidence.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'pair_binding_matches':[x['byte_identical'] for x in bindings],'diffs':[{'path':d['diff_path'],'hunks':d['hunks'],'added':d['added_lines'],'removed':d['removed_lines'],'matches':d['all_hunks_and_untouched_segments_reproduce_actual_after'],'problems':d['context_or_count_problems']} for d in diffs],'table_deltas':[{'name':t['name'],'before':t['before_table_line_count'],'after':t['after_table_line_count'],'removed':len(t['removed_or_changed_before_rows']),'added':len(t['new_or_changed_after_rows'])} for t in tables],'source_ids':source_ids,'identity_failures':[x for x in identity_comparisons if x['entrypoint_match'] is False or x['pinned_inventory_match'] is False],'806_pst_entries':len(summary['806_pst_delta_entries']),'read_file_count':len(SCOPE)},ensure_ascii=False,indent=2))
