from pathlib import Path
import json,sys
p=Path(__file__).resolve().parent/'inputs/frozen'/sys.argv[1]
d=json.loads(p.read_text(encoding='utf-8'))
for pointer in sys.argv[2:] or ['']:
    v=d
    for k in pointer.split('/'):
        if k: v=v[int(k)] if isinstance(v,list) else v[k]
    if '--keys' in sys.argv:
        pass
    print(json.dumps({'pointer':pointer,'value':v},ensure_ascii=True,indent=2))
