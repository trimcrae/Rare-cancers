from pathlib import Path
import hashlib
import json

root = Path(__file__).resolve().parent
base = Path('C:/Users/mcrae/.codex/review-workspaces/opus-capacity-sprint-20260907/capacity-campaign-20260908/observations/9716bf3d/PST-source-locators')
expected = {
    'PST-SOURCE-LOCATORS.md': (3444, '4d7bbf2c563c6f39d37c2d4a2433387dc49e37b5f5a8518c292e82ae5a49e512'),
    'geo_esummary_emc.txt': (30740, '1726d018625bd4d4afdadd9364a7447d650ae5c88e9a2c228fe4463845aaac0c'),
}
for name, (size, digest) in expected.items():
    source = base / name
    data = source.read_bytes()
    actual = hashlib.sha256(data).hexdigest()
    assert len(data) == size and actual == digest, name
    target = root / 'inputs/local/source-locators' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    item = {'source': source.as_posix(), 'bytes': len(data), 'sha256': actual,
            'retained_path': target.relative_to(root).as_posix(), 'exit_code': 0}
    with (root / 'collection-log.jsonl').open('a', encoding='utf-8') as out:
        out.write(json.dumps(item, ensure_ascii=True) + '\n')
    print(json.dumps(item, ensure_ascii=True))
