"""Mechanical excerpts of the late-delivered retained source; no retrieval or analysis."""
from pathlib import Path
import json
root = Path(__file__).resolve().parent
text = (root / 'inputs/local/source-locators/geo_esummary_emc.txt').read_text(encoding='utf-8')
obj = json.loads(text[text.index('{'):])['result']
out = {'source_line': 6, 'GSE24369': obj['200024369']}
for uid in ('200028866', '200004303'):
    item = obj[uid]
    out[item['accession']] = {key: val for key, val in item.items() if key != 'samples'}
out['GSE28866_normal_sample_titles'] = [s for s in obj['200028866']['samples'] if '_normal_' in s['title']]
out['GSE28866_duplicate_library_titles'] = [s for s in obj['200028866']['samples'] if '_rep' in s['title']]
formatted = json.dumps(out, ensure_ascii=True, indent=2) + '\n'
(root / 'retained-esummary-excerpts.json').write_text(formatted, encoding='utf-8')
print(formatted, end='')
