"""Inventory already-retained review bytes; not a scientific producer or test suite."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parent
PIN = "9f571e8170fb81dbe4d78515981ccb57c7a78b3e"
SCOPES = {
    "research/manuscripts/surface-targets/emc-surface-target-landscape.md": "Full scientific read, lines 1-1152, including historical appendices; material passages revisited with exact line numbers.",
    "research/manuscripts/surface-targets/emc-surface-target-landscape-si.md": "Full scientific read, lines 1-573, including all tables and notes.",
    "research/modalities/emc-tissue-read-statistics.json": "Primary summary rows parsed for all genes, BH decisions, confidence-interval widths, state counts and sensitivity summary logic; relevant definitions, control/panel and named-gene records read. Not every serialized line read individually; original raw-data execution not reproduced.",
    "research/modalities/emc-surfaceome-scan.json": "Source/class/identity/validation definitions and selected named rows read; all retained actionable rows parsed for counts and intersection/coverage; complete original scanned universe is not present.",
    "research/modalities/emc-surface-normal-window.json": "All classified rows parsed for labels, quantitative-field missingness and vital/immune hits; selected full antigen/control records read. This is the retained derived response, not an independent HPA API acquisition.",
    "research/modalities/surfaceome-instrument-limits.json": "Full scientific read, lines 1-263; limitations treated as claims to check against source logic, not independent validation.",
    "research/modalities/emc-expression-panels.json": "Selective scientific read of control expectations/results, read_8_SURFACE_ANTIGEN, named gene summaries, panel definitions/coverage and source/mapping metadata; no claim to read the entire 13 MB artifact line by line.",
    "research/modalities/aso-delivery-antigen.json": "Selected scientific sections: analysis scope and not-preregistered annotation, HPA missingness/inert override, stage-1 coverage, normal-prior comparisons, calibration/reference genes, selected antigen rows and limitations. Historical uncorrected statistical narratives were not accepted as current results.",
    "research/modalities/gse28866-tumour-vs-normal.json": "Source/header/library labels, group definitions, calibration/reference records and per-gene aggregate values/ratios read or parsed; no original peak-table payload retained in this file.",
    "research/literature/remaining-reference-metadata-2026-08-09.json": "Full metadata read. Bibliographic metadata verification only; not full-text verification of every scientific claim.",
    "research/literature/submission-reference-metadata-2026-08-09.json": "Selective metadata read, including PMID 15920699, 26310886, 36563884, 26961907, 28341109 and 34413129. Not a complete read of every external article.",
    "research/literature/emc-prior-art-2026-08-09.json": "Full scientific-method and result read; underlying entire literature corpus not re-screened.",
    ".claude/skills/paper-hardening/SKILL.md": "Frozen guidance retained for provenance; compared with the live guidance used for this bounded review. Not a scientific source or an acceptance test.",
    ".claude/skills/repo-gates/SKILL.md": "Guidance read; general gates not executed as commissioning prerequisites.",
    "research/autonomy/OPERATING_PROTOCOL.md": "Selected endpoint and scientific-boundary guidance, especially lines 44-73; not represented as a full protocol audit.",
    "research/modalities/emc_tissue_read_statistics.py": "Full scientific logic read, lines 1-439, including t/CI, BH, state, panel, sensitivity and resolution definitions. Not imported or executed.",
    "research/modalities/emc_expression_panels.py": "Selected material definitions and source/mapping/normalization/panel branches: lines 30-170, 1392-1523, 1642-1668, 1908-2023, 2347-2365, plus relevant function/call-site searches. Not a full 193 KB code audit; not imported or executed.",
    "research/modalities/emc_surfaceome_scan.py": "Scientific scan, class, source, ranking, BH, seed, validation, identity and result-emission branches read, especially lines 50-430. Plot-only remainder not fully read; not executed.",
    "research/modalities/emc_surface_normal_window.py": "Full scientific code read, lines 1-285, with emphasis on query fields and classification branches; not executed.",
    "research/modalities/emc_surface_figure.py": "Full code read, lines 1-157; plotted gene list, mutable input locator, axes and labels checked against actual PNG; not executed.",
    "research/modalities/gse28866_tumour_vs_normal.py": "Selected material parsing, library grouping and aggregation branches, especially lines 182-247, 269-337, 468-492 and function-index searches; not executed.",
    "research/modalities/emc-expression-panels-inputs.json": "All 42 GSE24369 and 16 GSE4303 retained sample annotations read; relevant probe IDs, mapping diagnostics and reduced input structure inspected. Raw biology arrays not reanalysed or claimed as fully line-read.",
    "research/modalities/accession-symbol-cache.json": "Retained exact cache and inspected structure/keys for mapping provenance. Not an independent verification of every accession-to-symbol mapping.",
    "research/literature/emc-prior-art-fulltext-screen-2026-08-10.json": "Full result and search-scope read, lines 1-133; original full-text corpus not re-screened.",
    "research/modalities/emc_prior_art_fulltext_screen.py": "Full code read, lines 1-138, including nested surface-term/antigen-near-EMC screening condition; not executed.",
    "research/modalities/emc-surface-prioritization.png": "Actual original PNG visually inspected at full 1610 x 896 pixels; dimensions also checked from PNG header. No regeneration.",
    "research/modalities/emc-surfaceome-scan.png": "Actual original legacy PNG visually inspected at full 1040 x 1040 pixels; distinguished from outgoing Figure 1. No regeneration.",
    "research/modalities/geo-gse28866-brunner-series.json": "Retained primary GEO series_record read in full, with cohort/sample metadata and material publication identifiers inspected; overall_design at line 5445 verified square-root compression and technical duplicates. Broad associated-publication query material not fully read.",
    "research/modalities/emc_atr_vulnerability.py": "Material mapping/sample-grouping branches read, lines 1446-1638; first-accession/first-resolved-gene choices inspected. Remainder not fully audited; not executed.",
    "research/modalities/emc-atr-vulnerability.json": "Selective identity-source read: part_a_hemcss_identity, retained Cellosaurus caution, fusion calls and NR4A3 expression. Large ancillary literature/search sections not fully read.",
}
LOCAL_SCOPES = {
    "inputs/local/FREEZE-P-ST.md": "Full handoff read; scientific claims treated as preparation assertions rather than final acceptance. All 13 listed main/SI/dependency byte/hash identities checked.",
    "inputs/local/preparation/check_bindings.py": "Integrity-only retained handoff dependency. Not run, not accepted as scientific validation, and not represented as a full independent code review.",
    "inputs/local/guidance/paper-hardening-SKILL.md": "Live guidance fully read for applicable review workflow; standing authorized scope took precedence over generic prepasses. No full gate campaign run.",
    "inputs/local/guidance/repo-gates-SKILL.md": "Live guidance fully read; exact bytes also match the frozen copy. No general repository gates run.",
    "inputs/local/source-locators/PST-SOURCE-LOCATORS.md": "Full read of late-delivered source-locator memo. Its scoped original-source search result is a provenance statement; its description of esummary sample coverage was independently corrected from actual bytes.",
    "inputs/local/source-locators/geo_esummary_emc.txt": "Late-delivered original retained GEO esummary bytes. Material JSON at line 6 read through mechanical extraction: full GSE24369 entry including all 42 sample titles; GSE28866 and GSE4303 series metadata/publication identifiers; GSE28866 adult/fetal normal and technical-replicate sample titles. Other series/sample entries not fully read. Does not contain a full probe or sample-processing supplement.",
}

records = []
for line in (ROOT / "collection-log.jsonl").read_text(encoding="utf-8").splitlines():
    item = json.loads(line)
    retained = Path(item["retained_path"])
    data = (ROOT / retained).read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    if digest != item["sha256"] or len(data) != item["bytes"]:
        raise RuntimeError("Retained bytes no longer match collection: " + str(retained))
    rel = retained.as_posix()
    item["retained_path"] = rel
    key = item.get("repo_path")
    item["read_scope"] = SCOPES[key] if key else LOCAL_SCOPES[rel]
    item["bytes_reverified_at_manifest"] = True
    if rel == "inputs/local/source-locators/geo_esummary_emc.txt":
        blob = hashlib.sha1(b"blob " + str(len(data)).encode("ascii") + b"\0" + data).hexdigest()
        assert blob == "64621bda29a49a155b08d00c5e407a59a53c9481"
        item["original_git_blob_verified_from_bytes"] = blob
        item["original_repository_path"] = "literature/ct-reverify-c3b-2026-08-07/geo_esummary_emc.txt"
        item["original_pin_scope"] = "Exact blob ID independently matched; owner reported an earlier 216bd1b5... retained commit. Not represented as part of the frozen candidate commit."
    records.append(item)

review_artifacts = []
names = [
    "FINAL-SCIENTIFIC-REVIEW-P-ST.md", "reviewer_calculations.py",
    "reviewer-calculations.json", "reviewer-calculations-stdout.txt",
    "reviewer-calculations-exit.txt", "collection-log.jsonl", "collect_inputs.py",
    "read_input.py", "inspect_json.py", "build_review_manifest.py", "collect_local_sources.py",
    "inspect_retained_esummary.py", "retained-esummary-excerpts.json",
]
for name in names:
    data = (ROOT / name).read_bytes()
    review_artifacts.append({"path": name, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
                             "provenance": "New reviewer record; not an original author execution output."})

manifest = {
    "review": "P-ST single final scientific baseline review, 2026-09-08",
    "fixed_commit": PIN,
    "work_directory": ROOT.as_posix(),
    "input_count": len(records),
    "repository_input_count": sum("repo_path" in r for r in records),
    "local_input_count": sum("repo_path" not in r for r in records),
    "git_access_rule": "Every Git read used GIT_NO_LAZY_FETCH=1; no fetch or checkout.",
    "scientific_check_run": {"script": "reviewer_calculations.py", "runs": 1, "exit_code": 0,
                             "scope": "Deterministic summaries/logic over retained records; no new raw-biology estimation."},
    "inputs": records,
    "review_artifacts": review_artifacts,
    "manifest_note": "Manifest files are excluded from their own digest list to avoid circular hashes. All input hashes and listed review-artifact hashes were calculated from exact bytes.",
}
(ROOT / "reviewed-input-manifest.json").write_text(json.dumps(manifest, ensure_ascii=True, indent=2) + "\n", encoding="utf-8")

lines = ["# P-ST reviewed-input manifest", "", "Fixed commit: `" + PIN + "`.", "",
         f"{len(records)} exact inputs retained; {manifest['repository_input_count']} frozen Git inputs and {manifest['local_input_count']} local preparation/guidance inputs. Collection hashes reverified. Read extent is stated separately from possession of bytes.", ""]
for i, item in enumerate(records, 1):
    lines += [f"## {i}. {item.get('repo_path', item['retained_path'])}", "",
              "- Source: `" + item["source"] + "`",
              "- Retained: `" + item["retained_path"] + "`",
              f"- Bytes: {item['bytes']}",
              "- SHA256: `" + item["sha256"] + "`",
              "- Read scope: " + item["read_scope"], ""]
lines += ["## New reviewer artifacts", "", "These are separate from original scientific inputs. The deterministic calculation script ran once and exited 0. No producer or original execution was recreated.", "",
          "| Artifact | Bytes | SHA256 |", "|---|---:|---|"]
for item in review_artifacts:
    lines.append(f"| `{item['path']}` | {item['bytes']} | `{item['sha256']}` |")
lines += ["", manifest["manifest_note"], ""]
(ROOT / "reviewed-input-manifest.md").write_text("\n".join(lines), encoding="utf-8")
print(json.dumps({"inputs": len(records), "all_bytes_reverified": True, "scientific_calculation_exit": 0,
                  "report": review_artifacts[0]}, ensure_ascii=True))
