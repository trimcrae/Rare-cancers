"""New deterministic reviewer checks, not original executions or new biological analyses.

No producer is imported. Checks use retained summaries, source constants and sample metadata.
"""
from pathlib import Path
import ast, collections, hashlib, json, math, re, statistics, struct

ROOT=Path(__file__).resolve().parent
BASE=ROOT/'inputs/frozen'
def j(name): return json.loads((BASE/'research/modalities'/name).read_text(encoding='utf-8'))
def bh(rows):
    pairs=sorted(rows.items(),key=lambda kv:kv[1]); n=len(pairs); result={}; last=1.
    for i in range(n-1,-1,-1):
        name,p=pairs[i]; last=min(last,p*n/(i+1)); result[name]=last
    return result
def literal(name,variable):
    tree=ast.parse((BASE/'research/modalities'/name).read_text(encoding='utf-8'))
    for n in tree.body:
        if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==variable for t in n.targets):
            return ast.literal_eval(n.value)
    raise KeyError(variable)

out={'identity':'New independent deterministic reviewer calculations, 2026-09-08',
     'scope':'No raw biology statistics, producer, network, stochastic computation or figure generation.'}
handoff=(ROOT/'inputs/local/FREEZE-P-ST.md').read_text(encoding='utf-8')
checks=[]
for rel,size,digest in re.findall(r'\| `([^`]+)`(?:[^|]*)\| (\d+) \| `([0-9a-f]{64})`',handoff):
    p=ROOT/'inputs/local/preparation/check_bindings.py' if rel=='checks/check_bindings.py' else BASE/rel
    b=p.read_bytes(); checks.append({'path':rel,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),
                                   'matches':len(b)==int(size) and hashlib.sha256(b).hexdigest()==digest})
assert len(checks)==13 and all(x['matches'] for x in checks)
out['handoff_integrity']=checks
scan=j('emc-surfaceome-scan.json'); prior=j('emc-surface-normal-window.json'); stats=j('emc-tissue-read-statistics.json')
panels=j('emc-expression-panels.json'); inp=j('emc-expression-panels-inputs.json'); seq=j('gse28866-tumour-vs-normal.json')
act=scan['actionable_antigens']; sig={g for g,r in act.items() if r['selectivity_significant']}
classic=['CDH11','KIT','CD248','FGFR1','NCAM1','GPC2','PTK7','MCAM','EPHB4','CD276','FAP','LRRC15','ERBB2','ALCAM','EGFR','B4GALNT1','SSTR2','CSPG4']
states=stats['cross_platform_state_corrected']['by_gene']; unmeasured=sig-set(states)
both={g for g in sig if g in stats['primary']['GPL6244'] and g in stats['primary']['GPL3290']}
classified={g:r for g,r in prior['antigens'].items() if 'window' in r}
restricted={g for g,r in classified.items() if r['window']=='RESTRICTED'}
out['sets']={'retained_actionable_n':len(act),'seed_matches_actionable':set(literal('emc_surfaceome_scan.py','SEED_SURFACE'))==set(act),
 'selective_n':len(sig),'selective':sorted(sig),'classic_table_rows_n':len(classic),'classic_evaluated_n':len(set(classic)&set(act)),
 'classic_selective':sorted(sig&set(classic)),'not_on_tissue_board':sorted(unmeasured),'selective_with_both_primary_contrasts':sorted(both),
 'selective_one_primary_contrast':sorted((sig&set(states))-both),'selective_no_prior':sorted(sig-set(classified)),
 'stored_label_intersection':sorted(sig&restricted),'classic_stored_label_intersection':sorted(sig&restricted&set(classic)),
 'n_class_per_actionable':sorted({r['n_class'] for r in act.values()})}
assert len(act)==47 and len(sig)==18 and len(sig&set(classic))==9 and len(unmeasured)==5 and len(both)==10
out['prior_missingness']={'records':len(prior['antigens']),'classified':len(classified),
 'null_tissue_specific_nTPM':[g for g,r in classified.items() if r.get('rna_tissue_specific_nTPM') is None],
 'null_blood_specific_nTPM':[g for g,r in classified.items() if r.get('rna_blood_cell_specific_nTPM') is None],
 'vital_hits':{g:r['vital_tissue'] for g,r in classified.items() if r['vital_tissue']},
 'restricted_label_with_detected_in_many':[g for g in sorted(restricted) if classified[g]['rna_tissue_distribution']=='Detected in many'],
 'liability_records_all_blood':all(r['immune_or_circulating'] for r in classified.values() if r['window']=='VITAL_OR_IMMUNE_LIABILITY')}
assert len(out['prior_missingness']['null_tissue_specific_nTPM'])==45 and not out['prior_missingness']['vital_hits']
out['statistics_summary_checks']={}
for plat,rows in stats['primary'].items():
    q=bh({g:r['p'] for g,r in rows.items()})
    dif=max(abs(q[g]-r['q']) for g,r in rows.items())
    halves=sorted((r['ci_hi']-r['ci_lo'])/2 for r in rows.values())
    bad=[g for g,r in rows.items() if not r['significant'] and r['ci_lo']*r['ci_hi']>0]
    out['statistics_summary_checks'][plat]={'n':len(rows),'significant':sum(r['significant'] for r in rows.values()),
     'max_BH_difference_from_rounded_p':dif,'same_significant_flags_from_rounded_p':all((q[g]<.05)==r['significant'] for g,r in rows.items()),
     'unadjusted_CI_excludes_zero_despite_BH_nonsignificant':bad,'standard_median_halfwidth':statistics.median(halves),
     'stored_algorithm_upper_middle_halfwidth':halves[len(halves)//2], 'standard_median_fullwidth':2*statistics.median(halves)}
    assert dif<.00005 and all((q[g]<.05)==r['significant'] for g,r in rows.items())
out['state_counts']={s:len(gs) for s,gs in stats['cross_platform_state_corrected']['by_state'].items()}
assert sum(out['state_counts'].values())==100
out['sensitivity_summaries']={k:{kk:vv for kk,vv in stats[k].items() if kk!='rows'} for k in ['sensitivity_reference_matched_GPL3290_DFSP_only','sensitivity_GPL6244_with_solitary_fibrous_tumour']}
out['selected_original_rows']={p:{g:stats['primary'][p].get(g) for g in ['KIT','MCAM','CDH11','ALCAM','GPC1','BGN','CD44','VCAN','CSPG4','FGFR1','PTK7','PDGFRA','DLL3']} for p in stats['primary']}
group=seq['sources'][0]['grouping']; normals=group['normal_columns']
samples=seq['sources'][0]['columns']['sample_columns']
sar=[s.strip() for s in samples if any(s.startswith(p+'_STT') for p in ['DDLPS','ESS','EWS','GIST','LMS','MLPS','SS'])]
out['sequencing_metadata']={'normal_n':len(normals),'normal_age_counts':dict(collections.Counter('fetal' if '_Fetal_' in s else 'adult' if '_Adult_' in s else 'unknown' for s in normals)),
 'normal_tissue_counts':dict(collections.Counter(s.split('_normal_')[-1] for s in normals)),
 'sarcoma_libraries':len(sar),'sarcoma_unique_specimen_labels':len({re.sub('_rep[12]$','',s) for s in sar}),
 'technical_replicates':group['technical_replicate_columns'], 'EMC_specimens':group['emc_columns']}
assert len(normals)==27 and len(sar)==32
out['sequencing_ratios_from_retained_reductions']={g:{'normal':r['emc_median']/r['normal_median'] if r['normal_median'] else None,
 'sarcoma':r['emc_median']/r['sarcoma_median'] if r['sarcoma_median'] else None} for g,r in seq['per_gene']['values'].items()}
out['cspg4_vs_cd248_stored_scale']=seq['per_gene']['values']['CSPG4']['emc_median']/seq['per_gene']['values']['CD248']['emc_median']
out['gse24369_annotations']={'sample_counts':stats['cohorts']['GPL6244']['class_counts'],
 'myxofibrosarcoma_samples':[s for s in inp['targets']['GSE24369_series_matrix.txt.gz']['samples'] if 'myxofibrosarcoma' in s['annotation_verbatim'].lower()],
 'primary_samples':6+29,'remaining':42-(6+29)}
show=literal('emc_surface_figure.py','SHOW')
out['figure_current_mismatch']={'shown':show,'classic_table_rows_omitted':sorted(set(classic)-set(show)),
 'selective_shown_n':len(set(show)&sig),'classic_selective_n':len(set(classic)&sig)}
out['png_dimensions']={}
for name in ['emc-surface-prioritization.png','emc-surfaceome-scan.png']:
    b=(BASE/'research/modalities'/name).read_bytes(); out['png_dimensions'][name]=dict(zip(['width','height'],struct.unpack('>II',b[16:24])))

# A logical example about intersection decisions, not an FDR simulation or proof of failure in EMC.
pa={f'g{i}':1e-6 if i<50 else .02 if i<52 else .5 for i in range(100)}
pb={f'g{i}':1e-6 if i>=50 else .02 if i<2 else .5 for i in range(100)}
ra={g for g,q in bh(pa).items() if q<.05}; rb={g for g,q in bh(pb).items() if q<.05}
out['intersection_logic_example']={'scope':'Deterministic counterexample to an algebraic inheritance of realized FDP; not a stochastic FDR proof and not an EMC reanalysis.',
 'truth':'First 50 effects are real only in A, last 50 only in B; no effect is real in both.',
 'rejections_A':len(ra),'rejections_B':len(rb),'false_rejections_each':2,'realized_FDP_each':2/52,
 'intersection':sorted(ra&rb),'realized_FDP_intersection':1.}
assert len(ra)==52 and len(rb)==52 and len(ra&rb)==4
out['all_assertions_passed']=True
(ROOT/'reviewer-calculations.json').write_text(json.dumps(out,ensure_ascii=True,indent=2)+'\n',encoding='utf-8')
print(json.dumps(out,ensure_ascii=True,indent=2))
