"""Document local-byte bindings and extract existing records; no scientific calculations."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parent
intake = json.loads((ROOT / 'intake-manifest.json').read_text(encoding='utf-8'))
baseline = intake['baseline_inputs_available_for_reuse']
by_repo = {r.get('repo_path'): r for r in baseline if r.get('repo_path')}
packet = json.loads((ROOT / 'inputs/correction/packet/PACKET-MANIFEST.json').read_text(encoding='utf-8'))

def read_json(name):
    return json.loads(Path(by_repo['research/modalities/' + name]['reused_exact_path']).read_text(encoding='utf-8'))

stats = read_json('emc-tissue-read-statistics.json')
seq = read_json('gse28866-tumour-vs-normal.json')
bindings = []
for entry in packet['entries']:
    old = by_repo.get(entry['path'])
    bindings.append(dict(entry, focused_status=(
        'EXACT_BASELINE_COPY_REUSED' if old and old['bytes'] == entry['bytes'] and old['sha256'] == entry['sha256']
        else 'NOT_IN_BASELINE_INPUT_SET_NOT_RECOLLECTED'),
        baseline_path=old.get('reused_exact_path') if old else None))

evidence = {
    'scope': 'Verbatim extraction and file binding only. No producer, inferential/statistical recalculation, biological analysis, source query, rendering, or Git access.',
    'panel_records_verbatim': stats['panel_scores_with_p'],
    'sequencing_top_level_keys': list(seq),
    'sequencing_per_gene_keys': list(seq['per_gene']),
    'sequencing_example_records_verbatim': {g: seq['per_gene']['values'][g] for g in ['CSPG4', 'ALCAM', 'PRAME']},
    'packet_bindings_to_original_exact_review_copies': bindings,
    'source_count_correction': 'Reviewer reading of the existing rows: nine scored GPL6244 contrasts and seven scored GPL3290 contrasts, sixteen total. GPL3290 somatostatin_receptor_family and hla_presented_intracellular_antigens_NOT_surface explicitly have scored=false. The original reviewer F10 statement of seventeen is corrected; no test was newly calculated.',
    'shared_annotation_status_at_this_pin': 'SPECIFIED_NOT_APPLIED; no later applied candidate supplied or inspected',
}
(ROOT / 'verification-evidence.json').write_text(json.dumps(evidence, ensure_ascii=True, indent=2) + '\n', encoding='utf-8')

new_scopes = {
    'inputs/correction/revised/emc-surface-target-landscape.md': 'Current main scientific body lines 1-1085 and correction appendix 1168-1419 read, including all changed passages; unchanged reference block carried from the full baseline reading. Textual diff inspected for repair scope; this is focused F01-F13 verification, not a new baseline.',
    'inputs/correction/revised/emc-surface-target-landscape-si.md': 'Entire current SI, all 700 lines, read against accepted F01-F13 criteria.',
    'inputs/correction/CORRECTION-RECORD-P-ST.md': 'Entire record read, including original execution claims, shorthand commands, and specified-versus-applied scope.',
    'inputs/correction/F01-F13-RESPONSE-MAP.md': 'Entire response map read; author assertions adjudicated against actual text and retained evidence.',
    'inputs/correction/annotation-correction/ANNOTATION-CORRECTION-gse28866-aggregation-order.md': 'Entire proposed annotation plan read. No application or producer execution.',
    'inputs/correction/packet/PACKET-MANIFEST.json': 'Entire manifest read. Entries compared to exact baseline inputs without recollection. Three code-only provenance entries absent from baseline input set not newly collected.',
    'inputs/correction/execution/check_pst_correction.py': 'Entire 242-line checker read; not executed. Hard-coded values, exact phrase checks, and manifest existence/hash checks inspected for their actual scope.',
    'inputs/correction/execution/apply_pst_correction.py': 'Selected edit anchors, input/output and exact-match failure branches inspected; full patch corpus not claimed as separately read. Not executed.',
    'inputs/correction/execution/apply_pst_correction_part2.py': 'Selected A7/aggregation edits and read/write/exact-match branches inspected; not executed.',
    'inputs/coordination/ROOT-ADJUDICATION.md': 'Entire root adjudication read; governs accepted correction scope and Figure 1 omission.',
    'inputs/coordination/PST-MF1-artifact-locators.json': 'Parsed P-ST correction entries only for size/hash/blob binding; MF1 entries are outside this focused task.',
    'inputs/baseline/FINAL-SCIENTIFIC-REVIEW-P-ST.md': 'Entire completed baseline report read as accepted repair criteria; immutable. This focused report adds a transparent correction of its F10 panel count.',
    'inputs/baseline/reviewer-calculations.json': 'Carried existing calculation results for accepted findings; not rerun or replaced.',
}
for rec in intake['new_inputs']:
    p = ROOT / rec['retained_path']
    raw = p.read_bytes()
    assert len(raw) == rec['bytes'] and hashlib.sha256(raw).hexdigest() == rec['sha256']
    rec['focused_read_scope'] = new_scopes.get(rec['retained_path'], (
        'Original small stdout/stderr/exit/head file read completely; preserved unaltered, not reconstructed.'
        if '/execution/' in rec['retained_path'] else
        'Exact frozen/reference input retained and hash-verified; original baseline read scope applies, not a new full reading.'))

material_scopes = {
    'research/modalities/emc-tissue-read-statistics.json': 'Retained primary definitions and named estimates used through accepted baseline findings; panel_scores_with_p.rows read in full in this focused pass to bind revised panel statements. No recomputation.',
    'research/modalities/gse28866-tumour-vs-normal.json': 'Schema and named final per_gene.values records inspected to distinguish stored final medians from unavailable per-library and per-peak intermediate values. Existing group/sample/scale evidence carried from baseline; no aggregation rerun.',
    'research/modalities/emc_tissue_read_statistics.py': 'Actual imports, declared inputs, main input reads and panel-output branches selectively reread; not executed.',
    'research/modalities/gse28866_tumour_vs_normal.py': 'Original baseline material aggregation-order evidence reused for the specified annotation repair; no new execution or mutation.',
    'research/modalities/geo-gse28866-brunner-series.json': 'Original full series_record/overall_design evidence reused for compression and sample composition; no query.',
    'research/modalities/emc-surfaceome-scan.json': 'Exact retained class, FAP/LRRC15, actionable, and missing-result evidence reused from original baseline; no new rank tests.',
    'research/modalities/emc-surface-normal-window.json': 'Original baseline quantitative-null/branch/label evidence reused; no new classification or HPA request.',
}
for rec in baseline:
    raw = Path(rec['reused_exact_path']).read_bytes()
    assert len(raw) == rec['bytes'] and hashlib.sha256(raw).hexdigest() == rec['sha256']
    rec['original_baseline_read_scope'] = rec.pop('read_scope', '')
    rec['focused_read_scope'] = material_scopes.get(rec.get('repo_path'), 'Exact baseline copy hash-reverified and prior read scope carried as background evidence; not newly fully read in this focused pass.')
    if rec['retained_path'].endswith('geo_esummary_emc.txt'):
        rec['focused_read_scope'] = 'Previously inspected exact source entry and baseline extraction reused to verify the correction credits PMID links and sample titles rather than accepting the inaccurate series-only locator memo. No source reacquisition or expanded bibliographic claim.'

manifest = dict(intake, task='ONE focused post-repair verification of accepted P-ST F01-F13',
    generated_date='2026-09-08', new_scientific_calculations=False, git_access_in_this_focused_pass=False,
    scope_note='Thirty-six exact original inputs reused without recollection. Twenty-five newly retained local candidate/coordination/baseline files. Available-for-reuse and read scope are distinct; scopes below do not imply every original byte was newly read.',
    original_report_unchanged=True)
(ROOT / 'focused-reviewed-input-manifest.json').write_text(json.dumps(manifest, ensure_ascii=True, indent=2) + '\n', encoding='utf-8')
lines = ['# P-ST focused verification: reviewed-input manifest', '', 'Date: 2026-09-08. Exact candidate pin: `' + intake['candidate_commit'] + '`.', '',
    'No new scientific calculation or producer. This is local-byte verification and reuse of the original 36-input evidence set. The JSON manifest gives exact source locators, blob qualification, original read scope, and focused read scope. Three packet-only provenance scripts not in that original set were not recollected.', '',
    '| Retained/current input | Bytes | SHA256 | Focused read scope |', '|---|---:|---|---|']
for rec in intake['new_inputs']:
    lines.append('| ' + rec['retained_path'] + ' | ' + str(rec['bytes']) + ' | `' + rec['sha256'] + '` | ' + rec['focused_read_scope'].replace('|','/') + ' |')
lines += ['', '## Original exact input reuse', '', '| Original retained input | Bytes | SHA256 | Focused scope |', '|---|---:|---|---|']
for rec in baseline:
    lines.append('| ' + rec['retained_path'] + ' | ' + str(rec['bytes']) + ' | `' + rec['sha256'] + '` | ' + rec['focused_read_scope'].replace('|','/') + ' |')
(ROOT / 'focused-reviewed-input-manifest.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
print(json.dumps({'new_local_inputs':len(intake['new_inputs']), 'exact_baseline_copies_reused':len(baseline), 'packet_entries_matching_baseline_copies':sum(r['focused_status']=='EXACT_BASELINE_COPY_REUSED' for r in bindings), 'packet_entries_not_recollected':[r['path'] for r in bindings if r['focused_status']!='EXACT_BASELINE_COPY_REUSED'], 'new_science':False}, ensure_ascii=True))
