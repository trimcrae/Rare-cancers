# P-ST reviewed-input manifest

Fixed commit: `9f571e8170fb81dbe4d78515981ccb57c7a78b3e`.

36 exact inputs retained; 30 frozen Git inputs and 6 local preparation/guidance inputs. Collection hashes reverified. Read extent is stated separately from possession of bytes.

## 1. inputs/local/FREEZE-P-ST.md

- Source: `C:/Users/mcrae/.codex/review-workspaces/opus-capacity-sprint-20260907/capacity-campaign-20260908/observations/9f571e81/P-ST-surface-freeze/FREEZE-P-ST.md`
- Retained: `inputs/local/FREEZE-P-ST.md`
- Bytes: 15790
- SHA256: `58bc14abab5fceaa21398ec162cb9e29ae1ebb21b56126f74e5f3a45e8cf7cec`
- Read scope: Full handoff read; scientific claims treated as preparation assertions rather than final acceptance. All 13 listed main/SI/dependency byte/hash identities checked.

## 2. research/manuscripts/surface-targets/emc-surface-target-landscape.md

- Source: `git:9f571e8170fb81dbe4d78515981ccb57c7a78b3e:research/manuscripts/surface-targets/emc-surface-target-landscape.md`
- Retained: `inputs/frozen/research/manuscripts/surface-targets/emc-surface-target-landscape.md`
- Bytes: 99615
- SHA256: `8931895d65bf6cc7de0d83b8cbd6c644b3eb664de221b56861a2a0940584df6f`
- Read scope: Full scientific read, lines 1-1152, including historical appendices; material passages revisited with exact line numbers.

## 3. research/manuscripts/surface-targets/emc-surface-target-landscape-si.md

- Source: `git:9f571e8170fb81dbe4d78515981ccb57c7a78b3e:research/manuscripts/surface-targets/emc-surface-target-landscape-si.md`
- Retained: `inputs/frozen/research/manuscripts/surface-targets/emc-surface-target-landscape-si.md`
- Bytes: 41853
- SHA256: `92a7c49fc406a391d519912108fe888dc499c635ec29d1c3f834445665cdafd1`
- Read scope: Full scientific read, lines 1-573, including all tables and notes.

## 4. research/modalities/emc-tissue-read-statistics.json

- Source: `git:9f571e8170fb81dbe4d78515981ccb57c7a78b3e:research/modalities/emc-tissue-read-statistics.json`
- Retained: `inputs/frozen/research/modalities/emc-tissue-read-statistics.json`
- Bytes: 90201
- SHA256: `3213777eefcea5c62f5cda457ca9e391dc63e7740ed58ec2aadf3cf120f12317`
- Read scope: Primary summary rows parsed for all genes, BH decisions, confidence-interval widths, state counts and sensitivity summary logic; relevant definitions, control/panel and named-gene records read. Not every serialized line read individually; original raw-data execution not reproduced.

## 5. research/modalities/emc-surfaceome-scan.json

- Source: `git:9f571e8170fb81dbe4d78515981ccb57c7a78b3e:research/modalities/emc-surfaceome-scan.json`
- Retained: `inputs/frozen/research/modalities/emc-surfaceome-scan.json`
- Bytes: 46945
- SHA256: `3180c4ba550350967f157fd9a1f15d13bd84e233c7fa16b3d2266842d0cb63c0`
- Read scope: Source/class/identity/validation definitions and selected named rows read; all retained actionable rows parsed for counts and intersection/coverage; complete original scanned universe is not present.

## 6. research/modalities/emc-surface-normal-window.json

- Source: `git:9f571e8170fb81dbe4d78515981ccb57c7a78b3e:research/modalities/emc-surface-normal-window.json`
- Retained: `inputs/frozen/research/modalities/emc-surface-normal-window.json`
- Bytes: 34621
- SHA256: `0787c7f7279562dcd9eca96a0ae4578a27773477e21f2e8ae940200c25b09aab`
- Read scope: All classified rows parsed for labels, quantitative-field missingness and vital/immune hits; selected full antigen/control records read. This is the retained derived response, not an independent HPA API acquisition.

## 7. research/modalities/surfaceome-instrument-limits.json

- Source: `git:9f571e8170fb81dbe4d78515981ccb57c7a78b3e:research/modalities/surfaceome-instrument-limits.json`
- Retained: `inputs/frozen/research/modalities/surfaceome-instrument-limits.json`
- Bytes: 15501
- SHA256: `1db6d18d91f074efddf4d2f2ed6b7d8daecf5d44a9d70801b872296433142e94`
- Read scope: Full scientific read, lines 1-263; limitations treated as claims to check against source logic, not independent validation.

## 8. research/modalities/emc-expression-panels.json

- Source: `git:9f571e8170fb81dbe4d78515981ccb57c7a78b3e:research/modalities/emc-expression-panels.json`
- Retained: `inputs/frozen/research/modalities/emc-expression-panels.json`
- Bytes: 13253561
- SHA256: `123bd05a9f9f5d08a362df3bd51cdbb72c241b49712123aaf5c5ea914f336bd9`
- Read scope: Selective scientific read of control expectations/results, read_8_SURFACE_ANTIGEN, named gene summaries, panel definitions/coverage and source/mapping metadata; no claim to read the entire 13 MB artifact line by line.

## 9. research/modalities/aso-delivery-antigen.json

- Source: `git:9f571e8170fb81dbe4d78515981ccb57c7a78b3e:research/modalities/aso-delivery-antigen.json`
- Retained: `inputs/frozen/research/modalities/aso-delivery-antigen.json`
- Bytes: 53488
- SHA256: `eab3a6f5a7d7bcf6271bda3b3f0580b06e0d90bc553d5b75038af43eb4070287`
- Read scope: Selected scientific sections: analysis scope and not-preregistered annotation, HPA missingness/inert override, stage-1 coverage, normal-prior comparisons, calibration/reference genes, selected antigen rows and limitations. Historical uncorrected statistical narratives were not accepted as current results.

## 10. research/modalities/gse28866-tumour-vs-normal.json

- Source: `git:9f571e8170fb81dbe4d78515981ccb57c7a78b3e:research/modalities/gse28866-tumour-vs-normal.json`
- Retained: `inputs/frozen/research/modalities/gse28866-tumour-vs-normal.json`
- Bytes: 27256
- SHA256: `ac0a17bd81dd8bc2ecc3b5bb380de5ae00921ae2d32b5a9595bd1449720be407`
- Read scope: Source/header/library labels, group definitions, calibration/reference records and per-gene aggregate values/ratios read or parsed; no original peak-table payload retained in this file.

## 11. research/literature/remaining-reference-metadata-2026-08-09.json

- Source: `git:9f571e8170fb81dbe4d78515981ccb57c7a78b3e:research/literature/remaining-reference-metadata-2026-08-09.json`
- Retained: `inputs/frozen/research/literature/remaining-reference-metadata-2026-08-09.json`
- Bytes: 14227
- SHA256: `422d30a2ddc853fd55e5eb4bcb5c089194583f8484195a5afbedb969b7083e3f`
- Read scope: Full metadata read. Bibliographic metadata verification only; not full-text verification of every scientific claim.

## 12. research/literature/submission-reference-metadata-2026-08-09.json

- Source: `git:9f571e8170fb81dbe4d78515981ccb57c7a78b3e:research/literature/submission-reference-metadata-2026-08-09.json`
- Retained: `inputs/frozen/research/literature/submission-reference-metadata-2026-08-09.json`
- Bytes: 20018
- SHA256: `7e313379b8febd2de8b16af17153c0ba381cfbe5bb5169a876b819d0dace0c0e`
- Read scope: Selective metadata read, including PMID 15920699, 26310886, 36563884, 26961907, 28341109 and 34413129. Not a complete read of every external article.

## 13. research/literature/emc-prior-art-2026-08-09.json

- Source: `git:9f571e8170fb81dbe4d78515981ccb57c7a78b3e:research/literature/emc-prior-art-2026-08-09.json`
- Retained: `inputs/frozen/research/literature/emc-prior-art-2026-08-09.json`
- Bytes: 6597
- SHA256: `3c45960a14a99ce739b7643c2f73705e3d0b8900841af1a289f9e534379d4112`
- Read scope: Full scientific-method and result read; underlying entire literature corpus not re-screened.

## 14. .claude/skills/paper-hardening/SKILL.md

- Source: `git:9f571e8170fb81dbe4d78515981ccb57c7a78b3e:.claude/skills/paper-hardening/SKILL.md`
- Retained: `inputs/frozen/.claude/skills/paper-hardening/SKILL.md`
- Bytes: 1937
- SHA256: `497689024cf143920696031f265ddf69d58381ea2cce4a025871d85d38ede4ea`
- Read scope: Frozen guidance retained for provenance; compared with the live guidance used for this bounded review. Not a scientific source or an acceptance test.

## 15. .claude/skills/repo-gates/SKILL.md

- Source: `git:9f571e8170fb81dbe4d78515981ccb57c7a78b3e:.claude/skills/repo-gates/SKILL.md`
- Retained: `inputs/frozen/.claude/skills/repo-gates/SKILL.md`
- Bytes: 1794
- SHA256: `228e27b07811a027d60e548d88e41e992280d788c2478aa2c7fb467af8cbafa1`
- Read scope: Guidance read; general gates not executed as commissioning prerequisites.

## 16. research/autonomy/OPERATING_PROTOCOL.md

- Source: `git:9f571e8170fb81dbe4d78515981ccb57c7a78b3e:research/autonomy/OPERATING_PROTOCOL.md`
- Retained: `inputs/frozen/research/autonomy/OPERATING_PROTOCOL.md`
- Bytes: 10898
- SHA256: `5a0051a18b88b7e0056a98f783ac22fe42099090c17698595715cb021411a9af`
- Read scope: Selected endpoint and scientific-boundary guidance, especially lines 44-73; not represented as a full protocol audit.

## 17. research/modalities/emc_tissue_read_statistics.py

- Source: `git:9f571e8170fb81dbe4d78515981ccb57c7a78b3e:research/modalities/emc_tissue_read_statistics.py`
- Retained: `inputs/frozen/research/modalities/emc_tissue_read_statistics.py`
- Bytes: 21058
- SHA256: `063d581566a3bb8d1eac20bb41aa8d22a14ff33be34a264090ae56c72bceceab`
- Read scope: Full scientific logic read, lines 1-439, including t/CI, BH, state, panel, sensitivity and resolution definitions. Not imported or executed.

## 18. research/modalities/emc_expression_panels.py

- Source: `git:9f571e8170fb81dbe4d78515981ccb57c7a78b3e:research/modalities/emc_expression_panels.py`
- Retained: `inputs/frozen/research/modalities/emc_expression_panels.py`
- Bytes: 193150
- SHA256: `05c343aa29162ec618539ec81cc2d648db923f21618093d59ae4dbe0eeec9cc5`
- Read scope: Selected material definitions and source/mapping/normalization/panel branches: lines 30-170, 1392-1523, 1642-1668, 1908-2023, 2347-2365, plus relevant function/call-site searches. Not a full 193 KB code audit; not imported or executed.

## 19. research/modalities/emc_surfaceome_scan.py

- Source: `git:9f571e8170fb81dbe4d78515981ccb57c7a78b3e:research/modalities/emc_surfaceome_scan.py`
- Retained: `inputs/frozen/research/modalities/emc_surfaceome_scan.py`
- Bytes: 27617
- SHA256: `fcbcff1e990d21235d323c4e9affcb042032cbb38080ba23c8f3e7d3211e46bb`
- Read scope: Scientific scan, class, source, ranking, BH, seed, validation, identity and result-emission branches read, especially lines 50-430. Plot-only remainder not fully read; not executed.

## 20. research/modalities/emc_surface_normal_window.py

- Source: `git:9f571e8170fb81dbe4d78515981ccb57c7a78b3e:research/modalities/emc_surface_normal_window.py`
- Retained: `inputs/frozen/research/modalities/emc_surface_normal_window.py`
- Bytes: 16575
- SHA256: `b476d7ea3d0523272f3136dec81836f7e7bd4da165034b63a8659f9583c40f69`
- Read scope: Full scientific code read, lines 1-285, with emphasis on query fields and classification branches; not executed.

## 21. research/modalities/emc_surface_figure.py

- Source: `git:9f571e8170fb81dbe4d78515981ccb57c7a78b3e:research/modalities/emc_surface_figure.py`
- Retained: `inputs/frozen/research/modalities/emc_surface_figure.py`
- Bytes: 8307
- SHA256: `de6046741734cec06d60379a88436f337d04c9babb934e53eefe0be3dd45f508`
- Read scope: Full code read, lines 1-157; plotted gene list, mutable input locator, axes and labels checked against actual PNG; not executed.

## 22. research/modalities/gse28866_tumour_vs_normal.py

- Source: `git:9f571e8170fb81dbe4d78515981ccb57c7a78b3e:research/modalities/gse28866_tumour_vs_normal.py`
- Retained: `inputs/frozen/research/modalities/gse28866_tumour_vs_normal.py`
- Bytes: 30914
- SHA256: `6dcea81de63a4dd9ab66f39144b2ba531351efd9f1a8d51b233388456bfbdb78`
- Read scope: Selected material parsing, library grouping and aggregation branches, especially lines 182-247, 269-337, 468-492 and function-index searches; not executed.

## 23. research/modalities/emc-expression-panels-inputs.json

- Source: `git:9f571e8170fb81dbe4d78515981ccb57c7a78b3e:research/modalities/emc-expression-panels-inputs.json`
- Retained: `inputs/frozen/research/modalities/emc-expression-panels-inputs.json`
- Bytes: 7825041
- SHA256: `6a4f778a3102b970f629906cf33357e97729a9d62ce9add20df709738cf1f3a8`
- Read scope: All 42 GSE24369 and 16 GSE4303 retained sample annotations read; relevant probe IDs, mapping diagnostics and reduced input structure inspected. Raw biology arrays not reanalysed or claimed as fully line-read.

## 24. research/modalities/accession-symbol-cache.json

- Source: `git:9f571e8170fb81dbe4d78515981ccb57c7a78b3e:research/modalities/accession-symbol-cache.json`
- Retained: `inputs/frozen/research/modalities/accession-symbol-cache.json`
- Bytes: 2098842
- SHA256: `51c8eda21396fc1c78acae6f267438d2875c0492fe6d0343b27ab139391d6048`
- Read scope: Retained exact cache and inspected structure/keys for mapping provenance. Not an independent verification of every accession-to-symbol mapping.

## 25. research/literature/emc-prior-art-fulltext-screen-2026-08-10.json

- Source: `git:9f571e8170fb81dbe4d78515981ccb57c7a78b3e:research/literature/emc-prior-art-fulltext-screen-2026-08-10.json`
- Retained: `inputs/frozen/research/literature/emc-prior-art-fulltext-screen-2026-08-10.json`
- Bytes: 3827
- SHA256: `14303c873b8c12fb5dc9157477d867a719f5ad27e4df11d4e2029bf2a4874e5a`
- Read scope: Full result and search-scope read, lines 1-133; original full-text corpus not re-screened.

## 26. research/modalities/emc_prior_art_fulltext_screen.py

- Source: `git:9f571e8170fb81dbe4d78515981ccb57c7a78b3e:research/modalities/emc_prior_art_fulltext_screen.py`
- Retained: `inputs/frozen/research/modalities/emc_prior_art_fulltext_screen.py`
- Bytes: 6531
- SHA256: `acbc572e5b2c843097a01a88b153dddfd33cd5ef149d8e37071826e8afa40b3b`
- Read scope: Full code read, lines 1-138, including nested surface-term/antigen-near-EMC screening condition; not executed.

## 27. research/modalities/emc-surface-prioritization.png

- Source: `git:9f571e8170fb81dbe4d78515981ccb57c7a78b3e:research/modalities/emc-surface-prioritization.png`
- Retained: `inputs/frozen/research/modalities/emc-surface-prioritization.png`
- Bytes: 128250
- SHA256: `130042b6afab8aea28874d37dd684cde96886ab25b488ab65b83dac391c439bd`
- Read scope: Actual original PNG visually inspected at full 1610 x 896 pixels; dimensions also checked from PNG header. No regeneration.

## 28. research/modalities/emc-surfaceome-scan.png

- Source: `git:9f571e8170fb81dbe4d78515981ccb57c7a78b3e:research/modalities/emc-surfaceome-scan.png`
- Retained: `inputs/frozen/research/modalities/emc-surfaceome-scan.png`
- Bytes: 67932
- SHA256: `835b0c3a515c084d6c0f0cb39504e565cb0bd980d59f6de0d7adf052d9e71366`
- Read scope: Actual original legacy PNG visually inspected at full 1040 x 1040 pixels; distinguished from outgoing Figure 1. No regeneration.

## 29. research/modalities/geo-gse28866-brunner-series.json

- Source: `git:9f571e8170fb81dbe4d78515981ccb57c7a78b3e:research/modalities/geo-gse28866-brunner-series.json`
- Retained: `inputs/frozen/research/modalities/geo-gse28866-brunner-series.json`
- Bytes: 285899
- SHA256: `c9440ea5c9cdefeaa25e6df102ec1ca49d7ceda473f95178775208432cd2e958`
- Read scope: Retained primary GEO series_record read in full, with cohort/sample metadata and material publication identifiers inspected; overall_design at line 5445 verified square-root compression and technical duplicates. Broad associated-publication query material not fully read.

## 30. inputs/local/preparation/check_bindings.py

- Source: `C:/Users/mcrae/.codex/review-workspaces/opus-capacity-sprint-20260907/capacity-campaign-20260908/observations/9f571e81/P-ST-surface-freeze/checks/check_bindings.py`
- Retained: `inputs/local/preparation/check_bindings.py`
- Bytes: 15002
- SHA256: `8881fcb83fa8a75f6f82a19b997575e2d0591b86a031fda6a8c06b741f87ab65`
- Read scope: Integrity-only retained handoff dependency. Not run, not accepted as scientific validation, and not represented as a full independent code review.

## 31. research/modalities/emc_atr_vulnerability.py

- Source: `git:9f571e8170fb81dbe4d78515981ccb57c7a78b3e:research/modalities/emc_atr_vulnerability.py`
- Retained: `inputs/frozen/research/modalities/emc_atr_vulnerability.py`
- Bytes: 186461
- SHA256: `52c63c8e6e114c2b94e1f2e45c57fb07222fcf745c393662755e5fcf799d6514`
- Read scope: Material mapping/sample-grouping branches read, lines 1446-1638; first-accession/first-resolved-gene choices inspected. Remainder not fully audited; not executed.

## 32. research/modalities/emc-atr-vulnerability.json

- Source: `git:9f571e8170fb81dbe4d78515981ccb57c7a78b3e:research/modalities/emc-atr-vulnerability.json`
- Retained: `inputs/frozen/research/modalities/emc-atr-vulnerability.json`
- Bytes: 342797
- SHA256: `8e6b766f3a09abaf56be56aa599dfc343f27ba54741794637194c56b303649e4`
- Read scope: Selective identity-source read: part_a_hemcss_identity, retained Cellosaurus caution, fusion calls and NR4A3 expression. Large ancillary literature/search sections not fully read.

## 33. inputs/local/guidance/paper-hardening-SKILL.md

- Source: `C:/Projects/EMC-Research/.claude/skills/paper-hardening/SKILL.md`
- Retained: `inputs/local/guidance/paper-hardening-SKILL.md`
- Bytes: 2413
- SHA256: `bb113276cb446d46f1cdfaa6621ea800c213c0e1c8d59f03b45f5fe90610961a`
- Read scope: Live guidance fully read for applicable review workflow; standing authorized scope took precedence over generic prepasses. No full gate campaign run.

## 34. inputs/local/guidance/repo-gates-SKILL.md

- Source: `C:/Projects/EMC-Research/.claude/skills/repo-gates/SKILL.md`
- Retained: `inputs/local/guidance/repo-gates-SKILL.md`
- Bytes: 1794
- SHA256: `228e27b07811a027d60e548d88e41e992280d788c2478aa2c7fb467af8cbafa1`
- Read scope: Live guidance fully read; exact bytes also match the frozen copy. No general repository gates run.

## 35. inputs/local/source-locators/PST-SOURCE-LOCATORS.md

- Source: `C:/Users/mcrae/.codex/review-workspaces/opus-capacity-sprint-20260907/capacity-campaign-20260908/observations/9716bf3d/PST-source-locators/PST-SOURCE-LOCATORS.md`
- Retained: `inputs/local/source-locators/PST-SOURCE-LOCATORS.md`
- Bytes: 3444
- SHA256: `4d7bbf2c563c6f39d37c2d4a2433387dc49e37b5f5a8518c292e82ae5a49e512`
- Read scope: Full read of late-delivered source-locator memo. Its scoped original-source search result is a provenance statement; its description of esummary sample coverage was independently corrected from actual bytes.

## 36. inputs/local/source-locators/geo_esummary_emc.txt

- Source: `C:/Users/mcrae/.codex/review-workspaces/opus-capacity-sprint-20260907/capacity-campaign-20260908/observations/9716bf3d/PST-source-locators/geo_esummary_emc.txt`
- Retained: `inputs/local/source-locators/geo_esummary_emc.txt`
- Bytes: 30740
- SHA256: `1726d018625bd4d4afdadd9364a7447d650ae5c88e9a2c228fe4463845aaac0c`
- Read scope: Late-delivered original retained GEO esummary bytes. Material JSON at line 6 read through mechanical extraction: full GSE24369 entry including all 42 sample titles; GSE28866 and GSE4303 series metadata/publication identifiers; GSE28866 adult/fetal normal and technical-replicate sample titles. Other series/sample entries not fully read. Does not contain a full probe or sample-processing supplement.

## New reviewer artifacts

These are separate from original scientific inputs. The deterministic calculation script ran once and exited 0. No producer or original execution was recreated.

| Artifact | Bytes | SHA256 |
|---|---:|---|
| `FINAL-SCIENTIFIC-REVIEW-P-ST.md` | 53772 | `6dd9fd532e853d3ac5b1d8605dad79d585bdd1356598cc407eef8415adc4cf1a` |
| `reviewer_calculations.py` | 8611 | `883c777f688b787efaa53e6d99494608fa00b4ecb246c9f4fdcc8c0ff4a775bf` |
| `reviewer-calculations.json` | 21735 | `8379d10701fd5aa1e7701b3ed75f231d1a1a3f8ba55c5e4a0a5ec3d6f37acfbe` |
| `reviewer-calculations-stdout.txt` | 21735 | `8379d10701fd5aa1e7701b3ed75f231d1a1a3f8ba55c5e4a0a5ec3d6f37acfbe` |
| `reviewer-calculations-exit.txt` | 3 | `13bf7b3039c63bf5a50491fa3cfd8eb4e699d1ba1436315aef9cbe5711530354` |
| `collection-log.jsonl` | 13981 | `5ec54beff2e43d326aab8425c62bafa1af3b8d5bc2345f36baa83a3abee96a91` |
| `collect_inputs.py` | 1755 | `f158d27bf40fd9f4de529ab702ba4c1e377d89de8c3d0805b2befc009c897076` |
| `read_input.py` | 792 | `ce83f6e9548df879cd00a9d8d1bc43dded0f6aaa573eee20d5add15a44287790` |
| `inspect_json.py` | 405 | `f8a16765f61691ad062f7c0ec1c1744ae5f482fbb0d0fb5509499f6f3fefee61` |
| `build_review_manifest.py` | 12742 | `1895ea2b64a48b329a29d744a3a0fd19fa4b9887002bb1cf62a31a6eaaf9f02d` |
| `collect_local_sources.py` | 1163 | `02461dec9b0e263e336e5603b4a646e9ff818a0fe170e249f4f610b9de6e1536` |
| `inspect_retained_esummary.py` | 905 | `65e3e6f7363357b62e7c26602ef400ec058d353f8981d6cdd7b74565cecbe39b` |
| `retained-esummary-excerpts.json` | 14086 | `da7259e09b3f27fdd3a9b5f6de51acd01370f325f6ae3d072cd6e9dbc96998a6` |

Manifest files are excluded from their own digest list to avoid circular hashes. All input hashes and listed review-artifact hashes were calculated from exact bytes.
