"""Finalize hash records only; no manuscript editing or scientific execution."""
from pathlib import Path
import hashlib
import json

root = Path(__file__).resolve().parent
old = root.parent / 'surface-final-review-20260908/FINAL-SCIENTIFIC-REVIEW-P-ST.md'
assert len(old.read_bytes()) == 53772
assert hashlib.sha256(old.read_bytes()).hexdigest() == '6dd9fd532e853d3ac5b1d8605dad79d585bdd1356598cc407eef8415adc4cf1a'
main = (root / 'inputs/correction/revised/emc-surface-target-landscape.md').read_text(encoding='utf-8')
baseline = (root / 'inputs/correction/frozen/emc-surface-target-landscape.md').read_text(encoding='utf-8')
# Confirm that the reference section carried from the baseline really is unchanged.
def references(t):
    start = t.index('## References')
    stop = t.index('## Appendix A. Correction and supersession register', start)
    return t[start:stop]
assert references(main) == references(baseline)
names = ['FOCUSED-VERIFICATION-P-ST-F01-F13.md', 'focused-reviewed-input-manifest.json',
         'focused-reviewed-input-manifest.md', 'intake-manifest.json', 'verification-evidence.json',
         'collect_verification_inputs.py', 'retain_verification_scope.py', 'finalize_delivery.py',
         'reviewer-scope-stdout.txt', 'reviewer-scope-stderr.txt', 'reviewer-scope-exit.txt',
         'emc-surface-target-landscape.md.diff', 'emc-surface-target-landscape-si.md.diff']
records=[]
for name in names:
    b=(root/name).read_bytes()
    records.append({'path':name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
payload={'date':'2026-09-08','candidate_pin':'b57754a83524f95240995edf32621aca408e4587',
         'original_final_unchanged':True,'candidate_reference_section_unchanged_from_baseline':True,
         'scope':'One focused F01-F13 verification; no new baseline or science calculation', 'files':records}
(root/'DELIVERY-HASHES.json').write_text(json.dumps(payload,ensure_ascii=True,indent=2)+'\n',encoding='utf-8')
print(json.dumps(payload,ensure_ascii=True))
