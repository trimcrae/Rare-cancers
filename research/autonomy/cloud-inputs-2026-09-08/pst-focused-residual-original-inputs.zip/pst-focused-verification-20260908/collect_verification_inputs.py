"""Retain the delivered P-ST correction; reuse exact baseline evidence without new science."""
from pathlib import Path
import hashlib,json,difflib
ROOT=Path(__file__).resolve().parent
SRC=Path('C:/Users/mcrae/.codex/review-workspaces/opus-capacity-sprint-20260907/capacity-campaign-20260908/observations/b57754a8')
BASE=ROOT.parent/'surface-final-review-20260908'
PIN='b57754a83524f95240995edf32621aca408e4587'
def h(b):return hashlib.sha256(b).hexdigest()
records=[]
def local(p,rel,kind):
 b=p.read_bytes();q=ROOT/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
 r={'source':p.as_posix(),'retained_path':rel,'bytes':len(b),'sha256':h(b),'kind':kind};records.append(r);return r
idx=json.loads((SRC/'PST-MF1-artifact-locators.json').read_text())
for r in idx['files']:
 if '/P-ST-correction/' not in r['repo_path']:continue
 tail=r['repo_path'].split('/P-ST-correction/',1)[1]
 rec=local(SRC/'P-ST-correction'/tail,'inputs/correction/'+tail,'revised candidate or author correction record')
 assert rec['bytes']==r['bytes'] and rec['sha256']==r['sha256']
 b=(ROOT/rec['retained_path']).read_bytes()
 blob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
 assert blob==r['git_blob']
 rec.update(repo_path=r['repo_path'],git_blob=blob,source_commit=PIN,blob_verified_from_bytes=True)
local(SRC/'PST-MF1-artifact-locators.json','inputs/coordination/PST-MF1-artifact-locators.json','intake locator; P-ST entries inspected, MF1 outside scope')
local(ROOT.parent/'P-ST-final-review-root-adjudication-20260908.md','inputs/coordination/ROOT-ADJUDICATION.md','accepted finding/repair scope')
for name in ['FINAL-SCIENTIFIC-REVIEW-P-ST.md','reviewed-input-manifest.json','reviewed-input-manifest.md','reviewer-calculations.json']:
 local(BASE/name,'inputs/baseline/'+name,'prior completed review evidence; no recalculation')
baseline=json.loads((BASE/'reviewed-input-manifest.json').read_text())
reused=[]
for r in baseline['inputs']:
 p=BASE/r['retained_path'];b=p.read_bytes()
 assert len(b)==r['bytes'] and h(b)==r['sha256']
 reused.append(dict(r,reused_exact_path=p.as_posix(),reused_without_recollection=True))
(ROOT/'intake-manifest.json').write_text(json.dumps({'candidate_commit':PIN,'new_inputs':records,'baseline_inputs_available_for_reuse':reused},ensure_ascii=True,indent=2)+'\n',encoding='utf-8')
for name in ['emc-surface-target-landscape.md','emc-surface-target-landscape-si.md']:
 old=BASE/'inputs/frozen/research/manuscripts/surface-targets'/name
 new=ROOT/'inputs/correction/revised'/name
 d=''.join(difflib.unified_diff(old.read_text(encoding='utf-8').splitlines(True),new.read_text(encoding='utf-8').splitlines(True),fromfile='baseline/'+name,tofile='revised/'+name,n=4))
 (ROOT/(name+'.diff')).write_text(d,encoding='utf-8')
print(json.dumps({'new_files':len(records),'reused_baseline_inputs':len(reused),'candidate_bytes_verified':True,'no_git_network_or_science_execution':True},ensure_ascii=True))
