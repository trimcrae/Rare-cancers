# Exact retained inputs and honest read scope

Candidate pin: `c6d97dcc2043bd2a21c749339637286915a29a82`. Hashes below are of exact retained bytes. Full retention does not imply full reading.

## 1. emc-fusion-partner-stratification.md

- Source: `c6d97dcc2043bd2a21c749339637286915a29a82:research/manuscripts/fusion-partner/emc-fusion-partner-stratification.md`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\fp-focused-verification-20260908\pinned\research\manuscripts\fusion-partner\emc-fusion-partner-stratification.md`
- Bytes: 86639
- SHA256: `e1dc9e691cf30d2fcf0e2dfdfc575d073387da5590534dfc4962196a7e47c32e`
- Git blob SHA1 of exact bytes: `6b5d1e966dcab2e20e6f472eb6c4bb0d2bb6216c`
- Scope: Full text, lines 1-1048; all revised claims mapped to accepted F01-F12.

## 2. emc-fusion-partner-pooling.json

- Source: `c6d97dcc2043bd2a21c749339637286915a29a82:research/manuscripts/fusion-partner/emc-fusion-partner-pooling.json`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\fp-focused-verification-20260908\pinned\research\manuscripts\fusion-partner\emc-fusion-partner-pooling.json`
- Bytes: 107051
- SHA256: `f44c15048a6331c62d9d7e5ad96345721649789c13c0a15e60516b05755374c2`
- Git blob SHA1 of exact bytes: `200afc418d836fff812d5fc53932cf19e22a87b0`
- Scope: Full JSON, lines 1-1249; current citation/cohort/analysis/provenance and quarantine checked.

## 3. emc_fusion_partner_pooling.py

- Source: `c6d97dcc2043bd2a21c749339637286915a29a82:research/manuscripts/emc_fusion_partner_pooling.py`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\fp-focused-verification-20260908\pinned\research\manuscripts\emc_fusion_partner_pooling.py`
- Bytes: 145580
- SHA256: `a0cb9e1d3a9e2ea1d240a5f33b9cbe9ba657906dbb690434b337a418b7e80a37`
- Git blob SHA1 of exact bytes: `6e04e36dd4b33ebdfd433e9e345db49d7ae16442`
- Scope: Focused static reading: 1-85, 143-203, 1417-1845, 1990-2344; whole-file keyword/call searches and source-binding loci. COHORTS/CITATIONS checked via full generated JSON and relevant source definitions. No execution; no claim of a new full-code baseline.

## 4. emc-fusion-partner-correction-register.md

- Source: `c6d97dcc2043bd2a21c749339637286915a29a82:research/manuscripts/fusion-partner/emc-fusion-partner-correction-register.md`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\fp-focused-verification-20260908\pinned\research\manuscripts\fusion-partner\emc-fusion-partner-correction-register.md`
- Bytes: 85254
- SHA256: `8502120e650fb41952d344a7d180cc2a6a3a83f4380a534d2b5fc7808b87b497`
- Git blob SHA1 of exact bytes: `5cb569b9b75859408f26a9e9146643821cf91e8c`
- Scope: Preamble/current status; A43-A53 (103-113) and relevant adjacent dated A38/A41/A42/A39 history. Other historical rows retained, not comprehensively re-adjudicated.

## 5. 4a0aa24dfc-BLOCKERS-AND-HANDOFF.md

- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\c6d97dcc\FP-correction\BLOCKERS-AND-HANDOFF.md`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\fp-focused-verification-20260908\provenance-originals\4a0aa24dfc-BLOCKERS-AND-HANDOFF.md`
- Bytes: 6970
- SHA256: `59eb34fe1ca576d3277d1f3b94b21c0ebf39f0b7d51ca5d6ce70a7dc2a6be60e`
- Git blob SHA1 of exact bytes: `771560d93da443bfebd4d542246ca97450312aa0`
- Scope: Full returned handoff. Author claims independently distinguished from review acceptance.

## 6. 501a275996-DEPENDENCY-AND-HASH-MANIFEST.json

- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\c6d97dcc\FP-correction\DEPENDENCY-AND-HASH-MANIFEST.json`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\fp-focused-verification-20260908\provenance-originals\501a275996-DEPENDENCY-AND-HASH-MANIFEST.json`
- Bytes: 6976
- SHA256: `0307af45b61bcf2b59b80519db2021b4d2e5a573f3b3d5f98bdae32ae895c9d9`
- Git blob SHA1 of exact bytes: `10a590e6295ffd4ae05f1285261e3e83060c842e`
- Scope: Full returned author manifest and command/source declarations.

## 7. e6b8be8f99-F01-F12-RESPONSE-MAP.md

- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\c6d97dcc\FP-correction\F01-F12-RESPONSE-MAP.md`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\fp-focused-verification-20260908\provenance-originals\e6b8be8f99-F01-F12-RESPONSE-MAP.md`
- Bytes: 12726
- SHA256: `1bdb3d59455711d93172d75c9dfa6763ca66de0d2499ee1812b359667303076f`
- Git blob SHA1 of exact bytes: `c13dbd83ac8127b97097d9efffbd236e7ff94779`
- Scope: Full returned response map mapped to all twelve accepted findings.

## 8. 7c2c4669cb-SOURCE-PROVENANCE-AND-EXCLUSIONS.md

- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\c6d97dcc\FP-correction\SOURCE-PROVENANCE-AND-EXCLUSIONS.md`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\fp-focused-verification-20260908\provenance-originals\7c2c4669cb-SOURCE-PROVENANCE-AND-EXCLUSIONS.md`
- Bytes: 6469
- SHA256: `179fa13a394de40a419f75d15ca9b80fbec3b19b8159f1d761dc8ea225d0d059`
- Git blob SHA1 of exact bytes: `4c3e989d5535db8ee3291143dfa6df28dfdb7eaf`
- Scope: Full returned source-provenance/exclusion account.

## 9. 2076ec5ac8-AFTER-hashes.txt

- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\c6d97dcc\FP-correction\execution\AFTER-hashes.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\fp-focused-verification-20260908\provenance-originals\2076ec5ac8-AFTER-hashes.txt`
- Bytes: 845
- SHA256: `aa7878e9d94a9ebb4c7d1f51cb81f611a67c6d7638ee4f0f64ffe449c49a0e42`
- Git blob SHA1 of exact bytes: `12bd4223a716432987fc98c8553755acfa870e25`
- Scope: Full original after bindings.

## 10. ea10032464-BEFORE-hashes.txt

- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\c6d97dcc\FP-correction\execution\BEFORE-hashes.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\fp-focused-verification-20260908\provenance-originals\ea10032464-BEFORE-hashes.txt`
- Bytes: 534
- SHA256: `9fefd462efe2734f8a34c95a060927890f8158afadb896bd8eea6cfd36739252`
- Git blob SHA1 of exact bytes: `2ab8a46be13d258249aa2f7585d2812d8bd35aa7`
- Scope: Full original before bindings.

## 11. 42004185eb-check-writes-nothing-demonstration.txt

- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\c6d97dcc\FP-correction\execution\check-writes-nothing-demonstration.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\fp-focused-verification-20260908\provenance-originals\42004185eb-check-writes-nothing-demonstration.txt`
- Bytes: 792
- SHA256: `4e88463921bab62feb8952c6824ae0068023be06c4eb5af286129c262c5738fc`
- Git blob SHA1 of exact bytes: `c3b004d09c078ff0a5b8e11d7d77423e9a824319`
- Scope: Full original demonstration; paired perturbed-before hash and restoration record absent.

## 12. 1a3b160a4e-numeric-delta.txt

- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\c6d97dcc\FP-correction\execution\numeric-delta.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\fp-focused-verification-20260908\provenance-originals\1a3b160a4e-numeric-delta.txt`
- Bytes: 48797
- SHA256: `3365bf1ac4dd48e62d4cd0e5a3597d2a3941900f7f4f907701f3be1ca5dc7966`
- Git blob SHA1 of exact bytes: `44925fc01bdce007f59fa5d3fff9d04d3c986aa9`
- Scope: Original author numerical delta retained in full; header, selected removed/added records and common-key-change summary read. Not independently recomputed.

## 13. 5c1e99f4cf-pytest-fp-checks-stdout.txt

- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\c6d97dcc\FP-correction\execution\pytest-fp-checks-stdout.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\fp-focused-verification-20260908\provenance-originals\5c1e99f4cf-pytest-fp-checks-stdout.txt`
- Bytes: 350742
- SHA256: `0c8160befcb92b5667ee5520e426383a0392f47880ca41c3fe071ee9c2ea31a9`
- Git blob SHA1 of exact bytes: `a3c578b9e8ec75f01bcedd0c03794f14f09147ff`
- Scope: Exact complete stdout retained; beginning 1-125, selected diagnostics/keyword scans, summary/tail through 4063 read. Not all 107 failures individually adjudicated.

## 14. 06cc19c593-pytest-fp-checks-summary.txt

- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\c6d97dcc\FP-correction\execution\pytest-fp-checks-summary.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\fp-focused-verification-20260908\provenance-originals\06cc19c593-pytest-fp-checks-summary.txt`
- Bytes: 4451
- SHA256: `19989e0716e9972244e7011c7dc20b359717155200093c670604a0ecd42c0cbe`
- Git blob SHA1 of exact bytes: `83fb114bfcdfc7afacd6619990b5091980444011`
- Scope: Full original summary/session-finish traceback/recorded EXIT=1.

## 15. 3374c5e954-regeneration-stderr.txt

- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\c6d97dcc\FP-correction\execution\regeneration-stderr.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\fp-focused-verification-20260908\provenance-originals\3374c5e954-regeneration-stderr.txt`
- Bytes: 0
- SHA256: `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`
- Git blob SHA1 of exact bytes: `e69de29bb2d1d6434b8b29ae775ad8c2e48c5391`
- Scope: Exact zero-byte original verified.

## 16. 2561710a78-regeneration-stdout.txt

- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\c6d97dcc\FP-correction\execution\regeneration-stdout.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\fp-focused-verification-20260908\provenance-originals\2561710a78-regeneration-stdout.txt`
- Bytes: 7380
- SHA256: `0616b074719395ebf8af390046c58d65606f35a7a8eea36aa4caa57e8f7dc611`
- Git blob SHA1 of exact bytes: `e5c7aea98e1a4be42670e842017f36af8ac5af4d`
- Scope: Full original stdout read; producer prints only 2400 characters per analysis. Not a complete artifact.

## 17. 9e9b273ad4-lenz-2023-primary-abstract.json

- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\c6d97dcc\FP-correction\source-intake\lenz-2023-primary-abstract.json`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\fp-focused-verification-20260908\provenance-originals\9e9b273ad4-lenz-2023-primary-abstract.json`
- Bytes: 2377
- SHA256: `682f8d34904b967cbe2e458ec995b093e667e643c2140481b7e535b64e59f52d`
- Git blob SHA1 of exact bytes: `a81513b35f47e994e99b3afdf97be0246778ad25`
- Scope: Author-created extract retained as provenance only. It is not the authentic original used to close the source hold.

## 18. 19933c8bd7-FINAL-SCIENTIFIC-REVIEW.md

- Source: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\fp-final-review-20260908\FINAL-SCIENTIFIC-REVIEW.md`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\fp-focused-verification-20260908\provenance-originals\19933c8bd7-FINAL-SCIENTIFIC-REVIEW.md`
- Bytes: 53999
- SHA256: `43e7f293e98a4ead02b7ca7897c090999d259650d8ed22fcf2ce8b73c376a785`
- Git blob SHA1 of exact bytes: `1fd84d44eeac2acb815367d9b97207c4971d9ea7`
- Scope: Full original accepted FP final report; baseline incorporated, not rerun.

## 19. 9df33edb72-FP-final-review-root-adjudication-20260908.md

- Source: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\FP-final-review-root-adjudication-20260908.md`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\fp-focused-verification-20260908\provenance-originals\9df33edb72-FP-final-review-root-adjudication-20260908.md`
- Bytes: 8494
- SHA256: `256c6ab297eb8f19f2544624a5c839766194c422a9f5a2124c3905613e0f43ce`
- Git blob SHA1 of exact bytes: `903aa5c8d7301f4a515d606da2f61e12c8e57959`
- Scope: Full root disposition and accepted scope.

## 20. 3aa2b5ae8b-7cf6e46c4c-emc_fusion_freq_agaram2014_pmc.txt

- Source: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\fp-final-review-20260908\provenance-originals\7cf6e46c4c-emc_fusion_freq_agaram2014_pmc.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\fp-focused-verification-20260908\provenance-originals\3aa2b5ae8b-7cf6e46c4c-emc_fusion_freq_agaram2014_pmc.txt`
- Bytes: 39636
- SHA256: `2e023e8aeaba388b38a1cf4f8eb7bb31cc1f9f4464e7814bf13208683e618482`
- Git blob SHA1 of exact bytes: `e8df2912937b7d340bb890aceaec1960268af5ee`
- Scope: Focused primary-source reread: abstract, Methods 169, molecular confirmation 626, follow-up 642 and accepted per-patient/DUK evidence; prior full review carried forward.

## 21. 153c26c265-7461adca90-PMC7563993.txt

- Source: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\fp-final-review-20260908\provenance-originals\7461adca90-PMC7563993.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\fp-focused-verification-20260908\provenance-originals\153c26c265-7461adca90-PMC7563993.txt`
- Bytes: 26795
- SHA256: `efa63c073872ee2a6a3afe328cb34ac68830b1dd368ddb49d962d2612de3c07e`
- Git blob SHA1 of exact bytes: `8f72a7371f12985c56737a46650e0b7e67abcf47`
- Scope: Focused retained review scope for response, integration/prior art, and cautious DMFS claim; prior full review carried forward.

## 22. 3c9edf052f-99b3f033fa-PMC7999686.txt

- Source: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\fp-final-review-20260908\provenance-originals\99b3f033fa-PMC7999686.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\fp-focused-verification-20260908\provenance-originals\3c9edf052f-99b3f033fa-PMC7999686.txt`
- Bytes: 35817
- SHA256: `d50bbdc5e4405264c06677d9cc2a16c26ac4cfa746aa3ada717a28d4a57c9b3b`
- Git blob SHA1 of exact bytes: `b9681a74b63f3a095eee15c61f069deb6c3a8e7c`
- Scope: Focused retained review response assignment/evaluability quotation and attributed antiangiogenic-insensitivity claim; prior review carried forward.

## 23. b358304fd2-537c0f6f8b-PMC5400622.txt

- Source: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\fp-final-review-20260908\provenance-originals\537c0f6f8b-PMC5400622.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\fp-focused-verification-20260908\provenance-originals\b358304fd2-537c0f6f8b-PMC5400622.txt`
- Bytes: 17532
- SHA256: `8f5e841ba5f739c47492761e1bd7a7ecf6a5c4987aff1fc1cea3d20adba8cac0`
- Git blob SHA1 of exact bytes: `69118d3320f0fd287533cf7d19beb5f43c410718`
- Scope: Focused secondary sunitinib passage, especially Introduction line 14 and contrast with weaker Discussion wording.

## 24. db7d7f5c57-c66217a83a-emc_pazopanib_pubmed.txt

- Source: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\fp-final-review-20260908\provenance-originals\c66217a83a-emc_pazopanib_pubmed.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\fp-focused-verification-20260908\provenance-originals\db7d7f5c57-c66217a83a-emc_pazopanib_pubmed.txt`
- Bytes: 19163
- SHA256: `83ed8715eb88e2d6d415dd1dcdfcd1bf6f772164276f650497b71c43e913bf6f`
- Git blob SHA1 of exact bytes: `a88c3661fcc535215f071a3b4fe4c22110dae6c5`
- Scope: Retained primary abstract analysis populations/results; prior final source adjudication carried forward. No primary full-text read.

## 25. 843be9d284-40ed56c778-nct02066285_ctgov_v2_full.txt

- Source: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\fp-final-review-20260908\provenance-originals\40ed56c778-nct02066285_ctgov_v2_full.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\fp-focused-verification-20260908\provenance-originals\843be9d284-40ed56c778-nct02066285_ctgov_v2_full.txt`
- Bytes: 16971
- SHA256: `1941727a4db95723920e5008367617c3f121ca66538094e9ff5e3a8a4e5abb95`
- Git blob SHA1 of exact bytes: `9b1e5fcc8eeae807bd8fa98d37720c891f0f89de`
- Scope: Retained protocol eligibility, particularly previous antiangiogenic exclusion; no patient-level enrolment audit.

## 26. 18cc0cea64-de2b0f2d8a-huang2023_epmc_core.txt

- Source: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\fp-final-review-20260908\provenance-originals\de2b0f2d8a-huang2023_epmc_core.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\fp-focused-verification-20260908\provenance-originals\18cc0cea64-de2b0f2d8a-huang2023_epmc_core.txt`
- Bytes: 12984
- SHA256: `d65fa7842c3950eceb872060c4c56d1c94604fd1e75bc99a8d4805650b64c4bd`
- Git blob SHA1 of exact bytes: `53b86f686d448a284affe5e7d45522f297dffb23`
- Scope: Exact MED/PMID 36948401 bibliographic/abstract record read in full; no claimed Table 1/full text.

## 27. dff3e5988b-f22398814f-PMC6766969.txt

- Source: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\fp-final-review-20260908\provenance-originals\f22398814f-PMC6766969.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\fp-focused-verification-20260908\provenance-originals\dff3e5988b-f22398814f-PMC6766969.txt`
- Bytes: 36431
- SHA256: `d9b736575b4f411e3665638d4d6667c39376054635b3070674f6d22994d10390`
- Git blob SHA1 of exact bytes: `6d41b82f368f5902cf670be77a139a7b2f26516e`
- Scope: Focused primary tumour/model/replicate passages and mechanistic hypothesis; prior source review carried forward. Unavailable correction text not read.

## 28. 909cb1a80b-ffcee4a75c-PMC9813045.txt

- Source: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\fp-final-review-20260908\provenance-originals\ffcee4a75c-PMC9813045.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\fp-focused-verification-20260908\provenance-originals\909cb1a80b-ffcee4a75c-PMC9813045.txt`
- Bytes: 29246
- SHA256: `3f8cd7e434a9ccd2a6dd8b3e6016ab891ddd8c029177b488270a347753c43cd0`
- Git blob SHA1 of exact bytes: `4acf7ff1c51130fefb7e7e8dd40b98a965e741df`
- Scope: Focused primary two-patient model origins, 40-drug versus three-drug validation, and interpretation. Complete drug-inventory figure not retained/read.

## 29. 006ab99644-dd4e1f2f02-pmc_html_PMC1868116.txt

- Source: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\fp-final-review-20260908\provenance-originals\dd4e1f2f02-pmc_html_PMC1868116.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\fp-focused-verification-20260908\provenance-originals\006ab99644-dd4e1f2f02-pmc_html_PMC1868116.txt`
- Bytes: 63736
- SHA256: `b692cda1b3118f9e67f7cc162de9692e1d78de8e9909520403b78b3f66140c50`
- Git blob SHA1 of exact bytes: `6ca78839aa756dcd55e1828fa96cbd2a86d101d4`
- Scope: Focused primary title/authors, Methods 178-184, patient-versus-tumour and published follow-up/partner context; original case-table adjudication carried forward.

## 30. 58a585f279-bf2be2a20b-epmc_core_32572850_multicentre.txt

- Source: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\fp-final-review-20260908\provenance-originals\bf2be2a20b-epmc_core_32572850_multicentre.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\fp-focused-verification-20260908\provenance-originals\58a585f279-bf2be2a20b-epmc_core_32572850_multicentre.txt`
- Bytes: 10269
- SHA256: `b9a576220af18e44ce6ad8fd32940833aab12e2e552b759ada869aeae1cc8ab2`
- Git blob SHA1 of exact bytes: `65a3bdccbb66954414ee75382c8aa0c2d94bab87`
- Scope: Exact MED/PMID 32572850 bibliographic/abstract record read in full, including NR4A3 inclusion, named partners and reported endpoints.

## 31. gse28866-tumour-vs-normal.json

- Source: `c6d97dcc2043bd2a21c749339637286915a29a82:research/modalities/gse28866-tumour-vs-normal.json`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\fp-focused-verification-20260908\pinned\research\modalities\gse28866-tumour-vs-normal.json`
- Bytes: 27256
- SHA256: `ac0a17bd81dd8bc2ecc3b5bb380de5ae00921ae2d32b5a9595bd1449720be407`
- Git blob SHA1 of exact bytes: `526084a99b3a44af0eb1720abe0ec268bae2c47a`
- Scope: Existing SEMA3C scores, sample denominators, and ratios: 625-632, 826-831; relevant nearby field definitions. No raw reanalysis or other-gene claim certification.

## 32. geo-gse28866-brunner-series.json

- Source: `c6d97dcc2043bd2a21c749339637286915a29a82:research/modalities/geo-gse28866-brunner-series.json`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\fp-focused-verification-20260908\pinned\research\modalities\geo-gse28866-brunner-series.json`
- Bytes: 285899
- SHA256: `c9440ea5c9cdefeaa25e6df102ec1ca49d7ceda473f95178775208432cd2e958`
- Git blob SHA1 of exact bytes: `83e92a1465971a2344076be210cc07bd067a5363`
- Scope: overall_design at 645/5445; normal developmental-stage annotations 3941-5111. No full 285899-byte record review or reanalysis.

## 33. gse28866-tumour-vs-normal-reading.md

- Source: `c6d97dcc2043bd2a21c749339637286915a29a82:research/manuscripts/fusion-output/gse28866-tumour-vs-normal-reading.md`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\fp-focused-verification-20260908\pinned\research\manuscripts\fusion-output\gse28866-tumour-vs-normal-reading.md`
- Bytes: 9079
- SHA256: `b3583acb4aaf68f893d7e711b5eb0dd41f2d4a957ee156a7ac1f14ef0a44db89`
- Git blob SHA1 of exact bytes: `86e1147807ffb47afcd1bb55be3095f168fc418b`
- Scope: Focused companion inspection for FP expression context/scale; not a new review of its other antigen claims.

## 34. publications.json

- Source: `c6d97dcc2043bd2a21c749339637286915a29a82:systems/graph/publications.json`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\fp-focused-verification-20260908\pinned\systems\graph\publications.json`
- Bytes: 63611
- SHA256: `0023e64c82fef653ec1a2eda9bc99db17ff632a812cde9e115672785b95e32a2`
- Git blob SHA1 of exact bytes: `cde16db9227ee6bf885611b2c7046fa73541de9a`
- Scope: Only PUB-FUSION-PARTNER, lines 230-243, adjudicated. Whole file retained for immutable binding; other paper entries out of scope.

## 35. 4a0241beb4-epmc_search_taf15_fulltext.txt

- Source: `C:\Users\mcrae\.codex\review-workspaces\opus-capacity-sprint-20260907\capacity-campaign-20260908\observations\7d7d4d3a\FP-reviewer-source-copies\epmc_search_taf15_fulltext.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\fp-focused-verification-20260908\provenance-originals\4a0241beb4-epmc_search_taf15_fulltext.txt`
- Bytes: 553043
- SHA256: `158c5005e6493416d0620d4ab49975b67b0d9182e9fcc2d0c34a4aa9358d35ae`
- Git blob SHA1 of exact bytes: `bfd551d768e80ae7c26863f71768c325d575f3c8`
- Scope: Authentic original container retained in full and byte/SHA256/Git-blob verified; only exact MED/PMID 36563884 bibliographic and full abstract record read. Other search records out of scope.

## 36. d0da2c92ae-6dd777c8fa-epmc_core_40828003.txt

- Source: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\fp-final-review-20260908\provenance-originals\6dd777c8fa-epmc_core_40828003.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\fp-focused-verification-20260908\provenance-originals\d0da2c92ae-6dd777c8fa-epmc_core_40828003.txt`
- Bytes: 10726
- SHA256: `166562b7aef0452895a92deeb3a19cbf0e35b1a0762d9e4ea913a7ce63ec8c84`
- Git blob SHA1 of exact bytes: `3e84958dfa77809e69e713d9c920d3f45a47b44d`
- Scope: Exact MED/PMID 40828003 bibliographic/abstract record read in full, including correct authors/title, patient/sample numbers, OS scope.

## 37. 2fed355570-97ed9a5da5-ft_sunitinib2014_ejc.txt

- Source: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\fp-final-review-20260908\provenance-originals\97ed9a5da5-ft_sunitinib2014_ejc.txt`
- Retained: `C:\Users\mcrae\Documents\Codex\2026-09-07\emc-research-orchestrator\work\fp-focused-verification-20260908\provenance-originals\2fed355570-97ed9a5da5-ft_sunitinib2014_ejc.txt`
- Bytes: 15951
- SHA256: `9b8e56ebb0520560323bc69736e130318c631a45b92be2007643be3de91b6595`
- Git blob SHA1 of exact bytes: `0978078ce1871bad92800e9eaf57dec8cebc17ad`
- Scope: Prior-final-review retained primary abstract carried forward; retained here for F04/F11 provenance. Not a new primary full-text read.

