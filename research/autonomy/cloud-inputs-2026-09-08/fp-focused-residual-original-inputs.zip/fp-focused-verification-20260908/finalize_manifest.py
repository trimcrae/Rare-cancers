"""Finalize exact-byte review manifest. Bookkeeping only; executes no scientific code."""
from pathlib import Path
import json, hashlib
root = Path(__file__).resolve().parent
records = json.loads((root/'retained-inputs.json').read_text(encoding='utf-8'))
scopes = {
 'emc-fusion-partner-stratification.md': 'Full text, lines 1-1048; all revised claims mapped to accepted F01-F12.',
 'emc-fusion-partner-pooling.json': 'Full JSON, lines 1-1249; current citation/cohort/analysis/provenance and quarantine checked.',
 'emc_fusion_partner_pooling.py': 'Focused static reading: 1-85, 143-203, 1417-1845, 1990-2344; whole-file keyword/call searches and source-binding loci. COHORTS/CITATIONS checked via full generated JSON and relevant source definitions. No execution; no claim of a new full-code baseline.',
 'emc-fusion-partner-correction-register.md': 'Preamble/current status; A43-A53 (103-113) and relevant adjacent dated A38/A41/A42/A39 history. Other historical rows retained, not comprehensively re-adjudicated.',
 'publications.json': 'Only PUB-FUSION-PARTNER, lines 230-243, adjudicated. Whole file retained for immutable binding; other paper entries out of scope.',
 'gse28866-tumour-vs-normal.json': 'Existing SEMA3C scores, sample denominators, and ratios: 625-632, 826-831; relevant nearby field definitions. No raw reanalysis or other-gene claim certification.',
 'geo-gse28866-brunner-series.json': 'overall_design at 645/5445; normal developmental-stage annotations 3941-5111. No full 285899-byte record review or reanalysis.',
 'gse28866-tumour-vs-normal-reading.md': 'Focused companion inspection for FP expression context/scale; not a new review of its other antigen claims.',
 'FINAL-SCIENTIFIC-REVIEW.md': 'Full original accepted FP final report; baseline incorporated, not rerun.',
 'FP-final-review-root-adjudication-20260908.md': 'Full root disposition and accepted scope.',
 'BLOCKERS-AND-HANDOFF.md': 'Full returned handoff. Author claims independently distinguished from review acceptance.',
 'DEPENDENCY-AND-HASH-MANIFEST.json': 'Full returned author manifest and command/source declarations.',
 'F01-F12-RESPONSE-MAP.md': 'Full returned response map mapped to all twelve accepted findings.',
 'SOURCE-PROVENANCE-AND-EXCLUSIONS.md': 'Full returned source-provenance/exclusion account.',
 'lenz-2023-primary-abstract.json': 'Author-created extract retained as provenance only. It is not the authentic original used to close the source hold.',
 'BEFORE-hashes.txt': 'Full original before bindings.',
 'AFTER-hashes.txt': 'Full original after bindings.',
 'regeneration-stdout.txt': 'Full original stdout read; producer prints only 2400 characters per analysis. Not a complete artifact.',
 'regeneration-stderr.txt': 'Exact zero-byte original verified.',
 'check-writes-nothing-demonstration.txt': 'Full original demonstration; paired perturbed-before hash and restoration record absent.',
 'pytest-fp-checks-summary.txt': 'Full original summary/session-finish traceback/recorded EXIT=1.',
 'pytest-fp-checks-stdout.txt': 'Exact complete stdout retained; beginning 1-125, selected diagnostics/keyword scans, summary/tail through 4063 read. Not all 107 failures individually adjudicated.',
 'numeric-delta.txt': 'Original author numerical delta retained in full; header, selected removed/added records and common-key-change summary read. Not independently recomputed.',
 'epmc_search_taf15_fulltext.txt': 'Authentic original container retained in full and byte/SHA256/Git-blob verified; only exact MED/PMID 36563884 bibliographic and full abstract record read. Other search records out of scope.',
 'huang2023_epmc_core.txt': 'Exact MED/PMID 36948401 bibliographic/abstract record read in full; no claimed Table 1/full text.',
 'epmc_core_32572850_multicentre.txt': 'Exact MED/PMID 32572850 bibliographic/abstract record read in full, including NR4A3 inclusion, named partners and reported endpoints.',
 'epmc_core_40828003.txt': 'Exact MED/PMID 40828003 bibliographic/abstract record read in full, including correct authors/title, patient/sample numbers, OS scope.',
 'ft_sunitinib2014_ejc.txt': 'Prior-final-review retained primary abstract carried forward; retained here for F04/F11 provenance. Not a new primary full-text read.',
 'emc_fusion_freq_agaram2014_pmc.txt': 'Focused primary-source reread: abstract, Methods 169, molecular confirmation 626, follow-up 642 and accepted per-patient/DUK evidence; prior full review carried forward.',
 'pmc_html_PMC1868116.txt': 'Focused primary title/authors, Methods 178-184, patient-versus-tumour and published follow-up/partner context; original case-table adjudication carried forward.',
 'PMC5400622.txt': 'Focused secondary sunitinib passage, especially Introduction line 14 and contrast with weaker Discussion wording.',
 'PMC7563993.txt': 'Focused retained review scope for response, integration/prior art, and cautious DMFS claim; prior full review carried forward.',
 'PMC7999686.txt': 'Focused retained review response assignment/evaluability quotation and attributed antiangiogenic-insensitivity claim; prior review carried forward.',
 'PMC6766969.txt': 'Focused primary tumour/model/replicate passages and mechanistic hypothesis; prior source review carried forward. Unavailable correction text not read.',
 'PMC9813045.txt': 'Focused primary two-patient model origins, 40-drug versus three-drug validation, and interpretation. Complete drug-inventory figure not retained/read.',
 'emc_pazopanib_pubmed.txt': 'Retained primary abstract analysis populations/results; prior final source adjudication carried forward. No primary full-text read.',
 'nct02066285_ctgov_v2_full.txt': 'Retained protocol eligibility, particularly previous antiangiogenic exclusion; no patient-level enrolment audit.',
}
out=[]
for rec in records:
    path=Path(rec['retained_path']); data=path.read_bytes()
    actual=hashlib.sha256(data).hexdigest()
    if actual!=rec['sha256'] or len(data)!=rec['bytes']:
        raise ValueError('Retained bytes changed: '+str(path))
    name=Path(rec['source'].replace('\\','/')).name
    scope=next((v for k,v in scopes.items() if name.endswith(k)), None)
    if scope is None: raise ValueError('Missing read scope: '+name)
    row=dict(rec, review_scope=scope,
        computed_git_blob_sha1=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest())
    if row['git_blob'] and row['git_blob']!=row['computed_git_blob_sha1']:
        raise ValueError('Git binding mismatch: '+str(path))
    out.append(row)
doc=dict(review='ONE focused FP F01-F12 post-repair scientific verification',
    pin='c6d97dcc2043bd2a21c749339637286915a29a82',
    input_count=len(out), source_acquisition=False, producer_executed=False, tests_executed=False,
    new_clinical_calculations=False, entries=out)
(root/'REVIEW-MANIFEST.json').write_text(json.dumps(doc,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
lines=['# Exact retained inputs and honest read scope','',
       'Candidate pin: `c6d97dcc2043bd2a21c749339637286915a29a82`. Hashes below are of exact retained bytes. Full retention does not imply full reading.','']
for i,r in enumerate(out,1):
    lines += [f"## {i}. {Path(r['retained_path']).name}",'',
        f"- Source: `{r['source']}`",f"- Retained: `{r['retained_path']}`",
        f"- Bytes: {r['bytes']}",f"- SHA256: `{r['sha256']}`",
        f"- Git blob SHA1 of exact bytes: `{r['computed_git_blob_sha1']}`",
        f"- Scope: {r['review_scope']}",'']
(root/'REVIEW-MANIFEST.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
print(json.dumps(dict(exit_status='successful', inputs=len(out), all_byte_bindings_match=True)))
