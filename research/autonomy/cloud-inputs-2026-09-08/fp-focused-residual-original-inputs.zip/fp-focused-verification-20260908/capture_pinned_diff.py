"""Review bookkeeping only: fixed-object textual diff; no producer execution."""
from pathlib import Path
import subprocess, os, json
root = Path(__file__).resolve().parent
cmd = ['git', '-C', 'C:/Projects/EMC-Research', 'diff', '--no-ext-diff', '--no-textconv', '--unified=3',
       'f44b75588fcd9666f8b96b71c2c88ebccb6095ac',
       'c6d97dcc2043bd2a21c749339637286915a29a82', '--',
       'research/manuscripts/emc_fusion_partner_pooling.py']
result = subprocess.run(cmd, capture_output=True,
    env=dict(os.environ, GIT_NO_LAZY_FETCH='1', GIT_TERMINAL_PROMPT='0'))
(root/'producer-fixed-pin.diff').write_bytes(result.stdout)
(root/'producer-fixed-pin.stderr.txt').write_bytes(result.stderr)
(root/'producer-fixed-pin.execution.json').write_text(json.dumps(dict(command=cmd,
    exit_code=result.returncode, no_lazy_fetch=True, scope='Static diff only; no code execution'), indent=2)+'\n')
print(json.dumps(dict(exit_code=result.returncode, stdout_bytes=len(result.stdout), stderr_bytes=len(result.stderr))))
