"""Reviewer source reading aid; copies records from retained JSON wrappers. No retrieval."""
from pathlib import Path
import json, hashlib
root = Path(__file__).resolve().parent
ledger = json.loads((root/'retained-inputs.json').read_text(encoding='utf-8'))
out = []
for suffix, pmid in [('epmc_search_taf15_fulltext.txt', '36563884'),
                     ('epmc_core_40828003.txt', '40828003'),
                     ('epmc_core_32572850_multicentre.txt', '32572850'),
                     ('huang2023_epmc_core.txt', '36948401')]:
    row = next(x for x in ledger if x['source'].endswith(suffix))
    p = Path(row['retained_path']); raw = p.read_bytes(); txt = raw.decode('utf-8')
    data = json.loads(txt[txt.index('{'):])
    recs = data['resultList']['result']; match = [x for x in recs if x.get('id') == pmid]
    if len(match) != 1: raise ValueError((pmid, len(match)))
    out.append(dict(original_container=str(p), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest(),
        git_blob_sha1=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest(),
        extraction_status='NEW REVIEWER READING AID; not an original source object',
        selected={k:match[0].get(k) for k in ['id','source','title','authorString','pubYear','journalInfo','doi','abstractText']}))
(root/'retained-primary-records.reading-aid.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(json.dumps(out,indent=2,ensure_ascii=False))
