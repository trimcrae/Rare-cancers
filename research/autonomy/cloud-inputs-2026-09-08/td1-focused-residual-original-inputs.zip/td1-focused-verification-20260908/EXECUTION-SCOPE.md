# TD1 focused verification — actual execution and retained evidence scope

This is the one focused verification of accepted F1–F11 at current pin `96812f4f4afdeaab9321d755b33e84b9d1d6c61f`. The initial actual clock read was 2026-09-08 23:52:18 UTC. The campaign stop remains 2026-09-09 02:37:19 UTC. No later input revision is covered.

## What ran in this verification

Only local copying/hash identity, fixed local Git-object reads, text searches/line display, JSON display and report/manifest writing ran. Git reads used `GIT_NO_LAZY_FETCH=1` and `GIT_TERMINAL_PROMPT=0`. No checkout, fetch, install, network request, source query, source-denial retry, biological producer, raw reanalysis, classifier, statistical calculation, test/gate suite or guard maintenance ran. No manuscript/source file was edited.

The Python runtime used was `C:/Users/mcrae/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe`, with UTF-8 I/O. New helpers are retained as `retain.py`, `intake.py`, `intake_parent.py`, `read_lines.py`, `read_focus-v1.py`, `read_focus.py` and `finalize_manifest.py`. These helpers are reading/identity tools, not scientific producers. No original reviewer or author scientific/check script was imported or executed.

| New operation | Actual outcome / retained receipt |
|---|---|
| `intake.py` | Exit 0; `intake.stdout.jsonl`, `intake.stderr.txt`, `intake.exit.txt`. Fifteen current pinned dependencies and the original review/author/source records retained. |
| `intake_parent.py` | Exit 0; `intake-parent.stdout.jsonl`, `intake-parent.stderr.txt`, `intake-parent.exit.txt`. Copies already-local parent TD1 patch/invariance originals. |
| `read_focus.py sources`, first version | Actual tool command exit 1: `json.decoder.JSONDecodeError: Expecting value: line 1 column 1 (char 0)` because a retained HTTP-wrapper text was passed directly to JSON parsing. The original helper is preserved as `read_focus-v1.py`. The original tool result is in the conversation; no dedicated raw stdout/stderr file was captured for that first display. This is a reviewer display-helper error, not an unavailable source or failed scientific calculation. No missing original stream has been manufactured. |
| Corrected source display | Exit 0, `source-abstracts-display.stdout.txt`, `.stderr.txt`, `.exit.txt`; parses the already-held body starting at its JSON opening after wrapper lines, and displays only six named abstracts. No new source acquisition. |
| Expression display / bounded expression display | Exit 0; `current-expression-display.*` and `current-expression-brief.*`. Reads and prints retained values and metadata; does not recalculate scores or classify samples. Large display output is not a claim that all unrelated E content was read. |
| Original-receipt display | Exit 0; `original-receipts-display.*`. Prints existing receipt text, not reruns. Individual original files remain separately retained with their hashes. |
| Routine line/search calls | Read-only. One `rg` pointed at a nonexistent workspace subdirectory `external` and exited 1; actual retained copies are under `provenance-originals`. Some large combined outputs were truncated by display limits; material passages were read again in bounded form. These are inspection limits, not scientific check results. |
| Final identity export | `finalize_manifest.py`; actual raw `.stdout.txt`, `.stderr.txt`, `.exit.txt` accompany its metadata export. Rehashing retained bytes establishes identity only. |

No new arithmetic receipt is supplied because no new arithmetic was performed. The original reviewer attempt-2 result was read and compared to the revised table. Its input hashes bind the pre-annotation numerical artifact; the current annotation changes preserve the numerical values. This is evidence continuity, not an assertion that those older original commands ran on current bytes.

## Original scientific/check evidence remains separate

Every retained original file has its own full source and retained location, byte length and SHA256 in `REVIEWED-INPUT-MANIFEST.json`. The original author CHECKS README, individual failed stdout/stderr/exit records, original successful records, patch files, code maps and current parent receipts are distinct from this reviewer’s display outputs.

The author’s repair sequence includes actual source-binding failures 01/02/03; patch failures 05/08/09; a nominally passing builder 06 later caught as unsound by invariance failure 07; later limited successful checks; five file-argument linter CLI exit-2 failures; remaining style and repo-mode linter exits 1. The source-binding final receipt has 230 checks, 0 failed; it does not authenticate absent full texts or validate all scientific sentences. The compact final annotation invariance has 441,602 checks, 0 failed. Its byte-identical preservation of C evidence/unknown blocks is a provenance fact and cannot make their unsupported interpretation valid.

The parent has six original apply exits 0. Original scan 07 exits 1 on the doubled `research/research` path, with empty stdout and a 487-byte traceback. Original corrected scan 08 exits 0, with a 406-byte stdout, no stderr, no leaf additions/removals or non-string changes, and 22 string changes across four JSON files. These records were read, not recreated or rerun. Current source files were separately read from the fixed pin.

The old full-review arithmetic attempt 1 remains an actual exit 1 on UTF-8 decoding with empty stdout; attempt 2 remains a distinct successful conditional calculation. Their scripts, runners and original outputs/exits are retained. The old local source-object failures with lazy fetching disabled and the later authentic four-source transport are separate facts; no failure was erased by subsequent availability. Earlier author preflight failure, skipped pytest and CLI failures remain as the original review describes. This focused pass confers no gate clearance.

## Scope of exact sources

The main was read fully. The original full review, root memo and author finding response were read fully. Current C and K were read fully. Other current artifacts/code were read to the exact TD1 constructs and consequential fields described in the manifest. The large expression/DDR/identity files, whole publication graph, broader census, and unrelated scientific fields were not subjected to new baselines. Retained-only auxiliary history is labelled as such.

The actual four class-definition source containers are retained byte-for-byte; six abstracts and their bibliographic metadata were examined. These are source abstracts, not full articles. Detailed clientship originals/supplements remain unavailable within the already-established lookup scope. No inference of global absence is made and no further access route was attempted.

The review disposition is NOT VERIFIED for current interpretive/reproducibility residuals, not because a broad gate was not rerun. The narrow paper remains salvageable by the finite correction batch. The parked stronger claim and held source/platform questions are not reopened.
