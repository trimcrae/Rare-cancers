"""Retain exact review inputs from the fixed Git pin; never run a producer."""
from pathlib import Path
import subprocess, hashlib, json, sys, os
ROOT = Path(__file__).resolve().parent
REPO = Path('C:/Projects/EMC-Research')
PIN = '96812f4f4afdeaab9321d755b33e84b9d1d6c61f'
MANIFEST = ROOT / 'retained-inputs.json'
GIT_ENV = dict(os.environ, GIT_NO_LAZY_FETCH='1', GIT_TERMINAL_PROMPT='0')
def sha(b): return hashlib.sha256(b).hexdigest()
def retain(path, kind='git'):
    records = json.loads(MANIFEST.read_text()) if MANIFEST.exists() else []
    if kind == 'git':
        proc = subprocess.run(['git','-C',str(REPO),'show',PIN+':'+path],capture_output=True,env=GIT_ENV)
        if proc.returncode: raise RuntimeError(proc.stderr.decode(errors='replace'))
        data = proc.stdout
        blob = subprocess.check_output(['git','-C',str(REPO),'rev-parse',PIN+':'+path],env=GIT_ENV).decode().strip()
        target = ROOT / 'pinned' / path
        source = PIN + ':' + path
    else:
        src = Path(path)
        data = src.read_bytes()
        blob = None
        target = ROOT / 'provenance-originals' / (sha(path.encode())[:10]+'-'+src.name)
        source = str(src)
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists() and target.read_bytes() != data: raise RuntimeError('Refusing overwrite different bytes: '+str(target))
    target.write_bytes(data)
    rec = dict(source=source, retained_path=str(target), kind=kind, git_blob=blob, bytes=len(data),sha256=sha(data),review_scope='retained; scope to be finalized')
    records = [r for r in records if r['source'] != source] + [rec]
    MANIFEST.write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(rec))
if __name__ == '__main__':
    kind = 'external' if '--external' in sys.argv else 'git'
    for arg in sys.argv[1:]:
        if not arg.startswith('--'): retain(arg,kind)




