"""Identity and read-scope export only. Does not execute any scientific/check producer."""
from pathlib import Path
import json,hashlib,datetime,re
R=Path(__file__).resolve().parent
PIN='96812f4f4afdeaab9321d755b33e84b9d1d6c61f'
rs=json.loads((R/'retained-inputs.json').read_text(encoding='utf-8'))
def digest(b):return hashlib.sha256(b).hexdigest()
def norm(s):return s.replace('\\','/')
scopes={
'research/manuscripts/dependency/emc-transcriptional-proteostatic-dependency.md':('full','Entire main, lines 1–532; all accepted F1–F11 and current-claim consistency.'),
'research/manuscripts/modality-census/cancer-modality-census.md':('focused','Consequential TD1 section lines 175–202 only, including current normal-tissue/selectivity echo; not a census baseline.'),
'systems/graph/publications.json':('focused','PUB-TXN-DEPENDENCY only, lines 533–546; other entries not reviewed.'),
'research/modalities/emc-expression-panels.json':('focused','Two TD1 panels and seven groups; both platform counts and all 58 retained annotation records; MYC, CDK7, HSP90AA1/readability and relevant proliferation controls; retained summary comparison. Not all genes/signature/background results or raw validation.'),
'research/modalities/census-route-expression-grading.json':('focused','RT-TXN-CDK and RT-CHAPERONE current summaries, TD1 gene/group evidence and changed fields; not other route science.'),
'research/modalities/depmap-sarcoma-dependency.json':('focused','24Q4 identity, threshold/catalogue count, CDK7/CDK9/HSP90AA1/HSP90AB1/CDC37 rows, SMARCB1 and BRD9 controls. No raw per-line distributions or unrelated target conclusions.'),
'research/modalities/fet-ddr-axis-scan.json':('focused','EMC CRISPR availability: FET EMC subgroup and emc_line ACH-001519 in metadata, no gene effects. Other DDR-axis results not reviewed.'),
'research/modalities/hemcss-label-priorart.json':('focused','Identity/fusion-status caveats and held-evidence scope relevant to no EMC CRISPR inference. No new whole-prior-art review.'),
'research/modalities/emc_expression_panels.py':('focused','TD1 definitions/prose lines 602–652; probe reduction/background rounding 1408–1509; group indices/z row 1652–1670; score logic 1986–2025; related definitions located. No execution.'),
'research/modalities/census_route_expression_grading.py':('focused','Header and depmap prior docstring 1–60; two TD1 route blocks 393–468 and corresponding changed literals. No execution.'),
'research/modalities/depmap_sarcoma_dependency.py':('focused','Release discovery references and data selection/statistics/control logic 217–306; no download/discovery/producer execution.'),
'research/modalities/emc_atr_vulnerability.py':('focused','Matrix annotation extraction 876–919, sample classifier 1608–1628; not the broader ATR study and no classifier execution.'),
'research/modalities/fet_ddr_axis_scan.py':('focused','Welch helper lines 160–180 and immediate context; no FET-axis analysis.'),
'research/literature/txn-dependency-class-definitions-2026-08-09.json':('full','Entire 110-line definition/citation record, and six original abstract records separately retained/read.'),
'research/literature/fet-fusion-chaperone-clientship-2026-08-27.json':('full','Entire current 306-line artifact including verdict, definitions, evidence, Q1–Q15, what_this_changes and open questions. Curated source assertions are not authentic unavailable primary full texts.'),
}
old_manifest_path=next(Path(r['retained_path']) for r in rs if Path(r['retained_path']).name.endswith('-FINAL-REVIEW-MANIFEST.json'))
old=json.loads(old_manifest_path.read_text(encoding='utf-8'))
old_entries=[]
def old_walk(o):
    if isinstance(o,dict):
        if 'retained_path' in o and 'source' in o:old_entries.append(o)
        for v in o.values():old_walk(v)
    elif isinstance(o,list):
        for v in o:old_walk(v)
old_walk(old)
origins={norm(o['retained_path']):o for o in old_entries}
parent_path=next(Path(r['retained_path']) for r in rs if Path(r['retained_path']).name.endswith('-TD1-SHARED-CURRENT-artifact-locators.json'))
parent=json.loads(parent_path.read_text(encoding='utf-8'))
parent_entries={str(Path(f['local_path'])):f for f in parent['files']}
source_abstracts={'epmc_cdk7_transcriptional.txt':'resultList.result[0], PMID 25043025',
 'epmc_hsf1_heat_shock_cancer.txt':'resultList.result[1], PMID 22863008',
 'epmc_hsp90_client.txt':'resultList.result[0] and [2], PMID 28429788 / 9108479',
 'epmc_transcriptional_addiction.txt':'resultList.result[0] and [1], PMID 28187285 / 26406377'}
receipt_catalog=[]
for i,r in enumerate(rs,1):
    p=Path(r['retained_path']);b=p.read_bytes()
    assert len(b)==r['bytes'] and digest(b)==r['sha256'],p
    r['manifest_id']=f'I{i:03d}'
    s=norm(r['source']);n=p.name
    if r['kind']=='git':
        rel=r['source'].split(':',1)[1]
        level,detail=scopes[rel]
        r['review_level']=level;r['review_scope']=detail
    else:
        r['review_level']='retained_only'
        r['review_scope']='Original retained for provenance/scope continuity; not represented as a new full scientific reading.'
        if norm(r['source']) in origins:
            r['transitive_original_binding']=origins[norm(r['source'])]
        if str(Path(r['source'])) in parent_entries:
            f=parent_entries[str(Path(r['source']))]
            r['original_returned_repo_path']=f['repo_path'];r['original_returned_git_blob']=f['git_blob']
        for suffix,rec in source_abstracts.items():
            if n.endswith(suffix) and len(b)>10000:
                r['review_level']='focused_primary_abstracts'
                r['review_scope']='Full original container retained; wrapper and '+rec+' metadata/abstract read at JSON body after line 5. Other search results not reviewed; not full articles.'
        if n.endswith('-FINAL-SCIENTIFIC-REVIEW.md') or n.endswith('-TD1-final-review-root-adjudication-20260908.md'):
            r['review_level']='full';r['review_scope']='Entire original accepted scientific review or root adjudication defining F1–F11; original findings integrated, no new baseline.'
        if '/TD1-repair/' in s:
            if n.endswith(('-FINDING-MAP.md','-CHANGED-FIELD-CODE-MAP.md','-README.md','-INVARIANCE-EVIDENCE.json')):
                r['review_level']='full';r['review_scope']='Entire author finding/field map, README or declared invariance evidence; claims compared to actual current bindings and not accepted by assertion.'
            if n.endswith('-td1_source_bindings.py'):
                r['review_level']='full';r['review_scope']='Entire source/text-binding script read, including conditional calculations and literal-only literature checks; never imported or executed.'
            if n.endswith('.patch'):
                r['review_level']='focused';r['review_scope']='Retained author patch; relevant changed-field map and current literal/binding endpoints inspected. No reviewer patch application.'
            if '/checks/' in s:
                if n.endswith(('.exit.txt','.stderr.txt')) or 'stdout.EMPTY' in n:
                    r['review_level']='receipt';r['review_scope']='Original recorded exit/stderr/empty-stream preserved and inspected as execution history; not rerun.'
                elif 'stdout' in n:
                    r['review_level']='focused_receipt';r['review_scope']='Original receipt retained; outcome/counts/failures and material reported binding scope inspected, not treated as scientific acceptance or rerun.'
                elif '-lint_' in n:
                    r['review_level']='focused_receipt';r['review_scope']='Original limited lint/CLI failure evidence; exit and TD1-related status inspected, no whole-repository review or new lint run.'
        if '/PARENT-TD1-PATCHES-' in s:
            if '/checks/' in s:
                r['review_level']='receipt';r['review_scope']='Original parent command/stdout/stderr/exit read; six applies and failed/corrected invariance runs, no rerun.'
            elif n.endswith('-verify_td1.py'):
                r['review_level']='full';r['review_scope']='Entire parent structural-invariance script read; path fix and limitations assessed, not run.'
            elif n.endswith('.diff'):
                r['review_level']='focused';r['review_scope']='Original returned diff retained; current TD1-relevant endpoints and field map used. No whole unrelated file review.'
        if '/reviewer-checks/' in s:
            r['review_level']='receipt'
            r['review_scope']='Original full-review arithmetic attempt 1/2 outputs and exits retained; successful attempt-2 numerical record read fully, failed attempt preserved. No rerun.'
        if '/source-access-records/' in s:
            r['review_level']='provenance';r['review_scope']='Original failed NO_LAZY_FETCH source-object access receipts retained and source limitation carried forward; no retry.'
        if n.endswith(('-FINAL-REVIEW-MANIFEST.json','-FINAL-REVIEW-DELIVERY.json','-SOURCE-BYTE-VERIFICATION.json','-MANIFEST.json','-EARLY-TD1-CURRENT-BINDINGS.json','-TD1-SHARED-CURRENT-artifact-locators.json')):
            r['review_level']='identity_metadata';r['review_scope']='Source/byte/current-binding metadata used for exact provenance. This does not imply scientific reading of every corpus item named in a transport manifest.'
    if ('/checks/' in s or '/reviewer-checks/' in s or '/source-access-records/' in s) and ('exit' in n or 'stdout' in n or 'stderr' in n or 'command' in n or '-lint_' in n):
        rec={'manifest_id':r['manifest_id'],'source':r['source'],'retained_path':r['retained_path'],'bytes':r['bytes'],'sha256':r['sha256'],'kind':'original_receipt_not_rerun'}
        if len(b)<10000:
            txt=b.decode('utf-8-sig',errors='replace')
            if 'exit' in n:rec['original_exit_text']=txt
            if 'command' in n:rec['original_command_text']=txt
        if n.endswith('.stdout.json'):
            try:
                j=json.loads(b.decode('utf-8'))
                rec['recorded_summary']={k:j[k] for k in ['n_checks','n_failed','failures','scope','method'] if k in j}
            except (UnicodeError,ValueError):rec['qualification']='Original empty/non-JSON/failed stream; retained unchanged, no fabricated parse.'
        receipt_catalog.append(rec)
(R/'retained-inputs.json').write_text(json.dumps(rs,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
counts={}
for r in rs:counts[r['review_level']]=counts.get(r['review_level'],0)+1
support=[]
for p in sorted(R.iterdir()):
    if p.is_file() and p.name not in {'REVIEWED-INPUT-MANIFEST.json','DELIVERY.json','HASHES.sha256','retained-inputs.json','finalize-manifest.stdout.txt','finalize-manifest.stderr.txt','finalize-manifest.exit.txt'}:
        b=p.read_bytes();support.append({'path':str(p),'bytes':len(b),'sha256':digest(b),'kind':'new_review_artifact_or_reading_helper_not_original_scientific_evidence'})
manifest={'review':'TD1 one focused F1–F11 verification','fixed_pin':PIN,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'disposition':'NOT VERIFIED; seven findings closed in main, F8/F9/F10/F11 partial; original strong claim PARK',
 'input_count':len(rs),'input_bytes_sum':sum(r['bytes'] for r in rs),'scope_counts':counts,
 'qualification':'Retention is not full reading. Scope is explicit per file. No source acquisition, producer, classifier, statistical calculation or broad test executed. All input hashes recomputed from retained local bytes.',
 'inputs':rs,'original_receipt_catalogue':receipt_catalog,'reviewer_support_files':support}
(R/'REVIEWED-INPUT-MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for name in ['FOCUSED-SCIENTIFIC-VERIFICATION-TD1.md','REVIEWED-INPUT-MANIFEST.json','EXECUTION-SCOPE.md']:
    p=R/name;b=p.read_bytes();print(json.dumps({'path':str(p),'bytes':len(b),'sha256':digest(b)},ensure_ascii=False))
print(json.dumps({'retained_inputs':len(rs),'scope_counts':counts,'original_receipt_files':len(receipt_catalog),'science_executed':False},ensure_ascii=False))
