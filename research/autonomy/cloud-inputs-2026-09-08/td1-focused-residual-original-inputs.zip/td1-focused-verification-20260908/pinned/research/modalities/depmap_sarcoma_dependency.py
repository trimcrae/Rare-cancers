#!/usr/bin/env python3
"""
DepMap transfer prior: is the chromatin / transcriptional machinery that the EWSR1 prion-like
domain recruits SELECTIVELY essential in sarcomas?

WHY. EMC has no cell line in DepMap, so its dependencies cannot be mined directly. But the
synthetic-lethal hypothesis (degrader-vs-synthetic-lethal.md) is that EWSR1::NR4A3, through the
*same* EWSR1 prion-like domain that retargets BAF in EWS-FLI1 [Boulay 2017], creates a
chromatin-remodeling dependency — sharpest at ncBAF/BRD9, which already has clinical-stage
degraders. This script tests whether that machinery is *selectively* essential across the
sarcoma lineages that ARE in DepMap (Ewing, synovial, etc.), as a transfer prior for EMC.

SELF-VALIDATION (the honesty check). If the method is sound it must recover two textbook
dependencies: BRD9 selectively essential in synovial sarcoma, and SMARCB1 selectively essential
in rhabdoid tumour. We compute and print those explicitly; if they don't fall out, distrust the
rest.

DATA (public DepMap CRISPR Chronos gene effect + model metadata), discovered via the figshare
API so no per-release file IDs are hard-coded. Gene effect: more negative = more essential
(~ -1 is the median common-essential gene; < -0.5 we call "dependent").

Output: depmap-sarcoma-dependency.json (+ .png chart). Internet required -> runs in CI.
"""

import io
import json
import os
import sys
import urllib.request

HERE = os.path.dirname(__file__)
OUT = os.path.join(HERE, "depmap-sarcoma-dependency.json")
CHART = os.path.join(HERE, "depmap-sarcoma-dependency.png")

# Genes the EWSR1-prion / fusion-transactivation hypothesis implicates, grouped.
GENE_GROUPS = {
    "ncBAF (primary hypothesis)": ["BRD9", "BICRA", "BICRAL"],
    "BAF / SWI-SNF core": ["SMARCA4", "SMARCA2", "SMARCB1", "ARID1A", "ARID1B", "SMARCC1", "PBRM1"],
    "BET / transcriptional": ["BRD4", "BRD2", "BRD3", "CDK9", "CDK7", "EP300", "CREBBP"],
    # ── added 2026-08-09 for the modality census's novel candidates ─────────────────────────────
    # ⭐ WHY THEY ARE HERE. The census registered 24 routes and then had to grade them from two small
    # archival ARRAY series, which measure abundance and cannot measure dependency. DepMap measures
    # exactly the missing quantity, the panel already runs, and adding a gene to a group is the whole
    # cost — so one $0 job gives a sarcoma-class dependency prior for every novel candidate at once.
    #
    # ⛔ AND IT IS A CLASS PRIOR, NOT AN EMC READING. There is no EMC line in DepMap: the one
    # "EMC" line on the curated record does not carry the fusion and has no CRISPR data at all. So
    # every number this produces is a transfer from other sarcomas, it inherits BLK-CLASS-INHERITANCE,
    # and the honest bound is not a small sample but NO EMC OBSERVATION. Nothing here may be reported
    # as an EMC dependency.
    "Apoptotic guardians (BH3)": ["MCL1", "BCL2L1", "BCL2", "BCL2L2", "BAX", "BAK1"],
    "Metabolic / biomarker-selected": ["PRMT5", "MAT2A", "MTAP", "ASS1"],
    "p53 axis and repair": ["MDM2", "MDM4", "TP53", "POLQ", "ATR", "WEE1"],
    "Chromatin (PRC2)": ["EZH2", "EED", "SUZ12"],
    "Chaperone": ["HSP90AA1", "HSP90AB1", "CDC37"],
    "Census kinases": ["SGK1", "RET", "CDK12", "CDK13"],
    # ── added 2026-08-09, second pass: the kinase-lead routes the array read could not grade ──────
    # PRKDC is the DNA-PK route's OWN named free next step, and it is the one gene here whose class
    # prior could actually move that route: the mechanism it rests on is a phosphorylation that
    # STABILISES the driver, so a sarcoma-wide dependency says whether inhibiting the kinase is
    # survivable in the tissue class at all. XRCC5/XRCC6 are the rest of the heterotrimer, read
    # beside it so "DNA-PK is essential" cannot be claimed from the catalytic subunit alone.
    "DNA-PK heterotrimer": ["PRKDC", "XRCC5", "XRCC6"],
    # ⭐ THE DRUG-SCREEN HITS, AND WHY THE EXPRESSION READ COULD NOT SUBSTITUTE. ALK and ROS1 have NO
    # PROBE on either archival array platform, so the only published EMC drug screen's hit could not
    # be attributed there at all — an instrument limit, not a negative. DepMap can at least say
    # whether these are dependencies anywhere in the tissue class. The HDACs are here because TWO of
    # the screen's THREE hits are pan-HDAC agents, which is a within-screen class replication the
    # one-agent framing of that lead never showed.
    "Drug-screen hit targets": ["ALK", "ROS1", "EGFR", "HDAC1", "HDAC2", "HDAC3", "HDAC6"],
    # ⭐ THE AXIS OF THE BEST EX-VIVO RESULT THIS DISEASE HAS, and it had never been read here.
    # `RT-CARFILZOMIB` rests on carfilzomib ± venetoclax being active across two PATIENT-DERIVED EMC
    # models — the only place in this portfolio where a drug was put on cells that actually carry
    # this disease. Its target axis was absent from this panel and from the expression panel until
    # 2026-08-09.
    #
    # ⛔ AND THE EXPECTED ANSWER IS PAN-ESSENTIALITY, WHICH WOULD QUALIFY THE LEAD RATHER THAN
    # SUPPORT IT — the same trap this panel already caught once. PRMT5 and MAT2A are dependencies in
    # 94.5% and 96.7% of the 91 SCREENED sarcoma lines (of 176 sarcoma models in the release), which
    # is why the PRMT5 manuscript reports its dependency
    # prior AGAINST its own route. A proteasome subunit required in every line offers nothing to
    # select on either, and if that is what comes back it belongs in the repurposing paper in the
    # same position and with the same prominence.
    # ⚠ NFE2L1 is included knowing a CRISPR score cannot see its bounce-back mechanism, which is
    # post-translational; it is here so the gene is on the record as read rather than skipped.
    "Proteasome and proteostasis (the ex-vivo lead's axis)": [
        "PSMB5", "PSMB1", "PSMD1", "PSMD14", "PSMC1", "VCP", "NFE2L1", "HSPA5", "SQSTM1"],
}
ALL_GENES = sorted({g for v in GENE_GROUPS.values() for g in v})
# context genes for sanity (a pan-essential and the fusion gene itself)
CONTEXT_GENES = ["POLR2A", "NR4A3", "EWSR1", "FLI1"]
# NR4A paralogue-essentiality comparison (the degrader SAFETY gate, H1). The tolerability case for
# a NR4A3-selective degrader rests partly on NR4A1/NR4A2 being similarly non-essential (so the
# family is dispensable in dividing cells and single-paralogue loss is compensated). This pulls all
# three across the FULL DepMap panel to quantify that — a direct query the literature pass could not.
NR4A_PARALOGUES = ["NR4A1", "NR4A2", "NR4A3"]
DEPENDENT_THRESHOLD = -0.5

# Known DepMap public-release figshare article IDs (newest first). Gene essentiality is stable
# across releases, so an older but reliably-hosted release is an acceptable transfer prior.
# 24Q4 is on Figshare+ (plus.figshare.com); 23Q2 (22765112) is on regular figshare and is the
# confirmed reliable anchor — both expose CRISPRGeneEffect.csv + Model.csv.
KNOWN_RELEASES = [("24Q4", 27993248), ("24Q4-alt", 27993966), ("23Q2", 22765112)]
WANT_FILES = {"CRISPRGeneEffect.csv", "Model.csv"}


def _get(url, timeout=120, data=None, headers=None):
    h = {"User-Agent": "rare-cancers/1.0", "Accept": "application/json"}
    if headers:
        h.update(headers)
    for i in range(4):
        try:
            req = urllib.request.Request(url, data=data, headers=h)
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return r.read()
        except Exception as e:  # noqa
            print(f"  retry {i+1} {url[:80]}: {e}", file=sys.stderr)
            import time
            time.sleep(2 ** i)
    raise RuntimeError(f"failed: {url}")


def _download(url, timeout=900, total_deadline=None):
    """Stream a (large) file to a temp path without holding it all in memory. Returns path.

    ⚠ `timeout=` on urlopen is a PER-SOCKET-OPERATION timeout, NOT a whole-transfer deadline: a peer
    that keeps dribbling a byte inside every timeout window never trips it, so the transfer can hang
    indefinitely and the retry loop multiplies it. Measured on run 30853818120 — the DepMap step took
    **15 min against a normal 17–26 s** and only ended because a re-dispatch cancelled it.

    So the loop below enforces two REAL wall clocks on top of the socket timeout:
      * `timeout`        — per-attempt whole-transfer deadline. An attempt that has been running
                           longer than this is abandoned and retried, mid-stream.
      * `total_deadline` — budget across ALL attempts (default 2 x `timeout`, replacing the old
                           unbounded ~4 x `timeout` worst case). Once spent, we raise instead of
                           starting another attempt.
    The workflow's `timeout-minutes:` is the outer backstop; this is the one that lets a stalled
    transfer *retry* rather than merely die.
    """
    import tempfile
    import time
    if total_deadline is None:
        total_deadline = 2 * timeout
    hard_stop = time.monotonic() + total_deadline
    f = tempfile.NamedTemporaryFile(delete=False, suffix=".csv")
    for i in range(4):
        if time.monotonic() >= hard_stop:
            break
        attempt_stop = min(time.monotonic() + timeout, hard_stop)
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "rare-cancers/1.0"})
            with urllib.request.urlopen(req, timeout=timeout) as r:
                # ⚠ `read()` blocks until it has the FULL requested size, so a deadline checked
                # around `r.read(1<<20)` is never reached while a peer dribbles — measured: the
                # first version of this fix still hung. `read1()` returns whatever has arrived,
                # which is what makes the wall clock below actually run.
                read1 = getattr(r, "read1", None) or r.read
                while True:
                    if time.monotonic() > attempt_stop:
                        raise TimeoutError(
                            f"whole-transfer deadline {timeout}s exceeded after "
                            f"{f.tell()} bytes (socket was still alive)")
                    chunk = read1(1 << 20)
                    if not chunk:
                        break
                    f.write(chunk)
            f.close()
            return f.name
        except Exception as e:  # noqa
            print(f"  retry {i+1} download {url[:80]}: {e}", file=sys.stderr)
            f.seek(0); f.truncate()
            remaining = hard_stop - time.monotonic()
            if remaining <= 0:
                break
            time.sleep(min(2 ** i, max(0.0, remaining)))
    raise RuntimeError(f"failed download (total deadline {total_deadline}s): {url}")


def _article_files(aid):
    try:
        return json.loads(_get(f"https://api.figshare.com/v2/articles/{aid}")).get("files", [])
    except Exception as e:  # noqa
        print(f"  article {aid}: {e}", file=sys.stderr)
        return []


def discover_depmap_files():
    """Resolve CRISPRGeneEffect.csv + Model.csv download URLs from a known DepMap release."""
    for label, aid in KNOWN_RELEASES:
        by_name = {f["name"]: f["download_url"] for f in _article_files(aid)}
        have = WANT_FILES & set(by_name)
        print(f"  DepMap {label} (figshare {aid}): exposes {sorted(have)}", file=sys.stderr)
        if WANT_FILES <= set(by_name):
            print(f"  using DepMap {label} (figshare {aid})", file=sys.stderr)
            return {"release": label, **{n: by_name[n] for n in WANT_FILES}}
    # fallback: search the regular figshare repo by the distinctive filename token
    try:
        arts = json.loads(_get("https://api.figshare.com/v2/articles?search_for=CRISPRGeneEffect"
                               "&page_size=20&order=published_date&order_direction=desc"))
        for art in arts:
            by_name = {f["name"]: f["download_url"] for f in _article_files(art["id"])}
            if WANT_FILES <= set(by_name):
                print(f"  using searched article {art['id']}", file=sys.stderr)
                return {"release": f"searched:{art['id']}", **{n: by_name[n] for n in WANT_FILES}}
    except Exception as e:  # noqa
        print(f"  search fallback failed: {e}", file=sys.stderr)
    raise RuntimeError("no DepMap article exposes both CRISPRGeneEffect.csv and Model.csv")


def main():
    try:
        import pandas as pd
    except ImportError:
        print("  pandas missing", file=sys.stderr)
        json.dump({"_status": "pandas missing"}, open(OUT, "w"), indent=2)
        return

    urls = discover_depmap_files()
    release = urls.get("release", "unknown")

    # Model metadata (small)
    model = pd.read_csv(io.BytesIO(_get(urls["Model.csv"], timeout=180)))
    id_col = "ModelID" if "ModelID" in model.columns else model.columns[0]
    lin_col = "OncotreeLineage" if "OncotreeLineage" in model.columns else "lineage"
    dis_col = "OncotreePrimaryDisease" if "OncotreePrimaryDisease" in model.columns else None
    sub_col = "OncotreeSubtype" if "OncotreeSubtype" in model.columns else None
    model = model.set_index(id_col)
    is_sarcoma = model[lin_col].isin(["Soft Tissue", "Bone"])
    sarcoma_ids = set(model.index[is_sarcoma])
    print(f"  {len(model)} models, {len(sarcoma_ids)} sarcoma (Soft Tissue/Bone)", file=sys.stderr)

    # CRISPR gene effect — stream to disk, then read only target columns (memory-safe)
    crispr_path = _download(urls["CRISPRGeneEffect.csv"], timeout=900)
    cols = list(pd.read_csv(crispr_path, nrows=0).columns)
    idx_col = cols[0]
    want = set(ALL_GENES) | set(CONTEXT_GENES) | set(NR4A_PARALOGUES)
    keep = {c.split(" (")[0]: c for c in cols[1:] if c.split(" (")[0] in want}
    ge = pd.read_csv(crispr_path, usecols=[idx_col] + list(keep.values()), index_col=0)
    ge.columns = [c.split(" (")[0] for c in ge.columns]
    print(f"  gene-effect: {ge.shape[0]} lines x {ge.shape[1]} target genes "
          f"(found {sorted(ge.columns)})", file=sys.stderr)

    sar = ge[ge.index.isin(sarcoma_ids)]
    rest = ge[~ge.index.isin(sarcoma_ids)]

    def stats(gene):
        if gene not in ge.columns:
            return None
        s, r = sar[gene].dropna(), rest[gene].dropna()
        if len(s) == 0 or len(r) == 0:
            return None
        return {
            "gene": gene,
            "sarcoma_mean": round(float(s.mean()), 3),
            "rest_mean": round(float(r.mean()), 3),
            "selectivity": round(float(r.mean() - s.mean()), 3),  # >0 = more essential in sarcoma
            "sarcoma_frac_dependent": round(float((s < DEPENDENT_THRESHOLD).mean()), 3),
            "rest_frac_dependent": round(float((r < DEPENDENT_THRESHOLD).mean()), 3),
            "n_sarcoma": int(len(s)),
        }

    genes_out = {grp: [x for g in gl if (x := stats(g))] for grp, gl in GENE_GROUPS.items()}
    context_out = [x for g in CONTEXT_GENES if (x := stats(g))]

    # --- self-validation on known selective dependencies -----------------------------------
    def subtype_mean(gene, predicate):
        if gene not in ge.columns or not (sub_col or dis_col):
            return None
        col = sub_col or dis_col
        ids = set(model.index[model[col].astype(str).str.contains(predicate, case=False, na=False)])
        vals = ge[gene].reindex([i for i in ge.index if i in ids]).dropna()
        if len(vals) == 0:
            return None
        return {"subtype_match": predicate, "n": int(len(vals)),
                "mean_gene_effect": round(float(vals.mean()), 3),
                "frac_dependent": round(float((vals < DEPENDENT_THRESHOLD).mean()), 3)}

    validation = {
        "BRD9_in_synovial": subtype_mean("BRD9", "synovial"),
        "SMARCB1_in_rhabdoid": subtype_mean("SMARCB1", "rhabdoid"),
        "_pass_criterion": "each should show clearly more-negative mean_gene_effect / high "
                           "frac_dependent vs the gene's rest_mean above",
    }

    # closest analogues to EMC: FET-fusion / translocation sarcomas
    analogues = {name: subtype_mean("BRD9", pat) for name, pat in
                 {"Ewing": "ewing", "Synovial": "synovial",
                  # ⚠ 2026-08-05 — THE NAME IS WRONG, THOUGH NO NUMBER RESTS ON IT. The substring
                  # "myxoid" matches 'Extraskeletal Myxoid Chondrosarcoma' (ACH-001519 /
                  # H-EMC-SS), not a liposarcoma line, in DepMap 24Q4. ✅ The group is EMPTY
                  # anyway -- that model has no CRISPR gene-effect data, so the committed
                  # artifact reads `"Myxoid_liposarcoma": null` and no dependency figure here
                  # depends on it (verified, not assumed). ⛔ And the model's identity is
                  # DISPUTED: Cellosaurus CVCL_1238 records that it does not harbor an EWSR1
                  # fusion, so it would not be an EMC read even if data appeared. Correction
                  # home: research/manuscripts/surface-targets/emc-surface-target-landscape.md (Amendment 1).
                  "Myxoid_liposarcoma": "myxoid", "Alveolar_RMS": "alveolar"}.items()}

    # Fusion-addiction proxy (degrader make-or-break): does a fusion partner read as a dependency
    # in its driver context? EWS-FLI1 (FLI1) in Ewing is the canonical analogue for whether EMC
    # would depend on EWSR1::NR4A3 — i.e. whether degrading the fusion should kill the cell.
    addiction_proxy = {
        "_note": "Analogy prior for EMC fusion-addiction (the degrader gate). If FLI1 is a "
                 "selective dependency in Ewing (where EWS-FLI1 is the driver), it supports the "
                 "prior that a FET-fusion sarcoma depends on its fusion — i.e. that degrading "
                 "EWSR1::NR4A3 could be lethal to EMC.",
        "FLI1_in_ewing": subtype_mean("FLI1", "ewing"),
        "FLI1_overall": stats("FLI1"),
        "NR4A3_overall": stats("NR4A3"),
        "EWSR1_overall": stats("EWSR1"),
    }

    # --- NR4A paralogue-essentiality comparison (H1 safety gate) --------------------------------
    # Pan-panel (ALL lineages) gene effect for NR4A1/2/3. The safety question is "is the whole NR4A
    # family broadly non-essential in dividing cells?" — a dispensability question, not a sarcoma-
    # selectivity one, so we report the full-panel distribution (mean/median/fraction dependent).
    def panel_stats(gene):
        if gene not in ge.columns:
            return {"gene": gene, "_status": "not in release"}
        v = ge[gene].dropna()
        if len(v) == 0:
            return {"gene": gene, "_status": "no data"}
        return {
            "gene": gene,
            "n_lines": int(len(v)),
            "mean_gene_effect": round(float(v.mean()), 3),
            "median_gene_effect": round(float(v.median()), 3),
            "min_gene_effect": round(float(v.min()), 3),      # most-dependent line
            "frac_dependent": round(float((v < DEPENDENT_THRESHOLD).mean()), 3),
            "n_dependent_lines": int((v < DEPENDENT_THRESHOLD).sum()),
        }

    nr4a = {g: panel_stats(g) for g in NR4A_PARALOGUES}
    nr4a_comparison = {
        "_note": "Pan-panel DepMap CRISPR gene effect for the three NR4A paralogues (H1 safety "
                 "prior). More negative = more essential; frac_dependent = fraction of lines below "
                 f"{DEPENDENT_THRESHOLD}. The tolerability argument for a NR4A3-selective degrader is "
                 "supported if ALL THREE are broadly non-essential (mean near 0, few dependent "
                 "lines) — i.e. the family is dispensable in dividing cells, so single-paralogue "
                 "loss is unlikely to be broadly toxic. Caveat: DepMap lines are proliferating "
                 "cancer lines, NOT the post-mitotic tissues (CNS/dopaminergic) where NR4A2 loss "
                 "is feared — DepMap can rule broad essentiality IN, but cannot clear tissue-"
                 "specific tolerability. No DepMap line is EMC.",
        "paralogues": nr4a,
        "all_broadly_nonessential": all(
            isinstance(nr4a[g], dict) and nr4a[g].get("mean_gene_effect", -9) > -0.2
            and nr4a[g].get("frac_dependent", 1) < 0.05 for g in NR4A_PARALOGUES),
    }

    result = {
        "_note": "DepMap CRISPR (Chronos) selective-essentiality transfer prior for EWSR1::NR4A3 "
                 "EMC, which has no DepMap line. Gene effect: more negative = more essential; "
                 "< -0.5 = dependent; selectivity = rest_mean - sarcoma_mean (>0 = sarcoma-"
                 "selective). A PRIOR from related sarcomas, NOT EMC data. See "
                 "degrader-vs-synthetic-lethal.md.",
        "data_source": f"DepMap public release {release} (figshare) CRISPRGeneEffect.csv + Model.csv",
        "n_models_total": int(len(model)),
        "n_sarcoma_models": len(sarcoma_ids),
        "dependent_threshold": DEPENDENT_THRESHOLD,
        "genes_by_group": genes_out,
        "context_genes": context_out,
        "nr4a_paralogue_comparison": nr4a_comparison,
        "self_validation": validation,
        "BRD9_by_fusion_sarcoma_subtype": analogues,
        "fusion_addiction_proxy": addiction_proxy,
    }
    json.dump(result, open(OUT, "w"), indent=2)
    print("wrote", OUT, file=sys.stderr)
    # concise summary to stdout
    print(json.dumps({
        "n_sarcoma_models": len(sarcoma_ids),
        "BRD9": stats("BRD9"), "BICRA": stats("BICRA"),
        "nr4a_paralogue_comparison": nr4a_comparison,
        "self_validation": validation,
    }, indent=2))
    render_chart(result)


def render_chart(result):
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        print("  matplotlib absent; skipping chart", file=sys.stderr)
        return
    rows = [x for grp in result["genes_by_group"].values() for x in grp]
    if not rows:
        return
    rows.sort(key=lambda r: r["selectivity"], reverse=True)
    genes = [r["gene"] for r in rows]
    y = range(len(genes))
    fig, ax = plt.subplots(figsize=(8, max(4, 0.45 * len(genes))))
    ax.barh(list(y), [r["sarcoma_mean"] for r in rows], height=0.38, label="Sarcoma", color="#c0392b")
    ax.barh([i + 0.4 for i in y], [r["rest_mean"] for r in rows], height=0.38,
            label="All other lineages", color="#7f8c8d")
    ax.axvline(DEPENDENT_THRESHOLD, ls="--", c="gray", lw=1)
    ax.set_yticks([i + 0.2 for i in y])
    ax.set_yticklabels(genes)
    ax.invert_yaxis()
    ax.set_xlabel("Mean CRISPR gene effect (more negative = more essential)")
    ax.set_title("Chromatin/transcriptional dependency in sarcoma vs other lineages (DepMap)\n"
                 "EWSR1::NR4A3 EMC transfer prior — sorted by sarcoma-selectivity")
    ax.legend(fontsize=8, loc="lower left")
    ax.grid(axis="x", alpha=0.3)
    fig.tight_layout()
    fig.savefig(CHART, dpi=130)
    print("wrote", CHART, file=sys.stderr)


if __name__ == "__main__":
    main()
