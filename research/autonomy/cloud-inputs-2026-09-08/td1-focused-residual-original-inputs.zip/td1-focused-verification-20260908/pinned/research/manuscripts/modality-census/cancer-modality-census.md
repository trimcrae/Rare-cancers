---
id: DOC-MODALITY-CENSUS
title: What oncology can do, and what reaches extraskeletal myxoid chondrosarcoma — a modality census
level: L3
kind: manuscript
status: live
canonical_for: ["the 2026-08-09 modality census and its triage", "the census-versus-search distinction"]
purpose: >
  Answer one question asked on 2026-08-09: the portfolio reasons about a handful of treatment
  categories, so how large is the space it was chosen from, and which parts of it have never been
  looked at? Enumerate every category of cancer treatment, grade each against this disease, and name
  the residue.
scope: >
  L3. This document explains and ranks; it does not own the census rows, which live in
  systems/graph/modalities.json and render to systems/views/modality-census.md. It grades MODALITY
  CLASSES and never targets. It re-grades no existing route, and it restates the reasoning of no prior
  ruling — where a class was already settled, the row points at the document that settled it.
audience: [maintainers, autonomous research agents, external reviewers]
date: 2026-08-09
last_verified: 2026-09-08
related: [DOC-TAX-MODALITY, DOC-EMC-UNEXPLORED-LANES, DOC-ARCHITECTURE]
---

# What oncology can do, and what reaches EMC

**Author:** Tristan D. McRae

*Independent researcher, unaffiliated.* Correspondence: trimcrae@gmail.com
ORCID: [0000-0002-1823-1451](https://orcid.org/0000-0002-1823-1451)

> **Scope of every absence statement in this document.** Where this document says that a class was
> never searched, never followed, never asked or never connected, the statement is about the corpus
> retained in this repository — the three prior sweeps named in §1, their committed probe files, and
> the artifacts cited in each row. It is not a statement about the literature, which has not been
> exhaustively retrieved for any class here. §6 restates this as a limit.

> **Nothing here asserts efficacy, safety, a therapeutic window or clinical readiness — for any class,
> in any verdict, including the ones that survive.** Every candidate below is a hypothesis with a named
> cheapest next observation, and several will not survive that observation.

---

## 1 · Why this is not another search

Three sweeps ran before this one. Each was a **search**: it issued queries and reported what came back.
A search's silence is ambiguous in a way that matters — a class absent from its output may have been
considered and dismissed, or may never have been pointed at, and those two situations call for opposite
responses. No prior document here could tell them apart.

The 2026-08-07 sweep measured what that ambiguity had cost, from the inside. Four whole categories had
been invisible to every previous search, and its diagnosis was not oversight but **instrument shape**.
The portfolio's searches had all been molecular-modality-centric, so physical and locoregional
treatment, the matrix as an address rather than an obstacle, non-cancer diseases sharing the phenotype,
and treatment strategy as distinct from new agents were each outside the shape of every query anyone
had written.

A **census** enumerates the space first and grades second. Its product is a denominator, and a
denominator is what turns *"nobody has looked at this"* from a recollection into a field that a checker
can verify. That is the whole methodological claim of this document, and it is a modest one.

⚠ **This is not a claim to have enumerated oncology.** It claims that the enumeration is explicit, that
every prior ruling is accounted for, and that the residue is named. Rows are certainly missing; the
register is built so adding one is an edit rather than a re-derivation.

## 2 · What the enumeration returned

**217 modality classes across 19 groups and 4 bands.** The full register, with every row's verdict and
pointer, is [`systems/views/modality-census.md`](../../../systems/views/modality-census.md).

| verdict | classes | of which never searched here |
|---|---:|---:|
| ✓ `on_board` — a route already covers it | 42 | 1 |
| ● `in_clinical_use` — the incumbent arsenal | 8 | 0 |
| ✕ `already_rejected` — a prior document settled it | 33 | 0 |
| ✕ `excluded` — this census closes it | 95 | 86 |
| ⭑ `candidate` | 20 | 6 |
| ⏸ `parked_capability` | 9 | 8 |
| — `not_applicable` | 10 | 10 |

**⭑ 111 of 217 classes had never been pointed at by any prior sweep here, and 14 of those are live.**

⛔ **THAT NUMBER WAS 127 WHEN THIS DOCUMENT WAS FIRST WRITTEN, AND THE FIRST VERSION WAS WRONG.**
The correction is in [§2.1](#21--the-headline-was-overstated-and-the-field-is-checkable-in-one-direction-only)
and matters more than the number does. *Superseded, retained: "127 of 215 classes had never been
pointed at by any prior sweep here, and 32 of those are live."*

⛔ **AND THE TABLE WENT STALE A SECOND TIME, FOR A DIFFERENT REASON.** This document's own scope note
says it does not own the census rows, which live in
[`systems/graph/modalities.json`](../../../systems/graph/modalities.json) and render to
[`systems/views/modality-census.md`](../../../systems/views/modality-census.md) — but the table above
was typed once and never regenerated against that registry. Eleven classes registered as `candidate`
when this document was written were re-graded to `excluded` on 2026-08-09, most as their cheapest next
observation was taken (§3.1, §3.2a, §3.3, §3.4, §3.6, §3.7, §3.8 each name the ones that bear on their
own theme). The table above is re-derived from the registry as it now stands, not retyped.
*Superseded, retained: "112 of 217 classes had never been pointed at by any prior sweep here, and 18 of
those are live," with the table reading `excluded 84/83`, `candidate 31/9`, `parked_capability 9/9`.*

Two readings of that number are wrong and worth heading off. It is **not** a claim that 111 opportunities
were missed — 86 of them are closed by this census on first inspection, which is what a denominator is
for. And it is **not** a criticism of the prior sweeps, which found things a census would not have: a
search goes deep where it points, and this went wide everywhere. The complaint is only that width had
never been measured.

The band breakdown behaves exactly as the 2026-08-07 diagnosis predicts, which is the closest thing
here to a validation of the method:

| band | classes | never searched | share |
|---|---:|---:|---:|
| `drug_mechanism` | 162 | 86 | 53 % |
| `delivery_and_conjugate` | 26 | 18 | 69 % |
| `physical_locoregional` | 15 | 3 | 20 % |
| `strategy_and_architecture` | 14 | 4 | 29 % |

Share is never-searched ÷ classes, rounded to the nearest whole percent. *Superseded, retained: the
`strategy_and_architecture` share read 28 %, which was 4/14 = 28.6 % truncated rather than rounded;
the count it derives from is unchanged.*

⚠ **And the corrected table no longer says what the first one did.** Before the audit, the physical
and strategy bands read 53 % and 54 % never-searched, which looked like confirmation that the
previously-invisible categories were the unexplored ones. After it they read 20 % and 29 % — the
LOWEST of the four — because the 2026-08-07 sweep had probed those bands thoroughly and this census
had failed to notice. The bands that are genuinely under-searched are `delivery_and_conjugate` and
`drug_mechanism`, which is the opposite of the original reading. *Superseded, retained: the 58/69/53/54
row and the sentence calling it a validation of the method.*

### 2.1 · The headline was overstated, and the field is checkable in one direction only

⛔ **The first version of this document said 127, and 15 of those rows were wrong.** They were filed
`never_searched` while the repository had already probed the class — most of them in the same
2026-08-07 sweep this document credits for the diagnosis. Isolated limb perfusion, regional
hyperthermia, carbon-ion therapy, percutaneous ablation, arginine deprivation, glycosaminoglycan
biosynthesis, metronomic dosing and hypoxia-activated prodrugs all have dedicated retrieval queries in
that sweep's own committed probe files. The sweep's §6 table does not list them, so they had been
**searched without being ruled on** — and this census read the absence from the table as an absence of
search.

⭐ **The structural defect this exposes is worth more than the count.** `prior_coverage` is checked in
**one direction only**: claiming `searched_before` requires a resolvable document, so a false positive
cannot survive a build. Nothing checks a false negative. A row that wrongly claims novelty passes every
gate, inflates the headline, and — the part that actually costs something — invites someone to build on
a "new" lead that is already graded.

The worst instance was hypoxia-activated prodrugs. The class had not merely been searched: its full
clinical record had been retrieved, the EMC hypoxia signal had been audited against a genome-wide null
that it fails on one of the two platforms, and the owning memo had ruled in terms that the signal is a
reason to ask a question rather than to revisit that class. This census filed it as unexplored, graded
it **supported** from the raw two-platform contrast, and did so by reading the panel artifact without
reading the audit that audits it. Both errors are corrected; the grade now carries the audit.

The audit that found them is [`census-novelty-audit.json`](../../modalities/census-novelty-audit.json),
and it is deliberately noisy — a term match is not coverage, so it surfaces questions and decides
nothing. ⚠ **It flagged 73 rows and adjudicates none of them** — every finding in the audit file is
recorded `UNREVIEWED`, and the adjudication is recorded in the census row itself, in
[`systems/graph/modalities.json`](../../../systems/graph/modalities.json). **Only the 20 candidate rows
were adjudicated there**, because those are the ones anyone would act on. The remaining flags are left
unreviewed rather than silently
cleared, so the count of 111 should be read as *an upper bound that has been tightened once*, not as a
settled figure.

⚠ **And the incumbent arsenal is 8 classes.** That is the answer to the framing that produced this work
— *"a pretty small arsenal"* — stated as a count rather than an impression: multi-kinase antiangiogenic
inhibitors, anthracyclines, alkylators, observation and deferred intervention, a KIT inhibitor used once
under a biomarker restriction, interferon in case reports, radiotherapy, and surgery. Of those, one class
carries the disease's only meaningful systemic response record.

## 3 · The live residue

Twenty classes survive. They group into seven themes, and every one of them is registered as a route
so that it inherits blockers, names an endpoint and can be argued with. *Superseded, retained:
"Thirty-one classes survive" — six of the eleven that dropped out are named individually below, where
each theme reports what its own cheapest observation found; the rest are the already-excluded members
of the §3.2 biomarker theme (§3.2a) and hypoxia-activated prodrugs (§3.8), both of which already carried
their own corrections before this table did.*

### 3.1 · Transcriptional and proteostatic dependency

⛔ **Transcriptional CDK inhibition is closed, and it is the theme's cautionary case rather than its
gap.** *Superseded, retained: "The largest single gap the census found, and it is in the place it
should least have been... The driver is a transcriptional oncoprotein whose entire mechanism is
transactivation, and transcriptional CDK dependency is the best-established vulnerability of
fusion-driven sarcomas as a class... What survives is narrower and still worth a route: the class was
named as a tier, never assessed against any EMC data, and never given one."* The class's own cheapest
observation — a pan-sarcoma DepMap dependency screen — arrived the same day it was registered and went
against it: across 91 screened sarcoma lines, CDK7 and CDK9 are dependencies in 100% of them, which is
the definition of pan-essential. EMC's transcript-level elevation of the transcriptional CDK machinery
(⛔ **superlative withdrawn 2026-09-08.** This read *"the most concordant elevation the whole census
found, on both readable platforms"*. Both halves are withdrawn: the census-wide superlative was never
established, and the corroborating platform — GPL3290 — was withdrawn as corroboration under the TD1
interpretation hold, so the elevation rests on GPL6244 alone. No replacement ranking is asserted and
no new analysis was run.) is real, but it buys
no window against normal tissue, because every sarcoma line needs these genes regardless of fusion
status. This closes the class on the evidence available here — transcript-level and small — as a
de-prioritisation with a stated basis, not a proof of impossibility
([`census-route-expression-grading.json`](../../modalities/census-route-expression-grading.json) →
`routes.RT-TXN-CDK`). ⚠ **The cytotoxicity concern the first version of this row already raised turned
out to be exactly the mechanism that closed it**, not a separate caveat sitting beside a surviving route.

**Chaperone dependency.** A chimeric protein is a folding problem — two domains that never evolved to sit
together — and chaperone dependence is the general consequence. That is a way to lower fusion protein
levels needing no pocket ligand, no assembled ternary complex and no paralogue discrimination, which are
the three blockers holding the portfolio's largest family down. ⚠ The class has a long record of clinical
failure on toxicity, and any assessment has to lead with it.

### 3.2 · Biomarker-selected classes, readable from data already on disk

Six classes are selected by a molecular state rather than by a growth rate, and in every case the
selecting feature is readable in expression data this repository already holds. That makes the whole
theme unusually cheap: these are lookups, not experiments. ⭐ **All six were run on 2026-08-09 and
[§3.2a](#32a--the-lookups-were-run-the-same-day-and-the-prediction-held) records what came back.**

| class | what selects it | why it was never asked here |
|---|---|---|
| PRMT5 / MAT2A | co-deletion of a metabolic locus | no source retained here reads the copy state in this disease |
| arginine deprivation | silencing of one biosynthetic enzyme | the class reads as "metabolic", and metabolic classes were dismissed as a group |
| MDM2 antagonism | wild-type p53 and a quiet genome | the profile is unusual enough that the class rarely finds it |
| MCL-1 / BCL-xL | which anti-apoptotic protein a model depends on | the result implying it was already held and never followed |
| EZH2 / PRC2 | a chromatin-remodeller defect | a neighbouring chromatin hypothesis exists and was never connected to it |
| POLθ | a replication-repair state | the class-inheritance argument was built and never extended |

⚠ **A shared caveat these six inherit together.** Expression is a surrogate for most of what selects
them — a transcript floor is not a copy-number call, and abundance is not activity. Each answer will be a
triage, and the honest output of the theme is which classes are *excluded* by the lookup rather than
which ones survive it.

#### 3.2a · The lookups were run the same day, and the prediction held

All six were graded on 2026-08-09 against the panel and its CI extension. **Four of the six were
excluded, one survived, and one stays open** — which is close to what the caveat above predicted the theme would produce, and it
is worth recording that a prediction of mostly-negatives was made before the answers arrived rather
than after.

| class | verdict |
|---|---|
| PRMT5 / MAT2A | **survived** — the locus reads lower where powered, the methylosome higher on both platforms; it now has its own paper |
| arginine deprivation | excluded — the selecting biomarker is *higher* in this disease on both platforms, not lower |
| MDM2 antagonism | excluded — the p53 transcriptional output is lower on both, not the live axis the class needs |
| MCL-1 / BCL-xL | **against at the abundance level** — all five druggable guardians are lower on both platforms. ⚠ **The class is not excluded and stays a candidate:** across the 91 screened sarcoma lines MCL1 and BCL2L1 are dependencies in 83.5 % and 75.8 % and BCL2 in 2.2 %, so the dependency prior points the opposite way to the abundance read, and the route was restored to open rather than down-graded (`census-route-expression-grading.json` → `RT-APOPTOSIS-DEP.route_action`) |
| EZH2 / PRC2 | excluded — neither selecting shape present |
| POLθ | excluded — the required *combination* is absent, because the homologous-recombination half is not there. ⚠ **Not because neither half is:** the alt-EJ half is present on both platforms. *Superseded, retained: "neither half of the required combination" — the verdict is unchanged, the reason given was wrong (`census-route-expression-grading.json` → `RT-POLQ.⚠_correction_2026_08_09`)* |

⛔ **The starred example in the first version of this section was the MCL-1 row, and the lookup went
against it.** *Superseded, retained: "The MCL-1 row is the sharpest of these because the evidence is
already in the building… That pattern is the signature of dependence on a different member of the same
family, and nobody has asked which one."* The reasoning was sound and the reading did not support it.
⚠ **What survives is narrower and still open:** low guardian abundance with elevated NOXA is compatible
with a primed state, which would make the combination-only result *more* interesting rather than less —
and abundance cannot distinguish those, because apoptotic dependency is which protein holds the
effectors. The observation stands; the MCL-1-dominance reading of it does not.

### 3.3 · Kinase leads with EMC-specific evidence that no retained source follows

Two classes where an observation in this disease already exists and has simply been left. Both were
surfaced by the 2026-08-07 sweep as lanes and never became routes; registering them is the follow-on that
sweep itself named. *Superseded, retained: "Four classes... Three were surfaced by the 2026-08-07 sweep
as lanes"* — RET and ALK/ROS1, the other two, took their cheapest observation on 2026-08-09 and it
closed each of them; see below.

- **SGK1** — positive across a full small series of tumours with an internal negative control, published
  two decades ago, and no follow-up appears among the sources retained here. No systematic retrieval
  was run for follow-up work on this class, so this is a gap in the retained corpus rather than a
  measured absence in the literature.
- **DNA-PK** — curated interaction evidence on the driver protein itself, and it needs neither a pocket
  ligand nor a ternary complex.

⛔ **RET is closed, on the credibility of the founding claim rather than on a negative measurement.**
*Superseded, retained: "RET — the only kinase reported as both expressed and activated in this disease,
from independent groups, with selective inhibitors approved elsewhere, unfollowed for over a decade."*
Re-reading the source shows the activation claim is a single sentence in a paywalled abstract, about "a
limited set" of at most ten tumours, with no recoverable denominator and no assay attribution — and the
approved selective agents are approved on a molecular state this disease is not reported to be in.
⚠ **This is a separate finding from what §3.8's expression pass reports, and the two are not in
tension.** That pass reads the RECEPTOR itself higher in EMC on both platforms (the lane's premise holds
there) but its ligand/co-receptor module lower on both — a SPLIT reading that, on its own, recommended
keeping the class with the co-receptor result carried as a caveat. What closes the class instead is the
founding clinical claim that RET is *activated* in this disease, which does not survive being re-read at
the source regardless of what the expression data show. Nothing here says the receptor is inactive in
EMC; it says nobody has measured it, which is a different and more useful statement
([`systems/graph/modalities.json`](../../../systems/graph/modalities.json) → `MOD-RET`).

⛔ **ALK / ROS1 is closed, because the screen hit it was raised from belongs to a different class.**
*Superseded, retained: "ALK / ROS1 — an inhibitor of this class was among the low-IC50 hits of a drug
screen run on a patient-derived line of this disease. The hit does not establish which target produced
it, because that agent inhibits several kinases, and the first step separates the observation from the
hypothesis."* That first step has now been taken: re-reading the screen shows two of its three hits
belong to a different single class already on the board, and abundance cannot attribute a screen hit to
a target in any case, so the hit is unattributable to this class in principle. ⚠ **This document said
until now that neither kinase could be read on either platform, and the owning artifact retracted that
on 2026-08-29:** ALK is readable on one of the two platforms and ROS1 on both, and where they are
readable they sit unremarkably — which rules neither of them out and is a statement about the
instrument rather than a negative reading. What closes the row
is that the screen's own weight sits elsewhere
([`systems/graph/modalities.json`](../../../systems/graph/modalities.json) → `MOD-ALK-ROS1`).

### 3.4 · The matrix as an address

The myxoid matrix is this disease's defining phenotype, and the portfolio's prose has treated it almost
entirely as an obstacle to delivery. Four classes take it as the target instead.

Two of them route around a limitation this repository has already flagged in its own instrument: the
surfaceome screen ranks tumour-cell monoculture transcripts, so it cannot see glycans and has no stromal
compartment in it at all. Its conclusion that no selective surface antigen exists is therefore a statement
about classic protein antigens and is narrower than it reads.

⛔ **The third option — stop the tumour building the matrix — was asked and closed the same day it was
registered.** *Superseded, retained: "One of the four is a question nobody appears to have asked in this
disease at all... The third option is to stop the tumour building it — the gel is a manufactured product
with a named biosynthetic pathway... the relevant expression read is already committed here and has
never been graded for this purpose."* It has now been graded: §3.8 below reports the result — the
sulfate-donor module is lower, not higher, than in comparator sarcomas, which is the opposite of the
selectivity the class needed. ⚠ **That pathway is shared with normal chondrogenesis, so this was always
a question about a window rather than a presence, and the window reads the wrong way**
([`census-route-expression-grading.json`](../../modalities/census-route-expression-grading.json) →
`routes.RT-MATRIX-SYNTHESIS`).

⛔ **The fourth option — use the matrix as the address rather than the target — has now been graded on
the same pass, and the capacity proxy does not support it: "NOT SUPPORTED ON CAPACITY — AND THE ROUTE'S
OWN QUESTION IS STILL UNREADABLE. This grades the proxy the route nominated, not the route's premise."**
The selecting feature is the placental-type oncofetal chondroitin-sulfate pattern on EMC tissue, and the
route needed the 4-O-sulfotransferase arm that writes that pattern, and the sulfate-donor module that
supplies every sulfation, high in EMC. Neither half returned it. The 4-O arm is **discordant** — lower
in EMC on one platform, higher on the other, and significant on neither — and all four of its genes are
readable on both platforms, so this is a taken reading and not a missing one. The sulfate-donor (PAPS)
module is **lower in EMC on both** platforms, the only concordant signal in the panel and the same
observation that graded matrix biosynthesis against its premise above. The core proteins that would
carry the chains are mildly higher on both and significant on neither.

⛔ **A sulfation pattern has no gene.** That is the panel's own standing caveat and it is what makes
this route's evidence asymmetric: sulfotransferase transcript is a proxy for the CAPACITY to write a
pattern and can never be a measurement of the pattern, and an epitope written by a low-abundance enzyme
on a long-lived glycan is entirely compatible with this reading. **So an unfavourable capacity read
weakens the route and cannot close it** — exactly the shape of the matrix-targeted immunocytokine row
in §3.8, where the address is a splice variant a gene-level probe cannot see. ⚠ It also says nothing
about whether any glycan-directed agent binds, works or is safe in this disease. The route is therefore
**kept, demoted**: the $0 observation it named has now been taken and returns no support, so a stain is
the only remaining instrument, and the route's readiness must stop claiming an unrun lookup
([`census-route-expression-grading.json`](../../modalities/census-route-expression-grading.json) →
`routes.RT-MATRIX-ADDRESS`).

### 3.5 · Locoregional and radiation

The portfolio contains no physical intervention of any kind. That is the cleanest instance of the
instrument-shape problem, and it matters here more than it would in most diseases, because this one is
indolent, extremity-primary and lung-metastasis-dominant — the exact profile regional and local therapy
was developed for.

- **Isolated limb perfusion**, with an approved agent and an established role in unresectable extremity
  sarcoma, against a disease whose most common primary site is deep soft tissue of the thigh and lower
  limb.
- **Lung-directed local therapy** — regional perfusion, inhaled delivery, percutaneous ablation — against
  a metastatic pattern the curated record describes as mostly lung, in a disease where removing isolated
  metastases is already documented to give long disease-free intervals.
- **Radiotherapy intensification** — particle therapy, brachytherapy, radiosensitisation, regional
  hyperthermia. This one attaches to a contradiction already live in this repository's record, where two
  registries and the largest series disagree about whether radiotherapy does anything. No prior sweep
  considered that the answer might be dose *quality* rather than dose.

⚠ **One negative generalises across this whole theme and is carried rather than rediscovered.** Boron
neutron capture was declined on the low density of cells per unit volume in a matrix-dominated tumour:
dose scales with boron atoms per unit volume, and the boron is delivered per cell. That
cells-per-volume correction applies to every modality dosed per volume but delivered per cell, and it now
carries to the Auger-emitter and radioimmunoconjugate rows as well.

### 3.6 · Strategy and reachability

Not new agents — changes to what a patient receives. Scheduling (adaptive and metronomic) and the two
reachability routes: eligibility defined by fusion family rather than histology, and the access pathways
by which a published hypothesis becomes a treated patient. *Superseded, retained: "Scheduling..., sequencing,
and the two reachability routes"* — **sequencing is closed**, on evidence base rather than plausibility.
Optimal treatment sequencing is a real clinical question in this disease, and the record curated in
this repository's clinical registry cannot answer any form of it: no randomised evidence for any
systemic therapy appears among the series that registry retains, every pooled denominator it holds is
under sixty patients, and the between-cohort response range is wide enough that this repository's own
pooling refuses to emit a single all-regimen figure. Those are properties of the curated corpus, not
a verified census of the world literature. ⛔ **The refusal is the
contribution** — this closes the class as an analysis target while making the negative itself
publishable
([`systems/graph/modalities.json`](../../../systems/graph/modalities.json) → `MOD-SEQUENCING`).

⭐ **The last of those closes a gap in the portfolio's own logic.** Every route here names publication as
its endpoint, on the correct reasoning that with no wet lab and no clinic the published record is the only
channel to a patient. But the mechanism by which a paper becomes a treatment — single-patient access,
off-label use, an outcome registry that captures the result — had never been registered as a route. The
portfolio had an endpoint and no next step after it.

### 3.7 · Nuclear receptors outside NR4A3

One lane from the 2026-08-07 sweep, still open: an orphan nuclear receptor implicated in dormancy has a
published tool compound — which is the known-answer control the program's own receptor never had, and
the reason this lane is worth more than its biology alone suggests. *Superseded, retained: "Two lanes...
A hormone-responsive 5′ partner can import a druggable transcriptional input the driver does not
otherwise have, and there is a reported instance of exactly that with durable benefit."* ⛔ **That
second lane is closed, on reach rather than on mechanism.** The class needs a hormone-responsive 5′
fusion partner to import the hormonal input, and the partner-frequency arithmetic says one is reported
in a single EMC patient across the sources this repository retains, and in none of the partner-genotyped
cases the cited cohorts cover. The denominator is those cohorts, not the world literature. The
mechanism survives; what fails is the number of patients it could reach, which for an
ultra-rare disease is the whole question — a de-prioritisation with a stated basis, not a proof
([`systems/graph/modalities.json`](../../../systems/graph/modalities.json) → `MOD-SERM-SERD`).

### 3.8 · The first grading pass, and what it cost

Sixteen of the routes registered above turned out not to need their cheapest observation **run** at all.
The genes are read and committed in the repository's targeted expression panel — 479 of them as it now
stands, after the extension §3.2a reports — and nobody
had graded them against these routes because the routes did not exist when the panel was built. That
is the census doing the one thing a census is for: the reading was on disk, and only the denominator
made anyone go and look at it.

Verdicts, which live in
[`census-route-expression-grading.json`](../../modalities/census-route-expression-grading.json) and are
not restated here:

| route | verdict |
|---|---|
| hypoxia-activated prodrugs | ⛔ **withdrawn** — the confound audit restricts the signature to one of the two platforms, and [`emc-hypoxia-reading.md`](../microenv/emc-hypoxia-reading.md) §5, which owns that audit, declines to license this class from the signal at all. *Superseded, retained: "**supported** — and the only one supported concordantly on both platforms"* |
| arginine deprivation | **against** — the selecting biomarker is not low in this disease on either platform |
| matrix biosynthesis | **against as stated** — the sulfate-donor module is lower, not higher, than in comparator sarcomas |
| RET | **split** — the receptor holds; the module that switches it on is depleted on both platforms |
| matrix-targeted immunocytokines | **present, not selective** — and the isoform that decides it is unreadable here |
| orphan-receptor dormancy | **unread** — no probe maps to the receptor on either platform |
| SGK1 (§3.3) | **discordant on the kinase, concordant on its substrate** — SGK1 itself is lower on one platform and higher on the other; its canonical substrate NDRG1 is higher on both, at the 98th percentile on one. ⚠ Every published SGK1→NDRG1 mechanism is a phosphorylation of NDRG1 protein, so the substrate elevation is not attributable to the kinase; the corroboration the route was registered for did not arrive |
| chaperone dependency (§3.1) | **partly supported** — the HSP90 machine is higher on both platforms and the co-chaperones follow it, while the HSP70 arm and the heat-shock response go the other way on both. ⚠ An elevated chaperone machine is not evidence that the fusion is its client, which is the route's actual premise and a co-immunoprecipitation question |

⭐ **Two of these are worth more than a positive would have been.** The RET result qualifies the lane
this census and the 2026-08-07 sweep both ranked highest: canonical signalling through that receptor
needs a ligand and a co-receptor, and relative to comparator sarcomas this disease has less of both.
That does not close the lane on THIS reading alone — ligand-independent activation exists, and bulk
tumour transcript cannot exclude a paracrine supply — but it moves the claim the lane may make from
*activated* to *expressed*, which is a different and much weaker sentence than the one it was registered
on. ⚠ **The lane is closed anyway, on a separate and later finding (§3.3): the founding clinical claim
that RET is activated in this disease does not survive being re-read at its source, regardless of what
this expression pass shows.** The two findings answer different questions and neither one alone would
have closed the class.

⚠ **And one returned nothing, which is recorded as nothing.** The dormancy receptor has no probe on
either platform. An unreadable gene is not an absent gene, and the pass reports it as unread rather
than letting a missing probe become a negative — the failure mode the source artifact's own governing
rule exists to prevent.

⚠ **The panel extension this section named as its next step has since run.** All six biomarker-selected
classes in §3.2 are now in this pass — their selecting genes are among the 479 the panel currently
reads — and [§3.2a](#32a--the-lookups-were-run-the-same-day-and-the-prediction-held) reports what came
back. *Superseded, retained: "Five of the six biomarker-selected classes in §3.2 are NOT in this pass,
because their selecting genes are not among the 243 the panel currently reads. Extending it is a free
CI job and is the immediate next step; until it runs, those five rows are unexamined rather than
open."*

## 4 · What the census closes, and why that is the larger half

Ninety-five classes are closed here on first inspection, and that is the census working rather than the
census failing. Most fall into four recurring shapes, and naming the shapes is more useful than listing
the rows:

1. **Proliferation-coupled classes** — mitotic kinases, antimetabolites, dietary restriction, most
   cytotoxics. Their effect scales with division rate, and this tumour is slow-cycling with an indolent
   course. This is the same ground on which a physical modality was already declined here.
2. **Classes gated on an antigen** — allogeneic and NK cell therapy, trispecifics, masked antibodies,
   alternative scaffolds, radioimmunoconjugates, peptide conjugates. Each changes format, effector,
   payload or safety margin, and none supplies an address. The gate is upstream of all of them.
3. **Classes gated on an existing immune response** — checkpoint combinations, costimulatory agonists,
   adenosine and IDO blockade, regulatory T-cell depletion, innate agonists. ⚠ The innate agonists needed
   a specific reason rather than the general one, since they are explicitly built for cold tumours: they
   supply priming, not antigens, and a genome this quiet is short of antigens.
4. **Classes selecting on a lesion this genome does not have** — MAPK, PI3K, FGFR, HER2, CDK4/6, WRN,
   RAS. A quiet clonal genome with a single founding translocation is a poor place to look for a second
   driver.

⭐ **Three closures are worth more than the rest, because they are new classes killed by facts the
repository already owned.** Splice-switching antisense, response-element decoy oligonucleotides and
oligonucleotide-directed degradation all look like clean fits for a DNA-binding fusion driver, and all
three fail on rulings already on the books — the splice acceptor at the junction is not fusion-unique, and
the paralogues' DNA-binding domains are near-identical. None had been named here before; each is now a
closed row with its argument attached.

## 5 · Reconciliation with the three prior searches

Every ruling made by a prior sweep is accounted for by a row that **points at it and does not restate its
reasoning**. That is a deliberate constraint rather than brevity: a second home for an argument is an
argument that drifts, and this repository has measured that failure enough times to build checkers
against it.

Thirty-three rows carry `already_rejected` with a resolvable pointer into the owning document. The pointer
is checked by the same machinery that checks every other pointer in the model, and a test asserts that
each of the three prior searches is reached by at least one row — so a ruling cannot fall out of the
record silently and reappear later as a fresh idea.

⚠ **The reconciliation test is deliberately weak and says so.** It asserts that each prior document is
reached, not that every row inside it was individually mapped. The strong form of that guarantee is the
per-row `prior_coverage` field, which is schema-enforced and requires a resolvable document before a class
may be called previously searched.

## 6 · Limits

- **A census is only as good as its taxonomy.** Nineteen groups is a choice, and a class that falls
  between two of them is a class that can be missed. The bands were chosen to make the previously
  invisible categories visible, which fixes the failure that was measured and not the general problem.
- **Most verdicts are judgements, not measurements.** The `excluded` rows in particular rest on a
  mechanism-versus-biology argument, and a mechanism argument is exactly the kind that a single
  measurement can overturn. They are recorded so they can be argued with, which is the most a document
  like this can offer.
- **`never_searched` is a statement about this repository, not about the field.** It says no sweep here
  pointed at a class. Others may have looked at it in this disease, and where they have, the honest next
  step is to find that work rather than to treat the class as unexamined. The same restriction governs
  every other absence statement in this document, including the ones phrased as "never followed",
  "never asked" or "never connected": each is scoped to the sweeps and artifacts retained here, and none
  of them rests on an exhaustive retrieval of the literature. A census assembled from a selected corpus
  can report what that corpus contains and cannot report what the field contains.
- **The candidate list is not ranked against the existing board.** Registering these as routes puts them
  on the same axes as the other routes, which is where ranking belongs. Nothing here claims a new
  candidate outranks an existing one.
- **Nothing here has been tested.** Every candidate carries a cheapest next observation precisely because
  none of them has had one yet.

## 7 · Declarations

**Author.** Tristan D. McRae, independent researcher, unaffiliated. Correspondence:
trimcrae@gmail.com. ORCID 0000-0002-1823-1451. Sole author, responsible for the content.

**Funding.** None.

**Competing interests.** None.

**Ethics.** This is an analysis of public data and of computed artifacts already held in this
repository. No new recruitment, sampling or intervention was carried out for it, and no new human
material was collected. No ethics approval was sought and none was obtained; no determination that
approval was unnecessary has been made by any committee, and none is claimed here. Patient numbers
quoted in the text are counts reported in published series and curated into this repository's
clinical registry; no individual-level record was newly obtained or generated.

**AI assistance.** Enumeration, grading, verification and drafting were carried out with substantial
assistance from Claude (Anthropic) and OpenAI models under the author's direction. The author is
responsible for every claim, including those produced with that assistance.

**Data and artifacts.** Every count and verdict printed above is derived from four committed
artifacts, and each is re-derivable from them without re-running any producer:

| artifact | what this document takes from it |
|---|---|
| [`systems/graph/modalities.json`](../../../systems/graph/modalities.json) | the 217 rows, their verdicts, bands, groups and `prior_coverage`; §2's two tables and §5's 33 `already_rejected` rows |
| [`research/modalities/census-novelty-audit.json`](../../modalities/census-novelty-audit.json) | §2.1's 73 flagged rows, all recorded `UNREVIEWED` |
| [`research/modalities/census-route-expression-grading.json`](../../modalities/census-route-expression-grading.json) | §3's per-route verdicts, the 16 graded routes of §3.8, and the sarcoma dependency fractions quoted in §3.1 and §3.2a |
| [`research/modalities/emc-expression-panels.json`](../../modalities/emc-expression-panels.json) | the 479 genes the panel reads, and the two expression platforms every "both platforms" statement refers to |

The rendered register is [`systems/views/modality-census.md`](../../../systems/views/modality-census.md),
generated from the first of those files.
