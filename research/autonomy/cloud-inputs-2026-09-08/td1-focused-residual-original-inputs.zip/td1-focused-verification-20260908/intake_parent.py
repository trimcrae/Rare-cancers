"""Copy exact already-local TD1 parent receipts; no new execution of checks."""
from pathlib import Path
import json
import retain
rs=json.loads(retain.MANIFEST.read_text())
p=next(Path(r['retained_path']) for r in rs if r['source'].replace('\\','/').endswith('/96812f4f/TD1-SHARED-CURRENT-artifact-locators.json'))
j=json.loads(p.read_text())
for f in j['files']:
    if 'PARENT-TD1-PATCHES' in f['repo_path'] and '/BEFORE/' not in f['repo_path'] and 'tcip' not in f['repo_path'].lower():
        retain.retain(f['local_path'],'external')
