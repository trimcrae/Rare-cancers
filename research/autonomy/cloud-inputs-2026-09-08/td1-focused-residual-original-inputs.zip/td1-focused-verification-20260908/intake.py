"""Retain fixed TD1 focused-review inputs only; no network or scientific execution."""
from pathlib import Path
import json
import retain
base=Path('C:/Users/mcrae/Documents/Codex/2026-09-07/emc-research-orchestrator')
old=base/'work/td1-final-review-20260908'
cap=Path('C:/Users/mcrae/.codex/review-workspaces/opus-capacity-sprint-20260907/capacity-campaign-20260908/observations')
paths=['research/manuscripts/dependency/emc-transcriptional-proteostatic-dependency.md','research/manuscripts/modality-census/cancer-modality-census.md','systems/graph/publications.json']
paths+=['research/modalities/'+x for x in ['emc-expression-panels.json','census-route-expression-grading.json','depmap-sarcoma-dependency.json','fet-ddr-axis-scan.json','hemcss-label-priorart.json','emc_expression_panels.py','census_route_expression_grading.py','depmap_sarcoma_dependency.py','emc_atr_vulnerability.py','fet_ddr_axis_scan.py']]
paths+=['research/literature/txn-dependency-class-definitions-2026-08-09.json','research/literature/fet-fusion-chaperone-clientship-2026-08-27.json']
for p in paths:retain.retain(p)
external=[base/'work/TD1-final-review-root-adjudication-20260908.md',old/'FINAL-SCIENTIFIC-REVIEW.md',old/'FINAL-REVIEW-MANIFEST.json',old/'FINAL-REVIEW-DELIVERY.json',cap/'96812f4f/EARLY-TD1-CURRENT-BINDINGS.json',cap/'96812f4f/TD1-SHARED-CURRENT-artifact-locators.json']
external+=sorted(p for p in (cap/'f6107376/TD1-repair').rglob('*') if p.is_file())
# Actual original held source files, source-access failures, original author failures and reviewer receipts.
for r in json.loads((old/'retained-inputs.json').read_text()):
 s=r['source'].replace('\\','/')
 if r['kind']!='git' or '/TD1-dependency/checks/' in s:
  external.append(Path(r['retained_path']))
external+=sorted(p for p in (old/'reviewer-checks').rglob('*') if p.is_file())
external+=sorted(p for p in (old/'source-access-records').rglob('*') if p.is_file())
external += [old/'reviewer_checks.py',old/'reviewer_checks_v2.py',old/'run_reviewer_checks.py',old/'run_reviewer_checks_v2.py',old/'SOURCE-BYTE-VERIFICATION.json']
for p in external:retain.retain(str(p),'external')
print(json.dumps({'current_dependency_files':len(paths),'external_files':len(external),'scope':'retention only; scientific review scopes finalized separately'}))
