"""Bounded display of retained evidence; no producer imports or new statistics."""
from pathlib import Path
import json,sys
R=Path(__file__).resolve().parent
rs=json.loads((R/'retained-inputs.json').read_text(encoding='utf-8'))
def path(s):
    hits=[r for r in rs if r['source'].replace('\\','/').endswith(s)]
    if len(hits)!=1:raise ValueError((s,len(hits)))
    return Path(hits[0]['retained_path'])
def read(s):return json.loads(path(s).read_text(encoding='utf-8'))
mode=sys.argv[1]
if mode=='q':
    q=read('/reviewer-checks/summary-arithmetic-attempt2.stdout.json')
    for k,v in q.items():
        if k=='expression':
            for x in v: print(json.dumps(x,ensure_ascii=False))
        else: print(k,json.dumps(v,ensure_ascii=False))
elif mode=='locators':
    j=read('/96812f4f/TD1-SHARED-CURRENT-artifact-locators.json')
    for f in j['files']:
        if 'PARENT-TD1-PATCHES' in f['repo_path'] and '/BEFORE/' not in f['repo_path']:
            print(f['repo_path'],f['local_path'])
elif mode=='routes':
    j=read('research/modalities/census-route-expression-grading.json')
    print('keys',list(j))
    for k in ['RT-TXN-CDK','RT-CHAPERONE']:
        print(k,json.dumps(j['routes'][k],ensure_ascii=False,indent=2))
elif mode=='ekeys':
    j=read('research/modalities/emc-expression-panels.json')
    print('keys',list(j))
    for k,v in j.items():
        print(k, list(v) if isinstance(v,dict) else (len(v) if isinstance(v,list) else str(v)[:1000]))
elif mode=='sources':
    wanted={'25043025','22863008','28429788','9108479','28187285','26406377'}
    for r in rs:
        if 'epmc_' not in r['source'] or r['bytes']<10000:continue
        p=Path(r['retained_path']);t=p.read_text(encoding='utf-8')
        j=json.loads(t[t.index('{'):],strict=False)
        body=j.get('body',j)
        if isinstance(body,str):body=json.loads(body,strict=False)
        print('CONTAINER',p.name,'topkeys',list(j))
        def visit(v,loc='$'):
            if isinstance(v,dict):
                if str(v.get('id','')) in wanted or str(v.get('pmid','')) in wanted:
                    print('RECORD',loc,json.dumps({k:v.get(k) for k in ['id','pmid','doi','title','authorString','pubYear','pubTypeList','abstractText']},ensure_ascii=False))
                    return
                for k,x in v.items():visit(x,loc+'.'+str(k))
            elif isinstance(v,list):
                for i,x in enumerate(v):visit(x,loc+'['+str(i)+']')
        visit(body)
elif mode=='e':
    j=read('research/modalities/emc-expression-panels.json')
    for k,v in j['platforms'].items():
        print('PLATFORM',k,'keys',list(v))
        for x in ['n_samples','samples','background_per_sample','value_kind','n_probes','probe_symbol_mapping']:
            if x in v: print(x,json.dumps(v[x],ensure_ascii=False))
    for g in ['MYC','CDK7','HSP90AA1']:
        v=j['gene_reads'][g]; print('GENE',g,json.dumps(v,ensure_ascii=False))
    for g in ['transcriptional_cdk','chaperone_dependency','instrument_controls']:
        print('PANEL',g,json.dumps(j['panels'][g],ensure_ascii=False))
elif mode=='ebrief':
    j=read('research/modalities/emc-expression-panels.json')
    for k,v in j['platforms'].items():
        print('PLATFORM',k)
        for x in ['class_counts','n_EMC','n_comparator','sample_annotations_verbatim']:
            print(x,json.dumps(v[x],ensure_ascii=False))
    for g in ['transcriptional_cdk','chaperone_dependency']:
        print('PANEL',g,json.dumps(j['panels'][g],ensure_ascii=False))
    print('CONTROLS',json.dumps(j['reads']['control'],ensure_ascii=False))
elif mode=='receipts':
    for r in rs:
        s=r['source'].replace('\\','/')
        if 'checks/' in s and ('TD1-repair' in s or 'PARENT-TD1' in s):
            if r['bytes']<8000:
                print('FILE',s,'RETAINED',Path(r['retained_path']).name)
                print(Path(r['retained_path']).read_text(encoding='utf-8-sig',errors='replace'))
