"""Informational, read-only source/identifier provenance lookup.

Given an identifier (DOI, PMID, PMCID, dataset/registry accession) or a URL, report
whether that identifier already appears in a supplied corpus of retained records, where
it appears (file plus JSON dotted path or line number), what dated statuses those
records carry, and what access evidence those records explicitly report.

What this tool is NOT
---------------------
* It is not an authorization mechanism. It never says a source may be fetched, retried
  or approved; it only quotes retained record text verbatim.
* It is not a scientific or acceptance gate. The CLI exits 0 for every lookup state by
  design, including unresolved and invalid candidates, so it cannot be wired in as a
  pass/fail check without a deliberate, visible change.
* It is not evidence of novelty. Absence from the index means the supplied corpus did
  not contain the identifier. The corpus is always incomplete; every non-match carries
  a mandatory note saying so.
* It performs no network access. Only ``urllib.parse`` (string parsing) is imported from
  urllib; no socket, no ``urllib.request``, no HTTP. Files are opened read-only.
* It never matches on titles. Title/abstract text is excluded from identity matching
  entirely, so no "same paper?" judgement is made from prose similarity.

Standard library only.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
import urllib.parse
from dataclasses import dataclass, field
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

# --------------------------------------------------------------------------------------
# Vocabulary
# --------------------------------------------------------------------------------------

IDENTITY_SCHEMES: Tuple[str, ...] = (
    "doi",
    "pmid",
    "pmcid",
    "geo",
    "arrayexpress",
    "bioproject",
    "sra",
    "ega",
    "nct",
    "eudract",
)

LOOKUP_STATES: Tuple[str, ...] = (
    "matched",
    "matched_prose_mention_only",
    "matched_with_divergent_states",
    "unresolved_not_indexed",
    "unresolved_url_without_identifier",
    "ambiguous_multiple_identifiers",
    "invalid_candidate",
)

ACCESS_LABELS: Tuple[str, ...] = (
    "proxy_or_network_failure",
    "http_403_unclassified_denial",
    "publisher_authentication_or_subscription",
    "policy_or_biology_refusal",
    "full_text_unavailable_in_scope",
    "reported_complete_source_recovered",
    "no_access_attempt_in_this_packet",
    "unclassified_reported_access_evidence",
)

DISCLAIMER = (
    "Informational read-only lookup over the supplied corpus of retained records. "
    "Not an authorization, not a novelty determination, not evidence of source "
    "availability, not scientific validation."
)

NON_MATCH_NOTE = (
    "A non-match is NOT novelty: it means this identifier was not found in the files "
    "enumerated in indexed_scope. The supplied corpus is incomplete by construction."
)

URL_NOTE = (
    "A URL alone never establishes article identity. A URL resolves only through an "
    "identifier embedded in the URL string itself; a newly surfaced URL is not a newly "
    "identified article."
)

TITLE_NOTE = (
    "Titles are excluded from matching entirely. Supply a DOI, PMID, PMCID or accession."
)

DATED_NOTE = (
    "Dated record statuses are reported verbatim in date order. Nothing is merged, "
    "ranked or superseded by this tool; conflicting or dated entries are all retained."
)

TEXT_EXTENSIONS = frozenset({".json", ".md", ".txt"})

# --------------------------------------------------------------------------------------
# Extraction and normalization
# --------------------------------------------------------------------------------------

_TRAILING = ".,;:)]}'\""

_PATTERNS: Tuple[Tuple[str, "re.Pattern[str]"], ...] = (
    ("doi", re.compile(r"10\.\d{4,9}/[A-Za-z0-9._;()/:+\-]+")),
    ("pmid", re.compile(r"PMID\s*:?\s*\d{4,9}\b", re.IGNORECASE)),
    ("pmcid", re.compile(r"\bPMC\d{4,9}\b", re.IGNORECASE)),
    ("geo", re.compile(r"\bG(?:SE|SM|PL)\d{3,9}\b")),
    ("arrayexpress", re.compile(r"\bE-[A-Z]{4}-\d{1,9}\b")),
    ("bioproject", re.compile(r"\bPRJ[A-Z]{2}\d{3,9}\b")),
    ("sra", re.compile(r"\bSR[RXPS]\d{5,12}\b")),
    ("ega", re.compile(r"\bEGA[SD]\d{6,15}\b")),
    ("nct", re.compile(r"\bNCT\d{8}\b")),
    ("eudract", re.compile(r"\b\d{4}-\d{6}-\d{2}\b")),
    ("url", re.compile(r"https?://[^\s\"'<>\]\),]+")),
)

_DOI_FULL = re.compile(r"^10\.\d{4,9}/\S+$")
_PMID_FULL = re.compile(r"^(?:pmid\s*:?\s*)?(\d{4,9})$", re.IGNORECASE)
_PMCID_FULL = re.compile(r"^(?:pmcid\s*:?\s*)?pmc(\d{4,9})$", re.IGNORECASE)
_SHA256 = re.compile(r"^[0-9a-fA-F]{64}$")

_DOI_URL_PREFIXES = (
    "https://doi.org/",
    "http://doi.org/",
    "https://dx.doi.org/",
    "http://dx.doi.org/",
    "https://www.doi.org/",
    "http://www.doi.org/",
)


def normalize_url(raw: str) -> str:
    """Weak, deliberately non-identifying URL key.

    Folds http/https and a leading 'www.', drops the fragment, strips one trailing
    slash, keeps path and query. This can conflate genuinely distinct hosts that differ
    only by 'www.'; that is a documented simplification, and a URL key is never used to
    assert article identity.
    """
    raw = raw.strip().rstrip(_TRAILING)
    parts = urllib.parse.urlsplit(raw)
    host = (parts.hostname or "").lower()
    if host.startswith("www."):
        host = host[4:]
    try:
        port = parts.port
    except ValueError:
        port = None
    suffix = ":%d" % port if port else ""
    path = parts.path.rstrip("/")
    query = "?%s" % parts.query if parts.query else ""
    return "%s%s%s%s" % (host, suffix, path, query)


def normalize_identifier(scheme: str, raw: str) -> str:
    """Normalize one raw identifier string for its scheme. No fuzzy matching anywhere."""
    value = raw.strip().rstrip(_TRAILING)
    if scheme == "doi":
        low = value.lower()
        for prefix in _DOI_URL_PREFIXES:
            if low.startswith(prefix):
                low = low[len(prefix):]
                break
        if low.startswith("doi:"):
            low = low[4:]
        return low.strip().rstrip(_TRAILING)
    if scheme == "pmid":
        return re.sub(r"\D", "", value)
    if scheme == "pmcid":
        return "PMC" + re.sub(r"\D", "", value)
    if scheme == "url":
        return normalize_url(value)
    if scheme == "eudract":
        return value
    return value.upper()


@dataclass(frozen=True)
class Mention:
    scheme: str
    raw: str
    normalized: str
    locator: str
    context: str  # "structured_field" or "prose_context"

    def as_dict(self) -> Dict[str, str]:
        return {
            "scheme": self.scheme,
            "raw": self.raw,
            "normalized": self.normalized,
            "locator": self.locator,
            "context": self.context,
        }


def extract_identifiers(text: str, locator: str = "", context: str = "prose_context") -> List[Mention]:
    """Extract every identifier mention from one string. Order is stable."""
    found: List[Mention] = []
    seen = set()
    for scheme, pattern in _PATTERNS:
        for match in pattern.finditer(text):
            raw = match.group(0).strip().rstrip(_TRAILING)
            if not raw:
                continue
            normalized = normalize_identifier(scheme, raw)
            if not normalized:
                continue
            key = (scheme, normalized, locator)
            if key in seen:
                continue
            seen.add(key)
            found.append(Mention(scheme, raw, normalized, locator, context))
    return found


def parse_candidate(query: str, kind: Optional[str] = None) -> Tuple[Optional[str], str]:
    """Resolve a query string to (scheme, normalized) or (None, reason).

    Bare digits are rejected unless ``kind='pmid'`` is given explicitly, so that a
    stray number cannot be silently treated as a PubMed identifier.
    """
    value = (query or "").strip()
    if not value:
        return None, "empty candidate"

    if kind:
        if kind not in IDENTITY_SCHEMES + ("url",):
            return None, "unknown kind %r" % kind
        if kind == "doi":
            normalized = normalize_identifier("doi", value)
            if _DOI_FULL.match(normalized):
                return "doi", normalized
            return None, "not a syntactically valid DOI"
        if kind == "pmid":
            match = _PMID_FULL.match(value)
            if match:
                return "pmid", match.group(1)
            return None, "not a syntactically valid PMID"
        if kind == "pmcid":
            match = _PMCID_FULL.match(value)
            if match:
                return "pmcid", "PMC" + match.group(1)
            return None, "not a syntactically valid PMCID"
        if kind == "url":
            if "://" not in value:
                return None, "not a syntactically valid URL"
            return "url", normalize_url(value)
        for scheme, pattern in _PATTERNS:
            if scheme != kind:
                continue
            match = pattern.fullmatch(value)
            if match:
                return scheme, normalize_identifier(scheme, value)
        return None, "not a syntactically valid %s" % kind

    doi_candidate = normalize_identifier("doi", value)
    if _DOI_FULL.match(doi_candidate):
        return "doi", doi_candidate
    if value.lower().startswith(("http://", "https://")):
        return "url", normalize_url(value)
    if _PMCID_FULL.match(value):
        return "pmcid", normalize_identifier("pmcid", value)
    if re.match(r"^pmid\s*:?\s*\d{4,9}$", value, re.IGNORECASE):
        return "pmid", re.sub(r"\D", "", value)
    for scheme, pattern in _PATTERNS:
        if scheme in ("doi", "pmid", "pmcid", "url"):
            continue
        if pattern.fullmatch(value):
            return scheme, normalize_identifier(scheme, value)
    if re.match(r"^\d+$", value):
        return None, "bare number: pass --kind pmid to query a PubMed identifier"
    return None, "unrecognised identifier syntax; titles are never matched"


# --------------------------------------------------------------------------------------
# Access-evidence classification (from explicitly reported text only)
# --------------------------------------------------------------------------------------

_ACCESS_TRIGGERS = (
    "access",
    "retriev",
    "request",
    "denial",
    "denied",
    "block",
    "refus",
    "403",
    "forbidden",
    "subscription",
    "full text",
    "full-text",
    "fulltext",
    "egress",
    "proxy",
    "unavailab",
    "paywall",
    "authenticat",
)

_ACCESS_RULES: Tuple[Tuple[str, Tuple[str, ...]], ...] = (
    ("proxy_or_network_failure", ("egress", "proxy", "network failure", "dns", "timeout", "connection refused")),
    ("http_403_unclassified_denial", ("403", "forbidden")),
    ("publisher_authentication_or_subscription", ("subscription", "authenticat", "paywall", "sign-in", "login")),
    ("policy_or_biology_refusal", ("guardrail", "refusal", "refused", "policy restriction", "policy-restricted")),
    ("full_text_unavailable_in_scope", ("not full text", "no full text", "no recovered original full text", "unavailab", "not recovered")),
    ("no_access_attempt_in_this_packet", ("no current access-state test was performed", "no access attempt", "not attempted", "no http request", "no request was made")),
)

_NEGATION_MARKERS = (" not ", "is not", "are not", "never", "none", "no current", "no recovered")


def classify_access_text(text: str) -> List[str]:
    """Multi-label classification of one reported access statement.

    Labels come only from phrases present in the record's own text. Unfamiliar wording
    fails toward 'unclassified_reported_access_evidence' rather than being guessed into
    a category, and distinct categories are never collapsed into one another (an HTTP
    403 is not relabelled as publisher authentication).

    'reported_complete_source_recovered' is never assigned from prose; it comes only
    from the structured retained-bytes signal (see _bytes_signal).
    """
    low = text.lower()
    if not any(trigger in low for trigger in _ACCESS_TRIGGERS):
        return []
    labels: List[str] = []
    for label, phrases in _ACCESS_RULES:
        if any(phrase in low for phrase in phrases):
            labels.append(label)
    if not labels:
        labels.append("unclassified_reported_access_evidence")
    return labels


def _negation_present(text: str) -> bool:
    low = " " + text.lower() + " "
    return any(marker in low for marker in _NEGATION_MARKERS)


def _access_event(record_id: str, locator: str, text: str) -> Optional[Dict[str, object]]:
    labels = classify_access_text(text)
    if not labels:
        return None
    return {
        "record_id": record_id,
        "locator": locator,
        "labels": labels,
        "quote": text,
        "negated_terms_present": _negation_present(text),
    }


# --------------------------------------------------------------------------------------
# Record scanning
# --------------------------------------------------------------------------------------

@dataclass
class Record:
    record_id: str
    path: str
    kind: str
    mentions: List[Mention] = field(default_factory=list)
    groups: List[List[Mention]] = field(default_factory=list)
    access_events: List[Dict[str, object]] = field(default_factory=list)
    statuses: List[Dict[str, str]] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)


def _bytes_signal(node: Dict[str, object]) -> Optional[Dict[str, str]]:
    """Detect an explicitly retained-bytes claim: a URL, a sha256 and an archive member
    recorded together in one object. This is the only source of the
    'reported_complete_source_recovered' label; it reports what the record states and
    does not verify any hash."""
    url = sha = member = None
    for key, value in node.items():
        if not isinstance(value, str):
            continue
        low = key.lower()
        if url is None and value.lower().startswith(("http://", "https://")):
            url = value
        if low == "sha256" or low.endswith("_sha256"):
            if _SHA256.match(value):
                sha = value
        if low in ("archive_member", "archive_members"):
            member = value
    if url and sha and member:
        return {"url": url, "sha256": sha, "archive_member": member}
    return None


def _walk_json(node: object, path: str, record: Record) -> None:
    if isinstance(node, dict):
        group: List[Mention] = []
        for key in sorted(node.keys()):
            value = node[key]
            child = "%s.%s" % (path, key) if path else key
            strings: List[Tuple[str, str]] = []
            if isinstance(value, str):
                strings.append((child, value))
            elif isinstance(value, list):
                for index, item in enumerate(value):
                    if isinstance(item, str):
                        strings.append(("%s[%d]" % (child, index), item))
            for locator, text in strings:
                mentions = extract_identifiers(text, locator, "structured_field")
                record.mentions.extend(mentions)
                group.extend(mentions)
                event = _access_event(record.record_id, locator, text)
                if event is not None:
                    record.access_events.append(event)
        if group:
            record.groups.append(group)
        signal = _bytes_signal(node)
        if signal is not None:
            record.access_events.append({
                "record_id": record.record_id,
                "locator": path or "$",
                "labels": ["reported_complete_source_recovered"],
                "quote": "record reports retained bytes: url=%s sha256=%s archive_member=%s"
                         % (signal["url"], signal["sha256"], signal["archive_member"]),
                "negated_terms_present": False,
                "hash_not_recomputed": True,
            })
        for key in sorted(node.keys()):
            value = node[key]
            child = "%s.%s" % (path, key) if path else key
            if isinstance(value, (dict, list)):
                _walk_json(value, child, record)
    elif isinstance(node, list):
        for index, item in enumerate(node):
            if isinstance(item, (dict, list)):
                _walk_json(item, "%s[%d]" % (path, index), record)


def _collect_statuses(node: object, record: Record) -> None:
    if not isinstance(node, dict):
        return
    date = ""
    for key in ("utc", "date", "recorded_utc", "timestamp"):
        value = node.get(key)
        if isinstance(value, str):
            date = value
            break
    for key in sorted(node.keys()):
        value = node[key]
        if not isinstance(value, str):
            continue
        low = key.lower()
        if low == "status" or low.endswith("_status"):
            record.statuses.append({
                "record_id": record.record_id,
                "date": date,
                "field": key,
                "status": value,
                "locator": key,
            })


def scan_file(path: str, record_id: str) -> Record:
    """Open one file read-only and index it. Never writes, never fetches."""
    extension = os.path.splitext(path)[1].lower()
    record = Record(record_id=record_id, path=path, kind=extension.lstrip("."))
    with open(path, "r", encoding="utf-8", errors="replace") as handle:
        text = handle.read()
    if extension == ".json":
        try:
            data = json.loads(text)
        except ValueError as exc:
            record.notes.append("JSON parse failed (%s); indexed as plain lines." % exc)
        else:
            _walk_json(data, "", record)
            _collect_statuses(data, record)
            return record
    for number, line in enumerate(text.splitlines(), start=1):
        locator = "line:%d" % number
        mentions = extract_identifiers(line, locator, "prose_context")
        record.mentions.extend(mentions)
        if mentions:
            record.groups.append(mentions)
        event = _access_event(record.record_id, locator, line)
        if event is not None:
            record.access_events.append(event)
    return record


def _iter_files(root: str) -> Iterable[Tuple[str, str]]:
    if os.path.isfile(root):
        yield root, os.path.basename(root)
        return
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = sorted(name for name in dirnames if not name.startswith("."))
        for name in sorted(filenames):
            if os.path.splitext(name)[1].lower() in TEXT_EXTENSIONS:
                full = os.path.join(dirpath, name)
                rel = os.path.relpath(full, root).replace(os.sep, "/")
                yield full, rel


@dataclass
class Index:
    roots: List[str]
    records: List[Record] = field(default_factory=list)

    @property
    def files(self) -> List[str]:
        return [record.record_id for record in self.records]

    def scope(self) -> Dict[str, object]:
        return {
            "roots": list(self.roots),
            "files": self.files,
            "file_count": len(self.records),
            "scope_note": (
                "Supplied corpus only: exactly these files were opened read-only. "
                "Records referenced by them but absent here were not inspected."
            ),
        }


def build_index(roots: Sequence[str]) -> Index:
    index = Index(roots=[str(root) for root in roots])
    seen = set()
    for root in index.roots:
        for path, record_id in _iter_files(root):
            key = os.path.abspath(path)
            if key in seen:
                continue
            seen.add(key)
            index.records.append(scan_file(path, record_id))
    index.records.sort(key=lambda record: record.record_id)
    return index


# --------------------------------------------------------------------------------------
# Lookup
# --------------------------------------------------------------------------------------

def _base_result(query: str, scheme: Optional[str], normalized: Optional[str], index: Index) -> Dict[str, object]:
    return {
        "query": query,
        "resolved_scheme": scheme,
        "normalized": normalized,
        "state": "",
        "matches": [],
        "url_key_mentions": [],
        "record_statuses": [],
        "access_evidence": [],
        "conflicts": [],
        "notes": [],
        "indexed_scope": index.scope(),
        "disclaimer": DISCLAIMER,
    }


def _matches_for(index: Index, scheme: str, normalized: str) -> List[Dict[str, str]]:
    matches: List[Dict[str, str]] = []
    for record in index.records:
        for mention in record.mentions:
            if mention.scheme == scheme and mention.normalized == normalized:
                entry = mention.as_dict()
                entry["record_id"] = record.record_id
                matches.append(entry)
    matches.sort(key=lambda entry: (entry["record_id"], entry["locator"]))
    return matches


def _co_identifier_conflicts(index: Index, scheme: str, normalized: str) -> List[Dict[str, object]]:
    partners: Dict[str, Dict[str, List[str]]] = {}
    for record in index.records:
        for group in record.groups:
            if not any(m.scheme == scheme and m.normalized == normalized for m in group):
                continue
            for mention in group:
                if mention.scheme == scheme or mention.scheme not in IDENTITY_SCHEMES:
                    continue
                bucket = partners.setdefault(mention.scheme, {})
                where = bucket.setdefault(mention.normalized, [])
                locator = "%s@%s" % (record.record_id, mention.locator)
                if locator not in where:
                    where.append(locator)
    conflicts: List[Dict[str, object]] = []
    for partner_scheme in sorted(partners):
        values = partners[partner_scheme]
        if len(values) > 1:
            conflicts.append({
                "type": "co_identifier_divergence",
                "query_scheme": scheme,
                "query_normalized": normalized,
                "partner_scheme": partner_scheme,
                "values": sorted(values),
                "provenance": {value: values[value] for value in sorted(values)},
                "note": (
                    "The same %s is bound to differing %s values in the supplied corpus. "
                    "Both bindings are retained; this tool does not adjudicate which is "
                    "correct, and asserts no cross-scheme identity that a record did not "
                    "state." % (scheme.upper(), partner_scheme.upper())
                ),
            })
    return conflicts


def lookup(index: Index, query: str, kind: Optional[str] = None) -> Dict[str, object]:
    """Look one candidate up. Always returns a result dict; never raises for bad input."""
    scheme, resolved = parse_candidate(query, kind)
    if scheme is None:
        result = _base_result(query, None, None, index)
        result["state"] = "invalid_candidate"
        result["reason"] = resolved
        result["notes"] = [NON_MATCH_NOTE, TITLE_NOTE]
        return result

    if scheme == "url":
        result = _base_result(query, "url", resolved, index)
        embedded = [
            mention for mention in extract_identifiers(query, "query", "query_string")
            if mention.scheme in IDENTITY_SCHEMES
        ]
        distinct = sorted({(m.scheme, m.normalized) for m in embedded})
        result["url_key_mentions"] = _matches_for(index, "url", resolved)
        if len(distinct) > 1:
            result["state"] = "ambiguous_multiple_identifiers"
            result["embedded_identifiers"] = [
                {"scheme": item[0], "normalized": item[1]} for item in distinct
            ]
            result["notes"] = [
                URL_NOTE,
                NON_MATCH_NOTE,
                "This URL embeds more than one identifier; it is not resolved to any "
                "single record, and no candidate was chosen arbitrarily.",
            ]
            return result
        if not distinct:
            result["state"] = "unresolved_url_without_identifier"
            result["notes"] = [
                URL_NOTE,
                NON_MATCH_NOTE,
                "This URL carries no embedded DOI/PMID/PMCID/accession, so it cannot "
                "identify an article. Any URL mentions listed under url_key_mentions are "
                "string co-occurrences only.",
            ]
            return result
        inner_scheme, inner_normalized = distinct[0]
        inner = lookup(index, inner_normalized, kind=inner_scheme)
        inner["query"] = query
        inner["resolved_via"] = {
            "url_key": resolved,
            "embedded_scheme": inner_scheme,
            "embedded_normalized": inner_normalized,
        }
        inner["url_key_mentions"] = result["url_key_mentions"]
        inner["notes"] = [URL_NOTE] + list(inner["notes"])
        return inner

    result = _base_result(query, scheme, resolved, index)
    matches = _matches_for(index, scheme, resolved)
    result["matches"] = matches
    if not matches:
        result["state"] = "unresolved_not_indexed"
        result["notes"] = [NON_MATCH_NOTE]
        return result

    matched_ids = sorted({entry["record_id"] for entry in matches})
    statuses: List[Dict[str, str]] = []
    events: List[Dict[str, object]] = []
    for record in index.records:
        if record.record_id not in matched_ids:
            continue
        statuses.extend(record.statuses)
        events.extend(record.access_events)
    statuses.sort(key=lambda entry: (entry["date"], entry["record_id"], entry["field"]))
    events.sort(key=lambda entry: (str(entry["record_id"]), str(entry["locator"])))
    result["record_statuses"] = statuses
    result["access_evidence"] = events

    conflicts = _co_identifier_conflicts(index, scheme, resolved)
    distinct_statuses = {entry["status"] for entry in statuses}
    if len(distinct_statuses) > 1:
        conflicts.append({
            "type": "differing_record_status",
            "statuses": statuses,
            "note": (
                "Records carry differing dated statuses. All are listed in date order and "
                "all are retained; none is superseded, merged or overwritten here. This "
                "flags divergence for human reading and does not assert contradiction."
            ),
        })
    result["conflicts"] = conflicts

    notes = [DATED_NOTE]
    if any(str(event["labels"]) and event.get("negated_terms_present") for event in events):
        notes.append(
            "At least one access statement contains negating wording. Labels record the "
            "categories named in the text, including categories the record explicitly "
            "rules out; read the verbatim quote before drawing any conclusion."
        )
    result["notes"] = notes

    if all(entry["context"] == "prose_context" for entry in matches):
        result["state"] = "matched_prose_mention_only"
        result["notes"].append(
            "Every match is a prose mention, not a structured record field: the corpus "
            "discusses this identifier but no structured record binds it."
        )
    elif conflicts:
        result["state"] = "matched_with_divergent_states"
    else:
        result["state"] = "matched"
    return result


# --------------------------------------------------------------------------------------
# CLI
# --------------------------------------------------------------------------------------

def render_text(result: Dict[str, object]) -> str:
    lines = [
        "query            : %s" % result["query"],
        "resolved_scheme  : %s" % result["resolved_scheme"],
        "normalized       : %s" % result["normalized"],
        "state            : %s" % result["state"],
    ]
    if result.get("reason"):
        lines.append("reason           : %s" % result["reason"])
    for entry in result["matches"]:
        lines.append("match            : %s :: %s [%s] (%s)"
                     % (entry["record_id"], entry["locator"], entry["context"], entry["raw"]))
    for entry in result["url_key_mentions"]:
        lines.append("url_mention      : %s :: %s" % (entry["record_id"], entry["locator"]))
    for entry in result["record_statuses"]:
        lines.append("status           : %s | %s | %s :: %s"
                     % (entry["date"] or "undated", entry["record_id"], entry["field"], entry["status"]))
    for entry in result["access_evidence"]:
        lines.append("access_evidence  : %s :: %s :: %s"
                     % (entry["record_id"], ",".join(entry["labels"]), entry["quote"]))
    for entry in result["conflicts"]:
        lines.append("conflict         : %s :: %s" % (entry["type"], entry["note"]))
    for note in result["notes"]:
        lines.append("note             : %s" % note)
    scope = result["indexed_scope"]
    lines.append("indexed_scope    : %d file(s): %s"
                 % (scope["file_count"], ", ".join(scope["files"])))
    lines.append("disclaimer       : %s" % result["disclaimer"])
    return "\n".join(lines)


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = argparse.ArgumentParser(
        description=(
            "Read-only identifier/source-provenance lookup over retained records. "
            "Informational only: exits 0 for every lookup state, including unresolved "
            "and invalid, so it cannot act as a gate."
        )
    )
    parser.add_argument("query", help="DOI, PMID, PMCID, accession or URL")
    parser.add_argument("--record", action="append", default=None,
                        help="file or directory to index (repeatable; default '.')")
    parser.add_argument("--kind", choices=sorted(IDENTITY_SCHEMES + ("url",)), default=None,
                        help="force the candidate scheme (required for a bare PMID)")
    parser.add_argument("--json", action="store_true", help="emit JSON")
    args = parser.parse_args(list(argv) if argv is not None else None)

    roots = args.record or ["."]
    index = build_index(roots)
    result = lookup(index, args.query, args.kind)
    if args.json:
        print(json.dumps(result, indent=2, sort_keys=True))
    else:
        print(render_text(result))
    return 0  # deliberate: every lookup state exits 0; this tool is not a gate.


if __name__ == "__main__":
    sys.exit(main())
