"""Behavioural tests for the read-only source-reuse index.

All fixtures are SYNTHETIC and labelled: identifiers use reserved namespaces only
(DOI prefix 10.5555/, PMID 999000xx, PMC9990001, host fixture.invalid). No fixture
asserts a real bibliographic fact, and no real source record is copied here.

The tests assert observable behaviour (lookup states, provenance, retained dated
statuses, access-label separation, CLI exit codes). They do not pin internal
structure, wording of prose, or file length.
"""

import contextlib
import io
import json
import os
import shutil
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import source_reuse_index as sri  # noqa: E402


ALPHA_EARLY = {
    "synthetic_fixture": True,
    "utc": "2026-09-01T00:00:00+00:00",
    "status": "open_candidate_potentially_distinct_report",
    "source_identity": {
        "doi": "10.5555/synthetic-alpha.0001",
        "pmid": "PMID 99900001",
    },
    "access_note": "Historical proxy EGRESS_BLOCKED result recorded for this candidate.",
}

ALPHA_LATE = {
    "synthetic_fixture": True,
    "utc": "2026-09-08T00:00:00+00:00",
    "status": "closed_at_deduplication_no_new_source_asset",
    "source_identity": {
        "doi": "10.5555/SYNTHETIC-ALPHA.0001",
        "pmid": "PMID 99900002",
    },
    "access_note": "No current access-state test was performed in this packet.",
}

BETA = {
    "synthetic_fixture": True,
    "utc": "2026-09-07T00:00:00+00:00",
    "status": "admitted_limited_transcribed_source_fields",
    "source": {
        "pmcid": "PMC9990001",
        "doi": "10.5555/synthetic-beta.0002",
        "url": "https://www.fixture.invalid/europepmc/rest/PMC9990001/fullTextXML",
        "sha256": "ab" * 32,
        "archive_member": "synthetic-fixture/primary-source/PMC9990001.xml",
        "locator": "JATS sec13, direct paragraph 1",
    },
    "denial_note": "Three institutional URLs each returned 403 on one direct request; none retried.",
    "subscription_note": "Only subscription full-text link metadata was present; this is not full text.",
    "odd_note": "Access route condition observed but not otherwise described here.",
}

GAMMA_MD = (
    "# Synthetic fixture memo (labelled synthetic)\n"
    "\n"
    "Candidate discussed in prose only: doi:10.5555/synthetic-gamma.0003 (PMID 99900003).\n"
)

DELTA_MD = (
    "# Synthetic fixture memo (labelled synthetic)\n"
    "\n"
    "Resolver lead: https://fixture.invalid/resolve?a=10.5555/synthetic-delta.0004"
    "&b=10.5555/synthetic-delta.0005\n"
    "Bare PDF lead: https://fixture.invalid/journals/impressive-response-longterm-survival.pdf\n"
)

PDF_URL = "https://fixture.invalid/journals/impressive-response-longterm-survival.pdf"


class SourceReuseIndexTest(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.root = tempfile.mkdtemp(prefix="sri-synthetic-fixture-")
        records = os.path.join(cls.root, "records")
        os.makedirs(records)
        for name, payload in (
            ("alpha-2026-09-01.json", ALPHA_EARLY),
            ("alpha-2026-09-08.json", ALPHA_LATE),
            ("beta-recovered.json", BETA),
        ):
            with open(os.path.join(records, name), "w", encoding="utf-8") as handle:
                json.dump(payload, handle, indent=2)
        for name, text in (("gamma-prose.md", GAMMA_MD), ("delta-leads.md", DELTA_MD)):
            with open(os.path.join(records, name), "w", encoding="utf-8") as handle:
                handle.write(text)
        cls.index = sri.build_index([cls.root])

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(cls.root, ignore_errors=True)

    def records_of(self, result):
        return sorted({entry["record_id"] for entry in result["matches"]})

    # 1
    def test_doi_spelling_variants_resolve_identically(self):
        variants = [
            "10.5555/synthetic-alpha.0001",
            "10.5555/SYNTHETIC-ALPHA.0001",
            "doi:10.5555/Synthetic-Alpha.0001",
            "https://doi.org/10.5555/synthetic-alpha.0001",
            "10.5555/synthetic-alpha.0001.",
        ]
        results = [sri.lookup(self.index, variant) for variant in variants]
        for result in results:
            self.assertEqual(result["normalized"], "10.5555/synthetic-alpha.0001")
            self.assertEqual(result["state"], results[0]["state"])
            self.assertEqual(self.records_of(result), self.records_of(results[0]))
        self.assertEqual(len(self.records_of(results[0])), 2)

    # 2
    def test_provenance_is_file_plus_field_or_line_with_context_flag(self):
        structured = sri.lookup(self.index, "10.5555/synthetic-alpha.0001")
        located = [
            entry for entry in structured["matches"]
            if entry["record_id"].endswith("alpha-2026-09-01.json")
        ]
        self.assertEqual(len(located), 1)
        self.assertEqual(located[0]["locator"], "source_identity.doi")
        self.assertEqual(located[0]["context"], "structured_field")

        prose = sri.lookup(self.index, "10.5555/synthetic-gamma.0003")
        self.assertEqual(prose["state"], "matched_prose_mention_only")
        self.assertEqual(len(prose["matches"]), 1)
        self.assertTrue(prose["matches"][0]["record_id"].endswith("gamma-prose.md"))
        self.assertEqual(prose["matches"][0]["locator"], "line:3")
        self.assertEqual(prose["matches"][0]["context"], "prose_context")

    # 3
    def test_pdf_url_without_identifier_is_unresolved_and_never_novelty(self):
        result = sri.lookup(self.index, PDF_URL)
        self.assertEqual(result["state"], "unresolved_url_without_identifier")
        self.assertEqual(result["matches"], [])
        joined = " ".join(result["notes"]).lower()
        self.assertIn("not novelty", joined)
        self.assertIn("url alone never establishes article identity", joined)
        for forbidden in ("new source", "novel article", "not previously known"):
            self.assertNotIn(forbidden, joined)

    # 4
    def test_url_resolves_through_embedded_pmcid_across_scheme_and_www_variants(self):
        query = "http://fixture.invalid/europepmc/rest/PMC9990001/fullTextXML"
        result = sri.lookup(self.index, query)
        self.assertIn(result["state"], ("matched", "matched_with_divergent_states"))
        self.assertEqual(result["resolved_via"]["embedded_scheme"], "pmcid")
        self.assertEqual(result["resolved_via"]["embedded_normalized"], "PMC9990001")
        self.assertEqual(self.records_of(result), ["records/beta-recovered.json"])
        self.assertEqual(
            sri.normalize_url(query),
            sri.normalize_url("https://www.fixture.invalid/europepmc/rest/PMC9990001/fullTextXML#sec1"),
        )

    # 5
    def test_two_dated_statuses_are_both_retained_in_date_order(self):
        result = sri.lookup(self.index, "10.5555/synthetic-alpha.0001")
        self.assertEqual(result["state"], "matched_with_divergent_states")
        dates = [entry["date"] for entry in result["record_statuses"]]
        self.assertEqual(dates, sorted(dates))
        statuses = [entry["status"] for entry in result["record_statuses"]]
        self.assertIn("open_candidate_potentially_distinct_report", statuses)
        self.assertIn("closed_at_deduplication_no_new_source_asset", statuses)
        conflict = [c for c in result["conflicts"] if c["type"] == "differing_record_status"]
        self.assertEqual(len(conflict), 1)
        self.assertIn("none is superseded", conflict[0]["note"])

    # 6
    def test_one_doi_bound_to_two_pmids_is_reported_as_divergence(self):
        result = sri.lookup(self.index, "10.5555/synthetic-alpha.0001")
        conflicts = [c for c in result["conflicts"] if c["type"] == "co_identifier_divergence"]
        self.assertEqual(len(conflicts), 1)
        self.assertEqual(conflicts[0]["partner_scheme"], "pmid")
        self.assertEqual(conflicts[0]["values"], ["99900001", "99900002"])
        self.assertEqual(len(conflicts[0]["provenance"]["99900001"]), 1)

    # 7
    def test_url_embedding_two_dois_is_ambiguous_not_arbitrarily_resolved(self):
        query = ("https://fixture.invalid/resolve?a=10.5555/synthetic-delta.0004"
                 "&b=10.5555/synthetic-delta.0005")
        result = sri.lookup(self.index, query)
        self.assertEqual(result["state"], "ambiguous_multiple_identifiers")
        embedded = sorted(item["normalized"] for item in result["embedded_identifiers"])
        self.assertEqual(embedded, ["10.5555/synthetic-delta.0004", "10.5555/synthetic-delta.0005"])
        self.assertEqual(result["matches"], [])

    # 8
    def test_title_string_is_never_matched(self):
        result = sri.lookup(self.index, "Impressive response and long-term survival in a rare sarcoma")
        self.assertEqual(result["state"], "invalid_candidate")
        self.assertEqual(result["matches"], [])
        joined = " ".join(result["notes"]).lower()
        self.assertIn("titles are excluded from matching entirely", joined)
        self.assertIn("not novelty", joined)

    # 9
    def test_access_categories_stay_distinct_and_unknown_wording_is_unclassified(self):
        result = sri.lookup(self.index, "PMC9990001")
        events = result["access_evidence"]

        denial = [e for e in events if "403" in e["quote"]]
        self.assertEqual(len(denial), 1)
        self.assertIn("http_403_unclassified_denial", denial[0]["labels"])
        self.assertNotIn("publisher_authentication_or_subscription", denial[0]["labels"])
        self.assertNotIn("proxy_or_network_failure", denial[0]["labels"])
        self.assertNotIn("reported_complete_source_recovered", denial[0]["labels"])

        subscription = [e for e in events if "subscription" in e["quote"].lower()]
        self.assertEqual(len(subscription), 1)
        self.assertIn("publisher_authentication_or_subscription", subscription[0]["labels"])
        self.assertIn("full_text_unavailable_in_scope", subscription[0]["labels"])
        self.assertNotIn("http_403_unclassified_denial", subscription[0]["labels"])

        odd = [e for e in events if e["quote"].startswith("Access route condition")]
        self.assertEqual(len(odd), 1)
        self.assertEqual(odd[0]["labels"], ["unclassified_reported_access_evidence"])

        recovered = [e for e in events if "reported_complete_source_recovered" in e["labels"]]
        self.assertEqual(len(recovered), 1)
        self.assertTrue(recovered[0]["hash_not_recomputed"])

        proxy = sri.classify_access_text(ALPHA_EARLY["access_note"])
        self.assertIn("proxy_or_network_failure", proxy)
        self.assertNotIn("http_403_unclassified_denial", proxy)
        self.assertNotIn("policy_or_biology_refusal", proxy)

        no_attempt = sri.classify_access_text(ALPHA_LATE["access_note"])
        self.assertIn("no_access_attempt_in_this_packet", no_attempt)
        self.assertNotIn("full_text_unavailable_in_scope", no_attempt)

        refusal = sri.classify_access_text("Retrieval declined under a biological guardrail refusal.")
        self.assertIn("policy_or_biology_refusal", refusal)
        self.assertNotIn("publisher_authentication_or_subscription", refusal)

    # 10
    def test_cli_exits_zero_for_unresolved_matched_and_invalid(self):
        queries = [
            "10.5555/absent-from-corpus.9999",
            "10.5555/synthetic-alpha.0001",
            "Impressive response and long-term survival in a rare sarcoma",
        ]
        expected = ["unresolved_not_indexed", "matched_with_divergent_states", "invalid_candidate"]
        for query, state in zip(queries, expected):
            buffer = io.StringIO()
            with contextlib.redirect_stdout(buffer):
                code = sri.main([query, "--record", self.root, "--json"])
            self.assertEqual(code, 0, msg=query)
            payload = json.loads(buffer.getvalue())
            self.assertEqual(payload["state"], state, msg=query)
            self.assertIn("not an authorization", payload["disclaimer"])


if __name__ == "__main__":
    unittest.main()
