# Source-reuse index: unchanged draft inputs

This capsule supplies original code and review/execution evidence for a separately owned
cloud repair task. It contains no corrected implementation and grants no scientific or
source-access acceptance.

- `research/tools/source_reuse_index.py` and its test file are the exact admitted LF bodies.
- Original execution: discovery failed before tests; direct invocation ran ten tests,
  with nine passing and one failing. Its first failing loop iteration stops later iterations.
- Both independent comparison diff blocks failed `git apply --check`; neither was applied,
  recounted or repaired. The comparison report also contains proposed, unexecuted test methods.
- `scripts/` contains the committed writer-branch tier files identified in the input manifest.

All capsule member names are relative. Original evidence is retained byte-for-byte and may
mention historical Windows paths; those are provenance, not cloud execution paths. Use the
relative member mappings in `input-manifest.json` to locate the supplied inputs. The capsule
does not supply the whole repository, original source corpus or all independent contract cases.
No new tests or CLI runs were performed while making this capsule.
