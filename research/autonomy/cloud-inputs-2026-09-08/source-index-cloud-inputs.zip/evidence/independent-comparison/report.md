# Independent comparison: recovered source-reuse index vs. frozen contract

Resource `paper:EMC-SOURCE-REUSE-INDEX-COMPARISON-20260908`. Base `2f6a8c603d83006488c3e2d9b1d1dbf1efa44b51`.
Model claude-opus-5, requested effort medium, read-only seat (Read/Glob/Grep only).

**Nothing was executed.** No test run, no import, no CLI invocation, no shell, no network, no hash
recomputation, no file written. Every command below is labelled NOT RUN. Failure behaviour is
derived by reading the delivered source and the frozen JSON records; it is static analysis, not
execution evidence. This is an informational program-tooling review: it is not scientific
validation, not clinical evidence, not source-eligibility adjudication, not a manuscript or paper
admission decision, and it authorizes nothing.

## 0. Inputs actually used and worktree state

Read in this worktree (exhaustive `Glob **/*`, executed): `.git`, `AGENTS.md`, `CLAUDE.md`,
`research/autonomy/OPERATING_PROTOCOL.md`, and five JSON records
(`anthracycline-exposure-gate-2026-09-07/integration.json`, `.../verified-source-extract.json`,
`pazopanib-exposure-gate-2026-09-07/integration.json`,
`sunitinib-primary-recovery-2026-09-07/integration.json`,
`trabectedin-case-deduplication-2026-09-08/integration.json`). `Glob **/*.py` returned no files:
there is no `research/tools/` and no Python in the tree, so the two code blocks are inputs supplied
by the amendment, not repository state. I read the sunitinib, trabectedin, anthracycline
verified-source-extract and pazopanib records in full to test the implementation's rules against
real data; I did not re-read the anthracycline `integration.json`.

The three prose memos cited by the contract report (`clinical-methods-checkpoints-2026-09-07/*.md`,
`peerj-validation-audit-2026-09-07/broader-observational-shortlist.txt`) are **absent from this
worktree**, matching the recovery report's own observation. Contract statements resting on them
(N5 Zenodo, N7 E-MTAB/GSE, ranked-checkpoints POLICY_RESTRICTED wording) are treated here as
unverified quotations from that frozen report, not as facts I checked.

**Delivery-integrity claims confirmed by reading, not by parsing:** both blocks are complete named
files with no stub bodies. The six `Ellipsis` AST nodes are variadic type annotations, exactly as
the admission record states — `IDENTITY_SCHEMES: Tuple[str, ...]`, `LOOKUP_STATES: Tuple[str, ...]`,
`ACCESS_LABELS: Tuple[str, ...]`, `_PATTERNS: Tuple[Tuple[str, "re.Pattern[str]"], ...]`, and two in
`_ACCESS_RULES: Tuple[Tuple[str, Tuple[str, ...]], ...]`. A successful AST parse remains no evidence
of runtime correctness and I draw none from it.

## 1. Material findings

Severity is engineering severity for an informational helper. None of these is a scientific or
publication blocker; none reopens any completed gate.

### F1 (major) — identifier fields carrying a bare value are never indexed → false non-match

*Location:* `source_reuse_index.py`, `_PATTERNS` PMID entry
`("pmid", re.compile(r"PMID\s*:?\s*\d{4,9}\b", re.IGNORECASE))`, consumed by
`extract_identifiers()` and `_walk_json()`.

*Concrete failure:* extraction is purely syntactic, so a PMID is only found when the *value* spells
out `PMID`. Real retained records store it bare under a field name:
`research/autonomy/sunitinib-primary-recovery-2026-09-07/integration.json:7` → `"pmid": "24703573"`,
and `research/autonomy/anthracycline-exposure-gate-2026-09-07/verified-source-extract.json:5` →
`"pmid": "24345066"`. Neither is indexed. A query for `24703573` with `--kind pmid` over
`research/autonomy` returns `state: unresolved_not_indexed` for a source that is demonstrably in the
corpus, with the note "A non-match is NOT novelty" — correct wording attached to a wrong answer.
This is precisely the reuse-blindness the tool was written to prevent, and it also breaks the
contract's N2 collapse rule. The DOI/PMCID cases happen to survive only because their values are
self-describing.

*Minimal repair:* index an identifier carried by the field *name* when the value parses under that
scheme, deduplicating against the syntactic hit. Diff in §3, hunks 5 and 7.

### F2 (major) — access labels assert categories the record explicitly negates

*Location:* `classify_access_text()` / `_ACCESS_RULES`, and `_access_event()`.

*Concrete failure:* classification is whole-string substring matching with no clause scoping.
`research/autonomy/trabectedin-case-deduplication-2026-09-08/integration.json:9` reads: "Historical
proxy EGRESS_BLOCKED results are **not** publisher authentication denials, biological guardrail
refusals or proof of global unavailability. This packet closed under its bounded no-repeat contract;
no current access-state test was performed." Tracing the rules, this one field produces five labels:
`proxy_or_network_failure` (correct, "proxy"/"egress"), `no_access_attempt_in_this_packet` (correct,
exact phrase), plus `publisher_authentication_or_subscription` ("authenticat"),
`policy_or_biology_refusal` ("refusals" contains "refusal") and `full_text_unavailable_in_scope`
("unavailability" contains "unavailab") — the three categories the sentence exists to rule out. The
same defect fires on `sunitinib .../integration.json:16` ("does not prove global source
unavailability" → `full_text_unavailable_in_scope`). `negated_terms_present` becomes `True` in both
cases, so a human reader is warned, but the `labels` list — the machine-readable field, and the very
thing the task asks to keep distinct — is wrong. The recovery report discloses this class of
weakness; the concrete five-label collapse on the motivating record is stated here exactly.

*Minimal repair, deliberately conservative:* do **not** silently drop negated labels (that would
wrongly delete the correct `full_text_unavailable_in_scope` from "this is not full text", sunitinib
:13). Instead attach per-label evidence — matched phrase, containing clause, and whether that clause
negates — and mark labels as mentions rather than assertions. Diff §3 hunks 1–3.

### F3 (major) — orthogonal `*_status` fields are reported as status divergence

*Location:* `lookup()`, `distinct_statuses = {entry["status"] for entry in statuses}` and the
`differing_record_status` conflict.

*Concrete failure:* `_collect_statuses()` harvests every key equal to `status` or ending `_status`.
`research/autonomy/pazopanib-exposure-gate-2026-09-07/integration.json:14–16` carries three
*orthogonal dimensions* — `operational_status: completed_verified`,
`scientific_status: primary_rechecked_...`, `source_asset_status: not_admitted_...`. Because the set
of values has size 3, a lookup matching that single record reports a `differing_record_status`
conflict ("Records carry differing dated statuses... none is superseded") and downgrades the state
to `matched_with_divergent_states`, from one record that contains no disagreement whatsoever. That
manufactures contradiction where the repository asserts none — the opposite of the contract's §4
requirement to carry real conflicts faithfully.

*Minimal repair:* flag divergence only when the *same field name* holds different values. Diff §3
hunk 13. The delivered test 5 still holds, since both alpha fixtures diverge on the field `status`.

### F4 (moderate) — silence is indistinguishable from "no access attempt", and policy exclusion produces no event

*Location:* `classify_access_text()` trigger gate (`if not any(trigger in low ...): return []`), and
`lookup()`, which sets `access_evidence` and never comments when it is empty.

*Concrete failure:* two different situations render identically as `access_evidence: []` — (a) the
record genuinely says nothing about access, (b) the record's wording is outside the phrase list. A
policy/biology exclusion phrased as "restricted reagent work, excluded from retrieval" contains none
of `_ACCESS_TRIGGERS`, so no event is emitted at all: the report is silent, and a reader cannot
distinguish NOT_ATTEMPTED from POLICY_RESTRICTED from "unavailable" — the exact access-state
separation this review is asked to check, and contract AC-16/AC-17. (The repository wording for this
case lives in `ranked-checkpoints.md`, which is absent from this worktree, so I state the code path,
not a verified hit on a real file.)

*Minimal repair:* add restriction/exclusion vocabulary to triggers and to the policy rule, and emit
an explicit note when matched records contributed no recognised access statement. Diff §3 hunks 1,
2, 13.

### F5 (moderate) — `record_id` collision merges evidence across different files

*Location:* `_iter_files()` (`yield root, os.path.basename(root)` for a file root),
`build_index()`, and `lookup()`'s `if record.record_id not in matched_ids`.

*Concrete failure:* records are selected for status/access reporting by *name equality*, not
identity. This repository stores three files literally named `integration.json`
(`pazopanib-...`, `sunitinib-...`, `trabectedin-...`). Invoking
`--record .../pazopanib-.../integration.json --record .../sunitinib-.../integration.json` gives both
records the id `integration.json`; a match in either then pulls in the *other* record's
`record_statuses` and `access_evidence`. Sunitinib's three HTTP-403 events and its
`closed_no_original_full_text_recovered` status would be attributed to a pazopanib match, and
`indexed_scope.files` lists `integration.json` twice with no way to tell them apart. That is a
provenance failure in a provenance tool (contract AC-26).

*Minimal repair:* carry `origin_path` and a positional record index on every match; select by
position; de-duplicate record ids. Diff §3 hunks 10, 12, 13.

### F6 (moderate) — a missing or empty corpus root silently yields `unresolved_not_indexed`

*Location:* `build_index()` / `_iter_files()` (a nonexistent root makes `os.path.isfile` false and
`os.walk` yield nothing), and `Index.scope()`.

*Concrete failure:* `--record research/tools` (a path that does not exist at this base) produces an
empty index and a verdict of `unresolved_not_indexed` with `file_count: 0`, wording identical to a
genuine non-match. A typo'd or moved corpus path therefore reads as "not previously seen" — the
false-novelty hazard again, and the concrete instance the contract raises as AC-24. The same silence
covers extension filtering: `TEXT_EXTENSIONS` skips `.xml`, `.zip`, `.csv`, so
`original-evidence.zip` and `hofvander2026.xml` are dropped from scope with no count reported.

*Minimal repair:* record missing roots and skipped files, and surface `scope_warnings` on every
result. Diff §3 hunks 9, 10, 11, 14.

### F7 (moderate) — `_bytes_signal` infers "source recovered" from key co-occurrence

*Location:* `_bytes_signal()`.

*Concrete failure:* the strongest positive access label, `reported_complete_source_recovered`, is
emitted whenever one object contains *any* string starting `http`, *any* key ending `_sha256` with
64 hex chars, and an `archive_member`. The key names need not be related. A record pairing a landing
page URL with, say, `archive_sha256` (the hash of a zip, not of the member) plus an `archive_member`
would be reported as retained bytes for that URL. On the real anthracycline record the rule happens
to be right (`verified-source-extract.json:8–10`, keys `url`/`sha256`/`archive_member`), and on
sunitinib it correctly stays silent (no http-valued string), but the rule is looser than the claim
it makes. `hash_not_recomputed: True` is present and correct; the *association* is still asserted
from structure alone.

*Minimal repair:* require the URL to come from a key whose name contains `url` and the digest from a
key named exactly `sha256`/`content_sha256`, and state the association basis in the event. Diff §3
hunks 6, 7. The delivered test 9 is unaffected.

### F8 (moderate) — synthetic fixture records are not labelled in output

*Location:* whole output path; no code reads `synthetic_fixture`, and `render_text()` has no marker.

*Concrete failure:* the delivered fixtures set `"synthetic_fixture": True` and the contract requires
(AC-28) that any report line containing a synthetic record render `[SYNTHETIC FIXTURE]`. The
implementation ignores the flag entirely. If a fixture directory is ever indexed alongside real
records — the natural way to smoke-test the CLI — synthetic identifiers appear in output
indistinguishable from real ones. `AGENTS.md` requires synthetic data to be explicitly labelled;
this output does not label it.

*Minimal repair:* detect the flag when scanning, propagate it to matches, and mark both the JSON and
the text rendering. Diff §3 hunks 4, 8, 10, 12, 13, 14.

### F9 (defect in the delivered tests) — test 10 assertion is case-sensitive and cannot pass

*Location:* `test_source_reuse_index.py`, `test_cli_exits_zero_for_unresolved_matched_and_invalid`,
final line `self.assertIn("not an authorization", payload["disclaimer"])`.

*Concrete failure:* `DISCLAIMER` reads "... **N**ot an authorization, not a novelty determination
...". The lowercase substring `not an authorization` does not occur in it, and `assertIn` on `str`
is case-sensitive, so the assertion raises `AssertionError` on the first loop iteration. Note the
contrast with tests 3 and 8, which lowercase via `" ".join(result["notes"]).lower()` first — this one
does not. Read statically, test 10 fails as written; the other nine traced clean against the code in
my reading, but I ran nothing and claim no passes.

*Minimal repair:* `.lower()` the compared value. Diff §4.

## 2. Comparison against the independent contract (agreements and divergences, not defects)

Confirmed by reading (not by execution): **no network capability** — imports are `argparse, json, os,
re, sys, urllib.parse` plus `dataclasses`/`typing`; no `urllib.request`, no `socket`. **No write
path** — the only `open()` is read mode in `scan_file()`. **No boolean authorization key** —
no `retrievable`/`allowed`/`approved` anywhere (contract AC-18 satisfied by inspection). **CLI is not
a gate** — `main()` returns 0 on every path. **No fuzzy matching** — exact normalized equality only,
so AC-05/AC-06-style near-miss accessions cannot cross-match. **Determinism** — records sorted by id,
matches and events sorted, `json.dumps(..., sort_keys=True)`; note event locators sort
lexicographically, so `line:10` precedes `line:2` (stable, just not numeric).

Divergences the coordinator must treat as reduced scope, all disclosed by the producer and none
resolved here: the `matched*`/`unresolved*` vocabulary is not the contract's `KNOWN_*` set and must
be renamed, not assumed equivalent; there is no `admitted_fields` model, so the false-reuse cases
AC-19–AC-22 (`FIELD_NOT_ADMITTED`, carried limitations) are unimplemented; no sha256 recomputation
(`PROVENANCE_UNVERIFIED`, AC-27); no `referenced_origin_missing` (AC-24 — F6 is a partial mitigation
only); no Zenodo concept/version advisory (AC-07 — two version DOIs come back as unrelated with no
`possible_same_deposit` note); no `base_revision` in any output (AC-26); no current-vs-superseded
designation, statuses are listed flat (AC-25 — arguably safer, but not what the contract asks); and
titles are refused outright rather than returned as advisory candidates (N9). Bare digits are
rejected without `--kind pmid`, which satisfies AC-04 but diverges from N2 — and, per F1, does
nothing to fix the indexing side.

## 3. Repair — `research/tools/source_reuse_index.py`

Unified diff against the recovered block (`code_sha256 bc348ce9…`). Hunks are context-matched; the
`@@` line numbers are indicative — apply with `git apply -C3` or `patch -l`. **NOT RUN:** this diff
has not been applied, compiled or executed.

```diff
--- a/research/tools/source_reuse_index.py
+++ b/research/tools/source_reuse_index.py
@@ -246,6 +246,9 @@
     "unavailab",
     "paywall",
     "authenticat",
+    "restrict",
+    "exclud",
+    "permitted",
 )
 
 _ACCESS_RULES: Tuple[Tuple[str, Tuple[str, ...]], ...] = (
@@ -253,7 +256,9 @@
     ("proxy_or_network_failure", ("egress", "proxy", "network failure", "dns", "timeout", "connection refused")),
     ("http_403_unclassified_denial", ("403", "forbidden")),
     ("publisher_authentication_or_subscription", ("subscription", "authenticat", "paywall", "sign-in", "login")),
-    ("policy_or_biology_refusal", ("guardrail", "refusal", "refused", "policy restriction", "policy-restricted")),
+    ("policy_or_biology_refusal", ("guardrail", "refusal", "refused", "policy restriction",
+                                   "policy-restricted", "restricted", "restriction",
+                                   "excluded from retrieval", "not permitted")),
     ("full_text_unavailable_in_scope", ("not full text", "no full text", "no recovered original full text", "unavailab", "not recovered")),
     ("no_access_attempt_in_this_packet", ("no current access-state test was performed", "no access attempt", "not attempted", "no http request", "no request was made")),
 )
@@ -268,6 +273,10 @@
     Labels come only from phrases present in the record's own text. Unfamiliar wording
     fails toward 'unclassified_reported_access_evidence' rather than being guessed into
     a category, and distinct categories are never collapsed into one another (an HTTP
     403 is not relabelled as publisher authentication).
+
+    A label means the category is NAMED in the text, including when the text names it
+    only in order to rule it out. Read label_evidence[label]['clause'] and
+    ['clause_is_negating'] on the event before consuming a label programmatically.
 
     'reported_complete_source_recovered' is never assigned from prose; it comes only
     from the structured retained-bytes signal (see _bytes_signal).
@@ -290,6 +299,34 @@
 def _negation_present(text: str) -> bool:
     low = " " + text.lower() + " "
     return any(marker in low for marker in _NEGATION_MARKERS)
 
 
+def _clauses(text: str) -> List[str]:
+    """Split one statement into clauses so a label can be tied to the clause that
+    produced it. Deliberately crude: sentence/semicolon boundaries only."""
+    parts = [clause for clause in re.split(r"(?<=[.;:])\s+|\n", text) if clause.strip()]
+    return parts or [text]
+
+
+def access_label_evidence(text: str) -> Dict[str, Dict[str, object]]:
+    """For each label, the matched phrase, the clause containing it, and whether that
+    clause is negating.
+
+    This exists because whole-string matching cannot tell "the source is behind
+    publisher authentication" from "these results are NOT publisher authentication
+    denials". Negated labels are retained rather than dropped -- dropping them would
+    also delete correct labels whose phrase is itself negative ("this is not full
+    text") -- but they are no longer indistinguishable from asserted ones.
+    """
+    evidence: Dict[str, Dict[str, object]] = {}
+    clauses = _clauses(text)
+    for label, phrases in _ACCESS_RULES:
+        for phrase in phrases:
+            for clause in clauses:
+                if phrase in clause.lower():
+                    evidence[label] = {
+                        "matched_phrase": phrase,
+                        "clause": clause.strip(),
+                        "clause_is_negating": _negation_present(clause),
+                    }
+                    break
+            if label in evidence:
+                break
+    return evidence
+
+
 def _access_event(record_id: str, locator: str, text: str) -> Optional[Dict[str, object]]:
     labels = classify_access_text(text)
     if not labels:
         return None
     return {
         "record_id": record_id,
         "locator": locator,
         "labels": labels,
+        "labels_are_mentions_not_assertions": True,
+        "label_evidence": access_label_evidence(text),
         "quote": text,
         "negated_terms_present": _negation_present(text),
     }
@@ -330,6 +367,7 @@
 @dataclass
 class Record:
     record_id: str
     path: str
     kind: str
+    synthetic: bool = False
     mentions: List[Mention] = field(default_factory=list)
     groups: List[List[Mention]] = field(default_factory=list)
     access_events: List[Dict[str, object]] = field(default_factory=list)
     statuses: List[Dict[str, str]] = field(default_factory=list)
     notes: List[str] = field(default_factory=list)
 
 
+_KEYED_SCHEMES: Dict[str, str] = {
+    "doi": "doi", "dois": "doi", "article_doi": "doi", "source_doi": "doi",
+    "pmid": "pmid", "pmids": "pmid", "pubmed_id": "pmid",
+    "pmcid": "pmcid", "pmc_id": "pmcid",
+    "nct": "nct", "nct_id": "nct",
+    "eudract": "eudract", "eudract_number": "eudract",
+    "geo": "geo", "geo_accession": "geo",
+    "arrayexpress": "arrayexpress", "arrayexpress_accession": "arrayexpress",
+    "bioproject": "bioproject", "sra": "sra", "ega": "ega",
+}
+
+
+def _keyed_mentions(key: str, text: str, locator: str,
+                    already: Sequence[Mention]) -> List[Mention]:
+    """Index an identifier carried by the FIELD NAME rather than by self-describing
+    syntax, e.g. {"pmid": "24703573"}.
+
+    Without this, a bare-value PMID stored in a retained record is never indexed and a
+    genuine reuse is reported as unresolved_not_indexed -- a false non-match, which is
+    the failure mode this tool exists to prevent.
+    """
+    scheme = _KEYED_SCHEMES.get(key.strip().lower())
+    if scheme is None:
+        return []
+    resolved_scheme, resolved = parse_candidate(text, kind=scheme)
+    if resolved_scheme is None:
+        return []
+    if any(m.scheme == resolved_scheme and m.normalized == resolved for m in already):
+        return []
+    return [Mention(resolved_scheme, text.strip(), resolved, locator, "structured_field")]
+
+
 def _bytes_signal(node: Dict[str, object]) -> Optional[Dict[str, str]]:
     """Detect an explicitly retained-bytes claim: a URL, a sha256 and an archive member
     recorded together in one object. This is the only source of the
     'reported_complete_source_recovered' label; it reports what the record states and
     does not verify any hash."""
     url = sha = member = None
     for key, value in node.items():
         if not isinstance(value, str):
             continue
         low = key.lower()
-        if url is None and value.lower().startswith(("http://", "https://")):
+        if url is None and "url" in low and value.lower().startswith(("http://", "https://")):
             url = value
-        if low == "sha256" or low.endswith("_sha256"):
-            if _SHA256.match(value):
-                sha = value
+        if low in ("sha256", "content_sha256") and _SHA256.match(value):
+            sha = value
         if low in ("archive_member", "archive_members"):
             member = value
     if url and sha and member:
         return {"url": url, "sha256": sha, "archive_member": member}
     return None
@@ -381,10 +463,12 @@
             for locator, text in strings:
                 mentions = extract_identifiers(text, locator, "structured_field")
+                mentions.extend(_keyed_mentions(key, text, locator, mentions))
                 record.mentions.extend(mentions)
                 group.extend(mentions)
                 event = _access_event(record.record_id, locator, text)
                 if event is not None:
                     record.access_events.append(event)
@@ -396,6 +480,8 @@
                 "quote": "record reports retained bytes: url=%s sha256=%s archive_member=%s"
                          % (signal["url"], signal["sha256"], signal["archive_member"]),
                 "negated_terms_present": False,
                 "hash_not_recomputed": True,
+                "association_basis": ("url/sha256/archive_member co-located in one record "
+                                      "object; the record's own structure is the only basis"),
             })
@@ -440,6 +526,13 @@
 def scan_file(path: str, record_id: str) -> Record:
     """Open one file read-only and index it. Never writes, never fetches."""
     extension = os.path.splitext(path)[1].lower()
     record = Record(record_id=record_id, path=path, kind=extension.lstrip("."))
     with open(path, "r", encoding="utf-8", errors="replace") as handle:
         text = handle.read()
+    head = "\n".join(text.splitlines()[:5]).lower()
+    if "synthetic fixture" in head:
+        record.synthetic = True
     if extension == ".json":
         try:
             data = json.loads(text)
         except ValueError as exc:
             record.notes.append("JSON parse failed (%s); indexed as plain lines." % exc)
         else:
+            if isinstance(data, dict) and (data.get("synthetic_fixture") or data.get("synthetic")):
+                record.synthetic = True
             _walk_json(data, "", record)
             _collect_statuses(data, record)
             return record
@@ -466,15 +559,23 @@
-def _iter_files(root: str) -> Iterable[Tuple[str, str]]:
+def _iter_files(root: str, skipped: Optional[List[str]] = None) -> Iterable[Tuple[str, str]]:
     if os.path.isfile(root):
         yield root, os.path.basename(root)
         return
     for dirpath, dirnames, filenames in os.walk(root):
         dirnames[:] = sorted(name for name in dirnames if not name.startswith("."))
         for name in sorted(filenames):
             if os.path.splitext(name)[1].lower() in TEXT_EXTENSIONS:
                 full = os.path.join(dirpath, name)
                 rel = os.path.relpath(full, root).replace(os.sep, "/")
                 yield full, rel
+            elif skipped is not None:
+                skipped.append(
+                    os.path.relpath(os.path.join(dirpath, name), root).replace(os.sep, "/"))
 
 
 @dataclass
 class Index:
     roots: List[str]
     records: List[Record] = field(default_factory=list)
+    missing_roots: List[str] = field(default_factory=list)
+    skipped_files: List[str] = field(default_factory=list)
 
     @property
     def files(self) -> List[str]:
         return [record.record_id for record in self.records]
 
     def scope(self) -> Dict[str, object]:
         return {
             "roots": list(self.roots),
+            "missing_roots": list(self.missing_roots),
             "files": self.files,
             "file_count": len(self.records),
+            "skipped_unindexed_files": list(self.skipped_files),
             "scope_note": (
                 "Supplied corpus only: exactly these files were opened read-only. "
                 "Records referenced by them but absent here were not inspected."
             ),
         }
 
 
 def build_index(roots: Sequence[str]) -> Index:
     index = Index(roots=[str(root) for root in roots])
     seen = set()
+    used_ids: Dict[str, int] = {}
     for root in index.roots:
-        for path, record_id in _iter_files(root):
+        if not os.path.exists(root):
+            index.missing_roots.append(root)
+            continue
+        for path, record_id in _iter_files(root, index.skipped_files):
             key = os.path.abspath(path)
             if key in seen:
                 continue
             seen.add(key)
+            if record_id in used_ids:
+                used_ids[record_id] += 1
+                record_id = "%s#%d" % (record_id, used_ids[record_id])
+            else:
+                used_ids[record_id] = 0
             index.records.append(scan_file(path, record_id))
     index.records.sort(key=lambda record: record.record_id)
     return index
 
 
+def _scope_warnings(index: Index) -> List[str]:
+    """Never let an empty or partial corpus look like a considered non-match."""
+    warnings: List[str] = []
+    if index.missing_roots:
+        warnings.append(
+            "Requested corpus root(s) do not exist and were not read: %s. A non-match "
+            "here reflects a missing corpus, not absence of the source."
+            % ", ".join(index.missing_roots))
+    if not index.records:
+        warnings.append(
+            "No file was indexed. Every lookup against this empty index is "
+            "uninformative and must not be read as a non-match.")
+    if index.skipped_files:
+        warnings.append(
+            "%d file(s) were not indexed because their extension is outside %s: %s"
+            % (len(index.skipped_files), sorted(TEXT_EXTENSIONS),
+               ", ".join(index.skipped_files[:20])))
+    return warnings
+
+
 # ----------------------------------------------------------------------------
 # Lookup
 # ----------------------------------------------------------------------------
 
 def _base_result(query: str, scheme: Optional[str], normalized: Optional[str], index: Index) -> Dict[str, object]:
     return {
         "query": query,
         "resolved_scheme": scheme,
         "normalized": normalized,
         "state": "",
         "matches": [],
         "url_key_mentions": [],
         "record_statuses": [],
         "access_evidence": [],
         "conflicts": [],
         "notes": [],
+        "scope_warnings": _scope_warnings(index),
+        "contains_synthetic_fixture_records": False,
         "indexed_scope": index.scope(),
         "disclaimer": DISCLAIMER,
     }
 
 
 def _matches_for(index: Index, scheme: str, normalized: str) -> List[Dict[str, str]]:
     matches: List[Dict[str, str]] = []
-    for record in index.records:
+    for position, record in enumerate(index.records):
         for mention in record.mentions:
             if mention.scheme == scheme and mention.normalized == normalized:
                 entry = mention.as_dict()
                 entry["record_id"] = record.record_id
+                entry["origin_path"] = record.path
+                entry["record_index"] = str(position)
+                entry["synthetic_fixture"] = "true" if record.synthetic else "false"
                 matches.append(entry)
-    matches.sort(key=lambda entry: (entry["record_id"], entry["locator"]))
+    matches.sort(key=lambda entry: (entry["record_id"], entry["origin_path"], entry["locator"]))
     return matches
@@ -600,18 +727,24 @@
-    matched_ids = sorted({entry["record_id"] for entry in matches})
+    matched_positions = {int(entry["record_index"]) for entry in matches}
     statuses: List[Dict[str, str]] = []
     events: List[Dict[str, object]] = []
-    for record in index.records:
-        if record.record_id not in matched_ids:
+    synthetic_hit = False
+    for position, record in enumerate(index.records):
+        if position not in matched_positions:
             continue
+        synthetic_hit = synthetic_hit or record.synthetic
         statuses.extend(record.statuses)
         events.extend(record.access_events)
     statuses.sort(key=lambda entry: (entry["date"], entry["record_id"], entry["field"]))
     events.sort(key=lambda entry: (str(entry["record_id"]), str(entry["locator"])))
     result["record_statuses"] = statuses
     result["access_evidence"] = events
+    result["contains_synthetic_fixture_records"] = synthetic_hit
 
     conflicts = _co_identifier_conflicts(index, scheme, resolved)
-    distinct_statuses = {entry["status"] for entry in statuses}
-    if len(distinct_statuses) > 1:
+    by_field: Dict[str, set] = {}
+    for entry in statuses:
+        by_field.setdefault(entry["field"], set()).add(entry["status"])
+    divergent_fields = sorted(name for name, values in by_field.items() if len(values) > 1)
+    if divergent_fields:
         conflicts.append({
             "type": "differing_record_status",
+            "divergent_fields": divergent_fields,
             "statuses": statuses,
             "note": (
                 "Records carry differing dated statuses. All are listed in date order and "
                 "all are retained; none is superseded, merged or overwritten here. This "
                 "flags divergence for human reading and does not assert contradiction."
             ),
         })
     result["conflicts"] = conflicts
 
     notes = [DATED_NOTE]
-    if any(str(event["labels"]) and event.get("negated_terms_present") for event in events):
+    if not events:
+        notes.append(
+            "No access statement was recognised in the matched record(s). This is 'no "
+            "access evidence recorded' -- not a completed attempt, not a denial, and not "
+            "evidence that the source is or is not available.")
+    if synthetic_hit:
+        notes.append(
+            "[SYNTHETIC FIXTURE] At least one matched record is labelled a synthetic "
+            "fixture. It is not evidence about any real source.")
+    if any(event.get("negated_terms_present")
+           or any(item.get("clause_is_negating")
+                  for item in event.get("label_evidence", {}).values())
+           for event in events):
         notes.append(
             "At least one access statement contains negating wording. Labels record the "
             "categories named in the text, including categories the record explicitly "
             "rules out; read the verbatim quote before drawing any conclusion."
         )
@@ -650,10 +793,17 @@
     if result.get("reason"):
         lines.append("reason           : %s" % result["reason"])
+    if result.get("contains_synthetic_fixture_records"):
+        lines.append("[SYNTHETIC FIXTURE] : at least one matched record is a labelled "
+                     "synthetic fixture and is not evidence about any real source.")
     for entry in result["matches"]:
-        lines.append("match            : %s :: %s [%s] (%s)"
-                     % (entry["record_id"], entry["locator"], entry["context"], entry["raw"]))
+        lines.append("match            : %s%s :: %s [%s] (%s)"
+                     % ("[SYNTHETIC FIXTURE] " if entry.get("synthetic_fixture") == "true" else "",
+                        entry["record_id"], entry["locator"], entry["context"], entry["raw"]))
@@ -668,6 +818,8 @@
     scope = result["indexed_scope"]
     lines.append("indexed_scope    : %d file(s): %s"
                  % (scope["file_count"], ", ".join(scope["files"])))
+    for warning in result.get("scope_warnings", []):
+        lines.append("scope_warning    : %s" % warning)
     lines.append("disclaimer       : %s" % result["disclaimer"])
     return "\n".join(lines)
```

## 4. Repair — `research/tools/tests/test_source_reuse_index.py`

```diff
--- a/research/tools/tests/test_source_reuse_index.py
+++ b/research/tools/tests/test_source_reuse_index.py
@@ -258,7 +258,7 @@
             self.assertEqual(code, 0, msg=query)
             payload = json.loads(buffer.getvalue())
             self.assertEqual(payload["state"], state, msg=query)
-            self.assertIn("not an authorization", payload["disclaimer"])
+            self.assertIn("not an authorization", payload["disclaimer"].lower())
```

Optional additional coverage for F1 and F3 — two behavioural tests that would have caught them.
Append inside `SourceReuseIndexTest`; they need one extra synthetic fixture written in `setUpClass`
(a JSON record with `{"synthetic_fixture": true, "utc": "...", "source": {"pmid": "99900004",
"doi": "10.5555/synthetic-epsilon.0006"}, "operational_status": "completed", "scientific_status":
"not_admitted"}`, saved as `records/epsilon-keyed.json`). **NOT RUN.**

```python
    # 11
    def test_bare_value_identifier_field_is_indexed(self):
        result = sri.lookup(self.index, "99900004", kind="pmid")
        self.assertNotEqual(result["state"], "unresolved_not_indexed")
        self.assertTrue(any(entry["record_id"].endswith("epsilon-keyed.json")
                            for entry in result["matches"]))

    # 12
    def test_orthogonal_status_fields_are_not_reported_as_divergence(self):
        result = sri.lookup(self.index, "10.5555/synthetic-epsilon.0006")
        self.assertEqual(
            [c for c in result["conflicts"] if c["type"] == "differing_record_status"], [])
        self.assertTrue(result["contains_synthetic_fixture_records"])
```

## 5. Proposed verification — all NOT RUN

Nothing here was executed by this seat; expected outcomes are inference from reading the code.

```
NOT RUN  python -m unittest discover -s research/tools/tests -t research/tools -p "test_*.py" -v
NOT RUN  python -c "import ast,sys; ast.parse(open('research/tools/source_reuse_index.py').read())"
NOT RUN  python research/tools/source_reuse_index.py 24703573 --kind pmid --record research/autonomy --json
NOT RUN  python research/tools/source_reuse_index.py 10.4172/clinical-practice.1000433 --record research/autonomy --json
NOT RUN  python research/tools/source_reuse_index.py https://example.invalid/some-article.pdf --record research/autonomy
NOT RUN  python research/tools/source_reuse_index.py 10.5281/zenodo.17866629 --record research/does-not-exist --json
```

The third command is the F1 regression check (pre-repair: `unresolved_not_indexed` for a PMID that is
present at `sunitinib-primary-recovery-2026-09-07/integration.json:7`; post-repair: a match). The
fourth exercises F2 and F3 against the trabectedin and pazopanib records. The last exercises F6.

## 6. Limitations and negative findings

- **No execution of any kind.** No test result, exit code, import, timing or coverage is reported or
  implied. The separate executor's results are not available to me and I assert nothing about them.
  My repairs are unverified drafts; the diffs have not been applied or compiled.
- **Correctness is not inferred from AST parsing.** The delivery check's `ast_parse: passed` and the
  six Ellipsis nodes are mechanical facts only; I re-derived the Ellipsis explanation by reading the
  annotations, and it agrees with the admission record.
- **Trace-based failure claims.** F1–F8 are read from the source against JSON records I read in this
  worktree. They are deterministic string/control-flow consequences, but they are analysis, not
  observed output.
- **Coverage of my own review is partial.** I traced all ten delivered tests and the main code paths;
  I did not exhaustively enumerate regex interactions (e.g. the EudraCT pattern `\d{4}-\d{6}-\d{2}`
  against arbitrary numeric text), nor `render_text` on every state, nor Windows path-separator
  behaviour in `record_id` construction for file roots.
- **Fixture counts are not acceptance criteria** and I propose none. The two extra tests in §4 are
  optional coverage for two of my findings, not a required count.
- **All fixtures in the delivered tests are synthetic and labelled** (reserved DOI prefix `10.5555/`,
  PMID `999000xx`, `fixture.invalid`); F8 concerns the tool's failure to *carry that label into its
  output*, not any mislabelling in the fixtures themselves.
- **Absent inputs.** The three prose memos, `research/literature/emc-trabectedin-denominator-2026-09-01.json`,
  every `original-evidence.zip`, `hofvander2026.xml` and `published-call-comparison.json` are not in
  this worktree. No archive hash was recomputed and none could be. Identifiers attributed to those
  files by either frozen report are unverified here.
- **Contract conformance is not established.** The implementation is a reduced-scope helper; the
  unimplemented contract cases listed in §2 remain unimplemented after my repairs, which deliberately
  do not add the `admitted_fields` model, hash verification, Zenodo advisories or `base_revision`.
- **Scope of this checkpoint.** No network access, no source recovery, no restricted-reagent work, no
  manuscript or paper review, no shared-file edit, no commit, no changed scientific criterion, no
  agent spawned, no follow-on task. This tool and this review are informational; neither is an
  authorization, a scientific admission, evidence of source availability, or a manuscript gate.