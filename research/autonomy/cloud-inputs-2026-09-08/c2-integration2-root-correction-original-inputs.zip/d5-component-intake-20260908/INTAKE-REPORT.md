# C2 and P-AB2 returned-original intake

This is a bounded mechanical intake of completed return `d5eb86e8093df671da081ea56b67dcfd79e1f0fe`, not a new scientific review or a test run. Original programs were read but never imported or executed. No source cache was queried, no Git operation was needed, no producer or builder ran, and no repository file changed. Endpoint status stays parked. Scientific interpretation and acceptance remain with root.

All paths below beginning `C2/` resolve under:
`C:/Users/mcrae/.codex/review-workspaces/opus-capacity-sprint-20260907/capacity-campaign-20260908/observations/d5eb86e8/CORRECTED-C-arm-attribution-v2/`.

All paths beginning `PAB2/` resolve under the sibling `P-AB2-unicode-offsets/`. `repo/` resolves under this observation's `research/manuscripts/`.

## Identity and boundaries

All **69** scoped inventory entries match their declared bytes and SHA256, and Git blob identity wherever declared: 49 C2 originals, 16 P-AB2 originals, two returned repository code files, index and receipt. The two returned root-reviewer originals also match the original files under `work/pab-root-bounded-verification/` byte for byte. All nine current C2 entries in `SHA256-v2-artifacts.txt` match. The six v1 references in that manifest were explicitly not re-audited or fetched.

| Original | Bytes | SHA256 |
|---|---:|---|
| `TD1-C2-PAB2-artifact-locators.json` | 54,595 | `d35c4e710aecc2db32e8cf917d57e019f72a0cd4ca318c39638d329fe6ed9d80` |
| `C2/CONTRACT-CORRECTED-C-arm-attribution-v2.md` | 9,460 | `cef10a2042a7f39ade213c89f02c53c40ea9fa0f95f5c66cf3a8bca5c09e42b0` |
| `PAB2/REPAIR-P-AB2-unicode-offsets.md` | 11,263 | `63a49d1c0807e221e7a38b54ff85255d744c2ae66915f91fba4e875f86c7d2e5` |
| `repo/claim_coverage.py` | 64,861 | `094a20684fc7db99ad383f60e032a48c3ca853d65d5686c414ea6ae67b6462af` |
| `repo/tests/test_the_census_credits_only_executable_references.py` | 12,316 | `6658d345662541c47047be1adacdebecab6bf0b6629bca34b3e49f3202c88d0d` |

The complete absolute-path/hash/blob inventory, exact patch hunk boundaries, saved commands/exits, and focused row comparisons are in `artifact-intake.json` beside this report. TD1 source contents were outside this task and were not inspected.

## C2: verified delivered behavior and discrepancies

The new versioned sibling contains three programs (derive, focused value tests, change-map), map/checks/schema, contract/change-map narrative, manifest and eight run directories. Existing v1/job3/leaf files are inputs by path; their historical assertions were not independently validated here.

Read the actual `C2/CORRECTED-C-arm-attribution-v2-derive.py`:

- Lines 146–182 build exact/case-whitespace label and description candidate lists and require a unique candidate. Lines 188–226 inspect the leaf's claimed label, including both `;` and `|` separators; narrative content is not a decision input.
- Lines 258–283 make conflicting unique label/description identities contested, and reserve `SOURCE_CONFIRMED` for two agreeing field identities or unique description identity alone. Lines 285–290 retain a lone label correspondence as `LABEL_MATCH`. These are equality-based cached-field states; the change-map explicitly says at lines 120–121 that they are **not** a registry assertion of group-arm identity or clinical validation. This intake did not establish the source evidence itself.
- Lines 292–327 retain ambiguity, unverified leaf proposals and their locators, and a contested absent leaf label. Lines 343–348 downgrade on the bound arm's own contrary description.
- Lines 368–435 separate registry type from comparator role; conditional registered-arm-set statements explicitly name unproved membership. Label-only type statements name the identity assumption. EXPERIMENTAL/OTHER does not yield a `NOT_CONTROL` role.

The delivered map and change-map each have **552 unique identical keys**. All 9,384 mapped field comparisons agree, as do the seven grouped count objects in checks JSON. State counts are **58 SOURCE_CONFIRMED, 132 LABEL_MATCH, 337 PROPOSED, 11 UNRESOLVED, 1 CONTESTED and 13 UNKNOWN**. All 333 conditional type rows carry a membership assumption. Comparator roles count 8 supported, 19 proposed, 4 contested, 166 not established and 355 unknown. The v1 narrative-token index has 314 rows: 313 now proposed and one description-identity confirmation. These are delivered table facts, not a source re-audit.

Discrepancies and narrowly bounded static limitations:

1. **Wrong named machine summary:** `C2/CORRECTED-C-arm-attribution-v2-checks.json:156` has `not_source_confirmed_rows: 362`. The correct complement is **494**, as stated in `CHANGE-MAP-v1-to-v2.md:62` and the change-map stdout. Derive lines 683–696 omit the 132 `LABEL_MATCH` rows from that named summary. All 18 saved checks pass despite this error.
2. **Contrary-description branch versus binding schema:** derive lines 343–348 change state to `CONTESTED` but retain `bound_arm_index`. Schema line 24 and the producer's check at lines 635–638 require a nonempty binding only for `SOURCE_CONFIRMED`/`LABEL_MATCH`. Focused test `t2a` (tests lines 66–73) checks the downgrade but not this binding invariant. This is a static edge-path inconsistency; no delivered row exercises it, and no new fixture was run.
3. **Zero-arm role branch ordering:** link logic returns unknown for zero arms, but comparator group-text proposal branches at derive lines 421–429 precede the zero-arm unknown branch at 430–432. Thus the general “zero arms stays UNKNOWN” assertion is broader than the code for zero arms plus comparator wording. The six delivered zero-arm rows remain unknown; existing `t4d` uses neutral text. No new scenario was run.
4. **“Verbatim” is an overstatement:** derive line 455 replaces newlines and takes the first 400 characters of leaf narrative; TSV writing at 596 also normalizes tabs/newlines. Schema line 36 and narrative call it verbatim. No delivered narrative is at the 400-character cap, so this intake does not claim an observed truncation; the transformation remains real. `group_description` is also capped, openly documented by schema line 44.
5. **Payload-count wording:** derive lines 83–85 define five BOR plus five placebo payload names, while the saved check detail at JSON line 111 says “12 payloads.” The loop at derive 674–681 iterates those ten names. The reported zero-occurrence source result was not rechecked; the number-of-payloads description is inconsistent with the actual loop.

The row-level contested and repaired multiarm locators are preserved in `artifact-intake.json`, including NCT04020185, NCT04387071 and the retained NCT02566993 composed-label contest. Source-field equality semantics, inherited disease/phase selection, and the underlying absence of explicit join fields remain outside this mechanical acceptance.

## Original C2 execution evidence, not reruns

Exact commands are in each `C2/CHECKS-RUNS/<directory>/cmd.txt`; all saved stderr files are empty. Tests use `python3 CORRECTED-C-arm-attribution-v2-tests.py`; derive uses `python3 CORRECTED-C-arm-attribution-v2-derive.py CORRECTED-C-arm-attribution-v2-map.tsv CORRECTED-C-arm-attribution-v2-checks.json`; change-map uses `python3 CORRECTED-C-arm-attribution-v2-changemap.py`.

| Directory | Saved exit/output |
|---|---|
| `RUN-01-tests-20260908T205949Z` | Exit 0; 15 PASS |
| `RUN-02-derive-20260908T205956Z` | Exit 1; 17 checks, narrative guard FAIL, suspect_lines=1; NOTE retains regex self-match diagnosis |
| `RUN-03-derive-20260908T210035Z` | Exit 1; same guard FAIL, suspect_lines=0; NOTE retains self-referential CORROBORATION literal diagnosis |
| `RUN-04-derive-20260908T210104Z` | Exit 0; 17 PASS, explicitly superseded; NOTE identifies nine multiarm rows misread by the semicolon-only splitter |
| `RUN-05-tests-20260908T210152Z` | Exit 0; 16 PASS after T3d |
| `RUN-06-derive-20260908T210209Z` | Exit 0; 18 PASS, final counts |
| `RUN-07-changemap-20260908T210247Z` | Exit 0; 58 confirmed / 494 not |
| `RUN-08-final-settled-tree-20260908T210534Z` | Exits 0/0/0; 16 tests, 18 checks; exit receipt records identical before/after map SHA `bd3d6085c0b6816dc847633db127fc27bf1d1e2ceeacd559a110387ca5065484` |

RUN-08's command record substitutes literal `<map> <checks>` placeholders; it is not a fully expanded shell transcript. Current map bytes match its stated hash. The return preserves the failed/superseded stdout and exits, but does not include a separate producer source snapshot and full map file for every historical attempt; do not infer their code identities from the final producer hash. In particular RUN-04's note explicitly says its outputs were replaced.

## P-AB2: exact patch scope and preserved failures

Both saved diffs under `PAB2/evidence/` match every hunk of the returned code. Reversing those text patches in memory reconstructs frozen `claim_coverage.py` exactly: 63,136 bytes, SHA `d6f47d118f854969371f8c2b5aa5ac48bcf5580f644ed72d63e94c393d4b8379`, blob `defa6592caf794f867ce62091b7cb5e7e138c674`. The test-file before blob is `341245dc6426b69650606de7727d7944d2f36c26`, matching the diff. No Git fetch or producer execution was used.

The only existing function whose executable AST changes is `_executable_source`. At returned `repo/claim_coverage.py:582–612`, AST columns retain the UTF8-byte conversion and tokenizer comment columns use character offsets. Existing `_test_patterns` executable logic is unchanged; its own-source-only scope docstring is corrected at 667–675. Global upper-bound statements are corrected in three code prose sites and the test docstring. `COVERAGE_FLOOR`'s assignment AST is unchanged; no literal was planted in an existing real guard to recover coverage. The test changes add three synthetic Unicode scope cases and two focused preservation/blanking tests, all using the pre-existing fictional document name.

| Original evidence file under `PAB2/evidence/` | Saved command/result |
|---|---|
| `attempt-01-BEFORE-counterexample.txt` | `python3 .../evidence/counterexample_repro.py`; exit 1, harness import-path error |
| `attempt-02-BEFORE-counterexample.txt` | Same harness path; exit 1, DEFECT REPRODUCED; literal not preserved and comment basename not erased; root `actual_blank` matches |
| `attempt-03-BEFORE-focused-mechanism-tests.txt` | `python3 -m pytest -p no:cacheprovider <frozen-check>/tests/test_the_census_credits_only_executable_references.py -q`; exit 1, 2 failed / 9 passed; later note preserves the insufficient comment fixture |
| `attempt-04-BEFORE-focused-mechanism-tests.txt` | Same test relative path from frozen-check cwd; exit 1, 3 failed / 8 passed after fixture tightening |
| `attempt-05-AFTER-focused-mechanism-tests.txt` | `python3 -m pytest -p no:cacheprovider research/manuscripts/tests/test_the_census_credits_only_executable_references.py -q`; exit 0, 11 passed, one pre-existing invalid-escape warning |
| `attempt-06-AFTER-counterexample.txt` | Harness absolute path; exit 0, REPAIRED; literal preserved and basename erased |
| `attempt-07-AFTER-census-check-endpoint.txt` | `python3 research/manuscripts/claim_coverage.py --check`; **exit 1** |
| `attempt-08-BEFORE-census-check-endpoint.txt` | `python3 research/manuscripts/_pab2_frozen_claim_coverage.py --check`; **exit 1** |
| `attempt-09-binding-identity-diff.txt` | Recorded as `diff <(tail of attempt-07 AFTER) <(tail of attempt-08 BEFORE)`; exit 0 |

Exact literal command lines, absolute receipt paths and summaries are in `artifact-intake.json`; the table abbreviates long frozen scratch paths. Attempt-04's saved stdout starts partway through a traceback and retains the summary, so it is not a complete diagnostic stream. Attempt-09's command is descriptive shorthand, not an executable command transcript. Attempt-08 does not itself carry a module SHA, although its report and scratch-copy context identify the frozen version. These qualifications prevent overstating “every exact command/module hash/full output is present.”

The actual saved stdout-plus-exit bodies of attempts 07 and 08 compare byte-identically. Both report four stale degrader-methods fields: sentences/uncovered 124→194, numbered/uncovered-numbered 54→102. This supports the narrow claim of identical recorded failure lists; it does not establish a successful census gate, census truth, or scientific binding. The claim-ablation sibling channel and splitlines/form-feed/Unicode-line-separator hazard remain open as the original report states.

No whole-paper certification, endpoint unpark, source/manifest scientific acceptance, new coverage floor, or test amnesty follows from this intake.
