param([string]$ReviewRoot = 'C:/Users/mcrae/Documents/Codex/2026-09-07/emc-research-orchestrator/work/atr-final-review-20260908')
$ErrorActionPreference = 'Stop'
$inputRoot = Join-Path $ReviewRoot 'inputs'
$manifest = Get-Content -Raw (Join-Path $ReviewRoot 'frozen-inputs-manifest.json') | ConvertFrom-Json
$cache = Get-Content -Raw (Join-Path $inputRoot 'research/modalities/emc-construct-inputs.json') | ConvertFrom-Json
$designs = Get-Content -Raw (Join-Path $inputRoot 'research/modalities/emc-fet-construct-designs.json') | ConvertFrom-Json
$frame = Get-Content -Raw (Join-Path $inputRoot 'research/modalities/emc-fet-frame-and-composition.json') | ConvertFrom-Json
$stamp = Get-Content -Raw (Join-Path $inputRoot 'research/manuscripts/figures/emc-atr-figure-provenance.json') | ConvertFrom-Json
$digests = foreach ($r in $manifest.files) {
    $p = Join-Path $inputRoot $r.path
    $actual = (Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()
    [pscustomobject]@{ path=$r.path; bytes=(Get-Item -LiteralPath $p).Length; sha256=$actual; matches_manifest=($actual -eq $r.sha256 -and (Get-Item -LiteralPath $p).Length -eq $r.bytes) }
}
$constructChecks = foreach ($c in $designs.constructs) {
    $retained = $c.junction_in_residue_numbering.five_prime_residues_fully_encoded
    $extra = $c.domains_retained_and_lost.n_extra_junction_encoded_residues
    $gene = $c.junction_in_exon_numbering.five_prime_gene
    $seq = $cache.genes.$gene.protein
    [pscustomobject]@{
        id=$c.id
        stored_protein_length=$c.protein_length_aa
        literal_sequence_length=$c.protein_sequence.Length
        sum_of_stored_moiety_lengths=($retained + $extra + $cache.genes.NR4A3.protein.Length)
        stored_orf_nt=$c.junction_in_nucleotide_numbering.fusion_orf_len_nt
        aa_times_three=($c.protein_length_aa * 3)
        stored_protein_has_complete_nr4a3_suffix=$c.protein_sequence.EndsWith($cache.genes.NR4A3.protein)
        stored_protein_has_expected_donor_prefix=$c.protein_sequence.StartsWith($seq.Substring(0,$retained))
        rg_in_existing_retained_prefix=[regex]::Matches($seq.Substring(0,$retained),'RG').Count
        rg_in_existing_wildtype=[regex]::Matches($seq,'RG').Count
        stored_rg_count=$c.domains_retained_and_lost.five_prime_FET_half.rg_dipeptides_retained
    }
}
$taf = $cache.genes.TAF15.protein
$tafBoundary = foreach ($n in @(161,174,175,176)) {
    [pscustomobject]@{retained_length=$n; complete_rg_dipeptides=[regex]::Matches($taf.Substring(0,$n),'RG').Count; terminal_residue=$taf.Substring($n-1,1)}
}
$figureDigests = foreach ($prop in $stamp.sources.PSObject.Properties) {
    $path = Join-Path $inputRoot ('research/modalities/'+$prop.Name)
    $actual = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant().Substring(0,16)
    $raw = [IO.File]::ReadAllText($path)
    [pscustomobject]@{source=$prop.Name; stamped_sha256_16=$prop.Value; actual_sha256_16=$actual; matches=($actual -eq $prop.Value); crlf_count=[regex]::Matches($raw,"`r`n").Count}
}
$phaseRows = foreach ($r in $frame.frame_rule.ewsr1_donor_exons) {
    [pscustomobject]@{exon=$r.ewsr1_donor_exon; coding_nt=$r.ewsr1_coding_nt_through_exon; phase=($r.ewsr1_coding_nt_through_exon % 3); stored_phase=$r.donor_end_phase; acceptor2_register=(($r.ewsr1_coding_nt_through_exon+176)%3); acceptor3_register=(($r.ewsr1_coding_nt_through_exon+2)%3)}
}
[pscustomobject]@{
    checked_utc=[DateTime]::UtcNow.ToString('o')
    scope='Read-only scalar, digest, and existing-string consistency checks. No biological producer, translation, new construct, alignment, prefix sweep, experiment, or full preflight was run.'
    reviewed_revision=$manifest.revision
    manifest_entries=$digests.Count
    manifest_mismatches=@($digests | Where-Object {-not $_.matches_manifest}).Count
    digests=$digests
    construct_consistency=$constructChecks
    seam_scalar_arithmetic=[pscustomobject]@{donor_remainder=(793%3); acceptor_exon2_nt=174; acceptor_exon3_utr_nt=2; summed_extension_nt=(1+174+2); codons=((1+174+2)/3); stored_extension_length=$frame.type2_seam.extra_residue_sequence.Length; stored_extension_occurs_at_expected_position=($designs.constructs[1].protein_sequence.Substring(264,59) -ceq $frame.type2_seam.extra_residue_sequence)}
    taf15_boundary=$tafBoundary
    taf15_ceiling_interpretation=[pscustomobject]@{first_rg_arg_1based=($taf.IndexOf('RG')+1); first_rg_gly_1based=($taf.IndexOf('RG')+2); manuscript_claimed_maximum_zero_rg_length=174; largest_prefix_with_no_complete_rg=($taf.IndexOf('RG')+1); extra_residues_possible_from_161_without_complete_rg=($taf.IndexOf('RG')+1-161)}
    phase_scalar_checks=$phaseRows
    stored_symmetric_sweep_gap=($frame.composition.symmetric_prefix_sweep.lowest_fet_prefix_value-$frame.composition.symmetric_prefix_sweep.tcf12_best_prefix_value)
    figure_source_digest_checks=$figureDigests
} | ConvertTo-Json -Depth 12
