---
review_type: independent final scientific review
paper_id: PUB-ATR-PANEL-ASK
model: gpt-6-astra
reasoning_effort: ultra
configuration_provenance: coordinator's configured dispatch for this agent; not inferred from the review filename
agent_task_path: /root/atr_final_ultra
agent_id: /root/atr_final_ultra
review_started_utc: 2026-09-08T13:48:18Z
scientific_review_completed_utc: 2026-09-08T13:59:46Z
report_written_utc: 2026-09-08T14:04:10Z
reviewed_revision: 1a0ce07f66ffefe26ab3bc691db587147ea4169c
manuscript_sha256: 75b2189e146647b4d865eee7ffe782723a03fb6b50c502e741dbba1c0f07be5a
manuscript_bytes: 61812
figure_png_sha256: fa94675f436692344f5514ac1d08f7d448b5ebdbae4ac16fe3a8572597eb07a7
recommendation: hold this frozen version for one bounded repair; contribution merits a modest computational preprint after repair
submission_blockers: 4
maintenance_findings: 1
editorial_suggestions: 2
full_preflight: UNRUN; separately owned
outgoing_pdf_render_qa: UNRUN; separately owned
publication_readiness: not determined by this scientific review
usage: unavailable
---

# Independent final scientific review

**Manuscript:** *Reading-frame constraints and retained RG content in NR4A3 fusion models of extraskeletal myxoid chondrosarcoma*.

**Decision:** Hold the exact frozen version for the four bounded corrections below. The underlying reference-transcript sequence report merits a preprint after those corrections. I found no reason to require a new biological experiment or a second annotation source before publishing explicitly conditional sequence models. This is a modest computational contribution, not evidence of an EMC DNA-repair defect or ATR-inhibitor response. I do not share the older review's confidence that a particular journal would accept it.

The strongest contribution is the auditable translation of the stated exon junctions, especially the type-2 untranslated-sequence insertion and the explicit coordinate tables. The phase rule is useful bookkeeping derived from the acceptor's two-base offset, rather than a new biological mechanism. TCF12's established non-FET family membership is not a discovery; the prefix comparison supplies descriptive support for a proposed control. The retained-RG positions and recruitment predictions are an application of another study's mechanism, without EMC validation. Those limits are compatible with a short computational preprint and with the present title.

## Frozen scope and review method

The only paper reviewed was the ATR/frame-composition manuscript at the revision above. I read the entire 806-line frozen manuscript, its cover letter, the exact Figure 1 PNG, its integration QA note, and the retained older peer review and response. The older response describes a different revision; its assertions that changes were applied were not treated as facts about this outgoing file. No old medium-effort review was counted as this ultra pass.

All **26** frozen-manifest entries matched their byte lengths and SHA256s. The supplied PNG was viewed directly. Its visible architecture, retained-RG counts, distinction between measured and computed positions, and type-2 seam agree with the manuscript at the resolution viewed. This was not a print-size or outgoing-PDF layout assessment.

I inspected the producers' relevant arithmetic, sequence-retention checks, composition calculations, alignment scoring, source extraction, and figure-provenance logic. I read the two supplied test modules but **did not execute** them. The only executed scientific checks were small read-only counts, integer arithmetic and comparisons of already-stored strings, preserved in `lightweight-checks.ps1` and `lightweight-checks.json`. No new fusion sequence was designed or translated, no biological producer was run, no sweep or alignment was regenerated, and no input or shared repository/state was changed.

Those checks independently established:

- The four stored protein lengths are 1058, 949, 1099 and 788 aa; their stored ORF nucleotide lengths equal three times those lengths. Each existing protein string has its stated donor prefix and the complete stored 626-aa NR4A3 suffix.
- Existing retained prefixes contain 8/30, 0/30, 11/30 and 0/31 RG dipeptides, respectively. These are counts of complete `RG` substrings.
- The type-2 scalar arithmetic is 1 + 174 + 2 = 177 nt = 59 codons; the existing 59-residue segment occupies the stated position in the stored protein. This is not an independent retranslation or patient-junction validation.
- The stored phase rows obey the modulo-three relation for the two stated acceptor offsets. The stored symmetric-sweep extrema differ by 0.039 after rounding. These checks do not validate an unobserved patient transcript or recompute the sweep.
- The TAF15 boundary counterexample and figure-stamp mismatch described below are real.

Existing source records were preferred. Three additional files were read strictly with `git show` at the reviewed revision: selected records in `research/manuscripts/aso/lit-targets-aso-verify.json`; selected mechanism paragraphs and provenance in `research/modalities/atr-hrd-sarcoma-series-inputs.json`; and relevant introductory/source-provenance passages of `research/manuscripts/dependency/emc-atr-vulnerability-assessment.md`. The last is context only, not another reviewed paper. The series-input cache identifies its mechanism text as **PMC10187251, the preprint**, which I did not silently relabel as the version of record.

A necessary version-of-record check used public primary sources: PubMed confirmed the 2026 Gracilla citation; Europe PMC's normal full-text REST endpoint returned HTTP 200 for PMC13223543. Its add-back and imaging paragraphs corroborate the retained preprint's pertinent account: one or all three RGG-rich domains were reintroduced, with the three-domain version described as the entire EWSR1 C-terminus, and recruitment was imaged at one-minute intervals for 15 minutes. This supports the assay premise; it does not establish a numerical RG-to-kinetics calibration for EMC. [Gracilla et al., version of record](https://pmc.ncbi.nlm.nih.gov/articles/PMC13223543/), [primary XML](https://www.ebi.ac.uk/europepmc/webservices/rest/PMC13223543/fullTextXML).

The direct PMC browser request returned a challenge, the publisher browser request returned HTTP 403, and the Europe PMC HTML browser request failed. These were source-access limits, not a review-task restriction. The independent public REST read succeeded. No missing text was treated as evidence that an experiment does not exist. The current article's supplementary construct sequences were not independently inspected; the exact one-domain and ATF1 constructs therefore remain unresolved for this review.

## Findings requiring correction before submission

### ATR-U1 — The TAF15 “largest zero-RG” boundary is off by one

**Class:** Submission blocker, confined to a numerical subclaim; high confidence.

**Exact outgoing claim/location:** Main manuscript lines 521–525, particularly “174, the largest retained length carrying no RG dipeptide”; repeated explanation at lines 578–583. The asserted margin is 174 − 161 = 13. The artifact repeats that definition in `composition.taf15_zero_rg_margin`.

**Observed evidence:** In the frozen TAF15 protein, the first RG starts at arginine 175 and ends at glycine 176. Direct counts give zero complete RG at retained lengths 161, 174 **and 175**, and one at 176. The census's `assess()` counts `RG` in `seq[:cut]`, whereas `rgg_free_ceiling()` returns the zero-based start index of the first match. Those functions therefore disagree about the largest RG-free retained length. This is not resolved by calling it a convention: the literal claim “largest retained length carrying no RG dipeptide” is false under the paper's own complete-dipeptide definition.

**Scientific consequence:** The claimed headroom to retaining the first complete RG is 14 residues, not 13. The actual TAF15 exon-6 retained length of 161 and its 0/31 count remain correct; no construct placement changes.

**Smallest defensible repair:** Either correct the ceiling to 175 and complete-dipeptide headroom to 14, with the corresponding narrowly scoped artifact/code correction, or retain the historical 174/13 values only with their accurate label: a conservative boundary ending **before the arginine that starts the first RG**. Remove the false “largest zero-RG” description in both prose locations. Preserve the dated registered P3 record and distinguish its distance-to-arginine statement from any current corrected metric.

### ATR-U2 — “Counted once in the two series” converts an unspecified count into zero

**Class:** Submission blocker, an unsupported frequency summary; high confidence in the evidentiary gap, not a finding that the true count is necessarily greater than one.

**Exact outgoing claim/location:** Table 1, main manuscript line 354: type 2 is “counted once in the two series that typed EWSR1 subtypes”; cover letter lines 53–54 conveys the same cross-series claim. The added phrase “absent from the counted types of [7]” does not identify that only an incomplete abstract enumeration was examined.

**Observed evidence:** The retained full abstract for Panagopoulos 2002 reports 15 EWS/CHN cases, gives 10 type-1 and two type-5 cases, and does not enumerate the remaining three transcript types. The public PubMed abstract agrees. The artifact stores an extracted sentence containing the two explicit counts; neither that extraction nor the complete abstract establishes a zero type-2 count. Okamoto's retained abstract does explicitly report one type-2 case among 15 fusion-positive cases. [Panagopoulos et al., abstract](https://pubmed.ncbi.nlm.nih.gov/12378528/).

**Scientific consequence:** The current wording presents a combined rarity conclusion that exceeds the retrieved evidence. The genomic intron counts do not independently determine the missing transcript-type count, and I have not inferred it from them.

**Smallest defensible repair:** State “1 of 15 fusion-positive cases in Okamoto [9]; the retrieved Panagopoulos abstract [7] does not state a type-2 count.” Remove the cross-series “counted once” summary in the cover letter and any active interpretive artifact wording that is distributed as a current frequency conclusion. No new retrieval is necessary if the claim is narrowed this way. Historical records can remain intact and marked as superseded.

### ATR-U3 — Proposed recruitment outcomes are overinterpreted as causal tests

**Class:** Submission blocker in the interpretation of the prediction set; high confidence.

**Exact outgoing claims/locations:** Table 5, lines 567 and 569, says a failure of type 1 to recruit earlier would “place the variable elsewhere,” and that no kinetic difference would “bound the dose-dependence to engineered constructs.” Lines 603–611 say discordant TCF12/EWSR1 recruitment “demonstrates FET specificity” and that recruitment of both assigns the driver to a shared feature and refutes the structural mechanism. Supplementary Table S2, line 752, says recruitment of NR4A3 alone would remove attribution to the FET moiety.

**Observed evidence:** The paper's own Table 2 and frozen sequences show that type 1 and type 2 differ by 167 fully encoded EWSR1 residues and by their junction-encoded segments (one versus 59 residues), as well as by eight RG dipeptides. They are not an isolated RG intervention. The stated controls are intact partner proteins, not tests of necessity within the same chimera. The manuscript also correctly acknowledges other recruitment determinants at lines 613–623. Non-FET and FET fusions could reach the same readout by different mechanisms; shared recruitment alone does not identify a shared cause. FET-mediated recruitment does not logically imply that all non-FET proteins must fail to recruit.

**Scientific consequence:** The proposed experiment can test the specified recruitment patterns in the constructs and conditions used. It cannot, by those patterns alone, establish or refute a unique FET/RG mechanism, localize the cause to NR4A3, or restrict dose-dependence to engineered fusions. This remains a problem even though the predictions were recorded before an experiment and downstream drug-response claims are disclaimed.

**Smallest defensible repair:** Preserve the original registered entries as historical records, but replace the current mechanistic outcome interpretation with a dated, narrower statement: results can support or contradict the specified recruitment ordering or nonrecruitment predictions; attribution to RG content or a particular moiety remains unresolved. Describe a TCF12-positive result as contradicting **P5's FET-exclusive prediction**, not as refuting FET-mediated recruitment in EWSR1::NR4A3. No additional experiment or new construct is required to make this wording defensible.

### ATR-U4 — Wild-type TCF12 cannot substitute for the P5 fusion test

**Class:** Submission blocker in what the supplied assay package can test; high confidence.

**Exact outgoing claim/location:** Main manuscript lines 641–644: lacking a sequenced TCF12::NR4A3 junction, “the arm runs with full-length GFP-TCF12,” which “tests the same question” about a non-FET N-terminus reaching a break.

**Observed evidence:** P5 at line 570 predicts the behavior of **TCF12::NR4A3**. The frozen artifact explicitly emits no such construct; its four controls include only full-length TCF12. Wild-type TCF12 lacks the NR4A3 moiety and retains its own C-terminal architecture. Recruitment or nonrecruitment of the full-length protein cannot assign behavior to its isolated N-terminus or answer what the fusion does.

**Scientific consequence:** Substitution would leave P5 untested while the text presents the arm as available. The limitation that the breakpoint is unpinned is correct; the proposed equivalence of the substitute is not.

**Smallest defensible repair:** Replace the substitute claim with “Full-length GFP-TCF12 is a partner-alone control; P5 remains untested unless a suitable TCF12::NR4A3 fusion is available.” State that limitation at P5 as well as in the controls section. This does not require reopening junction sourcing or designing a new construct.

## Maintenance and editorial observations

**ATR-M1 — Figure provenance needs release reconciliation. Class: maintenance/provenance, not a demonstrated scientific drawing error.** Main manuscript lines 302–305 and 704–707 direct readers to the figure check. The generator's `stamp()` hashes raw bytes with SHA256 and keeps 16 hexadecimal characters. All three stored stamps differ from the frozen source files:

| Source | Stored stamp | Current frozen SHA256 prefix |
|---|---|---|
| emc-construct-inputs.json | a561b8bb534d4148 | 9166e09ec8e9d0bb |
| emc-fet-construct-designs.json | 31117a8ac40755a5 | 726aae02ae38b41c |
| emc-fet-frame-and-composition.json | b8b52dc3085ff4c0 | eb92812555c9239c |

The frozen files already use LF line endings; normalizing CRLF to LF does not explain these differences. From the inspected code, the declared third command would report `STALE` for this frozen bundle; that is a code-based inference, **not a claimed executed command result**. The visible scientific content checked agrees with the current artifacts. The current QA note's separate concern about hard-coded box spans is also maintenance while the values agree. The release owner should reconcile the figure with its actual generating inputs or redraw and verify against settled inputs, then preserve truthful provenance. Do not merely replace stamp values and claim that an old image was generated from the new bytes. This observation cannot be used to mark the separately owned full preflight or PDF QA passed.

**ATR-E1 — Call review sources reviews. Class: editorial correction of provenance wording.** Main manuscript line 358 calls reference 4 a “primary source”; references 4 and 5 are reviews, as their titles and the retained metadata show. Repeated “every breakpoint is quoted from a primary source” statements in the manuscript and cover letter overstate the uniformity of the sourcing. The quotations still support the stated published exon definitions, so this does not invalidate the arithmetic. The smallest repair is “published sources, including primary reports and reviews,” with “review” at line 358, unless a primary quotation is actually supplied.

**ATR-E2 — Make the cached models easier to identify. Class: editorial/reproducibility presentation.** Supplementary Table S1 lines 740–743 uses “canonical” for three models although the cache records TAF15 ENST00000605844, FUS ENST00000254108 and TCF12 ENST00000333725. The cache retrieval date is 2026-08-12 and the release/version suffix is not recorded. The cache contains the sequences, so this is not evidence that the stored calculation cannot be reproduced. Replace “canonical” with the known accessions and state the recorded retrieval date; do not invent release, assembly or accession-version values. The TCF12 prefix result should continue to be scoped to the evaluated sequence/grid, not all possible isoforms.

## Objections independently rejected or bounded

- **No experiment means no publishable result:** rejected. A properly labeled, reproducible reference-transcript analysis is a legitimate small preprint contribution. Its usefulness does not require pretending that these sequences were expressed in patients.
- **A second annotation source is mandatory:** rejected as a universal condition for this paper's conditional models. The current manuscript explicitly discloses the single cache and unverified correspondence. The cached UniProt/Ensembl agreement for protein sequences is not an independent verification of the exon map. No alternative transcript was generated in this review.
- **The 176/177 arithmetic remains broken:** rejected for the current revision. It now accounts for the donor nucleotide and the two exon-3 UTR nucleotides. The stored string and scalar lengths agree.
- **ATF1 breakpoint rows are all measured constructs:** the current Table 3 and Figure 1B distinguish reported breakpoints from measured recruitment. Their uncertainty is a substantive limitation, not a reason to fabricate an exact construct assignment. No conclusion of global absence is drawn from the uninspected supplement.
- **P1's nonsignificant result proves equivalence:** the manuscript itself rejects this at lines 591–594. An unspecified equivalence margin remains a limit on future confirmation; it is not an executed invalid statistical analysis here. P2/P4 overlap is also disclosed, and does not require an arbitrary target number of independent predictions.
- **Prior-art zero proves novelty:** rejected. The retained screen is an abstract/title screen with an incompletely specified search strategy and no positive control. It supports only a bounded account of that retrieval. I found no basis here for a field-wide first-discovery claim about the insertion. The paper appropriately limits its documented correction to this programme's earlier model.
- **A stale figure digest proves a wrong scientific figure:** rejected. It proves a provenance mismatch. The discrepancy must be reconciled for release, but its biological consequence cannot be invented.

## Sources and files read

Paths below are relative to `inputs/` unless otherwise stated. Reading a source file does not mean executing its producer or accepting every historical claim it contains.

- `AGENTS.md`; `research/autonomy/OPERATING_PROTOCOL.md`; relevant acceptance/authority logic in `research/autonomy/publish_bar.py`; publication-authority schema inspection.
- `C:/Projects/EMC-Research/.claude/skills/paper-hardening/SKILL.md`, the requested review procedure.
- Main manuscript, cover letter, integration QA, older peer review and review response in `research/manuscripts/dependency/`.
- Exact `research/manuscripts/figures/emc-fusion-frame-fig1.png`; figure generator and provenance JSON. The figure PDF was digest-checked, not rendered or visually reviewed.
- `research/modalities/emc-fet-construct-designs.json`, `emc-fet-frame-and-composition.json`, relevant census records in `emc-fet-idr-census.json`, cache model fields and existing strings in `emc-construct-inputs.json`, and relevant `nr4a3-exon-audit.json` records.
- Relevant methods and checking paths in `emc_fet_construct_designs.py`, `emc_fet_idr_census.py`, the full `emc_fet_frame_and_composition.py`, and both supplied test modules.
- `research/literature/emc-prior-art-2026-08-09.json`; relevant entries in `remaining-reference-metadata-2026-08-09.json`; relevant source/denominator passages in `research/data/emc-clinical-registry.json`.
- The three exact-revision `git show` reads and public primary-source checks described in Methods. The Git object for `lit-targets-aso-verify.json`, not the working-tree file, supplied the full counted-series abstracts.

The model/effort metadata records the coordinator-configured dispatch of this agent, not an inference from a label on an older review. Start through scientific decision took about 12 minutes; report preparation followed. Token use and remaining subscription capacity were unavailable. No other agent was spawned.

## Submission disposition

One bounded scientific review is complete. Resolve ATR-U1–U4 in one repair, preserving historical preregistration records, and perform a focused independent check of the changed claims and dependencies. None of these findings calls for a new whole-paper cycle, new patient-junction research, or wet-laboratory work. The scientific contribution remains worth a modest computational preprint after that repair.

Full `PREFLIGHT_FULL=1`, outgoing PDF render QA, current venue requirements, publication authority and all other actual publish-bar clauses remain separately owned and **unverified by this review**. The inspected publish bar requires all its clauses plus authority; this report is not a substitute for those records. No unrelated repository-wide failure count was treated as a manuscript defect count or as gate clearance. No review or continuation of the held NR4A reagent Perspective, its successor routes, writer/W25 work, or Brenca patient-junction crosswalk was undertaken.
