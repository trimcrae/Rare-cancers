"""Reviewer bookkeeping only: no producer, statistical calculation, or Git/network access."""
from pathlib import Path
import json, hashlib, re

ROOT = Path(__file__).resolve().parent
records = json.loads((ROOT / 'retained-inputs.json').read_text(encoding='utf-8'))
by_name = {Path(r['source']).name: r for r in records if r['kind'] == 'external'}
dep = json.loads(Path(by_name['MF1-dependency-manifest.json']['retained_path']).read_text(encoding='utf-8'))
identities = []
for d in dep['inputs']:
    data = (ROOT / 'pinned' / d['path']).read_bytes()
    r = next(r for r in records if r['kind'] == 'git' and r['source'].endswith(':'+d['path']))
    identities.append(dict(path=d['path'], bytes=len(data), sha256=hashlib.sha256(data).hexdigest(),
        declared_bytes_match=len(data)==d['bytes'], declared_sha256_match=hashlib.sha256(data).hexdigest()==d['sha256'],
        declared_git_blob_matches_fixed_return_pin=r['git_blob']==d['git_blob']))
si = (ROOT / 'pinned/research/manuscripts/methods-record/degrader-methods-failure-record-SI.md').read_text(encoding='utf-8')
fore = json.loads((ROOT / 'pinned/research/modalities/nrv04-result-forensics.json').read_text(encoding='utf-8'))
source_counts = [{'prefix': s['prefix'], 'stored_leg_result_count': s['by_class']['leg_result']['n'],
    'trajectory_objects_found': s['recompute_verdict']['trajectory_objects_found']} for s in fore['surveys'].values()]
checks = []
for r in records:
    if r['kind'] != 'external' or not r['source'].endswith('.exit'):
        continue
    stem = Path(r['source']).stem
    found = {}
    for suffix in ('cmd','exit','stdout','stderr'):
        rr = by_name[stem+'.'+suffix]
        content = Path(rr['retained_path']).read_text(encoding='utf-8', errors='replace')
        if suffix in ('cmd','exit'):
            found[suffix] = content.strip()
        else:
            lines = content.splitlines()
            found[suffix+'_bytes'] = rr['bytes']
            found[suffix+'_last_lines'] = lines[-4:]
            found[suffix+'_mf1_lines'] = [line for line in lines if re.search(r'MF1-repair|methods-record/',line)]
            if len(found[suffix+'_mf1_lines']) > 35:
                found[suffix+'_mf1_lines'] = found[suffix+'_mf1_lines'][:35] + ['[remaining matches omitted; exact stream retained]']
    checks.append(dict(stem=stem, **found))
output = dict(scope='New reviewer bookkeeping: identities, existing declared source counts, SI row IDs, and preserved author check streams; no science calculation or producer executed.',
    dependency_manifest_commit=dep['commit'], reviewed_return_pin='01dd5a211c87e0044d735a8c840a9860da42b529',
    identity_checks=identities, si_instrument_ids=re.findall(r'^\| \*\*(V\d+)\*\* \|',si,re.M),
    forensic_source_counts_copied_not_recomputed=source_counts, original_author_check_records=checks)
print(json.dumps(output, indent=2, ensure_ascii=False))
