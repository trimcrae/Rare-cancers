$ python3 research/manuscripts/lint_citations.py
