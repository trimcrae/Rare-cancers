# Reviewer execution record

The only new check was `verify_package_metadata.py`, a local bookkeeping script. It reads the retained input ledger and exact retained copies, compares identities, lists SI IDs, copies existing per-prefix object-count fields, and selects command/exit/summary/MF1 lines from the preserved author streams. It does not run the author extraction, compute statistics, access Git, or access a network.

The shell calls are recorded here from the actual tool invocations, after execution; this note is not an original process stdout file.

Attempt 1 invoked the bundled Python at `C:/Users/mcrae/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe` with `work/mf1-focused-verification-20260908/verify_package_metadata.py`, redirecting stdout to `verify-package-metadata.stdout.json` and stderr to `verify-package-metadata.stderr.txt`. Exit 1 was captured in `verify-package-metadata.exit.txt`. The script failed while printing Unicode under the Windows cp1252 stdout encoding. The failed stdout is empty; the traceback is retained.

Attempt 2 invoked the identical script and interpreter after setting `PYTHONIOENCODING=utf-8`, with separate `verify-package-metadata-attempt2.stdout.json`, `.stderr.txt` and `.exit.txt`. Exit 0 was captured. The original failed files were not overwritten. The script's source did not change between attempts.

The retained author execution files are separate under `provenance-originals/` and are hashed in the input manifest. Their contents were never treated as new reviewer execution. Large broad-check streams received bounded summary/MF1-line inspection, not an unrelated repository audit. The author's abbreviated attempt-22 command remains abbreviated; no missing literal original command was recreated.

Other commands retained immutable files, read text/selected JSON fields, or created and hashed this report/manifest. They did not mutate the scientific source checkout or execute any science producer. All Git reads used `GIT_NO_LAZY_FETCH=1` and `GIT_TERMINAL_PROMPT=0`.
