# MF1: focused scientific verification of the F01–F12 repair

**Disposition: the repair is substantially improved but is not scientifically closed. HOLD the returned manuscript package for the finite residual corrections below. Do not PARK the narrower retrospective audit.** Its useful result remains an inspectable account of what one program's retained records did and did not establish. The failures of particular controls, the limits of an uncalibrated estimate, and the distinction between input, simulation and post-processing defects can support that account. The returned supplement still republishes claims the main withdraws, and several accepted reproducibility and chronology corrections remain incomplete.

This is the **one focused post-repair verification of the accepted F01–F12 batch**, not a new baseline review. I read the entire returned main, supplement, response matrix, extraction script, corrective interpretations, patch instructions and original final-review findings. I checked the changed interpretations against the named retained source fields needed to adjudicate those findings. I did not rerun the original reviewer's statistics or any science producer. Existing scientific, platform, source-access and publication holds remain unchanged.

## 1. Identity, authority and scope

Returned immutable pin: `01dd5a211c87e0044d735a8c840a9860da42b529` in `C:/Projects/EMC-Research`. Git inputs were read with `GIT_NO_LAZY_FETCH=1` and `GIT_TERMINAL_PROMPT=0`. No fetch, source acquisition, checkout mutation or manuscript edit was performed. Exact used inputs were retained in this verification workspace.

| shorthand | fixed input | bytes | SHA-256 |
|---|---|---:|---|
| M | `research/manuscripts/methods-record/degrader-methods-failure-record.md` | 73,844 | `4a99804f9f50ac687ad709b5ea0aad4bc5c9a48a351934aa24ee94364a64430e` |
| SI | sibling `degrader-methods-failure-record-SI.md` | 26,791 | `7e988f0a10118d9d1ec038e7d37c2b5d3527005c4f1f2b3b71971f95c04ea66a` |
| Response | `MF1-repair/F01-F12-response-matrix.md` | 20,148 | `4df3ba59fb9235eb5ffad154afb2c2a30fe2034dde4fb280133a20e1a1ba87f2` |
| Patches | `MF1-repair/patches/CURRENT-SUMMARY-PATCHES.md` | 11,940 | `d455f14daabe8937c26233c74ebc05e28bd011d52b3a137c5339de713074658a` |
| Package | `MF1-repair/PACKAGE-MANIFEST.json` | 6,384 | `a70bccaf5e906a51555aa08f4384d44489ddf6857365d652e235d24b6f998310` |
| Original review | `FINAL-SCIENTIFIC-REVIEW-MF1.md` | 38,953 | `f4a0aceec8fdea6a1da62de2dc36ef88637c6288c05f1cc7fc318b3c971b32be` |
| Root adjudication | `MF1-final-review-root-adjudication-20260908.md` | 6,673 | `071fcfc9afd0b99a87b8ad9d8ca260769431d6b222ca60662efb196bf9164365` |

The original review concerned `0b965a1279c81c10d9edc054842a33446e87762e`. Root accepted all twelve findings and authorized one coherent repair. This verification was performed by the known commissioned gpt-6-astra/ultra reviewer, without delegation. An author response saying “corrected” is not evidence of closure. The package's `commit_at_freeze` and its extraction-input manifest refer to `d5eb86e8093df671da081ea56b67dcfd79e1f0fe`; this differs from the later transport/return pin and is not by itself an error. I verified that **all 17 declared extraction inputs match the actual 01dd returned blobs in byte count, SHA-256 and Git blob identity**. This is an identity result, not validation of every sentence or every underlying experiment.

Line numbers below are one-based in the retained fixed files. `C` means `research/manuscripts/methods-record/corrective-interpretations-2026-09-08.md`; `E` means the returned `MF1-repair/extract_mf1_inventory.py`. Source paths not otherwise prefixed are under `research/modalities/`. The manifest records the full original and retained paths and the actual read scope for each input.

## 2. Finding-by-finding decision

“Closed in main” is deliberately distinguished from closure across the returned paper and its claimed current evidence chain.

| accepted finding | verification result | evidence and remaining action |
|---|---|---|
| **F01 — power, E1 validity, reference identity** | **Substantially corrected; partial overall** | M:70–79, 199–217, 419–459 correctly distinguish an executed failed operational calibration from an absent control or a powered demonstration of insensitivity. They retain 6 versus 5 model means, 22 admitted legs, +0.4373 Å, p=0.746753, mirror 0.255411 and the 462-arrangement floor. M:431–433 still transfers a single-hydrogen-bond mechanism to the panel's reference without the source's ligand qualification. Current census/roadmap powered-null summaries remain superseded rather than corrected in the returned pin. See R1, R3 and R5. |
| **F02 — S is not an effect bound** | **Closed in main; open in SI/current scope** | M:219–237, 382–393 and 618–624 correctly retain −0.1297 kcal/mol, two seeds per species and 0.3264 between-seed dispersion, identify the particle-count flag, distinguish modeled Hamiltonian intervention from biological causality and state the reference-state assumptions. No illustrative reviewer interval is promoted into an empirical result. **SI:72 nevertheless says S may be read as a bound and S≈0 means the marginal wedge is absent.** R1. |
| **F03 — closure does not identify the cause or certify convergence** | **Closed in main; open in SI/current scope** | M:239–265 and 625–630 preserve the repeated wrong sign, 1.543 kcal/mol absolute error and single-seed residuals while withdrawing unique localization, excluded sampling error, convergence certification and no-more-sampling claims. **SI:61 still says closure localizes the miss to endpoint-state error and more sampling will not fix it.** R1. |
| **F04 — distinguish infrastructure defects and persistence limits** | **Scientific interpretation corrected; count needs repair** | M:81–89 and 662–720 separate contaminated descriptive/shakeout inputs from the clean completed covalent panel; distinguish wrong-interface scoring from two wrong physical tethers; and state what the existing tests missed and what trajectories could not repair. The zero-coordinate conclusion is scoped to surveyed prefixes. M:702 and C:150–152 incorrectly apply 17 result objects to the combined two-prefix census; the source has 17 plus 1. R4. |
| **F05 — ascertainment and taxonomy** | **Substantially corrected; current claim-scope axis incomplete** | M:130–159, 304–335 and SI:51–93 explicitly distinguish 20 route entries (4/16 administrative partition) from 22 numbered records, mark V2/V18 outside the route, acknowledge retrospective ascertainment and distinguish V13, V15, V19 and V22 correctly. All 22 IDs are present exactly once. However the fourth axis is an uncorrected historical scope quotation presented as the paper's current claim scope. R1. |
| **F06 — chronology and dependence** | **Partial** | The “every method first” and “three independent validations” claims are withdrawn; the two V11 applications are properly identified as sharing an E1 readout/scorer. M:147, 374–386, 402–403 and 757–766 still assert the unestablished pre-run chronology as fact while conceding its necessary revisions are not presented. Literal shared structural inputs should not be inferred from sharing one program's assumptions/code. R2. |
| **F07 — decoys and gate failure do not prove impossibility** | **Closed in main; open in SI/current scope** | M:267–276, 532–543 and 589–595 correctly interpret 22/38 as a selected-decoy positive-call rate and 0.259 versus 0.53 as one operational gate on one frame. **SI:77 still says a signal smaller than its noise cannot be recovered by any downstream method.** R1. |
| **F08 — descriptor-scoped zero** | **Closed at the accepted scope** | M:348 and 553–570, SI:42 and :57, and C:198–208 identify the N/O heavy-atom proxy, 3.5 Å threshold, sequence-variable criterion, 16 generated NR4A3 models and the narrow in-sample development/harness check after an initial miss. They remove the “strongest” ranking and do not claim universal absence of discriminating interactions. The source's historical outcome sentence in SI:42 is accompanied immediately by the requisite descriptor and input limits. |
| **F09 — pose attribution and named genetics** | **Corrected in the returned paper; shared patch admission remains separate** | M:491–530 and SI:43 report 4 same-cavity/1 different among 5 gradeable systems plus 1 ungradeable and maintain conformer dependence and unresolved correctness. M:638–656 names NR4A1/NR4A2, reports the developmental complete-loss evidence and withdraws pharmacological-knockout equivalence. “Floor under how much sparing” at M:649 should mean an evidence-backed qualitative concern, not a measured sparing fraction or exposure threshold; the following explicit caveat prevents a quantitative safety conclusion. No new genetics or source investigation is needed. |
| **F10 — SD and MBAR SE are different estimands** | **Closed** | SI:39 and C:113–125 retain cycle SD 0.375 kcal/mol, per-leg MBAR SE 0.097–0.132 and n=3, and explicitly reject a transferable ratio. Neither 3.28 nor the original reviewer's illustrative 2.29 is adopted as a new uncertainty multiplier. |
| **F11 — external unbound-benchmark refutation** | **Withdrawn in the returned paper; stronger claim remains held** | M:608–610, 722–740 and 838, SI:46 and C:210–226 correctly distinguish the 64-atom single-system preparation from the asserted 66-atom released-case equality and withdraw the external refutation. The reopening condition requires the exact comparison and primary protocol statement, not a new retrieval route. Replace the repository-wide absence wording at M:734 with “not identified in the retained evidence used here”; the review did not establish global absence. Shared P6 is a proposal until an integrated binding is supplied. |
| **F12 — standalone audit and reproducible provenance** | **Major improvement; partial** | The new quantitative section, ten-row table, 22-entry supplement, audit methods, explicit record classes and honest non-public-release status substantially improve interpretability. But benchmark identities/answers already in the frozen census are omitted from the new display, the E1 exclusion denominator is incomplete, the extraction can reproduce superseded claims, and the main is falsely described as drift-proof generated output. R1 and R3. No absent public release, decorative figure or broad gate is used alone to hold this scientific verification. |

The four findings closed without a substantive paper correction in this focused pass are F08, F09 at its qualitative scope, F10, and F11's withdrawal. The other eight have at least one finite residual correction. This tally does not convert shared-patch proposals into integrated results.

## 3. Complete residual correction batch

### R1 — P1: the supplement republishes three withdrawn claims, and the proposed propagation path is incomplete

**Accepted findings affected:** F02, F03, F05, F07 and F12; F01 also remains on the shared current-summary path.

The new SI says it adds no claim absent from the main (SI:9, 23–25), tells the reader that a pass is bounded by its final scope column (SI:90–91), and labels that column **claim scope**, rather than “superseded historical annotation.” It then asserts:

| fixed location | current SI statement | contradiction |
|---|---|---|
| SI:61, V5 | closure localizes the miss to an endpoint-state error; more sampling will not fix it | M:244–265 and C:93–111 explicitly withdraw this inference |
| SI:72, V16 | S may be read as a bound; S≈0 means the marginal wedge is absent | M:219–237, 388–393 and C:67–89 explicitly withdraw both readings |
| SI:77, V20 | no downstream method can recover a signal below its noise | M:267–276, 589–595 and C:177–188 explicitly withdraw this universal claim |

These are not merely old raw artifacts preserved for history: they are copied into the newly generated reader-facing supplement as current claim limits. The adjacent author classifications point in the opposite direction. A warning glyph, “verbatim from the census,” or the stronger main-text correction does not resolve that contradiction.

**Cause in the returned extraction:** E:350 announces that `scope_limit` is unedited; E:459 loads `instrument-census.json`; E:474–476 copies its scope and result; E:497–504 renders the scope as the final reader-facing column. The fixed source contains the superseded statements at `instrument-census.json:72` (V5), :228 (V16), and :301 (V20), each in `instruments[id=...].scope_limit`. The inventory has useful author overrides for its first three axes, but no author-current scope axis to supersede these three fields.

**The shared patch instructions miss the dependency.** Patches:249–252 instruct the integrator to regenerate the census after P1–P6 but say MF1 extraction needs no regeneration because it does not read the roadmap. It reads the **census generated from that roadmap**. The actual dependency is:

`roadmap current rows → instrument-census.json → MF1 extraction → MF1-instrument-inventory.md and SI`.

P1–P6 also omit the V20 source-row correction. At the fixed returned roadmap, V20:1775 repeats the no-downstream-recovery statement; V11:1765 calls its NULL adequately powered. The latter also appears in active gate summaries at roadmap:683, 773, 1013–1040 and 2539. P3c changes the V16 source row, but P3b's patch of the “what it bounds” row does not address the adjacent absent-wedge reading at roadmap:983. A full historical rewrite is neither required nor authorized; the current statement a reader reaches must be explicitly superseded.

**Required correction, one coherent operation:**

1. Make the SI's current claim-scope axis agree with the accepted corrections. Either derive it from corrected current census rows, or provide an explicit, source-linked author-current scope and place any retained old quote in a separately labeled **superseded historical annotation**. Do not leave the old claim as the operative final scope column.
2. Correct or explicitly supersede the current V5, V16, V20 and V11 source rows and their necessary current entry points. Keep result values, administrative labels, original run outputs and original protocol history intact. The graph's `PUB-METHODS.what_it_would_claim` and `outcome_potential_why` need the scoped P1/P2 wording, not “each with its diagnosed mechanism” (`publications.json:337,342`).
3. Propagate an admitted shared source update through the dependent display extraction, or pin the historical input explicitly and apply the current-scope override there. Freeze and hash the resulting SI, inventory, input manifest and response matrix together. Update the false “no regeneration needed” instruction.

**Closure evidence:** the actual final current-scope cells and their bound source/extraction identities agree, with the old claims retained only as explicitly superseded history. A new scientific calculation, a green generic linter, or another baseline review is not the remedy.

### R2 — P1: factual pre-run assertions remain after the chronology withdrawal

**Accepted finding affected:** F06.

M:146–152 first says individual gates **were frozen before their own runs**, then says the current assertions cannot establish that chronology. M:374 calls S's outcome registered **in advance**; M:385–386 says its expected magnitude was registered in advance; M:402–403 says the consequence sentence was written before the deciding run; M:757–766 repeats the latter assertion while acknowledging that the paper does not present the rule revisions, amendment timings or first-outcome-access records needed to check it. These are factual chronology claims, not merely quotations of what a retained protocol asserts.

The retained `selectivity-sensitivity-control-prereg.md:11–32` has backfilled metadata and a “before first GPU leg” assertion alongside the August 2 amendment. As the accepted review already established, neither proves misconduct nor supplies the missing independent chronology. No new chronology audit was run in this verification.

**Required correction:** use the agreed attribution consistently: “the retained protocol describes this rule/outcome/consequence as prespecified.” Remove affirmative “was frozen before,” “registered in advance,” and “before the deciding run” wording wherever no precise pre-outcome revision is presented. The narrow interpretation of S and the program's stop decision does not depend on proving that chronology. Preserve any dated historical protocol text unchanged.

Also keep the shared-dependency statement literal. M:751–755 correctly identifies the two V11 applications' shared readout/scorer, but “shares this program's structural inputs” is broader than the demonstrated cross-lane relation. The original review establishes shared code, selection and structural **assumptions**, not that all three use identical structural input artifacts. The forensic account itself distinguishes valB's RCSB 8G1Q chain source from the affected NR-V04 co-folds (`nrv04-cofold-chain-forensics-2026-07-24.md:45–48`). State exact common inputs only where identified; otherwise use “shared program assumptions and code.” This does not restore an independence claim.

**Reopening only for stronger chronology:** identifiable pre-outcome rule versions, amendments and outcome-access bindings already retained. Missing documentation is not permission for a new run or a broad history investigation.

### R3 — P1: the quantitative inventory still hides available grading facts and overstates its generation/provenance

**Accepted finding affected:** F12, with F01/F05 consequences.

The new displays are a substantial repair, but a reader still cannot assess several headline support/failure classifications. SI:62–66 says a public relative-FEP benchmark recovered within an accepted band, an absolute benchmark had a large bias, a hydration free energy was approximately recovered, and an interface-mutation benchmark recovered a large effect. The exact frozen census already contains the omitted benchmark identities and values:

| source in `instrument-census.json` | already-retained grading facts omitted from the new display |
|---|---|
| V5, :69–71 | reference cooperativity +0.944 kcal/mol; result −0.599; the table reports only the 1.543 absolute error and wrong-sign conclusion |
| V6, :84–86 | TYK2 `ejm_31→ejm_42`, benchmark ΔΔG −0.24; result +0.37; absolute error 0.61, approximately 1 kcal/mol operational band |
| V7, :98–100 | T4-lysozyme L99A/benzene, reference −5.2 kcal/mol; +1.90 ±0.09 and approximately +7.1 bias |
| V8, :112–114 | methane hydration/FreeSolv, reference +2.0; result +1.60 ±0.04 |
| V10, :140–142 | barnase–barstar Y29A, +4.42 ±1.08 versus +3.4 |

These are **retained register values**, not new reviewer calculations or a new validation of their primary experiments. Copying them with that provenance is feasible without new source acquisition. Do not blindly carry the V5 source's “~34× statistical uncertainty” or infer the kind of any ± term: retain only the supported estimate and identify an uncertainty type from its already-held record, or explicitly mark it **not established in the cited record**. The identities, criterion and numerical answer are essential to interpreting the grading, even in a narrow record audit.

The E1 row's denominator also needs its excluded model. SI:37 reports 22 admitted legs, zero technical failures and zero rejected records beneath a column promising eligible/excluded/failed/unrun counts. `selectivity-sensitivity-control-prereg.md:26–31` describes an original **24-leg design**, exclusion of **SMARCA4 seed 3** for a recorded static input fault, and the resulting **22-leg admissible panel**. Zero collector `rejected_records` is a different stage from this model exclusion. Report those stages separately and identify the model as the sampling unit. This adds an existing exclusion fact, not a new eligibility decision.

Several publication-facing provenance claims are too strong:

- M:161–166 and 183–185 call the quantitative table **in §4** generated and say it cannot drift. The main contains authored quantitative paragraphs; the extraction writes a separate results file and the SI (E:585–593), not those main paragraphs. The 17-versus-18 inconsistency in R4 is a concrete demonstration of drift between them.
- SI:18–19 and E:531–532 say generation prevents drift. E mixes input-field extraction with hard-coded scientific classifications, descriptions, technical-failure counts and interpretive sentences. That is permissible author synthesis, but it is not guaranteed self-updating evidence.
- E:66–86 reads working-tree bytes while obtaining Git identities from `HEAD`; E:602–609 writes both into one input manifest. The current 17 inputs actually match, so **no current mismatch is alleged**. Following a shared-file change, the author must bind the bytes read and the source blob consistently rather than assuming this implementation guarantees it.
- Stripping all Markdown links (E:447–455) repairs broken relative links but leaves decontextualized references such as `:2310–2313` and “see the row note below” in SI:57 and :66. The new table needs a usable source column/key for each row and the corrective interpretation that governs it, rather than unexplained line numbers from a different document.

**Required correction:** expose the already-retained benchmark identity/reference/result/criterion fields for the relevant rows; distinguish the E1 exclusion stages; describe the main as authored synthesis and the SI as deterministic extraction plus explicit author classification; replace “cannot drift” with a verifiable fixed input/output binding; provide per-row source locators and mark unavailable primary support narrowly. Keep the honest statement that no immutable public release has yet been checked. A public release remains a later release requirement, not a commissioning prerequisite for this scientific check.

**Closure evidence:** the frozen displays contain the available facts needed to interpret each asserted grade, identify unknown uncertainty/source fields honestly, and bind their actual source bytes and current interpretations. No raw-statistics reanalysis, benchmark rerun, primary-source hunt or new figure is needed.

### R4 — P2: 17 is the first-prefix result count, not the combined two-prefix count

**Accepted findings affected:** F04 and F12.

M:701–707 and C:150–152 name **both** `nrv04-covalent-results/` and `nrv04-covalent-results-chainfix/` but report 17 final per-leg records. SI:45 reports 18. The existing fixed source resolves the issue directly:

- `nrv04-result-forensics.json:30–34`: **17** `leg_result` objects in `nrv04-covalent-results/`.
- `nrv04-result-forensics.json:1334–1338`: **1** in `nrv04-covalent-results-chainfix/`.
- `:671–674` and `:1413–1416`: **0** multi-frame trajectory objects in each survey.

E:113–116 sums the two existing survey counts, so **the SI's 18 is correct for the combined prefixes**. Correct the main, C7 and the response's repeated count to “17 under the original prefix and 1 under the chainfix prefix (18 stored result objects across both).” Do not relabel them 18 independent experiments or 18 originally intended panel legs. The original review's 17 is the first-prefix count; it should not be generalized to both surveys. This correction does not alter the absent-coordinate conclusion or imply any newly discovered trajectory.

### R5 — P2: a remaining E1 mechanism sentence crosses the corrected ligand boundary

**Accepted finding affected:** F01.

M:431–433 says that “the published selectivity turns on a single hydrogen bond.” The panel's actual reference is now correctly identified as PRT3789. But `selcal_panel.py:136–145` explicitly identifies the hydrogen-bond statement as a mechanism citation about the SMARCA2/SMARCA4 pair and VCB, **not a claim about PRT3789**. C:59–61 states this correction accurately. M:431–433 fails to carry it at the point of use.

**Required correction:** attribute the hydrogen-bond observation to its cited system/ligand context and make the transfer to the PRT3789 panel an unestablished mechanistic rationale, or omit the sentence. The sentence can simply say that the record does not separate an insensitive E1 readout from an unsuitable or structurally narrow test, with input validity also unresolved. Do not infer an expected Ångström effect or fetch the unavailable body of the reference. This is a source-identity correction already within F01.

## 4. What does not require reopening

The following parts of the repair are scientifically appropriate at the scope accepted by the original review:

- The failed endpoint control is executed evidence, with `NULL` and register `fails` retained; no technical failure is invented and no power is inferred from the permutation floor.
- S remains a reported conditional estimate with two-seed dispersion, comparability limits and no known-answer calibration; neither absence of a wedge nor a quantitative effect bound follows.
- Repeated wrong-sign valB calibration remains a failure of the operational calibration. Closure is not a causal diagnostic and no proposed spending or extra sampling is authorized by this review.
- The contaminated and clean co-fold sets, wrong interface, units and wrong physical tether are separated. Coordinate absence limits rescoring at the surveyed prefixes; it does not turn every historical observation into no evidence.
- D3 remains **0 gradeable among 12 listed cases: 2 R2b exclusions, 6 `dock.prm` UNRUN, 1 fetch refusal, 3 alignment refusals**. Six actual cross-method pose comparisons executed. These counts must not be collapsed into twelve failed docking executions or “the method never ran.” M:511–527 preserves the distinction.
- V4 remains built/staged, without a completed result, unrun and unauthorized. V21 remains 7/10 with `panel_readable: false` and the same three blocking receptors. No failed target is dropped or threshold changed.
- The biological genetics statements remain a qualitative concern about complete developmental loss, with no measured adult drug equivalence, safe exposure, sparing percentage or therapeutic window.
- The external-publication refutation remains withdrawn unless the exact already-held released-case comparison and primary protocol are identified. Source absence should be scoped to evidence actually inspected; no alternate source route is commissioned.

The narrow audit does not need a new successful selectivity control, wet-lab experiment or restored trajectory to exist as a useful paper. It needs its own statements and source hierarchy to be coherent. The remaining issues are not cured by calling the original findings “applied.”

## 5. Actual execution evidence and limits

All returned author `.cmd`, `.stdout`, `.stderr` and `.exit` files for attempts 01–22 were retained byte-for-byte and hashed. They were inspected as execution/provenance evidence, with bounded MF1-line and summary inspection of the large repository-wide streams. I did not perform a new broad gate sweep or a full scientific review of unrelated files named in those streams.

The raw outputs matter more than the README's compressed account:

| existing author record | actual retained result | scope of what it establishes |
|---|---|---|
| 05 / 14 / 20 `systems_check` | exit 1 in all three; **2695 / 2667 / 2666 ERROR**, respectively | attempt 14 still reports the MF1 termination memo's missing frontmatter; attempt 20 no longer does. README's claim that both attempts 2 and 3 had 2666 errors and no owned-file error is inaccurate for attempt 2. Preserve all streams and correct the summary; do not rerun the gate to change history. |
| 03 / 12 citation check | exit 1; 13 type-claim errors in the retained diagnostic summary | these are not a scientific acceptance or rejection of MF1; the cited errors identify other report paths. No new source retrieval follows from their embedded guidance. |
| 06 / 15 systems-map check | exit 1; 6 ERROR | no MF1 scientific clearance follows. |
| 18 owned-file claims check | exit 0; 0 ERROR, 6 WARN across 5 files | actual owned-file run, but it misses the SI's semantic contradictions. A green lint is not closure of F01–F12. |
| 19 default claims check | exit 0; 0 ERROR, 183 WARN across 138 files | broad corpus output; no new scientific conclusion. |
| 04 / 13 changed-prose check | exit 0; **0 changed passages** | cannot substantiate a claim that the repaired prose was substantively checked by this command. |
| 08 / 17 readability report | exit 0; output lists other target documents, not MF1 | advisory output, not an MF1 readability assessment. |
| 09 extraction | exit 0; 10 rows, 22 inventory entries, 17 inputs; recorded commit `5f40f49b4f41cb16a32862e607baeb060b333c6c` | an earlier author extraction, distinct from the final frozen display. |
| 22 final extraction | exit 0; 10 rows, 22 inventory entries, 17 inputs; recorded commit `d5eb86e8093df671da081ea56b67dcfd79e1f0fe` | final recorded author extraction. Its `.cmd` is abbreviated (`python3 .../extract_mf1_inventory.py (final settle)`), so the README's claim that every command file is exact is too strong. Do not manufacture the missing literal invocation. |

These reporting corrections are provenance cleanup within the finite batch. Inherited repository failures are not used as an automatic scientific HOLD, and none of these checks substitutes for the observed current-claim defects.

**New reviewer work:** `verify_package_metadata.py` performs bookkeeping only: it compares the 17 declared input identities against the retained fixed inputs, lists SI instrument IDs, copies the existing per-prefix count fields, and summarizes the preserved author check streams. It does not execute the author extraction or original reviewer calculations. The first run failed at console serialization with `UnicodeEncodeError` under Windows cp1252 (exit 1); its original stdout/stderr/exit remain preserved. The second run used `PYTHONIOENCODING=utf-8` and completed (exit 0), with its own distinct stdout/stderr/exit. No first-attempt output was overwritten. The successful metadata output confirms 17/17 input identity matches and all 22 SI IDs; it does not confer scientific validity on those records.

Other work in this workspace consisted of immutable retention, file reads, hashing, and bounded text/field inspection. No simulation, co-fold, docking, geometry recomputation, raw biological reanalysis, new statistical inference, installation, network source request or publisher/registry action occurred. No reviewer illustrative uncertainty quantity was recalculated or reused as primary evidence.

## 6. Integration status and stopping condition

The 01dd return contains **proposed** shared roadmap/graph edits. At that pin, `PUB-METHODS` still has the diagnosed-mechanism formulation, and the named census rows still contain superseded interpretations. This report does not assume parent integration from a patch file, a promise or a later unrelated commit. **No later integrated binding was part of this verification.** Root instructed this verification to finish on the already demonstrated defects rather than wait for routine integration; those defects in the returned SI/main persist regardless of whether P1–P6 are subsequently applied. No piecemeal new repair was commissioned by this reviewer.

**Finite closure condition:** root can adjudicate this one residual batch against the actual returned texts: R1's current scopes and dependency propagation, R2's attributed chronology, R3's complete available grading/provenance facts, R4's per-prefix count, and R5's ligand-specific mechanism qualification. Correct the inaccurate check-summary statements and narrow the external-source absence wording at the same time. Preserve original scientific outputs and failure records. The scientific proposition stays the narrow retrospective audit; stronger causal, sensitivity, therapeutic or field-general claims remain held under the original source-level reopening conditions.

This focused verification is not a request for an additional baseline, a new science campaign, or another round of generic publication gates. It identifies the remaining concrete text/data-display corrections in the already accepted F01–F12 scope.

The accompanying `REVIEWED-INPUT-MANIFEST.json` and `.md` distinguish full reading, bounded source/field inspection, identity-only retention and preserved execution streams. The `DELIVERABLE-HASHES.json` records this report, manifests and new bookkeeping evidence. A retained file is not automatically a full scientific read.
