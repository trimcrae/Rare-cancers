"""Freeze honest retention/read scope and hashes; no scientific computation."""
from pathlib import Path
import json, hashlib
from collections import Counter

ROOT = Path(__file__).resolve().parent
records = json.loads((ROOT/'retained-inputs.json').read_text(encoding='utf-8'))
full_external = {'FINAL-SCIENTIFIC-REVIEW-MF1.md', 'MF1-final-review-root-adjudication-20260908.md',
    'F01-F12-response-matrix.md', 'CURRENT-SUMMARY-PATCHES.md', 'PACKAGE-MANIFEST.json',
    'MF1-dependency-manifest.json', 'extract_mf1_inventory.py', 'TERMINATION-AND-RESUME-RECORD.md', 'README.md'}
full_git = {'degrader-methods-failure-record.md','degrader-methods-failure-record-SI.md',
    'corrective-interpretations-2026-09-08.md','nr4a3-5aks-reduction.json'}
bounded = {
    'selcal-verdict.json': 'lines 1-62 and manifest identity; reference/criterion/model-count fields; no statistical rerun',
    'valb-failure-propagation.json': 'lines 1-56, measured-estimand and power field identities; original results only',
    'nrv04-result-forensics.json': 'survey by_class and recompute_verdict fields, exact two-prefix counts and named result-object/source lines; no trajectory/geometry analysis',
    'nr4a2-sparing-bound.json': 'lines 2257-2278: current conclusion, caveat, tolerance wording and primary-cited survival annotation',
    'instrument-census.json': 'all relevant V1-V22 classification mapping through the SI; direct source fields for V1-V11, V16 and V20, especially benchmark identities/results and scope_limit; no new universe audit',
    'nrv04-cofold-chain-forensics-2026-07-24.md': 'lines 25-115: affected prefixes, chain identity, wrong tether, current fixes, and separate valB input source',
    'selcal_panel.py': 'lines 89-147: reference identity, no quantitative E1 link, deposited structures, and ligand-qualified mechanism citation',
    'selectivity-sensitivity-control-prereg.md': 'lines 1-48: backfilled metadata, pre-run assertion, amendment and 24-versus-22 leg eligibility',
    'nr4a3-program-map.md': 'bounded searches and current rows/entry points for the accepted F01-F03/F07/F09/F11 shared patches; not a full roadmap or other-paper review',
    'publications.json': 'PUB-METHODS record lines 331-344 only; other records not scientifically reviewed'
}
small_streams = {'01-lint_consistency.stdout','04-lint_changed_prose.stdout',
    '07-lint_submission_residue.stdout','08-lint_readability.stdout','09-extract_rerun.stdout',
    '10-lint_consistency-attempt2.stdout','13-lint_changed_prose-attempt2.stdout',
    '16-lint_submission_residue-attempt2.stdout',
    '17-lint_readability-attempt2.stdout','18-lint_claims-owned-files.stdout',
    '21-lint_consistency-attempt3.stdout','22-extract-final.stdout'}
for r in records:
    name = Path(r['retained_path']).name if r['kind']=='git' else Path(r['source']).name
    data=Path(r['retained_path']).read_bytes()
    assert len(data)==r['bytes'] and hashlib.sha256(data).hexdigest()==r['sha256'], r['source']
    if (r['kind']=='git' and name in full_git) or (r['kind']=='external' and name in full_external):
        category, scope='full reading','full text read in this focused verification; scientific scope limited to accepted F01-F12'
    elif r['kind']=='git' and name in bounded:
        category, scope='bounded inspection',bounded[name]
    elif r['kind']=='external' and name.endswith(('.cmd','.exit')):
        category, scope='execution metadata','full command/exit text read; preserved original author record, not reviewer execution'
    elif r['kind']=='external' and name.endswith(('.stdout','.stderr')):
        category='execution stream'
        scope=('empty stream retained and byte-verified' if len(data)==0 else
            'full small output inspected' if name in small_streams else
            'bounded final-summary and MF1-line inspection; exact full stream retained, no unrelated full-corpus review')
    else:
        category, scope='identity-only retention','exact bytes/hash/Git identity retained for input/output lineage; not separately full-read or independently scientifically re-reviewed'
    r['read_category']=category
    r['review_scope']=scope
manifest={'review':'ONE focused verification of accepted MF1 F01-F12 repair; not a new baseline',
    'return_pin':'01dd5a211c87e0044d735a8c840a9860da42b529',
    'no_later_integrated_binding_reviewed':True,
    'limitations':'No new source, producer, original reviewer calculation, simulation, geometry, broad gate, or manuscript edit. Retention is not full reading. 17 extraction-input identities matched.',
    'input_count':len(records),'read_categories':dict(Counter(r['read_category'] for r in records)),
    'files':records}
(ROOT/'REVIEWED-INPUT-MANIFEST.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
lines=['# MF1 focused verification: exact retained-input and read-scope manifest','',
    f'{len(records)} retained inputs. Exact byte/hash identity does not imply full scientific reading. The categories below state actual scope.',
    '', '| original source | retained path (relative to this workspace) | bytes | SHA-256 | Git blob | actual read scope |',
    '|---|---|---:|---|---|---|']
for r in records:
    values=[r['source'],str(Path(r['retained_path']).relative_to(ROOT)),str(r['bytes']),r['sha256'],r['git_blob'] or 'external original',r['read_category']+': '+r['review_scope']]
    lines.append('| '+' | '.join(x.replace('|','\\|').replace('\n',' ') for x in values)+' |')
(ROOT/'REVIEWED-INPUT-MANIFEST.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
deliverables=[]
names=['FOCUSED-SCIENTIFIC-VERIFICATION-MF1.md','REVIEWED-INPUT-MANIFEST.json','REVIEWED-INPUT-MANIFEST.md',
    'REVIEWER-EXECUTION-RECORD.md','verify_package_metadata.py','verify-package-metadata.stdout.json',
    'verify-package-metadata.stderr.txt','verify-package-metadata.exit.txt','verify-package-metadata-attempt2.stdout.json',
    'verify-package-metadata-attempt2.stderr.txt','verify-package-metadata-attempt2.exit.txt',
    'retain.py','read_lines.py','freeze_review_manifest.py','repair-intake.stdout.jsonl',
    'dependency-intake.stdout.jsonl','shared-input-intake.stdout.jsonl','retained-inputs.json']
for name in names:
    data=(ROOT/name).read_bytes()
    deliverables.append(dict(path=str(ROOT/name),bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
(ROOT/'DELIVERABLE-HASHES.json').write_text(json.dumps({'files':deliverables},indent=2)+'\n',encoding='utf-8')
print(json.dumps({'inputs':len(records),'read_categories':manifest['read_categories'],'deliverables':deliverables[:4]},indent=2))
