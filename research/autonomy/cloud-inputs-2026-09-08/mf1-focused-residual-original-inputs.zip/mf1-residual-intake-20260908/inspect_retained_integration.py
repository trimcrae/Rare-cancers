"""Bounded read/hash/compare of already-retained MF1 integration artifacts; no producers."""
import hashlib, json, re
from pathlib import Path

OUT = Path(__file__).resolve().parent
WORK = OUT.parent / 'mf1-focused-verification-20260908'
OBS = Path('C:/Users/mcrae/.codex/review-workspaces/opus-capacity-sprint-20260907/capacity-campaign-20260908/observations')
A6 = OBS / 'a6a21fc5'
B5 = OBS / 'b57754a8/MF1-integration-record'
INDEX = A6 / 'MF1-SHARED-INTEGRATION-artifact-locators.json'
idx = json.loads(INDEX.read_text(encoding='utf-8'))
inventory = []
def read(path, scope, expected=None):
    p = Path(path); b = p.read_bytes()
    rec = {'path': str(p), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest(), 'read_scope': scope}
    if expected:
        rec['declared_bytes'] = expected['bytes']; rec['declared_sha256'] = expected['sha256']
        rec['declared_identity_match'] = rec['bytes'] == expected['bytes'] and rec['sha256'] == expected['sha256']
        if expected.get('git_blob'):
            rec['git_blob'] = hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest()
            rec['declared_git_blob'] = expected['git_blob']; rec['git_blob_match'] = rec['git_blob'] == expected['git_blob']
    inventory.append(rec)
    return b.decode('utf-8-sig')
read(INDEX, 'full locator metadata')
texts = {}
for group in ['before', 'after', 'exact_diffs']:
    for item in idx[group]:
        texts[(group, item['repo_path'])] = read(item['local_path'], 'identity; bounded MF1 before/after fields or exact changed lines', item)
for field in ['full_exact_diff', 'original_commit_record', 'retained_original_source_patch', 'intake_receipt']:
    read(idx[field]['local_path'], 'full exact retained artifact', idx[field])
patch_text = Path(idx['retained_original_source_patch']['local_path']).read_text(encoding='utf-8')
targets = json.loads(read(B5 / 'originals/patch-targets-as-applied.json', 'full exact OLD/NEW target pairs'))
for p in sorted((B5 / 'originals').glob('instrument_census.*.txt')):
    read(p, 'full original execution stream; not rerun')
read(B5 / 'originals/SHA256SUMS.txt', 'full original declared hash record')
read(B5 / 'MF1-INTEGRATION-EXECUTION-RECORD.md', 'full retained execution-provenance narrative and limitations')
for f in ['FOCUSED-SCIENTIFIC-VERIFICATION-MF1.md', 'REVIEWER-EXECUTION-RECORD.md', 'verify-package-metadata.stdout.json', 'verify-package-metadata.stderr.txt', 'verify-package-metadata.exit.txt', 'verify-package-metadata-attempt2.stdout.json', 'verify-package-metadata-attempt2.stderr.txt', 'verify-package-metadata-attempt2.exit.txt']:
    read(WORK/f, 'R1-R5 and execution/stopping sections or preserved bookkeeping streams; no re-execution')
road = 'research/manuscripts/nr4a3-program-map.md'
pub = 'systems/graph/publications.json'
def line_of(s, needle):
    at = s.find(needle)
    return None if at < 0 else s.count('\n', 0, at) + 1
applied=[]
for tag, old, new in targets['pairs']:
    before, after = texts['before',road], texts['after',road]
    applied.append({'patch':tag,'path':road,'old_before_count':before.count(old),'new_after_count':after.count(new),'old_after_count':after.count(old),'after_line':line_of(after,new),'old':old,'new':new})
for tag,field in [('P1','what_it_would_claim'),('P2','outcome_potential_why')]:
    section = patch_text.split('## '+tag+' ·')[1].split('\n## ')[0]
    blocks = re.findall(r'```\n(.*?)\n```',section,re.S)
    old,new = [json.loads(x) for x in blocks[:2]]
    before,after=texts['before',pub],texts['after',pub]
    applied.append({'patch':tag,'path':pub,'field':field,'old_before_count':before.count(old),'new_after_count':after.count(new),'old_after_count':after.count(old),'after_line':line_of(after,new),'old':old,'new':new})
bound_lines = {}
for group in ['before','after']:
    bound_lines[group] = [{'line':i,'text':line} for i,line in enumerate(texts[group,road].splitlines(),1) if '0.65' in line]
def json_diff(a,b,path=''):
    if type(a)!=type(b): return [{'field':path,'before':a,'after':b}]
    if isinstance(a,dict):
        changes=[]
        for k in sorted(a.keys()|b.keys()):
            if k not in a or k not in b: changes.append({'field':path+'/'+k,'before':a.get(k),'after':b.get(k)})
            else: changes.extend(json_diff(a[k],b[k],path+'/'+k))
        return changes
    if isinstance(a,list):
        if len(a)!=len(b): return [{'field':path,'before':a,'after':b}]
        return [d for i,(x,y) in enumerate(zip(a,b)) for d in json_diff(x,y,path+'/'+str(i))]
    return [] if a==b else [{'field':path,'before':a,'after':b}]
json_changes = {}
for repo in [pub,'research/modalities/instrument-census.json']:
    json_changes[repo] = json_diff(json.loads(texts['before',repo]),json.loads(texts['after',repo]))
patterns = ['| V5 |','| V11 |','| V16 |','| V20 |','adequately powered','marginal wedge is absent','single hydrogen bond','no downstream method','what it does NOT bound','no bound']
residual_rows = [{'line':i,'text':line} for i,line in enumerate(texts['after',road].splitlines(),1) if any(p.lower() in line.lower() for p in patterns)]
result={'scope':'Mechanical comparison of retained a6 bytes against c6; focused report remains pinned to 01dd. No new science or test execution.','index_commit':idx['commit'],'index_parent':idx['parent'],'identities':inventory,'exact_target_presence':applied,'withdrawn_quantity_lines':bound_lines,'json_leaf_changes':json_changes,'bounded_roadmap_current_claim_rows':residual_rows,'changed_files':[x['repo_path'] for x in idx['after']]}
(OUT/'integration-evidence.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'identities_checked':len(inventory),'identity_mismatches':[x for x in inventory if x.get('declared_identity_match') is False or x.get('git_blob_match') is False],'patch_counts':[{k:v for k,v in x.items() if k not in ['old','new']} for x in applied]},ensure_ascii=False,indent=2))
census_text = texts['after','research/modalities/instrument-census.json']
for row in json.loads(census_text)['instruments']:
    if row['id'] in ['V5','V11','V16','V20']:
        print(json.dumps({'id':row['id'],'result':row['result'],'scope_limit':row['scope_limit'],'id_line':line_of(census_text,'"id": "'+row['id']+'"')},ensure_ascii=False))
for i,line in enumerate(texts['after',road].splitlines(),1):
    if any(s in line for s in ['adequately powered','no downstream method','S ≈ 0','with a quantified bound']):
        print(str(i)+': '+line)
print((B5/'originals/SHA256SUMS.txt').read_text())
print(json.dumps([r for r in inventory if 'verify-package-' in r['path']],indent=2))
