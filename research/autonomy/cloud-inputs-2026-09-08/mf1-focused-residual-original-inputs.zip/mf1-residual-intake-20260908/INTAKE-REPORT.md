# MF1 retained-input and residual-integration intake

Mechanical intake, 2026-09-08. **124/124 retained paths match the declared byte count and SHA-256; zero missing files and zero mismatches.** Total retained bytes: **5,297,699**. This verifies retained identities, not scientific acceptance or full reading of every retained source.

The focused review pins **01dd5a211c87e0044d735a8c840a9860da42b529** and explicitly excludes any later integrated binding. Its residuals must therefore be combined with the actual **a6a21fc591d2451038cdf53449b91e3990d59cfb** shared delta, whose parent is **c6d97dcc2043bd2a21c749339637286915a29a82**. **P1–P6 already landed; do not reapply them.** Their partial downstream propagation does not close R1–R5.

## Exact scope and artifacts

Paths below use these absolute roots:

- `W = C:/Users/mcrae/Documents/Codex/2026-09-07/emc-research-orchestrator/work/mf1-focused-verification-20260908`
- `O = C:/Users/mcrae/.codex/review-workspaces/opus-capacity-sprint-20260907/capacity-campaign-20260908/observations`
- `A = O/a6a21fc5`
- `B = O/b57754a8/MF1-integration-record`

Read/hash scope: all 124 absolute `retained_path` entries in `W/REVIEWED-INPUT-MANIFEST.json` for identities only; the focused report's R1–R5, execution and stopping sections; its saved bookkeeping failure/success records; the a6 locator and seven before/after files plus seven exact diffs; the full retained P1–P6 proposal and integration narratives; the four original b577 census/target files and original hash list. Before/after text inspection was confined to MF1 patch targets, changed JSON fields, three generated-view diffs and necessary residual current-summary rows. No Git command, fetch, source retrieval, test, scientific producer, source edit or shared-state mutation occurred.

`W/REVIEWED-INPUT-MANIFEST.json`: **89,581 B**, SHA-256 **932fd9ff5ff3d199028447ac1e9b0af8eeb4a2d4e12e87502c9f1a90d4272323**. The per-file result is `retained-124-verification.json` beside this report. `integration-evidence.json` records 40 additional read/hash entries, including every declared a6 before/after/diff identity; all declared bytes/SHA-256 and available Git-blob identities match. Its JSON leaf comparisons are exact; its bounded roadmap rows are evidence, not a new source audit.

## Applied changes: avoid duplicate repair

Each of the **11 transcribed targets** below has exactly one OLD occurrence before, one NEW occurrence after, and zero OLD occurrences after. The original target JSON supplies nine roadmap pairs; P1/P2 are checked against their exact quoted strings in the retained proposal.

| Target | Actual a6 location | Applied wording change |
|---|---|---|
| P1 | `A/systems/graph/publications.json:337`, array item 18 (`PUB-METHODS`).`what_it_would_claim` | Exactly supported claims / each diagnosed mechanism → route-selected retrospective instrument records, separate control/execution/outcome/scope, retained evidence per failure |
| P2 | same file:342, `outcome_potential_why` | Each failure has diagnosed mechanism → retained evidence, including unidentified cause |
| P3a | `A/research/manuscripts/nr4a3-program-map.md:691` | Claimed 0.65 bound → exploratory conditional estimate with two-seed dispersion, not confidence/equivalence/effect bound |
| P3b | same:987 | “what it bounds” → explicit bound withdrawal |
| P3c | same:1778 | V16 **result** bound language → conditional estimate |
| P4a / P4b / P4c | same:1290 / 1311 / 1767 | Closure localizes endpoint miss / excludes sampling → does not diagnose cause or exclude shared sampling bias |
| P5 | same:1803 | Orientation-only → 4 same-cavity, 1 different-cavity among 5 gradeable; 1 excluded |
| P6a / P6b | same:2508, two cells | External released-case 66-atom refutation → withdrawn; cited record is a 64-atom preparation |

The **two additional P3b repetitions** also changed: R11 row before:2416 → after:2424, and dependency row before:3238 → after:3246 now explicitly withdraw the 0.65 bound. This supplies the claimed total of **13 edits**. The dependency row still contains the preceding phrase **“with a quantified bound”** before its withdrawal; the new withdrawal has not removed that contradictory clause.

Exact a6 census JSON changes are only:

1. `/instruments/4/scope_limit` (V5): closure-diagnosis claim → explicit non-diagnostic interpretation.
2. `/instruments/15/result` (V16): bound → conditional estimate. **Its `scope_limit` did not change.**
3. `/coverage/4/hole_verbatim` (requirement R5 pose row): orientation-only → mixed cavity counts. This coverage-row R5 is distinct from focused-review residual R5 concerning the E1 ligand mechanism.

The seven-file delta is roadmap, census JSON/Markdown, graph JSON and three views. The generated methods and publications views carry the scoped P1 claim and repaired MF1 title. The partner view and corresponding L3 section also pick up the previously repaired fusion-partner title. There are no MF1 main, SI, extraction, inventory, input-manifest or response-matrix changes in this delta. Exact complete file identities are in `integration-evidence.json`; no additional science change is inferred from title propagation.

## Residual propagation against the existing R1–R5 report

| Existing residual | What a6 resolves | What remains demonstrated or outside this delta |
|---|---|---|
| R1: current scope and dependency | P1/P2 graph wording; V5 source/census scope; V16 result wording | V16 **scope** still permits a bound and says S≈0 means wedge absent; V20 universal no-recovery scope and V11 powered-NULL result remain. Dependent SI still requires current-scope correction or explicit historical pin plus current override, then bound SI/inventory/manifest/response identities. The “no regeneration needed” instruction remains in the unchanged proposal. |
| R2: chronology and shared-input attribution | None of the MF1 main-text targets occur in the delta | Existing report's M:146–152, 374–386, 402–403, 751–766 attribution fixes remain unclosed by a6. V16 census result itself still says “registered in advance.” Historical protocol bytes should remain historical. |
| R3: grading facts, exclusion stages, display provenance | No display/extraction changes | Existing benchmark identity/reference/result/criterion fields, original 24-leg design → excluded SMARCA4 seed 3 → 22 admitted legs, authored-main versus extracted-SI attribution, source locators and exact byte binding remain the finite requested work. |
| R4: prefix-specific count | No main/response changes | Existing source counts remain 17 original-prefix + 1 chainfix-prefix = 18 stored result objects; main/C7/response correction is outside a6. No independent-experiment inference follows. |
| R5: ligand-specific mechanism | No main change | Existing M:431–433 hydrogen-bond rationale still needs attribution/qualification or removal under the already-held ligand boundary; the pose coverage R5 edit is not this correction. |

Concrete a6 residual locators:

- Census `A/research/modalities/instrument-census.json`: V11 `result` at :156 is `NULL, adequately powered`; V16 `result` at :227 is corrected but still asserts advance registration; V16 `scope_limit` at :228 still says **“S may be read as a bound”** and **“the marginal wedge is absent”**; V20 `scope_limit` at :301 still says a signal smaller than its noise is **“not recoverable by any downstream method.”**
- Roadmap :986 retains **“S ≈ 0 → the marginal wedge is absent”**; :1773 retains V11 adequately powered; :1778 contains the corrected V16 result beside its unchanged scope; V20 source row is :1783. Necessary current entry-point supersession remains as identified by R1; no wholesale historical rewrite is inferred.
- Roadmap :3246 retains **“with a quantified bound”** immediately before its explicit withdrawal, as noted above.
- Proposal `O/01dd5a21/MF1-repair/patches/CURRENT-SUMMARY-PATCHES.md:249–252` still claims the MF1 extraction needs no regeneration because it does not read the roadmap. The focused report already documents the indirect roadmap → census → extraction → SI dependency. The a6 commit repeats that inaccurate no-regeneration claim.

The focused report's additional finite provenance cleanup (attempt-14 versus attempt-20 gate summaries, abbreviated final-extraction command, narrowly scoped external-source absence) also has no implementing file in a6. This is a routing map of existing findings, not a fresh scientific adjudication of a6 or any later working tree.

## Original execution provenance and preserved failures

`B/MF1-INTEGRATION-EXECUTION-RECORD.md` identifies the original admitted census command as `python3 research/modalities/instrument_census.py`, executed against c6 HEAD with dirty working inputs; its original files survive:

| Original | Bytes | SHA-256 | Content |
|---|---:|---|---|
| `B/originals/instrument_census.stdout.txt` | 1,472 | `7422c39bb84a1b8f0a227cc13bd17cfd402f461261fcf9ac1a30935be73018e6` | Wrote 22 instruments, 16 requirements; preserves original status/requirement counts |
| `B/originals/instrument_census.stderr.txt` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` | Empty |
| `B/originals/instrument_census.exit.txt` | 2 | `9a271f2a916b0b6ee6cecb2426f0b3206ef074578be55d9bc94f6f3fe3ab86aa` | Original exit 0 |
| `B/originals/patch-targets-as-applied.json` | 4,498 | `2efbd7cbc8b52ab1415b2a409ff046e9f1df672a2a2597e5ec8df185c7566c16` | Nine exact roadmap OLD/NEW pairs and graph occurrence counts `[1,1]` |

The original SHA256SUMS provides 16-character prefixes; all four agree with these actual full hashes. The record explicitly says no original patch-application streams survive and the three view-operation streams were sent to `/dev/null`. Reported uniqueness/view exits and G2 counts remain narrative claims, supplemented here by actual committed before/after bytes. They are not newly captured original logs or current gate proof.

The focused review's first bookkeeping run remains **exit 1**, with empty stdout and the original 652 B cp1252 `UnicodeEncodeError` traceback (SHA-256 `49afbc96328c1c79a5132b45ac6a988f06c92cccc4e8ca82a5ab67d0e6b1cf07`). Its 3 B exit file hashes to `f1b2f662800122bed0ff255693df89c4487fbdcf453d3524a42d4ec20c3d9c04`. Attempt 2 has its own 45,322 B stdout, empty stderr, exit 0; none replaced the failed files. Original author exit-1 records are included among the 124 unchanged retained inputs. No failed scientific or gate result was relabeled as a pass.

For transparency, this intake also had one inline Python display command fail at parse time (exit 1, unterminated string literal caused by shell quoting). It executed no file reads or mutations. The subsequently saved read/compare script completed with exit 0; it only hashes and compares retained text. No scientific calculation or reviewer verification script was rerun.

**Routing conclusion:** preserve the applied P1–P6 edits and original execution records. Commission only the already-defined residual R1–R5/current-display/provenance batch against the actual integrated source binding; a6 is not evidence that the 01dd-focused residuals are closed. Acceptance and any later source binding remain root's decision.
