from pathlib import Path
import hashlib, json, os, subprocess, sys
ROOT = Path(__file__).resolve().parent
REPO = Path('C:/Projects/EMC-Research')
PIN = 'f43f1495f40d8aff7b4f34bd385d55aac521a500'
ENV = dict(os.environ, GIT_NO_LAZY_FETCH='1', GIT_TERMINAL_PROMPT='0')

def retain(data, destination, entry):
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(data)
    entry.update(bytes=len(data), sha256=hashlib.sha256(data).hexdigest(), retained_path=destination.relative_to(ROOT).as_posix())
    return entry

def collect_git(rel):
    result = subprocess.run(['git', '-C', str(REPO), 'cat-file', 'blob', PIN + ':' + rel], env=ENV, capture_output=True)
    entry = {'repo_path': rel, 'source': 'git:' + PIN + ':' + rel, 'exit_code': result.returncode, 'git_no_lazy_fetch': '1'}
    if result.returncode == 0:
        retain(result.stdout, ROOT / 'inputs/frozen' / rel, entry)
    else:
        entry['stderr'] = result.stderr.decode('utf-8', 'replace')
    log(entry)

def log(entry):
    with (ROOT / 'collection-log.jsonl').open('a', encoding='utf-8') as out:
        out.write(json.dumps(entry, ensure_ascii=True) + '\n')
    print(json.dumps(entry, ensure_ascii=True))

def collect_local(src, rel):
    entry = {'source': str(src), 'exit_code': 0}
    retain(Path(src).read_bytes(), ROOT / 'inputs/local' / rel, entry)
    log(entry)

if __name__ == '__main__':
    if sys.argv[1] == '--local':
        collect_local(sys.argv[2], sys.argv[3])
    else:
        for rel in sys.argv[1:]: collect_git(rel)
