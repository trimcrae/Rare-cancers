# TCIP source-intake supplemental manifest

This supplements the immutable original reviewed-input manifest. Ten new inputs: seven original sources and three delivery-provenance records. Combined review: 30 distinct inputs. No new scientific calculation or baseline review.

Frozen manuscript: `f43f1495f40d8aff7b4f34bd385d55aac521a500`. Delivery: `c6d97dcc2043bd2a21c749339637286915a29a82`. Original sources: `216bd1b5fb25a56b90ef3cc2373e1fe68322708f`.

## 1. tcip-9mza-2026-08-07__cif_9MZA.txt

- Original source: `literature/tcip-9mza-2026-08-07/cif_9MZA.txt`
- Delivered: `C:/Users/mcrae/.codex/review-workspaces/opus-capacity-sprint-20260907/capacity-campaign-20260908/observations/c6d97dcc/TCIP-reviewer-source-copies/tcip-9mza-2026-08-07__cif_9MZA.txt`
- Retained: `source-intake/inputs/tcip-9mza-2026-08-07__cif_9MZA.txt`
- Bytes: 505711
- SHA256: `b81668a1eaeb1eb40e74c99b65f093f647fd78eec30cecf201aa83006bc75780`
- Git blob independently matched from bytes: `5a28267017322ccdd531f16cf5534278d3c61019`
- Read scope: Original retained fetch header and selected mmCIF metadata read: entry, citation, entity/polymer identity and chain mapping, method/refinement resolution, reference alignment/sequence-difference annotations, author-defined assembly and assembly evidence. Material locators include lines 1-12, 69-94, 128-188, 1634-1643, 1898-2020 (selected fields), 2183-2357. Atom-site coordinate table not scientifically remeasured or fully read; no geometry loaded into a computation.

## 2. tcip-9mza-2026-08-07__rcsb_entry_9MZA.txt

- Original source: `literature/tcip-9mza-2026-08-07/rcsb_entry_9MZA.txt`
- Delivered: `C:/Users/mcrae/.codex/review-workspaces/opus-capacity-sprint-20260907/capacity-campaign-20260908/observations/c6d97dcc/TCIP-reviewer-source-copies/tcip-9mza-2026-08-07__rcsb_entry_9MZA.txt`
- Retained: `source-intake/inputs/tcip-9mza-2026-08-07__rcsb_entry_9MZA.txt`
- Bytes: 14803
- SHA256: `5a333017d4fd48e561693c9a47373225abea2f7ff77e0c48d87716d6c10f07ff`
- Git blob independently matched from bytes: `cb483747c1bf9fc59d98a98d88c73aa96ee81cd9`
- Read scope: Successful original retained entry response: header and material payload fields struct, rcsb_primary_citation, rcsb_accession_info, rcsb_entry_info and entry identifiers read. Full response retained and parsed; other diffraction/refinement/software blocks not represented as a complete validation audit.

## 3. tcip-9mza-2026-08-07__rcsb_assembly_9MZA.txt

- Original source: `literature/tcip-9mza-2026-08-07/rcsb_assembly_9MZA.txt`
- Delivered: `C:/Users/mcrae/.codex/review-workspaces/opus-capacity-sprint-20260907/capacity-campaign-20260908/observations/c6d97dcc/TCIP-reviewer-source-copies/tcip-9mza-2026-08-07__rcsb_assembly_9MZA.txt`
- Retained: `source-intake/inputs/tcip-9mza-2026-08-07__rcsb_assembly_9MZA.txt`
- Bytes: 3621
- SHA256: `59e242396c964ca262928577809f234af5015526530ddcb6071cd04657221e3e`
- Git blob independently matched from bytes: `5b29296c8e377a18ac630833b16ce5564774777d`
- Read scope: Entire retained header/payload read, including author-defined A2B2 tetramer, identity operation, source-reported FRET support, monomer totals and assembly-level interface metadata. No geometry or assembly BSA recomputation and no independent FRET experiment review.

## 4. tcip-kat-structure-2026-08-07__rcsb_cite_pubmed_42476129.txt

- Original source: `literature/tcip-kat-structure-2026-08-07/rcsb_cite_pubmed_42476129.txt`
- Delivered: `C:/Users/mcrae/.codex/review-workspaces/opus-capacity-sprint-20260907/capacity-campaign-20260908/observations/c6d97dcc/TCIP-reviewer-source-copies/tcip-kat-structure-2026-08-07__rcsb_cite_pubmed_42476129.txt`
- Retained: `source-intake/inputs/tcip-kat-structure-2026-08-07__rcsb_cite_pubmed_42476129.txt`
- Bytes: 764
- SHA256: `78cbff3e1f58894848d8ff096868f83484d802658eea357c20ee2a2f2444e20e`
- Git blob independently matched from bytes: `a8b2b7b6914e200b200fb0837c4b426a55d8fe44`
- Read scope: Entire original retained request/header/error body read. It is HTTP 400 invalid search attribute, not a successful citation record, zero-hit response or egress denial.

## 5. tcip-kat-structure-2026-08-07__epmc_kat_tcip_record.txt

- Original source: `literature/tcip-kat-structure-2026-08-07/epmc_kat_tcip_record.txt`
- Delivered: `C:/Users/mcrae/.codex/review-workspaces/opus-capacity-sprint-20260907/capacity-campaign-20260908/observations/c6d97dcc/TCIP-reviewer-source-copies/tcip-kat-structure-2026-08-07__epmc_kat_tcip_record.txt`
- Retained: `source-intake/inputs/tcip-kat-structure-2026-08-07__epmc_kat_tcip_record.txt`
- Bytes: 16691
- SHA256: `0b3548cbf5eeb0ceca189e0b44fe355ad732d51a1fd6a8b9ca16aa38d4eee957`
- Git blob independently matched from bytes: `72349a3b9b249f1b4dcd678c08f4b4acc06852b4`
- Read scope: Original DOI-query response inspected, including request/hitCount, both complete scientific abstracts, citation/update relationships, publication identifiers/dates and availability/license fields. No underlying publisher/preprint full text or supplement delivered/read. JSON string control characters tolerated only in a reading aid; source bytes unchanged.

## 6. induced-proximity-transcription-2026-08-07___index.json

- Original source: `literature/induced-proximity-transcription-2026-08-07/_index.json`
- Delivered: `C:/Users/mcrae/.codex/review-workspaces/opus-capacity-sprint-20260907/capacity-campaign-20260908/observations/c6d97dcc/TCIP-reviewer-source-copies/induced-proximity-transcription-2026-08-07___index.json`
- Retained: `source-intake/inputs/induced-proximity-transcription-2026-08-07___index.json`
- Bytes: 184617
- SHA256: `a9aa10d1e2445c72b492c319c6fc2913e47549dddda07fbf5b06c93b5595dee8`
- Git blob independently matched from bytes: `67125a84d72c42989005b60dd403a64add58b147`
- Read scope: All 100 bibliographic record objects mechanically parsed for field inventory and 20 fullTextFile pointers; selected primary KAT-TCIP article/preprint abstracts read and pointer metadata inspected. Not all abstracts screened or full-text bodies read; index has no broad-query/page/total-hit envelope. No scientific term/output classifications recomputed.

## 7. induced-interface-vs-output-2026-08-07___index.json

- Original source: `literature/induced-interface-vs-output-2026-08-07/_index.json`
- Delivered: `C:/Users/mcrae/.codex/review-workspaces/opus-capacity-sprint-20260907/capacity-campaign-20260908/observations/c6d97dcc/TCIP-reviewer-source-copies/induced-interface-vs-output-2026-08-07___index.json`
- Retained: `source-intake/inputs/induced-interface-vs-output-2026-08-07___index.json`
- Bytes: 613998
- SHA256: `44d8a43d13f1eef4848b1c1d1f2fe4eebe962e269dd8a665f5921c8f801dfb12`
- Git blob independently matched from bytes: `80f9e46734265876021e9816887ce22e58af6afc`
- Read scope: All 300 bibliographic record objects mechanically parsed for field inventory and 51 fullTextFile pointers; selected titles/pointer metadata inspected. Not all abstracts screened or full-text bodies read; index has no broad-query/page/total-hit envelope. No scientific term/output classifications recomputed.

## 8. MANIFEST.json

- Original source: `delivery provenance`
- Delivered: `C:/Users/mcrae/.codex/review-workspaces/opus-capacity-sprint-20260907/capacity-campaign-20260908/observations/c6d97dcc/TCIP-reviewer-source-copies/MANIFEST.json`
- Retained: `source-intake/inputs/MANIFEST.json`
- Bytes: 3808
- SHA256: `7c5ad424f2c347eb28e2ac3d5c9d18b72b46412d4d62fb912383e2a7bc44509e`
- Read scope: Full delivered source-copy manifest read. Seven actual source byte counts, SHA256 and Git blob IDs independently verified. Original-source and delivery revisions kept distinct.

## 9. SHA256SUMS.txt

- Original source: `delivery provenance`
- Delivered: `C:/Users/mcrae/.codex/review-workspaces/opus-capacity-sprint-20260907/capacity-campaign-20260908/observations/c6d97dcc/TCIP-reviewer-source-copies/SHA256SUMS.txt`
- Retained: `source-intake/inputs/SHA256SUMS.txt`
- Bytes: 1602
- SHA256: `de6eb0e6a8ab04bd83ac7b2b2a85b7693b2b762b2d3f5878d4f96a4ee7ea5610`
- Read scope: Full delivered digest list read. Seven source entries match; stale empty-file self-entry explicitly qualified. Exact erroneous original retained unedited.

## 10. TCIP-source-copy-verification.json

- Original source: `delivery provenance`
- Delivered: `C:/Users/mcrae/.codex/review-workspaces/opus-capacity-sprint-20260907/capacity-campaign-20260908/observations/c6d97dcc/TCIP-source-copy-verification.json`
- Retained: `source-intake/inputs/TCIP-source-copy-verification.json`
- Bytes: 6189
- SHA256: `fe4c198dd5fee71aa6a3d65321d7a6bb7e0ee775ccd72750edeaa9908ec4933c`
- Read scope: Full coordinator verification record read as provenance. Actual source-byte identity independently checked, rather than accepting the verification assertion alone.

## New intake artifacts

| Artifact | Bytes | SHA256 |
|---|---:|---|
| `SOURCE-INTAKE-ADDENDUM-20260908.md` | 19411 | `7d2941dbbd64c080b37ac619ff4532b66134d7eb782b9fdb3377c0c101ff77f6` |
| `source_intake.py` | 2070 | `7a5d9ae733c90d4d8a1ce9f0f3603b58b7125714f0eb6ef6528fef4ec86ec47a` |
| `inspect_source_records.py` | 2130 | `33b253cbe363cef30487a5b5de4ca9eca29adb398a4c6289ddb7d0955bd452bf` |
| `build_source_supplement.py` | 7434 | `d60c41739b5bd280bfb7962123f29e948efe4e11df64e61359adbfc06940199a` |
| `source-intake/intake-verification.json` | 7502 | `219220ab3d5dbc0cec23aa7f159a177e4a125b78fcfbb84e7929d435a25322ac` |
| `source-intake/material-record-excerpts.json` | 218184 | `657cd8e925f4244321941dca0c3fff2051779f5bb5af765ea331d792c9757053` |

All 12 artifacts listed by the original review hash file remain unchanged. The original report remains 52,425 bytes, SHA256 `a00bec7213282192725722bb84736470868523acaa13766c2dac44ea4da82101`.

Supplemental manifest files are excluded from their own embedded hashes. SOURCE-INTAKE-HASHES.txt covers their final bytes; no circular self-entry.
