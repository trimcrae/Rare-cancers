"""Build a separate supplemental provenance manifest; leave completed review artifacts unchanged."""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parent
def digest(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
original_checks=[]
for line in (ROOT/'REVIEW-ARTIFACT-HASHES.txt').read_text().splitlines():
 want,name=line.split('  ',1);actual=digest(ROOT/name)
 assert actual['sha256']==want,name
 original_checks.append({'path':name,**actual,'unchanged':True})
scopes={
 'tcip-9mza-2026-08-07__cif_9MZA.txt':'Original retained fetch header and selected mmCIF metadata read: entry, citation, entity/polymer identity and chain mapping, method/refinement resolution, reference alignment/sequence-difference annotations, author-defined assembly and assembly evidence. Material locators include lines 1-12, 69-94, 128-188, 1634-1643, 1898-2020 (selected fields), 2183-2357. Atom-site coordinate table not scientifically remeasured or fully read; no geometry loaded into a computation.',
 'tcip-9mza-2026-08-07__rcsb_entry_9MZA.txt':'Successful original retained entry response: header and material payload fields struct, rcsb_primary_citation, rcsb_accession_info, rcsb_entry_info and entry identifiers read. Full response retained and parsed; other diffraction/refinement/software blocks not represented as a complete validation audit.',
 'tcip-9mza-2026-08-07__rcsb_assembly_9MZA.txt':'Entire retained header/payload read, including author-defined A2B2 tetramer, identity operation, source-reported FRET support, monomer totals and assembly-level interface metadata. No geometry or assembly BSA recomputation and no independent FRET experiment review.',
 'tcip-kat-structure-2026-08-07__rcsb_cite_pubmed_42476129.txt':'Entire original retained request/header/error body read. It is HTTP 400 invalid search attribute, not a successful citation record, zero-hit response or egress denial.',
 'tcip-kat-structure-2026-08-07__epmc_kat_tcip_record.txt':'Original DOI-query response inspected, including request/hitCount, both complete scientific abstracts, citation/update relationships, publication identifiers/dates and availability/license fields. No underlying publisher/preprint full text or supplement delivered/read. JSON string control characters tolerated only in a reading aid; source bytes unchanged.',
 'induced-proximity-transcription-2026-08-07___index.json':'All 100 bibliographic record objects mechanically parsed for field inventory and 20 fullTextFile pointers; selected primary KAT-TCIP article/preprint abstracts read and pointer metadata inspected. Not all abstracts screened or full-text bodies read; index has no broad-query/page/total-hit envelope. No scientific term/output classifications recomputed.',
 'induced-interface-vs-output-2026-08-07___index.json':'All 300 bibliographic record objects mechanically parsed for field inventory and 51 fullTextFile pointers; selected titles/pointer metadata inspected. Not all abstracts screened or full-text bodies read; index has no broad-query/page/total-hit envelope. No scientific term/output classifications recomputed.',
 'MANIFEST.json':'Full delivered source-copy manifest read. Seven actual source byte counts, SHA256 and Git blob IDs independently verified. Original-source and delivery revisions kept distinct.',
 'SHA256SUMS.txt':'Full delivered digest list read. Seven source entries match; stale empty-file self-entry explicitly qualified. Exact erroneous original retained unedited.',
 'TCIP-source-copy-verification.json':'Full coordinator verification record read as provenance. Actual source-byte identity independently checked, rather than accepting the verification assertion alone.',
}
intake=json.loads((ROOT/'source-intake/intake-verification.json').read_text())
records=[]
for r in intake['records']:
 p=ROOT/r['retained_path'];actual=digest(p)
 assert actual['bytes']==r['bytes'] and actual['sha256']==r['sha256']
 r=dict(r,read_scope=scopes[p.name],reverified=True);records.append(r)
names=['SOURCE-INTAKE-ADDENDUM-20260908.md','source_intake.py','inspect_source_records.py',
 'build_source_supplement.py','source-intake/intake-verification.json','source-intake/material-record-excerpts.json']
artifacts=[{'path':n,**digest(ROOT/n),'provenance':'New reviewer source-intake artifact, not an original scientific result.'} for n in names]
out={'review':'Source-only completion of the same TCIP final scientific review, 2026-09-08',
 'base_report':{'path':'FINAL-SCIENTIFIC-REVIEW-TCIP.md',**digest(ROOT/'FINAL-SCIENTIFIC-REVIEW-TCIP.md')},
 'base_manifest':'REVIEWED-INPUT-MANIFEST.json','base_review_artifacts_all_unchanged':True,
 'frozen_manuscript_commit':'f43f1495f40d8aff7b4f34bd385d55aac521a500',
 'delivery_commit':intake['delivery_commit'],'original_source_commit':intake['original_source_commit'],
 'supplemental_input_count':len(records),'original_source_count':7,'provenance_input_count':3,
 'combined_input_count':30,'combined_scope':'20 original-review inputs plus these 10 distinct supplemental source/provenance inputs. Scientific calculation still one run, exit 0; no baseline or scientific rerun.',
 'source_operation_scope':intake['scope'],'inputs':records,'new_source_intake_artifacts':artifacts,
 'original_artifact_integrity':original_checks,
 'hash_note':'Supplemental manifest files are excluded from their own embedded hashes. SOURCE-INTAKE-HASHES.txt covers their final bytes; no circular self-entry.'}
(ROOT/'SOURCE-INTAKE-SUPPLEMENTAL-MANIFEST.json').write_text(json.dumps(out,ensure_ascii=True,indent=2)+'\n',encoding='utf-8')
lines=['# TCIP source-intake supplemental manifest','',
 'This supplements the immutable original reviewed-input manifest. Ten new inputs: seven original sources and three delivery-provenance records. Combined review: 30 distinct inputs. No new scientific calculation or baseline review.','',
 'Frozen manuscript: `'+out['frozen_manuscript_commit']+'`. Delivery: `'+out['delivery_commit']+'`. Original sources: `'+out['original_source_commit']+'`.','']
for i,r in enumerate(records,1):
 lines += [f'## {i}. {Path(r["retained_path"]).name}','','- Original source: `'+r.get('original_path','delivery provenance')+'`',
 '- Delivered: `'+r['delivered_path']+'`','- Retained: `'+r['retained_path']+'`',f'- Bytes: {r["bytes"]}',
 '- SHA256: `'+r['sha256']+'`']
 if 'git_blob' in r:lines.append('- Git blob independently matched from bytes: `'+r['git_blob']+'`')
 lines+=['- Read scope: '+r['read_scope'],'']
lines+=['## New intake artifacts','','| Artifact | Bytes | SHA256 |','|---|---:|---|']
for r in artifacts:lines.append(f'| `{r["path"]}` | {r["bytes"]} | `{r["sha256"]}` |')
lines+=['','All '+str(len(original_checks))+' artifacts listed by the original review hash file remain unchanged. The original report remains 52,425 bytes, SHA256 `a00bec7213282192725722bb84736470868523acaa13766c2dac44ea4da82101`.','',out['hash_note'],'']
(ROOT/'SOURCE-INTAKE-SUPPLEMENTAL-MANIFEST.md').write_text('\n'.join(lines),encoding='utf-8')
hashnames=names+['SOURCE-INTAKE-SUPPLEMENTAL-MANIFEST.json','SOURCE-INTAKE-SUPPLEMENTAL-MANIFEST.md']
(ROOT/'SOURCE-INTAKE-HASHES.txt').write_text('\n'.join(digest(ROOT/n)['sha256']+'  '+n for n in hashnames)+'\n',encoding='utf-8')
print(json.dumps({'supplemental_inputs':len(records),'combined_inputs':30,'base_artifacts_unchanged':len(original_checks),
 'addendum':artifacts[0]},ensure_ascii=True))
