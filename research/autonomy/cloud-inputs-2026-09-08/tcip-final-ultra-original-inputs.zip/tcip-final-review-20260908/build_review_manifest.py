"""Inventory exact retained TCIP review inputs and new reviewer artifacts; no science producer."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parent
PIN = 'f43f1495f40d8aff7b4f34bd385d55aac521a500'
SCOPES = {
 'research/manuscripts/tcip/tcip-induced-interface-preprint.md': 'Entire manuscript read, lines 1-393, including all appendices, references and six figure specifications. Material passages revisited with exact line numbers. No actual rendered figures were present in this manuscript.',
 'research/manuscripts/tcip/tcip-induced-interface-preprint-si.md': 'Entire SI read, lines 1-277, including all tables, controls, literature assertions and reproduction instructions.',
 'research/modalities/nr4a3-tcip-reach.json': 'All 576 cell count fields parsed; all per-rung pooled and per-arm summaries and all ablation floor counts inspected/recomputed. Cross-check 24-cell record, named-effector fields, body geometry and material metadata read. Not every serialized line of this 332 KB file read individually. No original placements reproduced.',
 'research/modalities/nr4a3-induced-interface-census.json': 'All 22 entries parsed for classes, candidate/retained pairs, directional counts and selected denominator reconstruction. Complete 9MZA entry read, including ligands, chain descriptions, candidate pairs and full retained profiles; material controls/summary metadata inspected. No independent distances calculated from coordinates.',
 'research/modalities/nr4a3_tcip_reach.py': 'Scientific branches read, including lines 70-128, 235-482, 561-690, 783-854, 870-934, 1541-1699 and 1704-1775; function/call-site searches used. Selected code lines revisited. Not a full 112 KB audit of generated prose/rendering branches. Never imported or executed.',
 'research/modalities/nr4a3_induced_interface_census.py': 'Scientific definitions, parser and census logic read, lines 1-230 and 231-738, including entry classes, exact-distance classifier, query construction, eligibility, zero-contact filter and CLI. Later output-rendering boilerplate not represented as a full read. Never imported or executed.',
 'research/modalities/nr4a3_basin_search.py': 'Selected material branches read: lines 52-139, 329-426, 445-482 and 514-641, plus function/index searches. Static PARAMS parsed with ast.literal_eval. Anchor construction and complete placement loop inspected. Other closed-program production/biological branches not audited or executed.',
 'research/manuscripts/tcip/tcip-interface-floor-sizing.md': 'Entire 343-line sizing memo read, including all source narratives, controls and literature assertions. Memo assertions not treated as independently verified original source responses.',
 'research/modalities/nr4a3-tcip-route-memo.md': 'Selected material historical enumeration, replication, ablation and named-effector/construct passages, especially lines 140-280, read. Historical 40,000-sample and determinism claims recorded as narrative, not original-run verification. Remaining unrelated route discussion not fully read.',
 'research/modalities/nr4a3-tcip-reach.md': 'Entire generated 201-line view read, including populated named-arm results and stale verdict contradictions. Derived prose not treated as an independent measurement.',
 '.claude/skills/paper-hardening/SKILL.md': 'Full frozen review guidance read. The standing commission controls review scope; no new baseline prepass or publication action was inferred.',
 '.claude/skills/repo-gates/SKILL.md': 'Full frozen guidance read. General publication gates were not run and not used as scientific acceptance evidence.',
 'research/modalities/basin_geom.py': 'Material distance-field and random-distribution branches read, including lines 20-40, 134-159, 259-328 and 369-382. Other geometry utilities not fully audited. No producer import/execution.',
 'research/modalities/nr4a3-orientation-basins.json': 'Selected original committed per-pose statistics and metadata; all 24 old count records used by the TCIP cross-check parsed for the reviewer uncertainty diagnostic. Other large program sections not fully read or reanalysed.',
 'research/modalities/nr4a3-e3-arm-registry.json': 'Root method/limitations and all four arm source-entry, assembly-copy, status and staged-path metadata inspected. Ligand-coordinate arrays not fully line-read and not used for remeasurement. A broad initial display truncated; scope here reflects subsequent selected reads, not full-file review.',
 'research/modalities/nr4a3-effector-arm-registry.json': 'Both named-arm discovery/source-entry, construct size, assembly-copy, status, staged-path, self-check and staging-log metadata read. Not independent source acquisition or validation of all ligand coordinates. A broad initial display truncated; no full-file read claimed.',
 'research/manuscripts/degrader/selectivity-requirement-sizing.md': 'Material binary odds derivation and assumptions (lines 100-165) and claimed ternary transfer (lines 384-403) read, with heading/term searches for context. Remainder of the separate closed-program argument not adjudicated.',
}
LOCAL_SCOPES = {
 'inputs/local/SETTLEMENT.md': 'Full commissioning settlement read; author settlement, 28 checks and restricted-question framing not accepted as scientific adjudication or as a limit on this final review.',
 'inputs/local/MANIFEST.md': 'Full preparation manifest read. Stale self-entry distinguished from actual bytes and material-input identities.',
 'inputs/local/HASHES.txt': 'Full hash file read; ten main/SI/material dependency hashes independently matched in the one reviewer arithmetic run.',
}
records=[]
for line in (ROOT/'collection-log.jsonl').read_text(encoding='utf-8').splitlines():
 item=json.loads(line)
 p=ROOT/item['retained_path']
 data=p.read_bytes()
 if len(data)!=item['bytes'] or hashlib.sha256(data).hexdigest()!=item['sha256']:
  raise RuntimeError('Retained bytes changed: '+item['retained_path'])
 item['read_scope']=SCOPES[item['repo_path']] if 'repo_path' in item else LOCAL_SCOPES[item['retained_path']]
 item['bytes_reverified_at_manifest']=True
 records.append(item)

artifact_names=['FINAL-SCIENTIFIC-REVIEW-TCIP.md','reviewer_calculations.py',
 'reviewer-calculations.json','reviewer-calculations-stdout.txt','reviewer-calculations-exit.txt',
 'collect_inputs.py','collection-log.jsonl','read_input.py','inspect_json.py','build_review_manifest.py']
artifacts=[]
for name in artifact_names:
 data=(ROOT/name).read_bytes()
 artifacts.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),
                   'provenance':'New reviewer artifact; not an original author execution record.'})
manifest={'review':'TCIP single independent final scientific review, 2026-09-08',
 'fixed_commit':PIN,'work_directory':ROOT.as_posix(),'input_count':len(records),
 'frozen_git_input_count':sum('repo_path' in r for r in records),
 'local_input_count':sum('repo_path' not in r for r in records),
 'git_rule':'All Git reads used GIT_NO_LAZY_FETCH=1. No fetch or checkout.',
 'reviewer_calculation':{'script':'reviewer_calculations.py','runs':1,'exit_code':0,
 'scope':'Retained count arithmetic and analytic logic only; no geometry, random draws, science producers or biological re-estimation.'},
 'inputs':records,'review_artifacts':artifacts,
 'note':'Manifest files excluded from their own embedded digest table. A separate hash file covers their final bytes without a circular self-hash.'}
(ROOT/'REVIEWED-INPUT-MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=True,indent=2)+'\n',encoding='utf-8')
lines=['# TCIP reviewed-input manifest','',f'Fixed commit: `{PIN}`.','',
 f'{len(records)} exact retained inputs. Full retention and actual read scope are distinguished below. All collection byte counts and hashes were reverified.','']
for i,r in enumerate(records,1):
 lines += [f'## {i}. {r.get("repo_path",r["retained_path"])}','',
 '- Source: `'+r['source']+'`','- Retained: `'+r['retained_path']+'`',
 f'- Bytes: {r["bytes"]}','- SHA256: `'+r['sha256']+'`','- Read scope: '+r['read_scope'],'']
lines+=['## New reviewer artifacts','','The scientific arithmetic/logic script ran once, exit 0. No original execution was recreated.','',
 '| Artifact | Bytes | SHA256 |','|---|---:|---|']
for r in artifacts:
 lines.append(f'| `{r["path"]}` | {r["bytes"]} | `{r["sha256"]}` |')
lines+=['',manifest['note'],'']
(ROOT/'REVIEWED-INPUT-MANIFEST.md').write_text('\n'.join(lines),encoding='utf-8')
hash_names=artifact_names+['REVIEWED-INPUT-MANIFEST.json','REVIEWED-INPUT-MANIFEST.md']
hashes=[]
for name in hash_names:
 data=(ROOT/name).read_bytes()
 hashes.append(hashlib.sha256(data).hexdigest()+'  '+name)
(ROOT/'REVIEW-ARTIFACT-HASHES.txt').write_text('\n'.join(hashes)+'\n',encoding='utf-8')
print(json.dumps({'input_count':len(records),'frozen_inputs':manifest['frozen_git_input_count'],
 'local_inputs':manifest['local_input_count'],'all_retained_bytes_reverified':True,
 'report':artifacts[0]},ensure_ascii=True))
