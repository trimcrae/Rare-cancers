# TCIP reviewed-input manifest

Fixed commit: `f43f1495f40d8aff7b4f34bd385d55aac521a500`.

20 exact retained inputs. Full retention and actual read scope are distinguished below. All collection byte counts and hashes were reverified.

## 1. research/manuscripts/tcip/tcip-induced-interface-preprint.md

- Source: `git:f43f1495f40d8aff7b4f34bd385d55aac521a500:research/manuscripts/tcip/tcip-induced-interface-preprint.md`
- Retained: `inputs/frozen/research/manuscripts/tcip/tcip-induced-interface-preprint.md`
- Bytes: 28068
- SHA256: `2e2b7862c3c6412ff4ae9086fd2acca799ae8999511ca607d1a49e416e82d9a9`
- Read scope: Entire manuscript read, lines 1-393, including all appendices, references and six figure specifications. Material passages revisited with exact line numbers. No actual rendered figures were present in this manuscript.

## 2. research/manuscripts/tcip/tcip-induced-interface-preprint-si.md

- Source: `git:f43f1495f40d8aff7b4f34bd385d55aac521a500:research/manuscripts/tcip/tcip-induced-interface-preprint-si.md`
- Retained: `inputs/frozen/research/manuscripts/tcip/tcip-induced-interface-preprint-si.md`
- Bytes: 16663
- SHA256: `3483c0bbcbd94e4faa5b3de38da8010130b189336b79ac27cd08101c56748ba3`
- Read scope: Entire SI read, lines 1-277, including all tables, controls, literature assertions and reproduction instructions.

## 3. research/modalities/nr4a3-tcip-reach.json

- Source: `git:f43f1495f40d8aff7b4f34bd385d55aac521a500:research/modalities/nr4a3-tcip-reach.json`
- Retained: `inputs/frozen/research/modalities/nr4a3-tcip-reach.json`
- Bytes: 332469
- SHA256: `d962871998c17a680cf876e1676161a6d2c37f71e02c9ddf0867b68c1cadd604`
- Read scope: All 576 cell count fields parsed; all per-rung pooled and per-arm summaries and all ablation floor counts inspected/recomputed. Cross-check 24-cell record, named-effector fields, body geometry and material metadata read. Not every serialized line of this 332 KB file read individually. No original placements reproduced.

## 4. research/modalities/nr4a3-induced-interface-census.json

- Source: `git:f43f1495f40d8aff7b4f34bd385d55aac521a500:research/modalities/nr4a3-induced-interface-census.json`
- Retained: `inputs/frozen/research/modalities/nr4a3-induced-interface-census.json`
- Bytes: 141666
- SHA256: `5804422fdae00e6704c169eab4b92d59970b5ee5499c1e10f58a223c76d59b8d`
- Read scope: All 22 entries parsed for classes, candidate/retained pairs, directional counts and selected denominator reconstruction. Complete 9MZA entry read, including ligands, chain descriptions, candidate pairs and full retained profiles; material controls/summary metadata inspected. No independent distances calculated from coordinates.

## 5. research/modalities/nr4a3_tcip_reach.py

- Source: `git:f43f1495f40d8aff7b4f34bd385d55aac521a500:research/modalities/nr4a3_tcip_reach.py`
- Retained: `inputs/frozen/research/modalities/nr4a3_tcip_reach.py`
- Bytes: 111977
- SHA256: `6d5908ef1c639fb79010b5f7d489e31a4356e99b2b8ef72cd18d93c0f1f89ce9`
- Read scope: Scientific branches read, including lines 70-128, 235-482, 561-690, 783-854, 870-934, 1541-1699 and 1704-1775; function/call-site searches used. Selected code lines revisited. Not a full 112 KB audit of generated prose/rendering branches. Never imported or executed.

## 6. research/modalities/nr4a3_induced_interface_census.py

- Source: `git:f43f1495f40d8aff7b4f34bd385d55aac521a500:research/modalities/nr4a3_induced_interface_census.py`
- Retained: `inputs/frozen/research/modalities/nr4a3_induced_interface_census.py`
- Bytes: 37591
- SHA256: `3ca36c4d7f840c94c511f6a1c0feea1390b9292c8db8599989b9dcfccf35b391`
- Read scope: Scientific definitions, parser and census logic read, lines 1-230 and 231-738, including entry classes, exact-distance classifier, query construction, eligibility, zero-contact filter and CLI. Later output-rendering boilerplate not represented as a full read. Never imported or executed.

## 7. research/modalities/nr4a3_basin_search.py

- Source: `git:f43f1495f40d8aff7b4f34bd385d55aac521a500:research/modalities/nr4a3_basin_search.py`
- Retained: `inputs/frozen/research/modalities/nr4a3_basin_search.py`
- Bytes: 105384
- SHA256: `0d045aeaec7fce3700b0256aba3070616d5238b3d915c75e2b3e6dba7d0fdec0`
- Read scope: Selected material branches read: lines 52-139, 329-426, 445-482 and 514-641, plus function/index searches. Static PARAMS parsed with ast.literal_eval. Anchor construction and complete placement loop inspected. Other closed-program production/biological branches not audited or executed.

## 8. research/manuscripts/tcip/tcip-interface-floor-sizing.md

- Source: `git:f43f1495f40d8aff7b4f34bd385d55aac521a500:research/manuscripts/tcip/tcip-interface-floor-sizing.md`
- Retained: `inputs/frozen/research/manuscripts/tcip/tcip-interface-floor-sizing.md`
- Bytes: 21346
- SHA256: `f865a51c85a01ad6392d7951492acd48fd8e2a151122063fa6987bf6057ba707`
- Read scope: Entire 343-line sizing memo read, including all source narratives, controls and literature assertions. Memo assertions not treated as independently verified original source responses.

## 9. research/modalities/nr4a3-tcip-route-memo.md

- Source: `git:f43f1495f40d8aff7b4f34bd385d55aac521a500:research/modalities/nr4a3-tcip-route-memo.md`
- Retained: `inputs/frozen/research/modalities/nr4a3-tcip-route-memo.md`
- Bytes: 35843
- SHA256: `5ad3b4d5cf7f405f48dfc8bdc405b5e441460bb2f66310c0bbec1fc5f08e05d1`
- Read scope: Selected material historical enumeration, replication, ablation and named-effector/construct passages, especially lines 140-280, read. Historical 40,000-sample and determinism claims recorded as narrative, not original-run verification. Remaining unrelated route discussion not fully read.

## 10. research/modalities/nr4a3-tcip-reach.md

- Source: `git:f43f1495f40d8aff7b4f34bd385d55aac521a500:research/modalities/nr4a3-tcip-reach.md`
- Retained: `inputs/frozen/research/modalities/nr4a3-tcip-reach.md`
- Bytes: 17518
- SHA256: `499f220fde0274a3bfe26a6a5b91b36ccd3f53d2eaf8faa7e19c71312d67b663`
- Read scope: Entire generated 201-line view read, including populated named-arm results and stale verdict contradictions. Derived prose not treated as an independent measurement.

## 11. .claude/skills/paper-hardening/SKILL.md

- Source: `git:f43f1495f40d8aff7b4f34bd385d55aac521a500:.claude/skills/paper-hardening/SKILL.md`
- Retained: `inputs/frozen/.claude/skills/paper-hardening/SKILL.md`
- Bytes: 1937
- SHA256: `497689024cf143920696031f265ddf69d58381ea2cce4a025871d85d38ede4ea`
- Read scope: Full frozen review guidance read. The standing commission controls review scope; no new baseline prepass or publication action was inferred.

## 12. .claude/skills/repo-gates/SKILL.md

- Source: `git:f43f1495f40d8aff7b4f34bd385d55aac521a500:.claude/skills/repo-gates/SKILL.md`
- Retained: `inputs/frozen/.claude/skills/repo-gates/SKILL.md`
- Bytes: 1794
- SHA256: `228e27b07811a027d60e548d88e41e992280d788c2478aa2c7fb467af8cbafa1`
- Read scope: Full frozen guidance read. General publication gates were not run and not used as scientific acceptance evidence.

## 13. inputs/local/SETTLEMENT.md

- Source: `C:/Users/mcrae/.codex/review-workspaces/opus-capacity-sprint-20260907/capacity-campaign-20260908/observations/f43f1495/TCIP-settlement/SETTLEMENT.md`
- Retained: `inputs/local/SETTLEMENT.md`
- Bytes: 15514
- SHA256: `e656e95e3683712221c68d1b0f86d749502a663913f8ebbb148245278026042e`
- Read scope: Full commissioning settlement read; author settlement, 28 checks and restricted-question framing not accepted as scientific adjudication or as a limit on this final review.

## 14. inputs/local/MANIFEST.md

- Source: `C:/Users/mcrae/.codex/review-workspaces/opus-capacity-sprint-20260907/capacity-campaign-20260908/observations/f43f1495/TCIP-settlement/MANIFEST.md`
- Retained: `inputs/local/MANIFEST.md`
- Bytes: 15854
- SHA256: `cff7b9317f3393a64e5f096aec0d8bf44ba1377087a395ebd580539484535e88`
- Read scope: Full preparation manifest read. Stale self-entry distinguished from actual bytes and material-input identities.

## 15. inputs/local/HASHES.txt

- Source: `C:/Users/mcrae/.codex/review-workspaces/opus-capacity-sprint-20260907/capacity-campaign-20260908/observations/f43f1495/TCIP-settlement/HASHES.txt`
- Retained: `inputs/local/HASHES.txt`
- Bytes: 2186
- SHA256: `5f5f03217d265e27f22a3c6d6da3d72bcb304a659c06a38a7a2fc819b9871c93`
- Read scope: Full hash file read; ten main/SI/material dependency hashes independently matched in the one reviewer arithmetic run.

## 16. research/modalities/basin_geom.py

- Source: `git:f43f1495f40d8aff7b4f34bd385d55aac521a500:research/modalities/basin_geom.py`
- Retained: `inputs/frozen/research/modalities/basin_geom.py`
- Bytes: 26626
- SHA256: `db8cef6b0f34f105154be576734601228cdf2dbb9c857b7e03b92fd458f7f4f2`
- Read scope: Material distance-field and random-distribution branches read, including lines 20-40, 134-159, 259-328 and 369-382. Other geometry utilities not fully audited. No producer import/execution.

## 17. research/modalities/nr4a3-orientation-basins.json

- Source: `git:f43f1495f40d8aff7b4f34bd385d55aac521a500:research/modalities/nr4a3-orientation-basins.json`
- Retained: `inputs/frozen/research/modalities/nr4a3-orientation-basins.json`
- Bytes: 5861390
- SHA256: `2ea22a0821a4268a8ca6c7e6284f952242d4782916bcad9041cef067fbf97270`
- Read scope: Selected original committed per-pose statistics and metadata; all 24 old count records used by the TCIP cross-check parsed for the reviewer uncertainty diagnostic. Other large program sections not fully read or reanalysed.

## 18. research/modalities/nr4a3-e3-arm-registry.json

- Source: `git:f43f1495f40d8aff7b4f34bd385d55aac521a500:research/modalities/nr4a3-e3-arm-registry.json`
- Retained: `inputs/frozen/research/modalities/nr4a3-e3-arm-registry.json`
- Bytes: 79042
- SHA256: `04a6b769e7e8659702e59a4a7433a7cd2f7ad4ad6e1ed53828c949e4c1ceefad`
- Read scope: Root method/limitations and all four arm source-entry, assembly-copy, status and staged-path metadata inspected. Ligand-coordinate arrays not fully line-read and not used for remeasurement. A broad initial display truncated; scope here reflects subsequent selected reads, not full-file review.

## 19. research/modalities/nr4a3-effector-arm-registry.json

- Source: `git:f43f1495f40d8aff7b4f34bd385d55aac521a500:research/modalities/nr4a3-effector-arm-registry.json`
- Retained: `inputs/frozen/research/modalities/nr4a3-effector-arm-registry.json`
- Bytes: 58985
- SHA256: `03d2c1798404dcd1db097c1ff7d04c5fda135d9c4fda652532bea9d3236a701a`
- Read scope: Both named-arm discovery/source-entry, construct size, assembly-copy, status, staged-path, self-check and staging-log metadata read. Not independent source acquisition or validation of all ligand coordinates. A broad initial display truncated; no full-file read claimed.

## 20. research/manuscripts/degrader/selectivity-requirement-sizing.md

- Source: `git:f43f1495f40d8aff7b4f34bd385d55aac521a500:research/manuscripts/degrader/selectivity-requirement-sizing.md`
- Retained: `inputs/frozen/research/manuscripts/degrader/selectivity-requirement-sizing.md`
- Bytes: 53930
- SHA256: `ce9be0baed9f350bc8fee615bdef37f2e091704b9110dd9ce358d5adf49dc648`
- Read scope: Material binary odds derivation and assumptions (lines 100-165) and claimed ternary transfer (lines 384-403) read, with heading/term searches for context. Remainder of the separate closed-program argument not adjudicated.

## New reviewer artifacts

The scientific arithmetic/logic script ran once, exit 0. No original execution was recreated.

| Artifact | Bytes | SHA256 |
|---|---:|---|
| `FINAL-SCIENTIFIC-REVIEW-TCIP.md` | 52425 | `a00bec7213282192725722bb84736470868523acaa13766c2dac44ea4da82101` |
| `reviewer_calculations.py` | 12641 | `647a7de893487ca0fdacfe4dba36591c1705af963a330d4fe96d6f182cd3e5fe` |
| `reviewer-calculations.json` | 55463 | `ba6a8ffa3307b725bd4d3868b16b688336d5a71c794bc6cc7d8bc55d4de8bbee` |
| `reviewer-calculations-stdout.txt` | 55463 | `ba6a8ffa3307b725bd4d3868b16b688336d5a71c794bc6cc7d8bc55d4de8bbee` |
| `reviewer-calculations-exit.txt` | 3 | `13bf7b3039c63bf5a50491fa3cfd8eb4e699d1ba1436315aef9cbe5711530354` |
| `collect_inputs.py` | 1543 | `1e565736cbe4da74b9557851a9ba2f7daf6b15227d4a9db8d8f9c5b87a0ea22f` |
| `collection-log.jsonl` | 7610 | `997dacaac22af6b588206efda3e7d28652df9e09805cf2454b5214082de620ee` |
| `read_input.py` | 792 | `ce83f6e9548df879cd00a9d8d1bc43dded0f6aaa573eee20d5add15a44287790` |
| `inspect_json.py` | 405 | `f8a16765f61691ad062f7c0ec1c1744ae5f482fbb0d0fb5509499f6f3fefee61` |
| `build_review_manifest.py` | 9008 | `1f9f048146634fb44401aadfc12cafa21975a96786e93afb1b4d4d5dffadda12` |

Manifest files excluded from their own embedded digest table. A separate hash file covers their final bytes without a circular self-hash.
