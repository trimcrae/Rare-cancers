$ErrorActionPreference = 'Stop'
$taskRoot = 'C:/Users/mcrae/Documents/Codex/2026-09-07/emc-research-orchestrator/work/atr-final-review-20260908'
$focus = Join-Path $taskRoot 'review/focused-verification'
$observations = 'C:/Users/mcrae/.codex/review-workspaces/opus-capacity-sprint-20260907/capacity-campaign-20260908/observations'
$originalManifest = Get-Content -LiteralPath (Join-Path $taskRoot 'frozen-inputs-manifest.json') -Raw | ConvertFrom-Json
$currentManifest = Get-Content -LiteralPath (Join-Path $focus 'exact-inputs-manifest.json') -Raw | ConvertFrom-Json
function FileRecord([string]$path) {
    [pscustomobject]@{path=$path; bytes=(Get-Item -LiteralPath $path).Length; sha256=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLower()}
}
$originalChecks = foreach ($entry in $originalManifest.files) {
    $actual = FileRecord (Join-Path "$taskRoot/inputs" $entry.path)
    [pscustomobject]@{path=$entry.path; matches=($actual.bytes -eq $entry.bytes -and $actual.sha256 -ceq $entry.sha256)}
}
$originalReviewExpected = @{
    'atr-final-ultra-review.md'='51c586e8d32737c2f19ff80edb8099a77fe74f7799f1207a9c1f003609851800'
    'lightweight-checks.ps1'='44ae6958072f201d0ce6e8db4b584f27422c87d8ef7d058c52a4342c811954a3'
    'lightweight-checks.json'='45d0c5dd659ec61d91bb622e9168962efa2041aa0ba90e879108f0331eb24e22'
}
$originalReviewChecks = foreach ($name in $originalReviewExpected.Keys) {
    $actual = FileRecord (Join-Path "$taskRoot/review" $name)
    [pscustomobject]@{path=$name;sha256=$actual.sha256;matches=($actual.sha256 -ceq $originalReviewExpected[$name])}
}
$currentChecks = foreach ($entry in $currentManifest.files) {
    $actual = FileRecord (Join-Path "$focus/inputs" $entry.path)
    $old = @($originalManifest.files | Where-Object path -CEQ $entry.path)[0]
    [pscustomobject]@{path=$entry.path;bytes=$actual.bytes;sha256=$actual.sha256;matches_collected_manifest=($actual.bytes -eq $entry.bytes -and $actual.sha256 -ceq $entry.sha256);byte_identical_to_original=($actual.bytes -eq $old.bytes -and $actual.sha256 -ceq $old.sha256)}
}
$mainPath = 'research/manuscripts/dependency/emc-atr-collaborator-package.md'
$originalRows = @(Get-Content -LiteralPath (Join-Path "$taskRoot/inputs" $mainPath) | Where-Object {$_ -match '^\| P[1-5] \|'})
$currentRows = @(Get-Content -LiteralPath (Join-Path "$focus/inputs" $mainPath) | Where-Object {$_ -match '^\| P[1-5] \|'})
$historicalRowsIdentical = $originalRows.Count -eq 5 -and $currentRows.Count -eq 5 -and (($originalRows -join "`n") -ceq ($currentRows -join "`n"))
$stamp = Get-Content -LiteralPath "$focus/inputs/research/manuscripts/figures/emc-atr-figure-provenance.json" -Raw | ConvertFrom-Json
$prefixChecks = foreach ($source in $stamp.sources.PSObject.Properties) {
    $actual = FileRecord "$focus/inputs/research/modalities/$($source.Name)"
    [pscustomobject]@{source=$source.Name;stored_prefix=$source.Value;actual_prefix=$actual.sha256.Substring(0,16);matches=$actual.sha256.StartsWith($source.Value)}
}
$cache = Get-Content -LiteralPath "$focus/inputs/research/modalities/emc-construct-inputs.json" -Raw | ConvertFrom-Json
$accessions = foreach ($gene in @('EWSR1','TAF15','FUS','NR4A3','TCF12')) {
    [pscustomobject]@{gene=$gene;transcript=$cache.genes.$gene.transcript}
}
$rawCache = [IO.File]::ReadAllText("$focus/inputs/research/modalities/emc-construct-inputs.json")
$retrievedLiteral = [regex]::Match($rawCache,'"_fetched_utc"\s*:\s*"([^"]+)"').Groups[1].Value
$evidenceNames = @('lanes/m1-lane/RUNTIME-EVIDENCE.txt','lanes/m1-lane/run-timestamp.txt','lanes/m1-lane/generator-run.log','lanes/m1-lane/generator-run-success.log','parent-transcript/M1-literal-extracts.md')
$receipt = Get-Content -LiteralPath "$observations/campaign-small-originals-final-local-receipt.json" -Raw | ConvertFrom-Json
$executionEvidence = foreach ($name in $evidenceNames) {
    $sourcePath = Join-Path "$observations/campaign-small-originals-20260908" $name
    $expected = @($receipt.files | Where-Object member -CEQ $name)[0]
    $actual = FileRecord $sourcePath
    $copyPath = Join-Path "$focus/execution-evidence" $name
    New-Item -ItemType Directory -Path (Split-Path $copyPath) -Force | Out-Null
    [IO.File]::WriteAllBytes($copyPath, [IO.File]::ReadAllBytes($sourcePath))
    [pscustomobject]@{source=$sourcePath;copy=$copyPath;bytes=$actual.bytes;sha256=$actual.sha256;matches_collector_receipt=($actual.bytes -eq $expected.bytes -and $actual.sha256 -ceq $expected.sha256)}
}
$result = [pscustomobject]@{
    recorded_utc=[DateTime]::UtcNow.ToString('o')
    scope='Accepted repairs only; hashes, unchanged registered rows and existing metadata; no scientific producer or regeneration'
    revision=$currentManifest.revision
    original_input_checks=@($originalChecks)
    original_review_checks=@($originalReviewChecks)
    current_input_checks=@($currentChecks)
    original_five_registered_rows_identical=$historicalRowsIdentical
    m1_raw_source_prefix_checks=@($prefixChecks)
    e2_cached_retrieval_literal=$retrievedLiteral
    e2_cached_transcript_accessions=@($accessions)
    original_execution_evidence=@($executionEvidence)
}
$result | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath "$focus/focused-checks.json" -Encoding UTF8
$result | ConvertTo-Json -Depth 12
