from pathlib import Path
import ast
import difflib
import hashlib
import json
import sys

sys.stdout.reconfigure(encoding='utf-8')
BASE = Path(r'C:/Users/mcrae/.codex/review-workspaces/opus-capacity-sprint-20260907/capacity-campaign-20260908/observations/b14a8425')
OUT = Path(__file__).resolve().parent
MAIN = 'research/manuscripts/dependency/emc-transcriptional-proteostatic-dependency.md'
GP = 'research/modalities/census_route_expression_grading.py'
G = 'research/modalities/census-route-expression-grading.json'
C = 'research/literature/fet-fusion-chaperone-clientship-2026-08-27.json'

def sha(b):
    return hashlib.sha256(b).hexdigest()

def blob(b):
    return hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest()

def replace_once(s, old, new):
    assert s.count(old) == 1, ('nonunique replacement', old[:100], s.count(old))
    return s.replace(old, new)

before = {p: (BASE / p).read_bytes() for p in (MAIN, GP)}
assert sha(before[MAIN]) == '9523555483f00cfee00b6cd4cf64f5615f57c011f1640297bf952399e742b3ba'
assert blob(before[GP]).startswith('fe00fe381')  # b14 exact diff header; full SHA256 and blob recorded below
gp = before[GP].decode('utf-8')
old_doc = '''    ⛔ IT CONTAINS NO EMC LINE. The one line on the curated record does not carry the fusion and has
    no CRISPR data, so every figure here is a TRANSFER from other sarcomas and inherits
    BLK-CLASS-INHERITANCE. The honest bound is not a small sample; it is no EMC observation at all.

    ⚠ AND A DEPENDENCY IS NOT A WINDOW. `frac_dependent` near 1.0 means the gene is required in
    almost every sarcoma line -- which is evidence AGAINST a therapeutic window, not for one, unless
    the class exploits a state the normal cell does not share.'''
new_doc = '''    No EMC-labelled model contributes CRISPR gene-effect data to this release. ACH-001519 is
    present in the model metadata but has no gene-effect values; that availability record does
    not establish its disease or fusion identity. Every dependency figure here describes other
    cancer lines. Applying it to EMC is an uncalibrated transfer under BLK-CLASS-INHERITANCE.

    `frac_dependent` near 1.0 describes broad binary dependency in the screened cancer lines.
    This cancer-versus-cancer summary measures neither normal-tissue response nor a graded
    response to partial inhibition, and supplies no fusion-status-stratified result. It does
    not establish the presence or absence of a therapeutic window or EMC selectivity.'''
gp = replace_once(gp, old_doc, new_doc)
gp_after = gp.encode('utf-8')
old_tree, new_tree = ast.parse(before[GP].decode('utf-8')), ast.parse(gp)
old_fn = next(x for x in old_tree.body if isinstance(x, ast.FunctionDef) and x.name == 'depmap')
new_fn = next(x for x in new_tree.body if isinstance(x, ast.FunctionDef) and x.name == 'depmap')
assert ast.get_docstring(old_fn) != ast.get_docstring(new_fn)
old_fn.body[0].value.value = '<same depmap docstring>'
new_fn.body[0].value.value = '<same depmap docstring>'
assert ast.dump(old_tree, include_attributes=False) == ast.dump(new_tree, include_attributes=False)

main = before[MAIN].decode('utf-8')
identity_changes = {
    G: ('b45a35a4ee2636993e42e897c3be6d7705ccae8a', blob((BASE/G).read_bytes())),
    GP: ('18625608b378122adbe9dbcca16de370c357367b', blob(gp_after)),
    C: ('8728c34de793da848ccae012e808e668b69b24bd', blob((BASE/C).read_bytes())),
}
for p, (old_id, new_id) in identity_changes.items():
    main = replace_once(main, f'| `{p}` | `{old_id}` |', f'| `{p}` | `{new_id}` |')
old_status = '''`research/autonomy/opus-capacity-campaign-20260908/paper-lane/`. ⚠ Two of the objects above —
`census-route-expression-grading.json` and `fet-fusion-chaperone-clientship-2026-08-27.json` — have a
dated annotation-only correction prepared but not yet integrated at the time of writing; when it is
applied their blob identities change and no reported number, membership or quotation does. ⛔ **No
hash is claimed for the
raw GEO series matrices or the DepMap CSV inputs.**'''
new_status = '''`research/autonomy/opus-capacity-campaign-20260908/paper-lane/`. The table includes the integrated
annotation-only versions of `census-route-expression-grading.json`, its producer
`census_route_expression_grading.py`, and `fet-fusion-chaperone-clientship-2026-08-27.json`, including
the corrected dependency docstring. Their dated corrections supersede earlier interpretation
strings; the original before/after records retain the numerical-invariance evidence. These are
identities of the corrected artifacts, not evidence of a new producer execution. No reported
number, membership or source quotation was changed. ⛔ **No hash is claimed for the raw GEO series
matrices or the DepMap CSV inputs.**'''
main = replace_once(main, old_status, new_status)
after = {MAIN: main.encode('utf-8'), GP: gp_after}
old_rows = [l for l in before[MAIN].decode('utf-8').splitlines() if l.startswith('|')]
new_rows = [l for l in main.splitlines() if l.startswith('|')]
assert len(old_rows) == len(new_rows) == 78
row_changes = [(a,b) for a,b in zip(old_rows,new_rows) if a != b]
assert len(row_changes) == 3
assert all(any(f'| `{p}` |' in a for p in identity_changes) for a,b in row_changes)

bindings = {'base_commit':'b14a84259363f8b18c98d7754a305892cd37f92b',
            'scope':'Two document-only corrections prepared in isolated work directory; original inputs untouched; no scientific execution or repository mutation.',
            'files':[], 'identity_changes':identity_changes,
            'checks':{'GP_only_depmap_docstring_AST_change':True,'main_table_rows_before':78,
                      'main_table_rows_after':78,'main_changed_table_rows':3,
                      'main_table_changes_only_fixed_identity_rows':True,
                      'new_source_or_statistic_or_classifier_or_producer_runs':0}}
diff = []
for p in (GP, MAIN):
    for prefix, data in [('before',before[p]),('proposed',after[p])]:
        dest=OUT/prefix/p
        dest.parent.mkdir(parents=True,exist_ok=True)
        dest.write_bytes(data)
    diff.extend(difflib.unified_diff(before[p].decode('utf-8').splitlines(keepends=True),after[p].decode('utf-8').splitlines(keepends=True),fromfile='a/'+p,tofile='b/'+p,n=3))
    bindings['files'].append({'path':p,'before_bytes':len(before[p]),'before_sha256':sha(before[p]),'before_git_blob':blob(before[p]),'proposed_bytes':len(after[p]),'proposed_sha256':sha(after[p]),'proposed_git_blob':blob(after[p])})
(OUT/'FINAL-DOC-CORRECTION.patch').write_bytes(''.join(diff).encode('utf-8'))
(OUT/'BINDINGS.json').write_text(json.dumps(bindings,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(bindings,ensure_ascii=False,indent=2))
print('PATCH',len((OUT/'FINAL-DOC-CORRECTION.patch').read_bytes()),sha((OUT/'FINAL-DOC-CORRECTION.patch').read_bytes()))
