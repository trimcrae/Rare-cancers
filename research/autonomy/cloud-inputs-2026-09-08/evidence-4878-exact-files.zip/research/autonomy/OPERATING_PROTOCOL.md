---
id: DOC-AUTONOMY-OPERATING-PROTOCOL
title: Research operating protocol
kind: runbook
status: live
date: 2026-09-04
last_verified: 2026-09-04
purpose: Deliver useful computational EMC research with bounded review and explicit ownership.
audience: [maintainers, autonomous research agents]
scope: Work selection, review, coordination, and the Claude-to-Codex transition.
---

# Research operating protocol

This is the active procedure for both Codex and Claude. The user's 2026-09-04 instruction
authorizes structural changes to improve scientific throughput, cost, and coordination.
Historical runbooks explain old decisions; they do not override this procedure or current user
instructions. Publication permissions remain in `publication-authority.json` and its enforcers.

## Objective and work selection

Optimize for useful evidence that could improve EMC patient outcomes, not paper count, review
rounds, test count, or subscription consumption. Computational work must distinguish prediction,
association, and experimental validation. No wet-lab claim can be established by an LLM review.

1. **PUB-ASO is the first manuscript to finish.** Read its current manuscript, outgoing package,
   existing review evidence, and the dated readiness assessment. Do not start with the degrader
   program's entire roadmap. Its Qeios history remains under the human author's control; its
   intended journal is Nucleic Acid Therapeutics.
2. Until its package is ready or externally blocked, keep one manuscript owner and one separately
   owned process improvement. Parallel evidence retrieval, computation, and independent review
   are useful when they return distinct outputs. Multiple agents must not rewrite the same paper.
3. Choose subsequent projects by clinical relevance, a question public data can answer, credible
   validation, expected information gained, and effort. Record the concrete question and stop
   condition before starting. Reproducible reanalyses, benchmark datasets, and decisive negative
   results can be valuable; do not manufacture papers from work with no useful result.
   Before scientific drill-down or a runner contract, maintain a paper-level rank with evidence
   and reasons: importance, nontrivial novelty, achievable evidence and validation, coherent
   contribution, and utility come first. Distinguish demonstrated results from development
   prospects and blocked hypotheses. Feasibility and usage govern execution, not scientific
   rank; small preparation tasks inherit the selected paper's priority. Use the current
   [paper priority memo](portfolio-2026-09-05/recommendation.md).
   Use [bounded cycle contracts](RESEARCH_CYCLE.md) to specify the evidence, validation and stop
   condition for one existing route. Reuse matching verified output and reconcile unchanged
   failed inputs before considering another dispatch. Planning scores are judgements, not evidence.
4. An unrelated red health row or maintenance backlog is not a scientific task. Triage only the
   conditions that affect the proposed action. Enforce real budget, access, ownership, and evidence
   constraints. A process fix must remove observed friction and report its measured effect.

## Continue beyond a route-specific blocker

User reaffirmation, 2026-09-06: continuous substantive research is authorized, with existing
usage-reset credits when actual account limits require them. Waiting for correspondence,
an empty generated task list, a failed development experiment, or a paper not being ready
does not establish that all useful work is blocked. At each checkpoint, distinguish the
specific missing input from the next credible independent computation, exact source recovery,
authorized targeted request or genuinely new evidence-based question. Execute that next step
without an artificial daily reserve, total-round cap or inbox-only pause. Preserve negative
results and real acceptance criteria; do not repeat unchanged work or invent a paper merely
to consume credits. Keep finite worker checkpoints and explicit ownership, then continue.

## Review with an endpoint

**User rule, 2026-09-05: every paper requires one independent ultra-reasoning pass
before submission.** This applies to journal and preprint submissions and future revised
submissions, including the pending ASO submission; it does not retroactively reopen posted
versions or authorize publication. Keep routine research at medium. Plan the ultra pass as
part of the existing bounded review batch, not an extra recurring review cycle.

Freeze the paper and supporting evidence before this pass. Review scientific validity,
methods, novelty, claim strength, citations, limitations and whether the contribution merits
submission. Preserve the actual model and `reasoning_effort: ultra` execution record, reviewed
revision/deliverable digest, findings and their disposition. Do not relabel a historical high
or unknown-effort review as ultra. Reuse a documented ultra pass covering unchanged deliverables.
The coordinator must verify this evidence before declaring a package ready or handing it off
for submission; missing evidence blocks that readiness declaration. This is a procedural
submission requirement, not a claim that the existing publish-bar code already checks effort.

Resolve substantiated blockers in one batch and independently verify the changed claims and
dependencies. Editorial repairs do not require another full ultra pass. Material scientific
changes require a new pass covering the changed science and its dependencies. A zero-finding
review is valid; ultra reasoning is not experimental validation or a guarantee of correctness.

Freeze the outgoing files and identify their evidence before commissioning a review. Reuse
existing completed reviews when their deliverable digest still matches. Read
`publish_bar.py` for actual acceptance, not the convenience `converged` field alone.

For new work, budget one independent review batch covering claims/citations and methods/results,
one batched repair, and one independent verification of the changed claims and their dependencies.
This is an iteration budget, not a declaration that a paper must pass. Choose additional expert
lenses only for a named uncertainty. Maintain any evidence required by the existing publish bar;
a shorter workflow is not permission to fabricate a review record or override a failed clause.

Each finding names the exact outgoing artifact, evidence, consequence, and smallest correction:

| Class | Meaning | Action |
|---|---|---|
| Submission blocker | A current unsupported/misleading claim, invalid analysis, missing reproducibility evidence, or a real venue requirement | Resolve or narrow the claim before submission |
| Maintenance | Correct current content lacks a regression guard or tooling could be improved | Separate backlog; does not trigger another whole-paper review |
| Editorial suggestion | Optional wording, presentation, or speculative future work | Accept only if it improves clarity without starting a rewrite cycle |

Independently verify findings; reviewer labels are not evidence. Do not require a nonzero finding
count. Record disputed and dismissed findings with reasons. A repair replaces the defective text
and receives a focused evidence check; it does not append defensive paragraphs or reopen every
section. A material methods change may justify broader review; record that reason explicitly.

After the budget is used, return either a verified package or a precise unresolved issue. A new
whole-paper review needs changed scientific evidence, an independently demonstrated material
error, or an external review request. "Another fresh look" and unguarded correct sentences are
insufficient. Never change a real acceptance criterion merely to relabel unresolved work as ready.

## Ownership and integration

Use a separate Git worktree for each writing task. The coordinator alone integrates changes and
writes shared queue/status records. Assign ownership by paper or shared subsystem, not merely by
task name. A process worker must not change its own scientific task's acceptance rules mid-run.

Workers report a needed execution approval to the coordinator before entering a blocking tool
call. The coordinator owns the approval request and keeps its purpose visible to the user.
Do not leave several delegated workers silently waiting on separate permission prompts.

The legacy remote `claim.py` protocol uses a successful compare-and-push to `main` as its remote
claim. A local file, worktree, or branch is not a remote claim. The local Codex runner and local
legacy claims share the existing OS-held lock; its durable coordinator and resource records retain
ownership through output integration or explicit abandonment. A stopped process does not release
its unfinished paper to a second writer. Transfer ownership explicitly, and preserve interrupted
outputs when recovering. See [the runner](CODEX_RUNNER.md) for the actual commands.

The lock cannot fence a noncooperating worker on another machine. Cooperating legacy claims also
read the disabled-driver handover from fetched main. **Do not run both schedulers over the same
work.** Before autonomous local execution, pause/drain the legacy driver and identify outstanding
owners. Every writing launch rechecks the handover and outstanding legacy owners. A read-only
audit can run while handover is pending; an implementation branch is not a live cutover.

Start from a known base. Integrate coherent changes at a settled checkpoint, after checking current
main for conflicts. Do not merge main after every edit or push each status observation separately.
Preserve working branches and evidence until integration. On a collision, leave both versions
intact and reconcile; never choose a winner by last write.

A draft commit on an isolated work branch may anchor generated-artifact provenance before its
manifest is regenerated. Record the pending checks explicitly, generate the manifest from that
committed source, and validate before integration. A draft checkpoint is not a green gate or a
publication candidate. This avoids requiring a clean-source manifest before its source can exist
in a commit.

## Verification and cost

Run the smallest checks that cover the changed behavior during development. Batch all known fixes
and regenerations, then validate the settled tree once. Re-run only for a change, a failure, or an
unresolved concern. Use `scripts/preflight.sh` for the normal commit gate; its reported scope is
part of the result. Full publication verification still uses `PREFLIGHT_FULL=1` on the release
candidate, with its original log and exact revision. A skipped suite has not passed.

Do not add tests that merely pin a sentence, a file length, or a narrative incident. Add behavioral
checks for meaningful failure modes. Retain scientific provenance, arithmetic, reproducibility,
claim-strength, and artifact-integrity checks. An administrative hash mismatch with a safe full
fallback must not force a circular "full must pass before full can pass" repair loop.

Use saved ChatGPT authentication for local Codex work. API use is separately billed and is not an
automatic fallback. Preserve the active no-GPU-spend posture. Set a finite task duration and record
model, effort, base revision, output files, test scope, elapsed time, usage when available, unresolved
issues, and the next concrete action. Unknown remaining subscription capacity stays unknown.

Evaluate improvements by time to a verified artifact, substantive defects found, repair-induced
defects, duplicate work, and observed usage. Do not create work to reach a utilization target.

User allocation, 2026-09-07: use the Claude Code subscription with exactly `claude-opus-5`
for useful parallel evidence extraction, source comparison, methods/code drafting and focused
checks where medium effort is sufficient. The user wants substantial useful work before the
Wednesday morning weekly reset; remaining capacity and the exact reset time require observation.
Use [Claude delegation](CLAUDE_DELEGATION.md) under the existing research coordinator, with
distinct bounded inputs and retained outputs. Do not start a second scheduler, substitute a
model, use a paid fallback, or work around a service refusal. The coordinator verifies and
integrates results; the actual independent ultra submission pass remains required.

User routing correction, 2026-09-08 UTC (2026-09-07 Eastern), relayed by the existing Claude
launcher thread: default routine public-source recovery, extraction, curation, bounded scouting,
draft code and useful verification to exactly `claude-opus-5` at medium effort through that
launcher. Codex retains concise coordination, deterministic execution/integrity checks and
necessary final scientific adjudication. Do not extensively pre-solve source packets in Codex
before delegation. Parallelize distinct useful packets when available; preserve the existing
evidence standards, closed-source dispositions, acceptance criteria and spending limits. This
preference does not authorize replaying completed packets or creating work merely to use tokens.

User capacity expansion, 2026-09-08 UTC: the sole Claude launcher and submission owner relay an
explicit request for approximately 20 simultaneous Opus agents and approximately 25 hours of
useful sustained work. The admitted capacity campaign may select and refill distinct bounded
read-only research, review and code-draft child tasks within its workstreams without a new Codex
admission for every child. Its local manifest records scopes, inputs, ownership and actual runs;
the research coordinator retains scientific acceptance and integration. Observe actual memory,
model identity and deadlines before claiming capacity. Preserve the existing scheduler, spending
limits, source/refusal boundaries and publication checks. A completed paper does not pause useful
independent program work, and a worker target does not establish a running-worker count.

## Distribution and continuity

Use the [standing author declarations](author-declarations.json) for funding and competing
interests. On 2026-09-07 Tristan D. McRae confirmed no funding and no competing interests for all
papers in this program. Do not re-request these facts unless they change; this declaration does
not establish ethics approval, exemption, waiver, affiliation or consent.

Prepare reviewer-readable preprints, reusable data/code, accurate limitations, and venue metadata
together. aiXiv remains an authorized distribution option within the existing grant, not evidence
of scientific credibility. PUB-ASO remains excluded from automatic aiXiv posting. Recheck venue
rules at release time; do not wait indefinitely for a hypothetical higher-visibility AI venue.
Journal submission follows its existing authority. The user's 2026-09-06 standing research_correspondence
grant covers routine EMC outreach and follow-through without per-message approval; follow
[the correspondence procedure](correspondence/README.md) and its private durable ledger.

A cycle ends with a durable outcome and a clear next action. A process launch is not a delivered
result. Do not report a scheduler as active until an actual run produced and preserved its output.
Local runner receipts are not legacy `CYC-*` receipts or publication evidence. A remote cycle must
continue using the existing claim and receipt schemas until its readers are deliberately migrated.
The cycle adapter preserves local verified results separately, including input/output hashes,
independent check logs, elapsed time and observed usage. Independent maintenance needs measured
friction and normally consumes at most one of four cycles; useful science has selection priority.

## Basis for this change

The baseline is repository commit `c309b6f6e42ab6adb684c995dc9af2b6caa08fe5`.
`hardening-state/PUB-ASO.json` records round 34 with no blockers and maintenance findings, but its
recorder still used the retired zero-P1 rule. Historical instructions also required repeated blind
review, immediate synchronization, and continuing through an open-ended maintenance backlog.
These mechanisms rewarded activity and made acceptance move while the paper was being repaired.

OpenAI's current [Astra guide](https://developers.openai.com/api/docs/guides/latest-model?model=gpt-6-astra)
describes strong multistep research/coding and flags sensitivity to accumulated instructions and
excessive verification. That supports testing concise instructions and bounded review here; it
does not independently validate this project's science. [Codex authentication](https://learn.chatgpt.com/docs/auth)
distinguishes subscription sign-in from separately billed API use.
