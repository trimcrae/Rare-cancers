---
id: DOC-SOURCE-REUSE-PROGRAM-2026-09-08
title: Source reuse program checkpoint
level: —
kind: memo
status: live
purpose: Retain terminal source findings and the independently checked development of a source-reuse tool.
scope: Bounded source dispositions, original execution evidence and the standing parallel Opus campaign admission; no manuscript or clinical-result acceptance.
audience: [maintainers, autonomous research agents]
date: 2026-09-08
last_verified: 2026-09-08
---

# Source reuse program checkpoint, 2026-09-08

The parallel source scouts did not supply a newly admitted paper. Two molecular datasets were already in the retained work; registry treatment calibration lacked the necessary EMC-specific inputs. Original reports, including unsupported or incomplete assertions, remain in their hashed evidence archives. The coordinator dispositions in `terminal-integration.json` control their interpretation.

The source-index draft initially contained no code. A later recovery supplied complete helper and test bodies. A dated input amendment now sends those actual bodies to an isolated mechanical executor and a separate independent Opus comparison. Proposed test counts are not acceptance requirements. Original no-execution and interrupted-comparison records remain unchanged; no pass is inferred from delivery or parsing.

This checkpoint supports reuse of retained sources and explicit disclosure of incomplete input scope. It does not change the completed external-validation paper or authorize a new source/scientific route. Execution, comparison and any supported repair outcomes will be appended separately.
