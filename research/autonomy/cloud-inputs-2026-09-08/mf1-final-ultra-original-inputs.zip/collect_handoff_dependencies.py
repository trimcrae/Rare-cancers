import re
from collect_inputs import ROOT, collect_git
text = (ROOT/'inputs/local/HANDOFF-MF1-methods-record-frozen.md').read_text(encoding='utf-8')
for path in re.findall(r'^\| `([^`]+)`(?: \*\*\(main\)\*\*)? \| \d+ \| `[0-9a-f]{64}` \|$', text, re.M):
    if path != 'research/manuscripts/methods-record/degrader-methods-failure-record.md':
        collect_git(path)
