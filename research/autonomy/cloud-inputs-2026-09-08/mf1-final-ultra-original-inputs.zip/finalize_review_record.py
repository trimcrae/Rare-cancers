from pathlib import Path
import hashlib,json,re

R=Path(__file__).resolve().parent
entries=[json.loads(l) for l in (R/'collection-log.jsonl').read_text(encoding='utf-8').splitlines()]
full={
'research/manuscripts/methods-record/degrader-methods-failure-record.md',
'research/autonomy/OPERATING_PROTOCOL.md','.claude/skills/paper-hardening/SKILL.md','.claude/skills/repo-gates/SKILL.md',
'systems/views/registers/instruments.md','research/modalities/instrument-census.md',
'research/modalities/selcal-verdict.json','research/modalities/nrv04-retro-verdict.json',
'research/modalities/nr4a3-5aks-reduction.json','research/modalities/decoy-null-provenance.json',
'research/modalities/selectivity_calibration.py','research/modalities/ternary-env-parity.json',
'research/modalities/nr4a-safety-genetics.json','research/modalities/selcal-deepternary-frame.json',
'research/modalities/nrv04-cofold-chain-forensics-2026-07-24.md'}
selected={
'research/manuscripts/nr4a3-program-map.md':'Selected control, instrument, calibration, closure, causal-test, failure, validation, persistence and historical-result passages; not the entire roadmap.',
'systems/graph/instruments.json':'Selected instrument objects and V-numbered universe; structural parsing and counts.',
'systems/graph/routes.json':'RT-METHODS-PAPER and its instrument partition; no review of unrelated routes.',
'research/modalities/selcal_gate.py':'design_floor, leg_rows, verdict, operational membership and interpretation branches.',
'research/modalities/selcal_panel.py':'Reference identity/assay, shared panel structure, membership/amendment and PASS_CRITERION.',
'research/modalities/nrv04_retro_gate.py':'Model-level collapse, exact permutation, leave-one-model-out, registered constants and related declarations.',
'research/modalities/nr4a3_5aks_reduce.py':'Identity checking, statistics and reduce_S branches.',
'research/modalities/ternary_fep_reduce.py':'SD, t interval, aggregation, hysteresis and calibration decision branches.',
'research/modalities/selcal_interface_signature.py':'Descriptor scope, comparison fields, known_answer_check and input/result declarations.',
'research/modalities/selectivity-sensitivity-control-prereg.md':'Purpose, design/amendment provenance, reference set, criterion and prospective assertions.',
'research/modalities/selectivity-resolution-options.md':'Relevant power, sensitivity-control design, reference preconditions and outcome sections.',
'research/modalities/valb-triangle-reduction.json':'Triangle values, comparability, no-error-bar declaration, uncertainty and interpretation.',
'research/modalities/valb-triangle-closure.json':'Closure algebra, scope and power/noise sections.',
'research/modalities/valb-failure-propagation.json':'Measured inputs, noise-bound/power derivations, S argument and SD/SE interpretation.',
'research/modalities/selcal-collect.json':'Panel completion, input-fault exclusion and record inventory.',
'research/modalities/selcal-cofold-vs-crystal.json':'Provenance, reference/model distinction, grading records and source context.',
'research/modalities/selcal-cofold-dockq.json':'Cross-check result and scope.',
'research/modalities/selcal-dockq-decoy-scale.json':'Root schema and provenance inspection only; no structural reproduction.',
'research/modalities/selcal-interface-signature.json':'Known-answer result, source and scope; no remeasurement from crystals.',
'research/modalities/selcal-deepternary-controls.json':'Input context, blindness qualification and retained candidates; no new source checks.',
'research/modalities/selcal-deepternary-poscontrol.json':'In-set status, summary and claim scope.',
'research/modalities/selcal-reference-selectivity.json':'Schema/provenance inspection; primary text not independently retrieved.',
'research/modalities/nrv04-covalent-input-audit.json':'Input identities, contaminant records and aggregate admissibility result.',
'research/modalities/nrv04_covalent_input_audit.py':'Retained for provenance; scientific conclusions rely on data and chain-forensics record, not a full code audit.',
'research/modalities/nrv04-result-forensics.json':'Object classification, affected-result inventory, no-trajectory verdict and representative leg fields.',
'research/modalities/nrv04_result_forensics.py':'Classification and survey branches; no execution or cloud access.',
'research/modalities/antitarget-selfcontrol.json':'Criterion, panel results, repair delta and affected-claim interpretation.',
'research/modalities/pose-second-method.json':'Part A result, all twelve Part B dispositions, gradeability and limitations.',
'research/modalities/pose-conditionality-census.json':'Current evidence and pose/cavity attribution interpretation; schema of claim inventory.',
'research/modalities/r5-cross-method-cavity-attribution.json':'Rollup and relevant current interpretation; no coordinate reanalysis.',
'research/modalities/r3-generation-frame-harmonized.json':'Threshold, recorded score, gate and reference context.',
'research/modalities/nr4a3-5bt-gate.json':'Gate components, structural scope, verdict and count summary.',
'research/modalities/nr4a3-5bt-signature.json':'Original versus replicated result, structure-selection inventory and sixteen-model descriptor result.',
'research/modalities/nr4a2-sparing-bound.json':'Current genetic evidence/verdict, developmental/adult caveats and reported primary identifiers.',
'research/modalities/categorical-decoy-null.json':'Scope, selection schema, gradeability and result context; no structural calculations.',
'research/modalities/categorical-decoy-null-lbd.json':'Second scope, limits, C397 verdict and background dependencies.',
'research/modalities/apo-pose-recovery.json':'Criterion, selected panel, outcome structure and scope; no full docking-output validation.',
'research/modalities/apo-pose-site-in-regime.json':'Panel scope, outcome schema and preserved distinctions; no remeasurement.',
'research/modalities/nrv04-retro-secondaries.json':'Secondary/primary separation, provenance and relevant withdrawn-interface caveat.',
'research/modalities/step1-fanout-map.json':'Scope, counts, conditionality, charge provenance and historical restoration note.',
'research/modalities/nr4a3-5aks-lane-report.md':'Headings and relevant provenance/identity search hits only.',
'research/modalities/structural-provenance-census.json':'Schema and claim-specific search inspection only.',
'results/nr4a3-decoy/-mmgbsa/nr4a3-mmgbsa.json':'Primary committed score records: all 38 margins and their source fields compared to constant.',
'results/nr4a3-decoy/-mmgbsa-ms/nr4a3-mmgbsa.json':'Primary committed score records: all 38 margins and arm identity compared to constant.',
'results/nr4a3-decoy/-mmgbsa-metad-ms/nr4a3-mmgbsa.json':'Primary committed score records: all 38 margins and arm identity compared to constant.'}
uniq={}
for e in entries:
    if e['exit_code']!=0: continue
    p=R/e['retained_path']; b=p.read_bytes()
    assert hashlib.sha256(b).hexdigest()==e['sha256'] and len(b)==e['bytes']
    x=dict(e); rel=x.get('repo_path','')
    if rel in full: x['review_extent']='Full text/record read.'
    elif rel in selected: x['review_extent']=selected[rel]
    elif 'inputs\\local' in x['retained_path']: x['review_extent']='Full handoff or local guidance read; local source, not scientific data at fixed commit.'
    else: x['review_extent']='Retained and integrity/hash checked; not relied on as independently reviewed scientific contents.'
    uniq[x['retained_path']]=x
doc={'kind':'Exact retained-input manifest with honest review extent','fixed_commit':'0b965a1279c81c10d9edc054842a33446e87762e',
 'git_policy':'Every Git cat-file and ls-tree used GIT_NO_LAZY_FETCH=1. No fetch/checkout.',
 'n_retained_inputs':len(uniq),'files':sorted(uniq.values(),key=lambda x:x['retained_path']),
 'unsuccessful_reads':[e for e in entries if e['exit_code']!=0],
 'guidance_note':'Both frozen repository guidance and locally read guidance copies retained; byte identity is not inferred between them. Current local guidance is not a replacement scientific revision.'}
(R/'reviewed-input-manifest.json').write_text(json.dumps(doc,ensure_ascii=True,indent=2)+'\n',encoding='utf-8')
md=['# Reviewed and retained input manifest','',f"Fixed commit: `{doc['fixed_commit']}`.",'',
    'Exact bytes, source locators, SHA-256 and review extent are in `reviewed-input-manifest.json`. A retained or hashed file is not automatically a full scientific read.','',
    '| File | Bytes | SHA-256 | Extent |','|---|---:|---|---|']
for x in doc['files']:
    md.append('| '+x.get('repo_path',x['source'])+' | '+str(x['bytes'])+' | `'+x['sha256']+'` | '+x['review_extent']+' |')
(R/'reviewed-input-manifest.md').write_text('\n'.join(md)+'\n',encoding='utf-8')
outputs=[]
for p in sorted(R.iterdir()):
    if p.is_file() and p.name!='review-output-manifest.json':
        b=p.read_bytes(); outputs.append({'name':p.name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
(R/'review-output-manifest.json').write_text(json.dumps({'files':outputs},ensure_ascii=True,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'retained_inputs':len(uniq),'failed_reads':len(doc['unsuccessful_reads']),
 'report_bytes':(R/'FINAL-SCIENTIFIC-REVIEW-MF1.md').stat().st_size,
 'report_sha256':hashlib.sha256((R/'FINAL-SCIENTIFIC-REVIEW-MF1.md').read_bytes()).hexdigest(),
 'reviewer_calculation_exit':(R/'reviewer-calculations-exit.txt').read_text().strip()},ensure_ascii=True,indent=2))
