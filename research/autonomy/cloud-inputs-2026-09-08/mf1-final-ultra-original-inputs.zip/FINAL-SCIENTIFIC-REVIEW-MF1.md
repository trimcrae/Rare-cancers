# Independent final scientific review: MF1 methods failure record

**Disposition: MAJOR SCIENTIFIC REVISION. The frozen manuscript is not scientifically ready as a standalone preprint. A coherent repair using existing evidence is feasible; I do not recommend parking the entire audit.**

This is the one commissioned independent final scientific review of the frozen paper, not a preparation acceptance, a repeat baseline review, a publication decision, or authorization for new computation. The retained record contains useful, concrete cases of instrument failure, misattributed measurements, inadequate provenance, and unresolved validation. Several central methodological conclusions go beyond those cases or misread the evidence they cite. The appropriate endpoint is one batched scientific correction and focused verification of the corrected claims and their dependencies.

## Review identity and frozen scope

- Review date: 2026-09-08.
- Independent agent: `/root/mf1_final_ultra`; commissioned settings `gpt-6-astra`, `ultra`. The parent dispatch record is the authority for those settings. No usage or cost number is inferred from the agent name or review label.
- Repository: `C:/Projects/EMC-Research`.
- Fixed commit: `0b965a1279c81c10d9edc054842a33446e87762e`.
- Main: `research/manuscripts/methods-record/degrader-methods-failure-record.md`, 46,172 bytes; SHA-256 `a9058b6c40e32549f878347b2d4f8c0ed3f8593320ce417ef29367179a7d0fe2`.
- Main was read in full, including the taxonomy, support list, limitations, provenance, and declarations. Necessary source branches and retained data were inspected as identified below and in `reviewed-input-manifest.json`. Collection is not represented as a full scientific read of every byte of every dependency.
- All 41 handoff-listed files were read directly from local Git blobs at the fixed commit with `GIT_NO_LAZY_FETCH=1`; every byte count and SHA-256 matched the handoff. Additional claim-specific sources were collected the same way. Exact copies are retained under `inputs/frozen/`; the actual handoff and local guidance are under `inputs/local/`.
- No fetch, checkout, science producer, docking, molecular simulation, prediction, installation, broad test suite, ablation, manuscript edit, or external action was performed. No source-denial condition was bypassed. V4 remains unrun and unauthorized.
- The preparation handoff's historical “uncommitted” language does not describe the reviewed Git pin. Its style/metrics results are not scientific acceptance. The later-disclosed original preparation transcript was not needed to resolve the scientific questions and was not read or treated as missing science evidence.

All repository file/line references below refer to this fixed commit and the retained copies. `M:L` denotes line L of the main named above. References to JSON fields distinguish original retained data from reviewer arithmetic.

## Scientific merit that survives

The paper can make a useful, incremental contribution as a retrospective case study of how one computational program classified and corrected its own evidence. The value lies in identifiable failure mechanisms and auditable consequences, rather than a claim that computational selectivity prediction in general fails.

Several important facts survive this review:

1. The route really contains **20 unique instruments, 4 `support` and 16 `disclosed_failing`**. This is a route-selected denominator, not a whole-program failure frequency.
2. `selcal-verdict.json` really records **`NULL`**, a mean E1 difference of **+0.4373 Å**, one-sided **p = 0.746753**, **6 versus 5 model means**, and **zero admitted-arm technical failures**. Independent enumeration of all 462 assignments reproduces the statistic and both one-sided p-values. It was an executed, unsuccessful calibration attempt under the registered operational rule, not an absent control or absent result. Its statistical interpretation still needs F01.
3. The second docking method has **0 gradeable known-answer pairs out of 12 listed**, with **2 R2b exclusions, 6 `dock.prm` UNRUN entries, 1 fetch refusal, and 3 alignment refusals**. These are distinct dispositions. It also has six actual cross-method pose comparisons, so “the method never ran” would be false. The four non-`dock.prm` refusals are not attributable to `dock.prm`.
4. The anti-target panel records **7 of 10 cognate-ligand recoveries** and retains the same three failing receptors after the uniform receptor repair. The inability to justify whole-panel extrema from that panel is a sound, scoped audit finding.
5. The 38-drug decoy score distribution has a real committed source. I checked all three archived MM-GBSA arms; only `results/nr4a3-decoy/-mmgbsa/nr4a3-mmgbsa.json` reproduces `DECOY_2026_06_30`. Its **22 positive margins in 38** reproduce. The distinction between this observed call rate and biological false-positive rate is essential (F07).
6. The chain-assignment incident and lack of recoverable multi-frame coordinates are supported by a detailed retained census and forensic record. The paper currently combines different incidents incorrectly, but there is a useful, supportable provenance lesson after F04.
7. Noncovalent S does not test covalent-bond chemistry. An unrun control, an ineligible comparison, a failed operational calibration, a nondetection, and a statistical bound are different things. The paper's wish to preserve those distinctions is valuable; its present taxonomy does not consistently achieve it.

No wet-lab experiment is required to establish those audit facts. No efficacy, safety, clinical readiness, binding, or therapeutic-window conclusion is justified or needed.

## Required findings, prioritized

### F01 — P1: The “adequately-powered null” is established only as a test whose p-value can reach alpha

**Outgoing claim:** M:45–49, 99–107, 137, 173, 178–199. The abstract makes adequate power one of its three central negative results.

**Evidence:** `selcal-verdict.json:26–53` defines the operational criterion; `:61–101` contains the model means and reference set; `:155–156` makes the adequacy claim. `selcal_panel.py:399–408` explicitly equates adequate power with membership/reference-set clauses. `selcal_gate.py:38–50,228–246,300–305` implements those clauses, with no effect-size power calculation. The independent reviewer result is 1/462 = 0.0021645 for the attainable p-value floor. That is a statement about discreteness, not probability of detecting a relevant alternative.

There is also no established known answer in the **E1 observable**. `selcal_panel.py:89–124` states that E1 has no established quantitative link to degradation selectivity. Its reference establishes cellular degradation direction for **PRT3789**, whereas `PASS_CRITERION._what` still names **ACBI2** (`selcal_panel.py:370–371`; copied into `selcal-verdict.json:28`). The source expressly separates a mechanism citation about the protein pair from a claim about PRT3789 (`selcal_panel.py:136–145`). Finally, `selcal-cofold-vs-crystal.json:2–5` says the promised co-fold/crystal validation had not been implemented before the panel; `selcal-cofold-dockq.json` records low-quality target–E3 placement on all 12 scored co-folds. A nondetection on those inputs cannot isolate E1's sensitivity.

**Consequence:** The manuscript promotes failure to achieve the registered directional pipeline criterion into evidence of a powered failure to recover a known structural/dynamical difference. The caveats in §4.3 do not undo the stronger abstract and taxonomy wording. A technically successful MD leg also does not establish a physically correct input or an adequately sampled observable.

**Minimum correction:** Retain the original `NULL` tier and `fails` control state. Report an **executed calibration attempt that did not meet its directional discrimination criterion**, with the actual sample size, effect estimate, p-value, attainable floor, lack of established E1 effect size, and failed input-generation check. Remove “adequately powered,” “cannot see … at all,” and the claim that the reference-set floor establishes sensitivity. Correct the PRT3789/ACBI2 reference identity in current scientific summaries while preserving the historical original. Do not manufacture a new power calculation from the observed effect.

**Reopening for a stronger claim:** A previously retained, identifiable, genuinely prospective power specification in the E1 estimand with effect-size/noise assumptions, plus input-validity evidence supporting the claimed use of that readout. A small p-value floor or a `_frozen` Boolean is not that evidence. No new panel is necessary for the narrower repair.

### F02 — P1: Two seeds and an SD are not an effect-size bound; “preregistered null” does not confer validity

**Outgoing claim:** M:55–57, 139, 147–158, 365–366; the asserted distinction is the paper's centerpiece.

**Evidence:** `nr4a3-5aks-reduction.json:3–7,8–33` records S = −0.1297 kcal/mol and `S_err_kind: replicate_sd` = 0.3264, with **two values per species**. The reducer computes the difference of species means and `sqrt(sd_A² + sd_B²)` (`nr4a3_5aks_reduce.py:146–153,169–201`); it does not construct a confidence interval, equivalence test, likelihood bound, or calibrated physical-effect bound. `nr4a3-program-map.md:690–692` nevertheless translates the eligibility condition into exclusion of effects ≳0.65 kcal/mol at “2σ.”

Reviewer arithmetic reproduces the reported numbers. To expose the missing assumption rather than replace the original analysis, an explicitly illustrative independent Gaussian/equal-variance t interval at n = 2 + 2 is approximately **[−1.123, +0.863] kcal/mol**, with SE 0.2308 and two degrees of freedom. Even that model-dependent interval is not the paper's claimed 0.65 bound. The original record also reports `system_identity_problems` for particle counts (`nr4a3-5aks-reduction.json:34–53`). Different water counts do not by themselves prove invalid physics, and cross-species systems need not have identical counts; the material issue is that the manuscript treats the calculation as an unqualified bound without explaining the comparability flag, modeled ensemble, or uncertainty coverage.

**Consequence:** Prespecifying that a null is likely and not a stop is a decision rule, not an equivalence result. It does not establish absence of the marginal wedge or convert an uncalibrated estimator into a bound. “Causal” here can describe an intervention on the **modeled ligand Hamiltonian conditional on the chosen structures**; it is not a biological causal test of degradation or covalent selectivity. The blanket first-order opening-penalty cancellation argument at M:388–390 also needs the common-reference-state and ensemble assumptions that make a relative cancellation valid.

**Minimum correction:** Retain S as an **exploratory conditional estimate with between-seed dispersion**, compatible with zero at the observed precision, and say that the design's operational completion condition was met. Keep the statement that it has no known-answer calibrator and cannot test covalent chemistry. Remove the assertion that this alone returns a bound, proves a null, or shows an absent wedge. Explain the particle-count/comparability flag without either silently dismissing it or declaring all differently solvated runs invalid. Qualify the modeled causal and cancellation claims.

**Reopening for a bound:** A source-level uncertainty analysis with an explicit estimand, independence/covariance assumptions, sampling unit, coverage or equivalence criterion, handling of model/input uncertainty, and justified confidence. New V4 or new simulations are not required to publish the narrower recorded estimate.

### F03 — P1: Cycle closure does not uniquely localize the calibrator's failure or exclude sampling error

**Outgoing claim:** M:99–107, 136, 391–394, 434; repeated wrong sign is presented as excluding sampling, and the miss is said to be diagnosed as endpoint-state error.

**Evidence:** `valb-triangle-reduction.json:44–81` reports one-seed residuals R_ternary = −0.0312, R_binary = −0.2440, and R = +0.2128 kcal/mol, with **no replicate error bar**. `valb-triangle-closure.json:28–45` correctly states that endpoint-state errors are invisible to closure. The roadmap reverses that implication into “R ≈ 0 ⇒ endpoint-state error; more sampling will not fix it” (`nr4a3-program-map.md:1284–1307`). `valb-failure-propagation.json:31–75` itself says the triangle's power can be approximately 0.63 under its proposed upper noise estimate, not a clean exclusion. Its estimate of an “upper bound” on sigma from three replicates (`:16–29`) is not a confidence bound on the underlying variance.

The algebraic issue is decisive: the residual measures one linear contrast of edge errors. Errors [1, 2, 3] on the three oriented edges give zero closure despite every edge being wrong. Conservatively structured bias caused by shared incomplete sampling can also telescope. Observing a small residual neither identifies the physical cause nor bounds all the edge errors. Repetition of a wrong sign strengthens the observed calibration failure; it does not rule out shared metastability or sampling bias.

The “converged sampling … all present” claim is also too strong relative to the retained diagnostic account: the roadmap reports binary ligand departure and a `MEASURED_FAILURE` convergence state (`nr4a3-program-map.md:1567–1579`). A passed closure/antisymmetry statistic is not a general convergence certificate.

**Minimum correction:** Keep the repeated wrong-sign **operational calibration failure**. State that cycle closure is compatible with several unresolved error sources and cannot detect a conservative endpoint bias. Report selected diagnostics as selected diagnostics, not proof of converged sampling. Remove unique localization, excluded-sampling, and no-remediation-by-sampling claims from the paper and any current summary it asks readers to treat as authoritative.

**Reopening for diagnosis:** Retained discriminating evidence that separates proposed causes, rather than another closure identity or the same failed comparison. This review does not authorize obtaining that evidence. The narrower failure report is publishable without a uniquely identified cause.

### F04 — P1: The “largest retraction” combines different input sets and overstates what persistence can repair

**Outgoing claim:** M:58–62 and 420–430 say the panel's retraction arose from chain ordering, units, and contaminated inputs; no known-answer test could catch any of them; all were correctable in principle but not in practice because trajectories were absent.

**Evidence:** `nrv04-cofold-chain-forensics-2026-07-24.md:25–60` explicitly distinguishes contaminated **descriptive-v3/shakeout** co-folds from the **completed covalent feasibility panel**, whose July 22 inputs were clean of that contamination. The chain-order error affected the completed panel (`:64–99`); its warhead-only legs also tethered the wrong cysteine, a change to the simulated physical system. The retained result census (`nrv04-result-forensics.json:5–50,671–674`) identifies 17 result records, zero multi-frame trajectory objects under the surveyed prefix, and the reason corrected-interface readouts cannot be recomputed. That supports a retrospective census conclusion, not a proof about every possible external copy of the data.

The source itself says **existing tests did not catch** these defects (`nrv04-cofold-chain-forensics-2026-07-24.md:21`); it does not say known-answer tests cannot catch them. Its fixes include chain-identity and contaminant-rejection checks (`:103–119`). A known fixture with reordered chain IDs, a unit-scaled geometry fixture, or a verified chain-sequence reference can detect exactly these errors. Persisting coordinates permits corrected post-processing; it cannot convert a trajectory generated with the wrong protein or covalent bond into the counterfactual trajectory of the intended system.

**Consequence:** The paper's second central rule is motivated by an inaccurate causal history and an incorrect universal claim. It also conflates input, execution, and analysis defects—the distinction the audit should be teaching.

**Minimum correction:** Separate the contaminated co-fold incident, wrong-interface post-processing, unit conversion, and wrong covalent tether, with the affected panels named. Say the existing tests missed these defects. Explain which results a saved trajectory could have enabled to be rescored and which physical-input errors still require a new computation. Retain the lost-coordinate finding at the surveyed prefixes. Replace “largest” unless a defined measure of magnitude is supplied. Persist inputs, identities, code/parameter versions, and trajectories appropriate to the observable; trajectory storage alone is not sufficient.

**Reopening for a merged or stronger historical claim:** Original identified panel/seed provenance establishing that the same executed panel actually carried each alleged defect. The current forensic source establishes the opposite for contamination. No recreation of the lost runs is needed or permitted for this repair.

### F05 — P1: A route-selected register does not establish complete ascertainment, and the four categories mix different axes

**Outgoing claim:** M:91–97, 206–249, 460–464; the audit is “complete, not selective” and the missing-failures objection is answerable “by construction.”

**Evidence:** The 4/16 partition at M:232–236 is correct. The numbered instrument census has **22** entries (`instrument-census.md:13,39–60`); V2 and V18 are absent from the route partition. V2 is relevant to the assembly/generator examples the main discusses. The full graph also has additional non-V instruments. A graph-generated view proves consistency with the chosen graph, not that every historically used method was discovered, registered, or included. The census was added retrospectively and itself says V21 had been quoted for months without a row (`instrument-census.md:58`).

Nor are all examples in M:243–245 known-answer controls in the same sense. V13's “control” is a **mechanism hypothesis** about a two-state opening; its failure is not a failed recovery of independently established truth (`instrument-census.md:51`; `systems/graph/instruments.json`, V13). V15's permutation nulls are not a positive known-answer benchmark (`instrument-census.md:53`). V19 contains both a completed negative-control arm and an unrun decisive arm (`:57`); assigning it a single “could not resolve” row erases an execution dimension. V22 has no **successful** known-answer calibration, but the paper itself now documents an attempted known-answer panel with no gradeable cases. “No control exists” is not a sufficiently precise description of that history.

**Minimum correction:** Keep the verified 20-instrument route count and explicitly state the inclusion rule and why V2/V18 are outside that count. Either provide a complete 22-entry numbered-instrument supplement with inclusion flags or narrow “complete” to the enumerated route records. Separate **control availability/type**, **execution/eligibility**, **statistical or operational outcome**, and **claim scope** as fields; then give a complete per-instrument mapping. Preserve the original route label `disclosed_failing` as a historical administrative field, not a scientific failure total. Distinguish hypothesis failure, validation failure, technical failure, nondetection, and no possible grade.

**Reopening for whole-program completeness:** A fixed audit universe, time cutoff, reproducible inclusion/exclusion rule, and evidence of inventory ascertainment against the program's executed/claimed methods. Merely regenerating the graph cannot establish it. No whole-repository staging or generic guard corpus is needed.

### F06 — P1: “Every method … first” is contradicted by the history; the three attempts are not demonstrated independent validations

**Outgoing claim:** M:35–49, 91–92, 273–277, 353–355. The abstract says every method used to support a selectivity statement was **first** tested against a known answer, and describes three “independent, preregistered” attempts.

**Evidence:** The main itself describes previously untested instruments assessed for the first time in August (M:273–277), and the V21 census says it had been quoted for months before its first test. V9/V14/V16/V22 lack successful known-answer calibration; V4 never returned a result. Two of the three headline attempts are V11 applications, with a shared E1 readout and scorer (`selcal_gate.py:198`; `nrv04_retro_gate.py:98–166`). The alchemical and E1 lanes are different instruments, correctly noted at M:171–174, but different instruments or systems alone do not establish statistical or failure-mode independence. This is one program with shared code, selection decisions, and structural assumptions.

Preregistration should be reported as a verifiable chronology. The current preregistration files contain amendments and backfilled metadata; e.g. `selectivity-sensitivity-control-prereg.md:11–32` has a backfilled August 5 date, while `selcal-verdict.json:166` gives the August 2 outcome timestamp. This does **not** prove post hoc registration, but current `_frozen` assertions and a current Git pin alone do not prove which rule existed before outcome access. The main does not give the individual freeze revisions, amendment timing, or first outcome-access record needed for a reader to check its strongest chronological claim.

**Minimum correction:** State that the audit retrospectively assembled **three recorded attempts**, with the shared and differing dependencies specified. Replace “every method was first put to” with the actual mixture of prospective checks, retrospective checks, absent calibrators, and unrun plans. For each claimed prespecification, provide the original rule locator/revision, amendments, input exclusion timing, and outcome locator if those retained records establish them. Otherwise use “the retained protocol describes these rules as prespecified.” Do not label the attempts three independent confirmations of a single scientific proposition.

**Reopening for stronger chronology/independence:** Identifiable pre-outcome rule versions and an explicit independence argument for the particular inferential claim. This is an evidence identification task, not permission for new validation runs.

### F07 — P1: Decoy positive calls and a pocket score do not prove universal impossibility or a biological false-positive rate

**Outgoing claim:** M:108–109, 323–326, 361–364, 382–390, 417–418. The manuscript claims a within-repository false-positive rate, exclusion of a design class, an unrecoverable signal, and that a candidate cannot be better than its designed pocket.

**Evidence:** The archived canonical decoy output supplies computed scores and computational labels; it does not supply measured NR4A negative labels. The 22/38 rate is therefore an **empirical positive-call rate among the selected non-NR4A decoys**, not an independently measured biological false-positive rate. `selectivity_calibration.py:17–20` states that the distribution depends on receptor frames; `:7–14` even uses that background to identify an above-background candidate. This is evidence against taking margin > 0 alone as selectivity, not evidence that no downstream method can extract useful information or that the design class is impossible.

`r3-generation-frame-harmonized.json.verdict` gives **0.259 versus the program's 0.53 threshold**. It establishes failure of that chosen screening gate, not a theorem about binding, ligand-induced states, or every molecule generated there. Likewise, one program cannot establish the universal claim that an in-silico instrument will “never” answer a class of questions; it can state that its computations do not empirically establish binding or replace the relevant measurement.

**Minimum correction:** Report each operational gate and conditional distribution at its actual scope. Replace “false-positive rate” with the measured decoy call-rate definition unless experimentally negative labels are established. Replace permanent design-class and downstream-impossibility prescriptions with the specific unsupported inference that was withdrawn. State that conditional predictions are not empirical demonstrations of binding. Keep the existing no-efficacy/no-selectivity safeguards.

**Reopening for broader statements:** Independently established negative labels, a justified reference population/selection scheme, or a proof matching the claimed universal domain. The existing threshold and decoy data cannot supply those claims by themselves.

### F08 — P2: The V1 null concerns a defined polar-contact descriptor, not all discriminating contacts

**Outgoing claim:** M:258, 336–342 calls this the strongest negative and says there is no sequence-encoded discriminating contact in any model.

**Evidence:** `selcal_interface_signature.py:29–31` explicitly labels its output a **heavy-atom polar-contact proxy**, not a measured hydrogen bond. `:159–186,191–209` shows the side-chain-polar criterion and a glutamine-specific known-answer check. The implementation notes that the criterion was corrected after the initial known-answer miss. `nr4a3-5bt-signature.json:4568–4578` reports zero qualifying positions across the 16 focus models, and labels the result descriptive. One recovered contact does not establish sensitivity to all polar interactions, hydrophobic contacts, energies, or a target-specific mechanism.

**Minimum correction:** Name the descriptor and threshold, say **no qualifying sequence-variable polar contact under this descriptor in these generated structures**, and identify the known-answer recovery as an in-sample development/harness check with a narrow scope. Preserve the supported statement that these models provide no such contact-based justification for a selectivity claim. Remove or define the unmeasured ranking “strongest.” No additional benchmark is required for this descriptive version.

### F09 — P2: Two current interpretations are contradicted by the paper's own retained dependencies

**F09a, pose location:** M:294–298 says the disagreement decomposes as same location, different orientation. `pose-conditionality-census.json:118–133,404` and the directly retained `r5-cross-method-cavity-attribution.json:491–506` show **4 same-cavity and 1 different-cavity system among 5 gradeable**, with another system ungradeable. The source explicitly rejects a universal orientation-only reading. **Repair:** report the mixed cavity attribution and retain that neither docking method is thereby proven correct or wrong. D3's 0/12 dispositions remain unchanged.

**F09b, genetic requirement:** M:403–407 initially describes one direction as bounded and then calls the other paralogue unbounded in either direction. `nr4a2-sparing-bound.json:2266–2268` establishes a citable complete-germline Nr4a2-loss consequence; `:14,2267` explicitly distinguishes developmental complete loss from adult transient protein degradation. **Repair:** state the current asymmetric evidence, identify NR4A1/NR4A2 by name, and preserve the adult/developmental distinction. Replace “would reconstitute” a knockout genotype with a qualified concern about combined loss; no pharmacological equivalence is measured here. No new genetics or exposure study is necessary for that correction.

### F10 — P2: The SD/MBAR-SE lesson compares different estimands and cannot supply an exact uncertainty multiplier

**Outgoing claim:** M:431–433 says the within-run uncertainty understates uncertainty by “exactly that factor.”

**Evidence:** `valb-failure-propagation.json:5–14,146–153` compares a **cycle** replicate SD of 0.375 with **per-leg** MBAR SEs of 0.097–0.132, producing approximately 3.28. A cycle is a difference of legs. Under an explicit independence illustration, the two-leg MBAR SE is sqrt(0.097² + 0.132²), giving a ratio approximately **2.29**, not 3.28; covariance changes it again. SD across replicates and SE of a replicate mean also answer different questions. Three replicates do not establish a universally transferable correction factor or a rigorous upper noise bound.

**Minimum correction:** Keep the useful warning that within-run precision does not describe between-run variability or accuracy. Report the observed SD and SE with their estimands and sample counts, and remove the exact inflation-factor claim. Do not replace 3.28 with 2.29 as a supposedly correct empirical factor; the calculation only demonstrates the missing assumptions.

### F11 — P1: The accusation about a published “unbound” benchmark is not demonstrated by the cited retained source

**Outgoing claim:** M:108–109 and 375–378 say the audit refuted a published method's claim from its released data.

**Evidence:** The cited roadmap entry (`nr4a3-program-map.md:2500`) asserts that shipped ligand coordinates are identical to the native structure over 66 atoms and points to `selcal-deepternary-frame.json`. The actual fixed file is a **single SMARCA2 preparation record with 64 degrader atoms** (`selcal-deepternary-frame.json:26–29,53–71`); it records alignment/preparation and file readability, not the asserted 66-atom equality on a released benchmark case. `selcal-deepternary-poscontrol.json` does establish an in-set 6HAX harness result, but it is not the primary paper's protocol definition or the missing coordinate comparison. “Unbound” can describe different aspects of inputs; a mismatch between a user's interpretation of a label and released inputs is not by itself a refutation of the publication's explicit claim.

**Minimum correction:** Either provide the already-retained actual released-case comparison, pinned file identities, and the exact primary protocol statement being contradicted, or narrow this to a finding about the program's own assumed input protocol and its consequent relabeling. Keep the in-set control's memorization-permitting scope. Do not assert a defect in the external publication on the basis of the current pointer.

**Reopening:** The exact retained source-level comparison and primary text addressing what information the method claims to withhold. No new literature/source search or blocked-program investigation is commissioned here; if the retained comparison cannot be identified, withdraw the external refutation claim.

### F12 — P1: The main is not yet a standalone, reproducibly interpretable audit

**Outgoing locations:** M:26–29, 91–110, 130–132, 208–212, 518–559, 585–588.

There are actually **four Markdown tables** in the main (separator lines 135, 242, 257, 308). The preparation metric “0 tables” is not an accurate count of those displays, and zero figures is not an objection. The problem is the intentional omission of most numerical results, methods, and primary citations while the paper makes quantitative and causal methodological claims. To recover the core argument, a reader must traverse a 616,465-byte roadmap, generated registers with different denominators, and nested JSON files containing both historical and current interpretations. Those sources themselves contain contradictions identified above. “A committed artifact exists” does not identify the executed version, establish the correctness of its interpretation, or make a preprint's data accessible.

The main has no conventional primary-source references for its known answers or external-method claims. It leaves prior-art citation as a future obligation at M:510–512. It also still says the field is short of these audits at M:35–36 despite §9.2 saying its unsupported bibliometric framing was removed. The retained E1 reference distinguishes a published qualitative claim from inaccessible quantitative data; that distinction must reach the main rather than be discoverable only in code. Data availability provides relative paths, not an accessible immutable repository/archive release and a versioned manifest.

**Minimum correction:** Provide a compact main results table and a per-instrument supplementary inventory generated from the chosen frozen source, so the single-source practice is preserved without withholding the results. At minimum expose: control/reference identity; operational criterion; units; eligible, excluded, failed, and unrun counts; sampling unit; estimate and uncertainty type; actual result; interpretive limit; source revision/path. Add a methods paragraph specifying the audit universe, ascertainment, retrospective/prospective status, and handling of contradictory or superseded records. Provide primary references already supported by retained sources, and a precise data/code release locator with file hashes. Distinguish original raw records, retained reductions, narrative annotations, and new reviewer/author calculations. Identify input or trajectory gaps at the claims they limit rather than claiming end-to-end execution reproduction for everything. Remove the residual unsupported field-frequency/novelty premise.

This is a substantive reproducibility repair, not a demand for decorative figures or a conventional experimental IMRaD format. Missing original trajectories do not automatically invalidate a historical audit; they limit the class of conclusion that can be independently checked. The decoy chain can already be made inspectable end to end from its retained run outputs. The E1 inference can already be independently recomputed from its retained model-level values, although that does not validate the trajectories that produced them.

## One coherent correction batch and stopping condition

The batch should revise the abstract, thesis, taxonomy, results, and general lessons together. Fixing isolated sentences while leaving the central “powered null / causal bound / uniquely diagnosed failure” framing would not resolve these findings.

1. Reframe the paper as a **retrospective audit of the specified instrument records**, with explicit scope and ascertainment. Preserve the accurate 20-entry route partition and explain its relationship to the 22-entry numbered census.
2. Replace unsupported scientific interpretations with measured outcomes: unsuccessful operational E1 calibration; descriptive S estimate and dispersion; repeated wrong-sign calibration with unresolved cause; distinct infrastructure incidents with their actual affected inputs.
3. Separate the axes of control type, execution state, inferential outcome, and claim scope. Keep failed, unrun, excluded, and ungradeable records visible.
4. Correct current dependent summaries that would otherwise contradict the revised main, while preserving original execution outputs and historical decisions as immutable evidence. Add explicit corrective interpretation rather than silently rewriting original result provenance.
5. Add the compact quantitative inventory, known-answer citations, actual frozen provenance locators, and limitations needed for a reader to reproduce the audit's reductions. Apply F08–F11's narrower source-specific corrections.

**No scientific rerun is a prerequisite for this narrower paper.** In particular, no V4, new co-fold, new trajectory, design change, source-query reopening, or wet-lab result is requested. Stronger claims have explicit source-level reopening conditions in the findings; if they cannot be met from retained records, omit those claims. After the batch, a focused independent verification should check only the changed claims and their dependencies. Another whole-paper baseline review is not warranted merely by administrative or unrelated repository changes.

**Why not PARK:** The original decoy outputs, model-level E1 data, D3 disposition records, and chain/trajectory forensic records provide enough substance for a useful, truthful audit after narrowing. Its central practical merit does not require proving that all methods are intrinsically incapable, that all nulls are powered, or that storage repairs every error. If the author elects to retain those stronger unsupported claims instead of narrowing, park that formulation pending the exact evidence specified above; do not reopen the underlying programs simply to rescue the prose.

## Verification record and limitations of this review

`reviewer_calculations.py` is a **new, independent, deterministic reviewer script** using only Python's standard library and retained inputs. It is not an original execution transcript. One run completed with exit **0**, all arithmetic assertions passed, and it wrote:

- `reviewer-calculations.json`: complete structured results, including 41-file hash agreement, route counts, exact E1 enumeration, S arithmetic and explicitly assumed illustrative interval, closure arithmetic/counterexample, three archived decoy-arm comparisons, D3 counts, zero-event bound illustration, uncertainty-estimand illustration, and the four-table count.
- `reviewer-calculations-stdout.txt`: saved full combined command output.
- `reviewer-calculations-exit.txt`: saved process exit code.

No original producer was imported or executed; the one constant was read through Python AST literal extraction. No stochastic power simulation or new structural computation was performed. The exact D3 fetch/alignment refusal records were additionally read directly; no attempt was made to repair or rerun them. The zero-event calculation agrees with the manuscript's “narrowed, not excluded” interpretation under the stated independent-Bernoulli approximation; the paper should not present the approximate bound as a literal zero rate.

The retained record review does **not** certify every original model coordinate, trajectory, experiment, timing statement, cloud object inventory, or external paper quotation. It distinguishes verified arithmetic and inspected source logic from those historical assertions. The complete reviewed/retained input manifest records that scope; hashes establish byte identity, not scientific truth. A single mistyped collection path (`selcal-interface-signature.py`) returned Git exit 128; the actual underscore-named file was then read successfully at the same fixed pin. No required blob was missing and no network hydration occurred. There is no claim that publication CI, a venue gate, or submission authority was established.

The report completes the commissioned final scientific review. Historical presentation acceptance and passing guard counts should not be substituted for resolution of F01–F12.
