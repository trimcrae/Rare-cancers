"""New independent reviewer arithmetic only. No producers, network, or original artifact writes.

These calculations re-read retained summaries, not original simulation trajectories.
The illustrative t interval is an explicit counterexample to interpreting two SDs as
a coverage guarantee; it is NOT a replacement analysis of the original experiment.
"""
from pathlib import Path
import ast, hashlib, itertools, json, math, re, statistics, sys

ROOT=Path(__file__).resolve().parent
F=ROOT/'inputs/frozen'
def read(rel): return json.loads((F/rel).read_text(encoding='utf-8'))
out={'kind':'NEW REVIEWER CALCULATIONS; not original execution output', 'python':sys.version, 'checks':{}}

handoff=(ROOT/'inputs/local/HANDOFF-MF1-methods-record-frozen.md').read_text(encoding='utf-8')
rows=re.findall(r'^\| `([^`]+)`(?: \*\*\(main\)\*\*)? \| (\d+) \| `([0-9a-f]{64})` \|$',handoff,re.M)
comparison=[]
for path,n,sha in rows:
    b=(F/path).read_bytes()
    comparison.append({'path':path,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),
                       'match':len(b)==int(n) and hashlib.sha256(b).hexdigest()==sha})
out['checks']['handoff_manifest']={'n':len(comparison),'all_match':all(r['match'] for r in comparison),'files':comparison}
assert len(comparison)==41 and all(r['match'] for r in comparison)

route=next(x for x in read('systems/graph/routes.json') if x['id']=='RT-METHODS-PAPER')
ins=route['instruments']
vs=[x['id'] for x in read('systems/graph/instruments.json') if re.fullmatch(r'V\d+',x['id'])]
paper=ins['support']+ins['disclosed_failing']
out['checks']['route_partition']={'support':ins['support'],'disclosed_failing':ins['disclosed_failing'],
 'unique_cited':len(set(paper)),'V_numbered_register':len(vs),'V_numbered_not_in_route':sorted(set(vs)-set(paper))}
assert len(ins['support'])==4 and len(ins['disclosed_failing'])==16 and len(set(paper))==20

sel=read('research/modalities/selcal-verdict.json')
a=list(sel['model_means_A'].values()); b=list(sel['model_means_B'].values()); pool=a+b
obs=statistics.mean(a)-statistics.mean(b); n=len(a); m=len(b)
stats=[]
for comb in itertools.combinations(range(n+m),n):
    s=sum(pool[i] for i in comb)
    stats.append(s/n-(sum(pool)-s)/m)
p=sum(x<=obs+1e-10 for x in stats)/len(stats)
pm=sum(x>=obs-1e-10 for x in stats)/len(stats)
out['checks']['selcal']={'n_model_A':n,'n_model_B':m,'statistic':obs,'n_arrangements':len(stats),
 'p_less':p,'p_greater':pm,'attainable_floor':1/len(stats),'original_tier':sel['tier'],
 'original_technical_failures':sel['technical_failures'],
 'interpretation':'Arithmetic reproduces. Attainable p-value floor is not an effect-size power calculation.'}
assert round(p,6)==sel['p'] and round(obs,4)==sel['statistic'] and round(pm,6)==sel['p_mirror']

ks=read('research/modalities/nr4a3-5aks-reduction.json')
x=ks['per_species']['NR4A3']['dg_morph_kcal']; y=ks['per_species']['NR4A1']['dg_morph_kcal']
est=statistics.mean(x)-statistics.mean(y); sd1=statistics.stdev(x); sd2=statistics.stdev(y)
quadrature_sd=math.hypot(sd1,sd2); se=math.sqrt(sd1**2/len(x)+sd2**2/len(y))
# Exactly t(.975,df=2), the equal-variance normal illustration for n=2+2.
q=.95; tcrit=math.sqrt(2*q*q/(1-q*q)); half=tcrit*se
out['checks']['5aks']={'S':est,'sd_A':sd1,'sd_B':sd2,'quadrature_SD':quadrature_sd,'twice_quadrature_SD':2*quadrature_sd,
 'independent_means_SE':se,'illustration_assumptions':'independent Gaussian values, equal variances, no model bias; assumptions NOT established by record',
 'illustrative_t_df':2,'illustrative_t95_critical':tcrit,'illustrative_CI95':[est-half,est+half],
 'original_system_identity_problems':ks['system_identity_problems'],
 'interpretation':'Original arithmetic reproduces. No confidence/equivalence or physical-effect bound follows from a two-seed eligibility rule.'}
assert round(est,4)==ks['S_kcal'] and round(quadrature_sd,4)==ks['S_err_kcal']

tri=read('research/modalities/valb-triangle-reduction.json')
v=tri['dg_morph_kcal_by_env_and_edge']
res={env:vals['T1']+vals['T2']-vals['T3'] for env,vals in v.items()}
err=[1.0,2.0,3.0]
out['checks']['closure']={'R_ternary':res['ternary'],'R_binary':res['binary'],'R_coop':res['ternary']-res['binary'],
 'counterexample_nonzero_edge_errors':err,'counterexample_closure':err[0]+err[1]-err[2],
 'interpretation':'A cycle sees one contrast of edge errors. Zero contrast does not identify their generating cause or bound every error; shared sampling bias can cancel.'}
assert round(res['ternary']-res['binary'],4)==tri['R_kcal']

const_tree=ast.parse((F/'research/modalities/selectivity_calibration.py').read_text(encoding='utf-8'))
const=next(ast.literal_eval(n.value) for n in const_tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='DECOY_2026_06_30' for t in n.targets))
prov=read('research/modalities/decoy-null-provenance.json')
raw_arms=[]
for arm in prov['arms']:
    doc=read(arm['artifact'])
    candidates=doc['candidates']
    # Retained output's explicit selectivity-margin field; no rescoring of molecules.
    margins=[r['mm_min_margin'] for r in candidates]
    raw_arms.append({'arm':arm['arm'],'n':len(margins),'positive':sum(v>0 for v in margins),
        'matches_constant':sorted(margins)==sorted(const)})
out['checks']['decoy']={'arms':raw_arms,'constant_n':len(const),'constant_positive':sum(v>0 for v in const),
 'constant_positive_fraction':sum(v>0 for v in const)/len(const),
 'interpretation':'Positive-call rate under the specified decoy selection. Biological false-positive rate requires known biological negative labels, not supplied by these score records.'}
assert [x['arm'] for x in raw_arms if x['matches_constant']]==['-mmgbsa']

pose=read('research/modalities/pose-second-method.json')
pair_states=[]
for pair in pose['part_b']['pairs']:
    # Only direct disposition fields; no inference from the empty numeric grades.
    pair_states.append({k:v for k,v in pair.items() if not isinstance(v,(dict,list))} |
                       {'second_method_status':pair.get('second_method',{}).get('_status')})
out['checks']['D3']={'n_pairs':len(pair_states),'n_R2b':sum(p.get('excluded_by')=='R2b' for p in pair_states),
 'n_dock_prm_UNRUN':sum('dock.prm' in (p['second_method_status'] or '') for p in pair_states),
 'n_gradeable':pose['part_b']['rollup']['n_gradeable'],'recorded_states':pair_states}
assert len(pair_states)==12 and out['checks']['D3']['n_R2b']==2 and out['checks']['D3']['n_dock_prm_UNRUN']==6 and out['checks']['D3']['n_gradeable']==0

out['checks']['zero_event_bound']={'n':191,'events':0,'rule_of_three':3/191,'one_sided_95_binomial_upper':1-.05**(1/191),
 'comparison_rate_1_of_191':1/191,'one_sided_Fisher_0_vs_1_equal_arms':.5,
 'assumption':'Independent Bernoulli trials; repeats/candidate correlations would need separate treatment.'}
out['checks']['uncertainty_estimands']={'cycle_SD':.375,'per_leg_MBAR_SEs':[.097,.132],
 'cycle_SD_over_mean_per_leg_SE':.375/statistics.mean([.097,.132]),
 'cycle_SD_over_independent_two_leg_SE':.375/math.hypot(.097,.132),
 'interpretation':'The reported approximately 3.28 factor compares different quantities. Any same-estimand comparison also requires covariance and SE-versus-SD definitions.'}

main=(F/'research/manuscripts/methods-record/degrader-methods-failure-record.md').read_text(encoding='utf-8')
separators=[i for i,l in enumerate(main.splitlines(),1) if re.match(r'^\|\s*:?-+',l)]
out['checks']['presentation']={'markdown_table_separator_lines':separators,'n_markdown_tables':len(separators),
 'interpretation':'Four actual Markdown tables; the preparation metrics reporting zero tables are not a reliable scientific presentation count.'}
assert len(separators)==4

(ROOT/'reviewer-calculations.json').write_text(json.dumps(out,ensure_ascii=True,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in out['checks'].items() if k!='handoff_manifest'},ensure_ascii=True,indent=2))
print('All reviewer arithmetic assertions passed. Original records were not modified.')
