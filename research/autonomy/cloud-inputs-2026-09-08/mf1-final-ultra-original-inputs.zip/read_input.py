from pathlib import Path
import json, sys
root=Path(__file__).resolve().parent/'inputs/frozen'
path=root/sys.argv[1]
lines=path.read_text(encoding='utf-8').splitlines()
if len(sys.argv)>2:
    for arg in sys.argv[2:]:
        if arg.startswith('@'):
            data=json.loads('\n'.join(lines))
            for key in arg[1:].split('.'):
                if key: data=data[int(key)] if isinstance(data,list) else data[key]
            print(json.dumps(data, ensure_ascii=True, indent=2))
        else:
            span=arg.split(':'); a=int(span[0]); b=int(span[-1])
            for i in range(a-1,min(b,len(lines))): print(f'{i+1}: '+lines[i].encode('ascii','backslashreplace').decode())
else:
    for i,l in enumerate(lines): print(f'{i+1}: '+l.encode('ascii','backslashreplace').decode())
