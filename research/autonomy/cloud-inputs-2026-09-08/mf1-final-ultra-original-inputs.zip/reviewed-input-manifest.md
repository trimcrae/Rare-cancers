# Reviewed and retained input manifest

Fixed commit: `0b965a1279c81c10d9edc054842a33446e87762e`.

Exact bytes, source locators, SHA-256 and review extent are in `reviewed-input-manifest.json`. A retained or hashed file is not automatically a full scientific read.

| File | Bytes | SHA-256 | Extent |
|---|---:|---|---|
| .claude/skills/paper-hardening/SKILL.md | 1937 | `497689024cf143920696031f265ddf69d58381ea2cce4a025871d85d38ede4ea` | Full text/record read. |
| .claude/skills/repo-gates/SKILL.md | 1794 | `228e27b07811a027d60e548d88e41e992280d788c2478aa2c7fb467af8cbafa1` | Full text/record read. |
| CLAUDE-history.md | 16024 | `0314e347ae78fe2891e44d33ffbda91df1b23e6d3fa1f2580adb39e4e0a1c405` | Retained and integrity/hash checked; not relied on as independently reviewed scientific contents. |
| research/autonomy/OPERATING_PROTOCOL.md | 10898 | `5a0051a18b88b7e0056a98f783ac22fe42099090c17698595715cb021411a9af` | Full text/record read. |
| research/autonomy/opus-capacity-campaign-20260908/paper-lane/MF1-preparation/SETTLED-figure-and-text-presentation.md | 15290 | `cc78e4b28ce1b557c451f211e16d51ea3da7c440e55e984a2c5bcda3c8f25f57` | Retained and integrity/hash checked; not relied on as independently reviewed scientific contents. |
| research/manuscripts/methods-record/degrader-methods-failure-record.md | 46172 | `a9058b6c40e32549f878347b2d4f8c0ed3f8593320ce417ef29367179a7d0fe2` | Full text/record read. |
| research/manuscripts/nr4a3-program-map.md | 616465 | `e33db25530872819117e1c7281404c7341a3f9570ed05a3536efb1a8324625b8` | Selected control, instrument, calibration, closure, causal-test, failure, validation, persistence and historical-result passages; not the entire roadmap. |
| research/manuscripts/program/paper-framing-options.md | 60281 | `3154bdd9facdb93a5a84b53dbff847021380f4320fe9848bb9e2bb28dd017b79` | Retained and integrity/hash checked; not relied on as independently reviewed scientific contents. |
| research/modalities/antitarget-selfcontrol.json | 81221 | `74c36ff5385706ba549a39bd66a2004d25a30b4d302584384c7fa75035d8899c` | Criterion, panel results, repair delta and affected-claim interpretation. |
| research/modalities/apo-pose-recovery.json | 382759 | `6f60c5f37949dbf89d6d709656d33b6113519e48802fa335c88a7782b9cfa4dd` | Criterion, selected panel, outcome structure and scope; no full docking-output validation. |
| research/modalities/apo-pose-site-in-regime.json | 377767 | `97cb06e63a4f8709bae1f2f4e731d9106a4fa988e56c285a55ddbecc0f31d372` | Panel scope, outcome schema and preserved distinctions; no remeasurement. |
| research/modalities/categorical-decoy-null-lbd.json | 154730 | `29c234062776e45cb729b6f6206e28a4a52dd11d30d15b237a40559177cc6b1b` | Second scope, limits, C397 verdict and background dependencies. |
| research/modalities/categorical-decoy-null.json | 55925 | `e7aa7b9c598d2129cb0f2fe160316d01730e7fd650c5e2779510e3ac5f1c80be` | Scope, selection schema, gradeability and result context; no structural calculations. |
| research/modalities/decoy-null-provenance.json | 5170 | `3bd0c10cebf42bc248744c30de6a56a7dc3d6b69a610f9cd9f6063a5e5649bb4` | Full text/record read. |
| research/modalities/decoy_null_provenance.py | 7279 | `318ba3b7ef7caed3f1037c6ccf0394a3e7e2f6c84f191913569dded5191a0e1f` | Retained and integrity/hash checked; not relied on as independently reviewed scientific contents. |
| research/modalities/instrument-census.json | 30336 | `c9eb3bd57b7a13b582ee7ee9a05c55c711ff1fa2a697e58fd764187d4aac08bf` | Retained and integrity/hash checked; not relied on as independently reviewed scientific contents. |
| research/modalities/instrument-census.md | 21475 | `350b328516e697e1344619c10233c38a0577125162da6c167593f2515252854e` | Full text/record read. |
| research/modalities/instrument_census.py | 17914 | `f3c3bb603dea6e53e858b8828e92662dc34c53dd5c634794e89c14a986a2996b` | Retained and integrity/hash checked; not relied on as independently reviewed scientific contents. |
| research/modalities/nr4a-safety-genetics.json | 3970 | `9acc806b8bd94f612a983c3819dce721a4d82246076f2f2206656625bdb1c75c` | Full text/record read. |
| research/modalities/nr4a2-sparing-bound.json | 75050 | `c5e732e658200e5732bebb8e89e778016e3daa58826e3749e41cea0efeea8c58` | Current genetic evidence/verdict, developmental/adult caveats and reported primary identifiers. |
| research/modalities/nr4a3-5aks-lane-report.md | 37696 | `cead26644551771d175a604fe94ba446b872a5067aba94b943407220664b954a` | Headings and relevant provenance/identity search hits only. |
| research/modalities/nr4a3-5aks-reduction.json | 1696 | `63736eda6ac0c05ea97ad240d9f16388aa9cfffa15484382d6e455fa5babc4a6` | Full text/record read. |
| research/modalities/nr4a3-5bt-gate.json | 48431 | `f4dbee00f2f0f7e903de60446bc4f5d07b2e01bc7cbe30c6e23226fcbf5478ee` | Gate components, structural scope, verdict and count summary. |
| research/modalities/nr4a3-5bt-signature.json | 73145 | `474f366968b77b30670345694ea46e52a78a585c688b8b6aae0483ba28a20784` | Original versus replicated result, structure-selection inventory and sixteen-model descriptor result. |
| research/modalities/nr4a3-nrv04-retrospective-prereg.md | 47569 | `8c1258a4d34c2336cb844769d8be703e6a0ad3a79fcf43ba110974f002719427` | Retained and integrity/hash checked; not relied on as independently reviewed scientific contents. |
| research/modalities/nr4a3_5aks_reduce.py | 12508 | `e2e53b72b424c74a67a7422810e8f83a9f935effb10e99a9acd202b40c4dd0ef` | Identity checking, statistics and reduce_S branches. |
| research/modalities/nrv04-cofold-chain-forensics-2026-07-24.md | 10317 | `b545cf607b874036a37f5231177169125ab85a28a1641177e290f06deb84285f` | Full text/record read. |
| research/modalities/nrv04-covalent-input-audit.json | 74282 | `4d218022e724952609607aac79027a98c061ea7024d5440e09e5c63f6997652f` | Input identities, contaminant records and aggregate admissibility result. |
| research/modalities/nrv04-cys-conservation.json | 892 | `ae579ee1d7fec65ed3d572589cdec95becd3f454aaa0fb10ddf40ba8af3df326` | Retained and integrity/hash checked; not relied on as independently reviewed scientific contents. |
| research/modalities/nrv04-result-forensics.json | 71920 | `17ba6f1c042996cdf4b7b91504646237b2711da86b1e77ea6ade3f6b1d3ae77e` | Object classification, affected-result inventory, no-trajectory verdict and representative leg fields. |
| research/modalities/nrv04-retro-secondaries.json | 76668 | `9a8288ba5122b8ac523b4720bbc816c1d16db83b9a9467bb1e49e4a80f1ce228` | Secondary/primary separation, provenance and relevant withdrawn-interface caveat. |
| research/modalities/nrv04-retro-verdict.json | 7797 | `f39714dcea6a9d42e8aab52f75e3c7a16e93d4309cc8c44ad9377c21aa42346c` | Full text/record read. |
| research/modalities/nrv04_covalent_input_audit.py | 23700 | `2910fe80b8d0a0315101e3f676c436be55450d13f13717bd13d3743356d2a96d` | Retained for provenance; scientific conclusions rely on data and chain-forensics record, not a full code audit. |
| research/modalities/nrv04_result_forensics.py | 14541 | `c23c2da5044c9bed6d1ecb29d4827f528f03739e914407432e28c29197214fc1` | Classification and survey branches; no execution or cloud access. |
| research/modalities/nrv04_retro_gate.py | 20635 | `4b2608806d313d1ea6a01603fe9a6509f563d74f7a46ca0e525622423732fba0` | Model-level collapse, exact permutation, leave-one-model-out, registered constants and related declarations. |
| research/modalities/pose-conditionality-census.json | 39770 | `b164fd14404241430f7a87fffdb787c4de5e519ca1f88f83acf41ec43262fbba` | Current evidence and pose/cavity attribution interpretation; schema of claim inventory. |
| research/modalities/pose-second-method.json | 92755 | `0e1019ce9a91f061358419bc734bdac62d8b652617fbbdb1a1ea3b8210d09a81` | Part A result, all twelve Part B dispositions, gradeability and limitations. |
| research/modalities/r3-generation-frame-harmonized.json | 16921 | `65a08298be77ec09b833e2766d1cd0b5afe70b745733b0c84c5e462c26c29fba` | Threshold, recorded score, gate and reference context. |
| research/modalities/r5-cross-method-cavity-attribution.json | 32592 | `39b361f2fcaf58cfcca5dbe150b50a6b8366e2625a9eecc4e8fc087da5664a4b` | Rollup and relevant current interpretation; no coordinate reanalysis. |
| research/modalities/selcal-cofold-dockq.json | 25028 | `563940a2cd8d510519cf647b5c69dabc990fcde783cc178a306363a18780f10c` | Cross-check result and scope. |
| research/modalities/selcal-cofold-vs-crystal.json | 41796 | `815614755c549fafa6ad8d38a86ce746856f58e685878adfca8c42fded6c5ad5` | Provenance, reference/model distinction, grading records and source context. |
| research/modalities/selcal-collect.json | 2988 | `416ba9947f6b53b72e94b0d1e8cf8e265beab03b061491ad646439f4157e9afc` | Panel completion, input-fault exclusion and record inventory. |
| research/modalities/selcal-deepternary-controls.json | 20591 | `33be04c5cf3f7af5303997d0ee229ace4e92cddf3dd68149e62a70b155bfe3c5` | Input context, blindness qualification and retained candidates; no new source checks. |
| research/modalities/selcal-deepternary-frame.json | 1534 | `35492ec9a8cbb1f5637ad3438fbb4bc7d5848174ff941e98dc888bc671a4c677` | Full text/record read. |
| research/modalities/selcal-deepternary-poscontrol.json | 4874 | `77a641be493be2c2d488b46c796f033cd7b4e94b7e6112d15c99b8509f75d229` | In-set status, summary and claim scope. |
| research/modalities/selcal-dockq-decoy-scale.json | 6935 | `2c4942e049e33a95195e001eca7c246e772e1d3b5fa0802a26f5dde689a2f21c` | Root schema and provenance inspection only; no structural reproduction. |
| research/modalities/selcal-interface-signature.json | 22259 | `278e0d836f3d4e576e818a5e3e508cb70773886d65033111e475b36181433a65` | Known-answer result, source and scope; no remeasurement from crystals. |
| research/modalities/selcal-reference-selectivity.json | 56479 | `a8fcb3c87f9f5359c912c0901c2938c9e38c0109178347b298e40ab83b262502` | Schema/provenance inspection; primary text not independently retrieved. |
| research/modalities/selcal-verdict.json | 8145 | `0faae150a91ba727764971802516e7189137d39dc82168b02b36b93b3da8f92c` | Full text/record read. |
| research/modalities/selcal_gate.py | 21711 | `9ef70038fc78bf4aae23097a759e8a58539bef3985d481d4d12609951e60dfdc` | design_floor, leg_rows, verdict, operational membership and interpretation branches. |
| research/modalities/selcal_interface_signature.py | 15766 | `3ad0753681c632b0170ca5424a45480e86855552913dc40227f67d160fb7758e` | Descriptor scope, comparison fields, known_answer_check and input/result declarations. |
| research/modalities/selcal_panel.py | 32608 | `9630422ae64b37df74e647d7ce3954f66bc56c0a6b73004dfaa662971738e918` | Reference identity/assay, shared panel structure, membership/amendment and PASS_CRITERION. |
| research/modalities/selectivity-resolution-options.md | 34653 | `619fdd924a1a13771f1ecbdda2750481b746910f2dc2d6f0a0fc50a82a3197fd` | Relevant power, sensitivity-control design, reference preconditions and outcome sections. |
| research/modalities/selectivity-sensitivity-control-prereg.md | 21455 | `9526979f76950926c70ea22084495a988bc46c5612ae38783d5c83b84c2a4a30` | Purpose, design/amendment provenance, reference set, criterion and prospective assertions. |
| research/modalities/selectivity_calibration.py | 3893 | `946029ffeadd0098d1b650a75c9cd78c14c9c1f94bf121ed8b2eca625e43ac7f` | Full text/record read. |
| research/modalities/step1-fanout-map.json | 74817 | `6052d5754bad5672e910d6612fb2d883802e705f35c449f2922d713c50096220` | Scope, counts, conditionality, charge provenance and historical restoration note. |
| research/modalities/structural-provenance-census.json | 8396 | `d5d34788542aa2cba84dea0051585e2f61b901f319151a88905ae385950d530b` | Schema and claim-specific search inspection only. |
| research/modalities/ternary-env-parity.json | 1002 | `daea6c4fdec8d44a17feee0504b232454637bdae1bdc83e185a9de810b55c0a4` | Full text/record read. |
| research/modalities/ternary-lane-guard-audit-2026-07-25.md | 100933 | `25dc4d0036badb3001d90fe48889583bff01771eab2b42e0475a296fe9ad523e` | Retained and integrity/hash checked; not relied on as independently reviewed scientific contents. |
| research/modalities/ternary_fep_reduce.py | 54495 | `d7b2248d9803581effa3ac61bbb35e7df1011ea9c5b089af292d82dde2914dea` | SD, t interval, aggregation, hysteresis and calibration decision branches. |
| research/modalities/valb-failure-propagation.json | 17073 | `ca87ad53bb0c227c440dbbc36cbd9d48d32fa3eed4e6034e9569fbdb32a10e62` | Measured inputs, noise-bound/power derivations, S argument and SD/SE interpretation. |
| research/modalities/valb-triangle-closure.json | 18343 | `8c8782f965b9c19a33e6836f73f42946e599d2c4760540d778d93e5a7d0cba8e` | Closure algebra, scope and power/noise sections. |
| research/modalities/valb-triangle-frozen.json | 4925 | `b999d0c8be2cc88c873142534bf570fd37bba6879847e507afc04ea4b266e371` | Retained and integrity/hash checked; not relied on as independently reviewed scientific contents. |
| research/modalities/valb-triangle-reduction.json | 15576 | `8174ccd0f62d6ec00a385d3f6255cce3366098bc89eb1b37c7e549a80543eadf` | Triangle values, comparability, no-error-bar declaration, uncertainty and interpretation. |
| research/modalities/valb_failure_propagation.py | 53502 | `c8a92cecba6b0e1478d51123f9408f33189b1c89b0d4e428c35ceae46b51ef15` | Retained and integrity/hash checked; not relied on as independently reviewed scientific contents. |
| research/modalities/valb_triangle_reduce.py | 24060 | `82e02592e00b922536966a34b13faf10f3222ec6507f32bc65e74907887d8e84` | Retained and integrity/hash checked; not relied on as independently reviewed scientific contents. |
| results/nr4a3-decoy/-mmgbsa-metad-ms/nr4a3-mmgbsa.json | 21034 | `ad4612dd6a3ffd303695f7c533ee3c0bdc88845fc3033c5d6ae87c45bce5756c` | Primary committed score records: all 38 margins and arm identity compared to constant. |
| results/nr4a3-decoy/-mmgbsa-ms/nr4a3-mmgbsa.json | 20970 | `63f31e88f25c31d97ac9a8f8328b1f7e2d5dd49bc4e21acaa00f21519058c346` | Primary committed score records: all 38 margins and arm identity compared to constant. |
| results/nr4a3-decoy/-mmgbsa/nr4a3-mmgbsa.json | 16170 | `1c914cbd6f37a4be056b156bab5047c7a4e6c10fdde03780514cdee66b00ef32` | Primary committed score records: all 38 margins and their source fields compared to constant. |
| systems/graph/instruments.json | 27696 | `04b771cdaab5bd297dccb0b3eb4a68d7dc1229d728587c949ee172b1e14ea6c3` | Selected instrument objects and V-numbered universe; structural parsing and counts. |
| systems/graph/publications.json | 63611 | `0023e64c82fef653ec1a2eda9bc99db17ff632a812cde9e115672785b95e32a2` | Retained and integrity/hash checked; not relied on as independently reviewed scientific contents. |
| systems/graph/routes.json | 617198 | `17d208e48c7901eeb01c64a16a415bb1f56a6ce729dfd05846c3b5e0e25f3d3b` | RT-METHODS-PAPER and its instrument partition; no review of unrelated routes. |
| systems/views/registers/instruments.md | 12319 | `d5f539de36e16a49a22a232b703abb49501fd8016aa69da33223c6f35bcac3cc` | Full text/record read. |
| C:/Users/mcrae/.codex/review-workspaces/opus-capacity-sprint-20260907/capacity-campaign-20260908/observations/0b965a12/MF1-preparation/HANDOFF-MF1-methods-record-frozen.md | 14658 | `72eb8568a2c8bc1301787d64dad05b4fc1241906af22e2e38b8d25005b45ee48` | Full handoff or local guidance read; local source, not scientific data at fixed commit. |
| C:/Projects/EMC-Research/.claude/skills/paper-hardening/SKILL.md | 2413 | `bb113276cb446d46f1cdfaa6621ea800c213c0e1c8d59f03b45f5fe90610961a` | Full handoff or local guidance read; local source, not scientific data at fixed commit. |
| C:/Projects/EMC-Research/.claude/skills/repo-gates/SKILL.md | 1794 | `228e27b07811a027d60e548d88e41e992280d788c2478aa2c7fb467af8cbafa1` | Full handoff or local guidance read; local source, not scientific data at fixed commit. |
