from pathlib import Path
import hashlib, json, os, subprocess, sys

ROOT = Path(__file__).resolve().parent
REPO = Path('C:/Projects/EMC-Research')
PIN = '0b965a1279c81c10d9edc054842a33446e87762e'
ENV = dict(os.environ, GIT_NO_LAZY_FETCH='1', GIT_TERMINAL_PROMPT='0')

def collect_git(rel):
    p = subprocess.run(['git', '-C', str(REPO), 'cat-file', 'blob', PIN + ':' + rel], env=ENV, capture_output=True)
    entry = {'repo_path': rel, 'source': 'git:' + PIN + ':' + rel, 'exit_code': p.returncode, 'git_no_lazy_fetch': '1'}
    if p.returncode == 0:
        dst = ROOT / 'inputs' / 'frozen' / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        dst.write_bytes(p.stdout)
        entry.update(bytes=len(p.stdout), sha256=hashlib.sha256(p.stdout).hexdigest(), retained_path=str(dst.relative_to(ROOT)))
    else:
        entry['stderr'] = p.stderr.decode('utf-8', 'replace')
    with (ROOT / 'collection-log.jsonl').open('a', encoding='utf-8') as f:
        f.write(json.dumps(entry, ensure_ascii=True) + '\n')
    print(json.dumps(entry, ensure_ascii=True))

def collect_local(src, rel):
    b = Path(src).read_bytes()
    dst = ROOT / 'inputs' / 'local' / rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    dst.write_bytes(b)
    entry = {'source': str(src), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest(), 'retained_path': str(dst.relative_to(ROOT)), 'exit_code': 0}
    with (ROOT / 'collection-log.jsonl').open('a', encoding='utf-8') as f:
        f.write(json.dumps(entry, ensure_ascii=True) + '\n')
    print(json.dumps(entry, ensure_ascii=True))

if __name__ == '__main__':
    if sys.argv[1] == '--local':
        collect_local(sys.argv[2], sys.argv[3])
    else:
        for rel in sys.argv[1:]: collect_git(rel)
