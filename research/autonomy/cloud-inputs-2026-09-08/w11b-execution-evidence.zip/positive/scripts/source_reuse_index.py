"""Informational, read-only source/identifier provenance lookup.

Given an identifier (DOI, PMID, PMCID, dataset/registry accession) or a URL, report
whether that identifier already appears in a supplied corpus of retained records, where
it appears (file plus JSON dotted path or line number), what dated statuses those
records carry, and what access evidence those records explicitly report.

What this tool is NOT
---------------------
* It is not an authorization mechanism. It never says a source may be fetched, retried
  or approved; it only quotes retained record text verbatim.
* It is not a scientific or acceptance gate. The CLI exits 0 for every lookup state by
  design, including unresolved and invalid candidates, so it cannot be wired in as a
  pass/fail check without a deliberate, visible change.
* It is not evidence of novelty. Absence from the index means the supplied corpus did
  not contain the identifier. The corpus is always incomplete; every non-match carries
  a mandatory note saying so.
* It performs no network access. Only ``urllib.parse`` (string parsing) is imported from
  urllib; no socket, no ``urllib.request``, no HTTP. Files are opened read-only.
* It never matches on titles. Title/abstract text is excluded from identity matching
  entirely, so no "same paper?" judgement is made from prose similarity.

Standard library only.

Repairs applied after independent review (each demonstrated with a failing case before
the change; see the paired test file, which pins every one as a regression):

* F1  identifiers carried by a *field name* with a bare value (``"pmid": "24703573"``)
      are now indexed, deduplicated against the syntactic hit. They were invisible
      before, producing a false non-match on a record that is in the corpus.
* F2  access labels now carry per-label evidence (matched phrase, containing clause,
      whether that clause negates). Labels are mentions of a category, never assertions
      that the category applies. No label is silently dropped.
* F3  status divergence is flagged only when the *same field name* holds different
      values. Orthogonal ``*_status`` dimensions in one record no longer manufacture a
      contradiction the record does not state.
* F4  restriction/exclusion vocabulary is recognised, and a match whose records carry no
      recognised access statement now says so explicitly instead of rendering silence
      identically to "nothing to report".
* F5  records are identified by position, not by basename. Two files both called
      ``integration.json`` no longer pool each other's statuses and access evidence.
* F6  missing roots and skipped non-text files are recorded and surfaced as
      ``scope_warnings`` on every result, so a typo'd corpus path cannot read as
      "not previously seen".
* F7  the retained-bytes signal requires a URL from a ``*url*`` key and a digest from a
      ``sha256``-named key, and states the association basis. Unrelated key
      co-occurrence no longer claims a recovered source.
* F8  records flagged ``synthetic_fixture`` are labelled as such in JSON and text output
      (AGENTS.md requires synthetic data to be explicitly labelled).
"""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
import urllib.parse
from dataclasses import dataclass, field
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

# --------------------------------------------------------------------------------------
# Vocabulary
# --------------------------------------------------------------------------------------

IDENTITY_SCHEMES: Tuple[str, ...] = (
    "doi",
    "pmid",
    "pmcid",
    "geo",
    "arrayexpress",
    "bioproject",
    "sra",
    "ega",
    "nct",
    "eudract",
)

LOOKUP_STATES: Tuple[str, ...] = (
    "matched",
    "matched_prose_mention_only",
    "matched_with_divergent_states",
    "unresolved_not_indexed",
    "unresolved_url_without_identifier",
    "ambiguous_multiple_identifiers",
    "invalid_candidate",
)

ACCESS_LABELS: Tuple[str, ...] = (
    "proxy_or_network_failure",
    "http_403_unclassified_denial",
    "publisher_authentication_or_subscription",
    "policy_or_biology_refusal",
    "full_text_unavailable_in_scope",
    "reported_complete_source_recovered",
    "no_access_attempt_in_this_packet",
    "unclassified_reported_access_evidence",
)

DISCLAIMER = (
    "Informational read-only lookup over the supplied corpus of retained records. "
    "Not an authorization, not a novelty determination, not evidence of source "
    "availability, not scientific validation."
)

NON_MATCH_NOTE = (
    "A non-match is NOT novelty: it means this identifier was not found in the files "
    "enumerated in indexed_scope. The supplied corpus is incomplete by construction."
)

URL_NOTE = (
    "A URL alone never establishes article identity. A URL resolves only through an "
    "identifier embedded in the URL string itself; a newly surfaced URL is not a newly "
    "identified article."
)

TITLE_NOTE = (
    "Titles are excluded from matching entirely. Supply a DOI, PMID, PMCID or accession."
)

DATED_NOTE = (
    "Dated record statuses are reported verbatim in date order. Nothing is merged, "
    "ranked or superseded by this tool; conflicting or dated entries are all retained."
)

LABEL_MENTION_NOTE = (
    "Access labels record which categories a record's own wording NAMES. A label is a "
    "mention, not an assertion: a record that explicitly rules a category out still "
    "names it. Read label_evidence and the verbatim quote before drawing any conclusion."
)

NO_ACCESS_EVIDENCE_NOTE = (
    "Matched records contributed no recognised access statement. That is silence in the "
    "supplied text, not a finding: it does not mean access was attempted, was not "
    "attempted, was permitted, or was restricted. Unknown, not zero."
)

TEXT_EXTENSIONS = frozenset({".json", ".md", ".txt"})

SYNTHETIC_MARKER = "[SYNTHETIC FIXTURE]"

# --------------------------------------------------------------------------------------
# Extraction and normalization
# --------------------------------------------------------------------------------------

_TRAILING = ".,;:)]}'\""

_PATTERNS: Tuple[Tuple[str, "re.Pattern[str]"], ...] = (
    ("doi", re.compile(r"10\.\d{4,9}/[A-Za-z0-9._;()/:+\-]+")),
    ("pmid", re.compile(r"PMID\s*:?\s*\d{4,9}\b", re.IGNORECASE)),
    ("pmcid", re.compile(r"\bPMC\d{4,9}\b", re.IGNORECASE)),
    ("geo", re.compile(r"\bG(?:SE|SM|PL)\d{3,9}\b")),
    ("arrayexpress", re.compile(r"\bE-[A-Z]{4}-\d{1,9}\b")),
    ("bioproject", re.compile(r"\bPRJ[A-Z]{2}\d{3,9}\b")),
    ("sra", re.compile(r"\bSR[RXPS]\d{5,12}\b")),
    ("ega", re.compile(r"\bEGA[SD]\d{6,15}\b")),
    ("nct", re.compile(r"\bNCT\d{8}\b")),
    ("eudract", re.compile(r"\b\d{4}-\d{6}-\d{2}\b")),
    ("url", re.compile(r"https?://[^\s\"'<>\]\),]+")),
)

_DOI_FULL = re.compile(r"^10\.\d{4,9}/\S+$")
_PMID_FULL = re.compile(r"^(?:pmid\s*:?\s*)?(\d{4,9})$", re.IGNORECASE)
_PMCID_FULL = re.compile(r"^(?:pmcid\s*:?\s*)?pmc(\d{4,9})$", re.IGNORECASE)
_SHA256 = re.compile(r"^[0-9a-fA-F]{64}$")

_DOI_URL_PREFIXES = (
    "https://doi.org/",
    "http://doi.org/",
    "https://dx.doi.org/",
    "http://dx.doi.org/",
    "https://www.doi.org/",
    "http://www.doi.org/",
)


def normalize_url(raw: str) -> str:
    """Weak, deliberately non-identifying URL key.

    Folds http/https and a leading 'www.', drops the fragment, strips one trailing
    slash, keeps path and query. This can conflate genuinely distinct hosts that differ
    only by 'www.'; that is a documented simplification, and a URL key is never used to
    assert article identity.
    """
    raw = raw.strip().rstrip(_TRAILING)
    parts = urllib.parse.urlsplit(raw)
    host = (parts.hostname or "").lower()
    if host.startswith("www."):
        host = host[4:]
    try:
        port = parts.port
    except ValueError:
        port = None
    suffix = ":%d" % port if port else ""
    path = parts.path.rstrip("/")
    query = "?%s" % parts.query if parts.query else ""
    return "%s%s%s%s" % (host, suffix, path, query)


def normalize_identifier(scheme: str, raw: str) -> str:
    """Normalize one raw identifier string for its scheme. No fuzzy matching anywhere."""
    value = raw.strip().rstrip(_TRAILING)
    if scheme == "doi":
        low = value.lower()
        for prefix in _DOI_URL_PREFIXES:
            if low.startswith(prefix):
                low = low[len(prefix):]
                break
        if low.startswith("doi:"):
            low = low[4:]
        return low.strip().rstrip(_TRAILING)
    if scheme == "pmid":
        return re.sub(r"\D", "", value)
    if scheme == "pmcid":
        return "PMC" + re.sub(r"\D", "", value)
    if scheme == "url":
        return normalize_url(value)
    if scheme == "eudract":
        return value
    return value.upper()


@dataclass(frozen=True)
class Mention:
    scheme: str
    raw: str
    normalized: str
    locator: str
    context: str  # "structured_field", "prose_context" or "structured_field_name"

    def as_dict(self) -> Dict[str, str]:
        return {
            "scheme": self.scheme,
            "raw": self.raw,
            "normalized": self.normalized,
            "locator": self.locator,
            "context": self.context,
        }


def extract_identifiers(text: str, locator: str = "", context: str = "prose_context") -> List[Mention]:
    """Extract every identifier mention from one string. Order is stable."""
    found: List[Mention] = []
    seen = set()
    for scheme, pattern in _PATTERNS:
        for match in pattern.finditer(text):
            raw = match.group(0).strip().rstrip(_TRAILING)
            if not raw:
                continue
            normalized = normalize_identifier(scheme, raw)
            if not normalized:
                continue
            key = (scheme, normalized, locator)
            if key in seen:
                continue
            seen.add(key)
            found.append(Mention(scheme, raw, normalized, locator, context))
    return found


def scheme_for_field_name(key: str) -> Optional[str]:
    """F1: map a JSON field NAME to an identity scheme, or None.

    Accepts the bare scheme name and a ``<qualifier>_<scheme>`` suffix, so ``pmid``,
    ``source_pmid`` and ``primary_doi`` all resolve. Nothing here inspects the value;
    a field name only proposes a scheme, and the value must still parse under it.
    """
    low = key.strip().lower()
    for scheme in IDENTITY_SCHEMES:
        if low == scheme or low.endswith("_" + scheme):
            return scheme
    return None


def extract_field_name_identifier(key: str, value: str, locator: str) -> Optional[Mention]:
    """F1: index a bare identifier whose scheme is carried by its field name.

    Real retained records store ``"pmid": "24703573"`` — a value that spells out no
    scheme, so purely syntactic extraction never sees it and the tool reports a false
    non-match. The value must parse as a *complete* identifier of the field's scheme;
    prose in an identifier-named field yields nothing.
    """
    scheme = scheme_for_field_name(key)
    if scheme is None:
        return None
    parsed_scheme, parsed = parse_candidate(value, kind=scheme)
    if parsed_scheme is None:
        return None
    return Mention(parsed_scheme, value.strip(), parsed, locator, "structured_field_name")


def parse_candidate(query: str, kind: Optional[str] = None) -> Tuple[Optional[str], str]:
    """Resolve a query string to (scheme, normalized) or (None, reason).

    Bare digits are rejected unless ``kind='pmid'`` is given explicitly, so that a
    stray number cannot be silently treated as a PubMed identifier.
    """
    value = (query or "").strip()
    if not value:
        return None, "empty candidate"

    if kind:
        if kind not in IDENTITY_SCHEMES + ("url",):
            return None, "unknown kind %r" % kind
        if kind == "doi":
            normalized = normalize_identifier("doi", value)
            if _DOI_FULL.match(normalized):
                return "doi", normalized
            return None, "not a syntactically valid DOI"
        if kind == "pmid":
            match = _PMID_FULL.match(value)
            if match:
                return "pmid", match.group(1)
            return None, "not a syntactically valid PMID"
        if kind == "pmcid":
            match = _PMCID_FULL.match(value)
            if match:
                return "pmcid", "PMC" + match.group(1)
            return None, "not a syntactically valid PMCID"
        if kind == "url":
            if "://" not in value:
                return None, "not a syntactically valid URL"
            return "url", normalize_url(value)
        for scheme, pattern in _PATTERNS:
            if scheme != kind:
                continue
            match = pattern.fullmatch(value)
            if match:
                return scheme, normalize_identifier(scheme, value)
        return None, "not a syntactically valid %s" % kind

    doi_candidate = normalize_identifier("doi", value)
    if _DOI_FULL.match(doi_candidate):
        return "doi", doi_candidate
    if value.lower().startswith(("http://", "https://")):
        return "url", normalize_url(value)
    if _PMCID_FULL.match(value):
        return "pmcid", normalize_identifier("pmcid", value)
    if re.match(r"^pmid\s*:?\s*\d{4,9}$", value, re.IGNORECASE):
        return "pmid", re.sub(r"\D", "", value)
    for scheme, pattern in _PATTERNS:
        if scheme in ("doi", "pmid", "pmcid", "url"):
            continue
        if pattern.fullmatch(value):
            return scheme, normalize_identifier(scheme, value)
    if re.match(r"^\d+$", value):
        return None, "bare number: pass --kind pmid to query a PubMed identifier"
    return None, "unrecognised identifier syntax; titles are never matched"


# --------------------------------------------------------------------------------------
# Access-evidence classification (from explicitly reported text only)
# --------------------------------------------------------------------------------------

_ACCESS_TRIGGERS = (
    "access",
    "retriev",
    "request",
    "denial",
    "denied",
    "block",
    "refus",
    "403",
    "forbidden",
    "subscription",
    "full text",
    "full-text",
    "fulltext",
    "egress",
    "proxy",
    "unavailab",
    "paywall",
    "authenticat",
    # F4: restriction/exclusion wording previously fell outside the gate entirely.
    "restrict",
    "exclud",
    "embargo",
)

_ACCESS_RULES: Tuple[Tuple[str, Tuple[str, ...]], ...] = (
    ("proxy_or_network_failure", ("egress", "proxy", "network failure", "dns", "timeout", "connection refused")),
    ("http_403_unclassified_denial", ("403", "forbidden")),
    ("publisher_authentication_or_subscription", ("subscription", "authenticat", "paywall", "sign-in", "login")),
    ("policy_or_biology_refusal", (
        "guardrail", "refusal", "refused", "policy restriction", "policy-restricted",
        # F4: a policy/biology exclusion is a category of its own, not "unclassified".
        "policy restricted", "restricted under policy", "excluded by policy",
        "excluded from retrieval", "excluded from this packet", "restricted reagent",
        "policy exclusion",
    )),
    ("full_text_unavailable_in_scope", ("not full text", "no full text", "no recovered original full text", "unavailab", "not recovered")),
    ("no_access_attempt_in_this_packet", ("no current access-state test was performed", "no access attempt", "not attempted", "no http request", "no request was made")),
)

_NEGATION_MARKERS = (" not ", "is not", "are not", "never", "none", "no current", "no recovered")

_CLAUSE_SPLIT = re.compile(r"(?<=[.;])\s+")


def _clauses(text: str) -> List[str]:
    """Split one statement into clauses for per-label evidence. Deliberately crude and
    documented as such: it exists to quote the surrounding clause, not to parse English."""
    parts = [part.strip() for part in _CLAUSE_SPLIT.split(text) if part.strip()]
    return parts or [text.strip()]


def classify_access_text(text: str) -> List[str]:
    """Multi-label classification of one reported access statement.

    Labels come only from phrases present in the record's own text. Unfamiliar wording
    fails toward 'unclassified_reported_access_evidence' rather than being guessed into
    a category, and distinct categories are never collapsed into one another (an HTTP
    403 is not relabelled as publisher authentication).

    A label means the category is NAMED in the text. It does not mean the record
    asserts it: a sentence written to rule a category out still names it. Use
    ``classify_access_details`` for the per-label evidence that separates the two.

    'reported_complete_source_recovered' is never assigned from prose; it comes only
    from the structured retained-bytes signal (see _bytes_signal).
    """
    return [detail["label"] for detail in classify_access_details(text)]


def classify_access_details(text: str) -> List[Dict[str, object]]:
    """F2: labels WITH evidence — matched phrase, containing clause, clause negation.

    No label is dropped on account of negation. Dropping would delete correct labels
    (``"this is not full text"`` genuinely reports unavailable full text) as readily as
    wrong ones, so the tool reports what it matched and where, and leaves the reading to
    a human.
    """
    low = text.lower()
    if not any(trigger in low for trigger in _ACCESS_TRIGGERS):
        return []
    clause_list = _clauses(text)
    details: List[Dict[str, object]] = []
    for label, phrases in _ACCESS_RULES:
        for phrase in phrases:
            if phrase not in low:
                continue
            clause = next((c for c in clause_list if phrase in c.lower()), text.strip())
            details.append({
                "label": label,
                "matched_phrase": phrase,
                "clause": clause,
                "clause_has_negation": _negation_present(clause),
            })
            break
    if not details:
        details.append({
            "label": "unclassified_reported_access_evidence",
            "matched_phrase": "",
            "clause": text.strip(),
            "clause_has_negation": _negation_present(text),
        })
    return details


def _negation_present(text: str) -> bool:
    low = " " + text.lower() + " "
    return any(marker in low for marker in _NEGATION_MARKERS)


def _access_event(record_id: str, locator: str, text: str) -> Optional[Dict[str, object]]:
    details = classify_access_details(text)
    if not details:
        return None
    return {
        "record_id": record_id,
        "locator": locator,
        "labels": [detail["label"] for detail in details],
        "label_evidence": details,
        "quote": text,
        "negated_terms_present": _negation_present(text),
        "labels_are_mentions_not_assertions": True,
    }


# --------------------------------------------------------------------------------------
# Record scanning
# --------------------------------------------------------------------------------------

@dataclass
class Record:
    record_id: str
    path: str
    kind: str
    position: int = -1
    synthetic_fixture: bool = False
    mentions: List[Mention] = field(default_factory=list)
    groups: List[List[Mention]] = field(default_factory=list)
    access_events: List[Dict[str, object]] = field(default_factory=list)
    statuses: List[Dict[str, str]] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)


_URL_KEY = re.compile(r"url", re.IGNORECASE)
_SHA_KEYS = ("sha256", "content_sha256", "member_sha256", "file_sha256")


def _bytes_signal(node: Dict[str, object]) -> Optional[Dict[str, str]]:
    """Detect an explicitly retained-bytes claim: a URL, a sha256 and an archive member
    recorded together in one object. This is the only source of the
    'reported_complete_source_recovered' label; it reports what the record states and
    does not verify any hash.

    F7: the URL must come from a key whose NAME contains 'url' and the digest from a key
    named sha256/content_sha256/member_sha256/file_sha256. Before this, any http-valued
    string plus any ``*_sha256`` plus an ``archive_member`` — key names unrelated — was
    reported as retained bytes for that URL. The association basis is now stated so a
    reader can see which keys were tied together.
    """
    url = sha = member = None
    url_key = sha_key = ""
    for key, value in node.items():
        if not isinstance(value, str):
            continue
        low = key.lower()
        if url is None and _URL_KEY.search(low) and value.lower().startswith(("http://", "https://")):
            url = value
            url_key = key
        if sha is None and low in _SHA_KEYS and _SHA256.match(value):
            sha = value
            sha_key = key
        if low in ("archive_member", "archive_members"):
            member = value
    if url and sha and member:
        return {
            "url": url,
            "sha256": sha,
            "archive_member": member,
            "association_basis": "keys %s + %s + archive_member in one object" % (url_key, sha_key),
        }
    return None


def _is_synthetic(node: object) -> bool:
    """F8: does any object in this record carry a truthy ``synthetic_fixture`` flag?"""
    if isinstance(node, dict):
        if node.get("synthetic_fixture"):
            return True
        return any(_is_synthetic(value) for value in node.values())
    if isinstance(node, list):
        return any(_is_synthetic(item) for item in node)
    return False


def _walk_json(node: object, path: str, record: Record) -> None:
    if isinstance(node, dict):
        group: List[Mention] = []
        for key in sorted(node.keys()):
            value = node[key]
            child = "%s.%s" % (path, key) if path else key
            strings: List[Tuple[str, str]] = []
            if isinstance(value, str):
                strings.append((child, value))
            elif isinstance(value, list):
                for index, item in enumerate(value):
                    if isinstance(item, str):
                        strings.append(("%s[%d]" % (child, index), item))
            for locator, text in strings:
                mentions = extract_identifiers(text, locator, "structured_field")
                seen = {(m.scheme, m.normalized, m.locator) for m in mentions}
                by_name = extract_field_name_identifier(key, text, locator)
                if by_name is not None and (by_name.scheme, by_name.normalized, by_name.locator) not in seen:
                    mentions.append(by_name)
                record.mentions.extend(mentions)
                group.extend(mentions)
                event = _access_event(record.record_id, locator, text)
                if event is not None:
                    record.access_events.append(event)
        if group:
            record.groups.append(group)
        signal = _bytes_signal(node)
        if signal is not None:
            record.access_events.append({
                "record_id": record.record_id,
                "locator": path or "$",
                "labels": ["reported_complete_source_recovered"],
                "label_evidence": [{
                    "label": "reported_complete_source_recovered",
                    "matched_phrase": "",
                    "clause": signal["association_basis"],
                    "clause_has_negation": False,
                }],
                "quote": "record reports retained bytes: url=%s sha256=%s archive_member=%s"
                         % (signal["url"], signal["sha256"], signal["archive_member"]),
                "association_basis": signal["association_basis"],
                "negated_terms_present": False,
                "labels_are_mentions_not_assertions": True,
                "hash_not_recomputed": True,
            })
        for key in sorted(node.keys()):
            value = node[key]
            child = "%s.%s" % (path, key) if path else key
            if isinstance(value, (dict, list)):
                _walk_json(value, child, record)
    elif isinstance(node, list):
        for index, item in enumerate(node):
            if isinstance(item, (dict, list)):
                _walk_json(item, "%s[%d]" % (path, index), record)


def _collect_statuses(node: object, record: Record) -> None:
    if not isinstance(node, dict):
        return
    date = ""
    for key in ("utc", "date", "recorded_utc", "timestamp"):
        value = node.get(key)
        if isinstance(value, str):
            date = value
            break
    for key in sorted(node.keys()):
        value = node[key]
        if not isinstance(value, str):
            continue
        low = key.lower()
        if low == "status" or low.endswith("_status"):
            record.statuses.append({
                "record_id": record.record_id,
                "date": date,
                "field": key,
                "status": value,
                "locator": key,
            })


def scan_file(path: str, record_id: str) -> Record:
    """Open one file read-only and index it. Never writes, never fetches."""
    extension = os.path.splitext(path)[1].lower()
    record = Record(record_id=record_id, path=path, kind=extension.lstrip("."))
    with open(path, "r", encoding="utf-8", errors="replace") as handle:
        text = handle.read()
    if extension == ".json":
        try:
            data = json.loads(text)
        except ValueError as exc:
            record.notes.append("JSON parse failed (%s); indexed as plain lines." % exc)
        else:
            record.synthetic_fixture = _is_synthetic(data)
            _walk_json(data, "", record)
            _collect_statuses(data, record)
            return record
    for number, line in enumerate(text.splitlines(), start=1):
        locator = "line:%d" % number
        mentions = extract_identifiers(line, locator, "prose_context")
        record.mentions.extend(mentions)
        if mentions:
            record.groups.append(mentions)
        event = _access_event(record.record_id, locator, line)
        if event is not None:
            record.access_events.append(event)
    return record


def _iter_files(root: str, skipped: List[str]) -> Iterable[Tuple[str, str]]:
    if os.path.isfile(root):
        yield root, os.path.basename(root)
        return
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = sorted(name for name in dirnames if not name.startswith("."))
        for name in sorted(filenames):
            full = os.path.join(dirpath, name)
            if os.path.splitext(name)[1].lower() in TEXT_EXTENSIONS:
                rel = os.path.relpath(full, root).replace(os.sep, "/")
                yield full, rel
            else:
                # F6: a dropped file used to leave no trace at all.
                skipped.append(os.path.relpath(full, root).replace(os.sep, "/"))


@dataclass
class Index:
    roots: List[str]
    records: List[Record] = field(default_factory=list)
    missing_roots: List[str] = field(default_factory=list)
    skipped_files: List[str] = field(default_factory=list)

    @property
    def files(self) -> List[str]:
        return [record.record_id for record in self.records]

    def warnings(self) -> List[str]:
        """F6: never let an empty or mistyped corpus read like a genuine non-match."""
        warnings: List[str] = []
        for root in self.missing_roots:
            warnings.append(
                "Corpus root does not exist and contributed no files: %r. A non-match "
                "against a missing root says nothing about the identifier." % root
            )
        if not self.records:
            warnings.append(
                "The index is EMPTY: zero files were opened. Every lookup against this "
                "index is unresolved by construction and carries no information."
            )
        if self.skipped_files:
            warnings.append(
                "%d file(s) were skipped because their extension is outside %s: %s. "
                "Their contents were not indexed."
                % (len(self.skipped_files), sorted(TEXT_EXTENSIONS),
                   ", ".join(sorted(self.skipped_files)[:10]))
            )
        return warnings

    def scope(self) -> Dict[str, object]:
        return {
            "roots": list(self.roots),
            "files": self.files,
            "file_origins": [
                {"record_id": r.record_id, "origin_path": r.path, "position": r.position,
                 "synthetic_fixture": r.synthetic_fixture}
                for r in self.records
            ],
            "file_count": len(self.records),
            "missing_roots": list(self.missing_roots),
            "skipped_files": list(self.skipped_files),
            "scope_warnings": self.warnings(),
            "scope_note": (
                "Supplied corpus only: exactly these files were opened read-only. "
                "Records referenced by them but absent here were not inspected."
            ),
        }


def build_index(roots: Sequence[str]) -> Index:
    index = Index(roots=[str(root) for root in roots])
    seen = set()
    used_ids: Dict[str, int] = {}
    for root in index.roots:
        if not os.path.exists(root):
            index.missing_roots.append(root)
            continue
        for path, record_id in _iter_files(root, index.skipped_files):
            key = os.path.abspath(path)
            if key in seen:
                continue
            seen.add(key)
            record = scan_file(path, record_id)
            index.records.append(record)
    index.records.sort(key=lambda record: (record.record_id, os.path.abspath(record.path)))
    for position, record in enumerate(index.records):
        # F5: two files may share a basename. Identity is the position; the id is only a
        # label, disambiguated so a reader can tell the two apart in output.
        count = used_ids.get(record.record_id, 0)
        used_ids[record.record_id] = count + 1
        if count:
            record.record_id = "%s#%d" % (record.record_id, count + 1)
        record.position = position
        for collection in (record.access_events, record.statuses):
            for entry in collection:
                entry["record_id"] = record.record_id
    return index


# --------------------------------------------------------------------------------------
# Lookup
# --------------------------------------------------------------------------------------

def _base_result(query: str, scheme: Optional[str], normalized: Optional[str], index: Index) -> Dict[str, object]:
    scope = index.scope()
    return {
        "query": query,
        "resolved_scheme": scheme,
        "normalized": normalized,
        "state": "",
        "matches": [],
        "url_key_mentions": [],
        "record_statuses": [],
        "access_evidence": [],
        "conflicts": [],
        "notes": [],
        "indexed_scope": scope,
        "scope_warnings": scope["scope_warnings"],
        "synthetic_fixture_records": [],
        "disclaimer": DISCLAIMER,
    }


def _matches_for(index: Index, scheme: str, normalized: str) -> List[Dict[str, object]]:
    matches: List[Dict[str, object]] = []
    for record in index.records:
        for mention in record.mentions:
            if mention.scheme == scheme and mention.normalized == normalized:
                entry: Dict[str, object] = dict(mention.as_dict())
                entry["record_id"] = record.record_id
                entry["record_position"] = record.position
                entry["origin_path"] = record.path
                entry["synthetic_fixture"] = record.synthetic_fixture
                matches.append(entry)
    matches.sort(key=lambda entry: (str(entry["record_id"]), str(entry["locator"])))
    return matches


def _co_identifier_conflicts(index: Index, scheme: str, normalized: str) -> List[Dict[str, object]]:
    partners: Dict[str, Dict[str, List[str]]] = {}
    for record in index.records:
        for group in record.groups:
            if not any(m.scheme == scheme and m.normalized == normalized for m in group):
                continue
            for mention in group:
                if mention.scheme == scheme or mention.scheme not in IDENTITY_SCHEMES:
                    continue
                bucket = partners.setdefault(mention.scheme, {})
                where = bucket.setdefault(mention.normalized, [])
                locator = "%s@%s" % (record.record_id, mention.locator)
                if locator not in where:
                    where.append(locator)
    conflicts: List[Dict[str, object]] = []
    for partner_scheme in sorted(partners):
        values = partners[partner_scheme]
        if len(values) > 1:
            conflicts.append({
                "type": "co_identifier_divergence",
                "query_scheme": scheme,
                "query_normalized": normalized,
                "partner_scheme": partner_scheme,
                "values": sorted(values),
                "provenance": {value: values[value] for value in sorted(values)},
                "note": (
                    "The same %s is bound to differing %s values in the supplied corpus. "
                    "Both bindings are retained; this tool does not adjudicate which is "
                    "correct, and asserts no cross-scheme identity that a record did not "
                    "state." % (scheme.upper(), partner_scheme.upper())
                ),
            })
    return conflicts


def _status_conflicts(statuses: Sequence[Dict[str, str]]) -> List[Dict[str, object]]:
    """F3: divergence means the SAME field name carrying different values.

    Orthogonal dimensions (``operational_status``, ``scientific_status``,
    ``source_asset_status``) in one record disagree about nothing, and reporting them as
    a contradiction manufactures a conflict the repository does not assert.
    """
    by_field: Dict[str, List[Dict[str, str]]] = {}
    for entry in statuses:
        by_field.setdefault(entry["field"], []).append(entry)
    conflicts: List[Dict[str, object]] = []
    for field_name in sorted(by_field):
        entries = by_field[field_name]
        if len({entry["status"] for entry in entries}) > 1:
            conflicts.append({
                "type": "differing_record_status",
                "field": field_name,
                "statuses": entries,
                "note": (
                    "Field %r carries differing dated statuses. All are listed in date "
                    "order and all are retained; none is superseded, merged or "
                    "overwritten here. This flags divergence for human reading and does "
                    "not assert contradiction. Statuses under DIFFERENT field names are "
                    "orthogonal dimensions and are not compared." % field_name
                ),
            })
    return conflicts


def lookup(index: Index, query: str, kind: Optional[str] = None) -> Dict[str, object]:
    """Look one candidate up. Always returns a result dict; never raises for bad input."""
    scheme, resolved = parse_candidate(query, kind)
    if scheme is None:
        result = _base_result(query, None, None, index)
        result["state"] = "invalid_candidate"
        result["reason"] = resolved
        result["notes"] = [NON_MATCH_NOTE, TITLE_NOTE] + list(result["scope_warnings"])
        return result

    if scheme == "url":
        result = _base_result(query, "url", resolved, index)
        embedded = [
            mention for mention in extract_identifiers(query, "query", "query_string")
            if mention.scheme in IDENTITY_SCHEMES
        ]
        distinct = sorted({(m.scheme, m.normalized) for m in embedded})
        result["url_key_mentions"] = _matches_for(index, "url", resolved)
        if len(distinct) > 1:
            result["state"] = "ambiguous_multiple_identifiers"
            result["embedded_identifiers"] = [
                {"scheme": item[0], "normalized": item[1]} for item in distinct
            ]
            result["notes"] = [
                URL_NOTE,
                NON_MATCH_NOTE,
                "This URL embeds more than one identifier; it is not resolved to any "
                "single record, and no candidate was chosen arbitrarily.",
            ] + list(result["scope_warnings"])
            return result
        if not distinct:
            result["state"] = "unresolved_url_without_identifier"
            result["notes"] = [
                URL_NOTE,
                NON_MATCH_NOTE,
                "This URL carries no embedded DOI/PMID/PMCID/accession, so it cannot "
                "identify an article. Any URL mentions listed under url_key_mentions are "
                "string co-occurrences only.",
            ] + list(result["scope_warnings"])
            return result
        inner_scheme, inner_normalized = distinct[0]
        inner = lookup(index, inner_normalized, kind=inner_scheme)
        inner["query"] = query
        inner["resolved_via"] = {
            "url_key": resolved,
            "embedded_scheme": inner_scheme,
            "embedded_normalized": inner_normalized,
        }
        inner["url_key_mentions"] = result["url_key_mentions"]
        inner["notes"] = [URL_NOTE] + list(inner["notes"])
        return inner

    result = _base_result(query, scheme, resolved, index)
    matches = _matches_for(index, scheme, resolved)
    result["matches"] = matches
    if not matches:
        result["state"] = "unresolved_not_indexed"
        result["notes"] = [NON_MATCH_NOTE] + list(result["scope_warnings"])
        return result

    # F5: select contributing records by POSITION, never by record_id string equality.
    matched_positions = {entry["record_position"] for entry in matches}
    statuses: List[Dict[str, str]] = []
    events: List[Dict[str, object]] = []
    synthetic: List[str] = []
    for record in index.records:
        if record.position not in matched_positions:
            continue
        statuses.extend(record.statuses)
        events.extend(record.access_events)
        if record.synthetic_fixture:
            synthetic.append(record.record_id)
    statuses.sort(key=lambda entry: (entry["date"], entry["record_id"], entry["field"]))
    events.sort(key=lambda entry: (str(entry["record_id"]), str(entry["locator"])))
    result["record_statuses"] = statuses
    result["access_evidence"] = events
    result["synthetic_fixture_records"] = sorted(synthetic)

    conflicts = _co_identifier_conflicts(index, scheme, resolved)
    conflicts.extend(_status_conflicts(statuses))
    result["conflicts"] = conflicts

    notes = [DATED_NOTE]
    if events:
        notes.append(LABEL_MENTION_NOTE)
    else:
        # F4: silence and "nothing recognised" used to render identically.
        notes.append(NO_ACCESS_EVIDENCE_NOTE)
    if any(event.get("negated_terms_present") for event in events):
        notes.append(
            "At least one access statement contains negating wording. Labels record the "
            "categories named in the text, including categories the record explicitly "
            "rules out; read the verbatim quote before drawing any conclusion."
        )
    if synthetic:
        notes.append(
            "%s Matched record(s) %s are labelled synthetic fixtures and assert no "
            "bibliographic fact." % (SYNTHETIC_MARKER, ", ".join(sorted(synthetic)))
        )
    notes.extend(result["scope_warnings"])
    result["notes"] = notes

    if all(entry["context"] == "prose_context" for entry in matches):
        result["state"] = "matched_prose_mention_only"
        result["notes"].append(
            "Every match is a prose mention, not a structured record field: the corpus "
            "discusses this identifier but no structured record binds it."
        )
    elif conflicts:
        result["state"] = "matched_with_divergent_states"
    else:
        result["state"] = "matched"
    return result


# --------------------------------------------------------------------------------------
# CLI
# --------------------------------------------------------------------------------------

def _mark(entry: Dict[str, object], text: str) -> str:
    """F8: prefix a rendered line whose record is a labelled synthetic fixture."""
    return "%s %s" % (SYNTHETIC_MARKER, text) if entry.get("synthetic_fixture") else text


def render_text(result: Dict[str, object]) -> str:
    synthetic_ids = set(result.get("synthetic_fixture_records") or [])
    lines = [
        "query            : %s" % result["query"],
        "resolved_scheme  : %s" % result["resolved_scheme"],
        "normalized       : %s" % result["normalized"],
        "state            : %s" % result["state"],
    ]
    if result.get("reason"):
        lines.append("reason           : %s" % result["reason"])
    for entry in result["matches"]:
        lines.append("match            : " + _mark(entry, "%s :: %s [%s] (%s) <- %s"
                     % (entry["record_id"], entry["locator"], entry["context"],
                        entry["raw"], entry["origin_path"])))
    for entry in result["url_key_mentions"]:
        lines.append("url_mention      : " + _mark(entry, "%s :: %s"
                     % (entry["record_id"], entry["locator"])))
    for entry in result["record_statuses"]:
        text = "%s | %s | %s :: %s" % (entry["date"] or "undated", entry["record_id"],
                                       entry["field"], entry["status"])
        if entry["record_id"] in synthetic_ids:
            text = "%s %s" % (SYNTHETIC_MARKER, text)
        lines.append("status           : %s" % text)
    for entry in result["access_evidence"]:
        text = "%s :: %s :: %s" % (entry["record_id"], ",".join(entry["labels"]), entry["quote"])
        if entry["record_id"] in synthetic_ids:
            text = "%s %s" % (SYNTHETIC_MARKER, text)
        lines.append("access_evidence  : %s" % text)
        for detail in entry.get("label_evidence", []):
            lines.append("  label_basis    : %s | phrase=%r | clause_negates=%s"
                         % (detail["label"], detail["matched_phrase"],
                            detail["clause_has_negation"]))
    for entry in result["conflicts"]:
        lines.append("conflict         : %s :: %s" % (entry["type"], entry["note"]))
    for note in result["notes"]:
        lines.append("note             : %s" % note)
    for warning in result.get("scope_warnings") or []:
        lines.append("scope_warning    : %s" % warning)
    scope = result["indexed_scope"]
    lines.append("indexed_scope    : %d file(s): %s"
                 % (scope["file_count"], ", ".join(scope["files"])))
    lines.append("disclaimer       : %s" % result["disclaimer"])
    return "\n".join(lines)


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = argparse.ArgumentParser(
        description=(
            "Read-only identifier/source-provenance lookup over retained records. "
            "Informational only: exits 0 for every lookup state, including unresolved "
            "and invalid, so it cannot act as a gate."
        )
    )
    parser.add_argument("query", help="DOI, PMID, PMCID, accession or URL")
    parser.add_argument("--record", action="append", default=None,
                        help="file or directory to index (repeatable; default '.')")
    parser.add_argument("--kind", choices=sorted(IDENTITY_SCHEMES + ("url",)), default=None,
                        help="force the candidate scheme (required for a bare PMID)")
    parser.add_argument("--json", action="store_true", help="emit JSON")
    args = parser.parse_args(list(argv) if argv is not None else None)

    roots = args.record or ["."]
    index = build_index(roots)
    result = lookup(index, args.query, args.kind)
    if args.json:
        print(json.dumps(result, indent=2, sort_keys=True))
    else:
        print(render_text(result))
    return 0  # deliberate: every lookup state exits 0; this tool is not a gate.


if __name__ == "__main__":
    sys.exit(main())
