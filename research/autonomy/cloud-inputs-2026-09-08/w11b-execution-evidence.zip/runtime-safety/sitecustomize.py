import json, os, sys
_allowed = os.path.normcase(os.path.realpath(os.environ["W11B_ALLOWED_TEMP"]))
_log = os.environ["W11B_AUDIT_LOG"]
def _audit(event, args):
    if event == "shutil.rmtree":
        target = os.path.normcase(os.path.realpath(os.fsdecode(args[0])))
        allowed = os.path.commonpath([_allowed, target]) == _allowed and target != _allowed
        with open(_log, "a", encoding="utf-8") as f:
            f.write(json.dumps({"event":event,"target":target,"allowed":allowed}) + "\n")
        if not allowed:
            raise RuntimeError("Fixture cleanup outside this run's private TEMP is prohibited")
    elif event in ("socket.connect", "socket.connect_ex", "socket.getaddrinfo", "socket.bind"):
        with open(_log, "a", encoding="utf-8") as f:
            f.write(json.dumps({"event":event,"blocked":True}) + "\n")
        raise RuntimeError("Network calls are outside the supplied-code execution scope")
sys.addaudithook(_audit)
