import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time

ROOT = Path(__file__).resolve().parent
PYTHON = r"C:/Users/mcrae/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe"
DEPS = r"C:/Projects/EMC-Research/.cache/python-deps"


def sha(data):
    return hashlib.sha256(data).hexdigest()


freeze = json.loads((ROOT / "execution-freeze.json").read_text(encoding="utf-8"))
for entry in freeze["files"]:
    assert sha((ROOT / entry["path"]).read_bytes()) == entry["sha256"]
(ROOT / "harness-freeze.json").write_text(json.dumps({
    "utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "path": "run_exact.py",
    "sha256": sha(Path(__file__).read_bytes()),
    "execution_freeze_sha256": sha((ROOT / "execution-freeze.json").read_bytes()),
}, indent=2) + "\n", encoding="utf-8")

results = []
for name in ("positive", "negative"):
    temp = ROOT / "temp" / name
    temp.mkdir(parents=True, exist_ok=False)
    env = os.environ.copy()
    env.update({
        "TEMP": str(temp), "TMP": str(temp), "TMPDIR": str(temp),
        "PYTHONPATH": str(ROOT / "runtime-safety") + os.pathsep + DEPS,
        "PYTHONDONTWRITEBYTECODE": "1",
        "PYTHONUTF8": "1",
        "PYTEST_DISABLE_PLUGIN_AUTOLOAD": "1",
        "W11B_ALLOWED_TEMP": str(temp),
        "W11B_AUDIT_LOG": str(ROOT / (name + ".audit.jsonl")),
    })
    argv = [PYTHON, "-X", "utf8", "-B", "-m", "pytest",
            "scripts/tests/test_source_reuse_index.py", "-q",
            "--basetemp", str(temp / "pytest")]
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    t0 = time.monotonic()
    result = subprocess.run(argv, cwd=ROOT / name, env=env,
                            capture_output=True, timeout=120)
    elapsed = round(time.monotonic() - t0, 6)
    (ROOT / (name + ".stdout.txt")).write_bytes(result.stdout)
    (ROOT / (name + ".stderr.txt")).write_bytes(result.stderr)
    text = result.stdout.decode("utf-8", errors="replace")
    summary = [line for line in text.splitlines()
               if re.search(r"\b\d+ (?:passed|failed|error|skipped)", line)]
    audit = ROOT / (name + ".audit.jsonl")
    audit_rows = [json.loads(line) for line in audit.read_text().splitlines()] if audit.exists() else []
    entry = {
        "name": name, "argv": argv, "cwd": str(ROOT / name),
        "utc_started": start, "elapsed_seconds": elapsed,
        "exit_code": result.returncode,
        "stdout_path": name + ".stdout.txt", "stdout_sha256": sha(result.stdout),
        "stderr_path": name + ".stderr.txt", "stderr_sha256": sha(result.stderr),
        "pytest_summary_lines": summary,
        "private_temp": str(temp),
        "cleanup_events": len([r for r in audit_rows if r["event"] == "shutil.rmtree"]),
        "cleanup_all_allowed": all(r.get("allowed", False) for r in audit_rows if r["event"] == "shutil.rmtree"),
        "network_events": len([r for r in audit_rows if r["event"].startswith("socket.")]),
        "environment_overrides": {key: env[key] for key in (
            "TEMP", "TMP", "TMPDIR", "PYTHONPATH", "PYTHONDONTWRITEBYTECODE",
            "PYTHONUTF8", "PYTEST_DISABLE_PLUGIN_AUTOLOAD", "W11B_ALLOWED_TEMP", "W11B_AUDIT_LOG")},
    }
    results.append(entry)
    (ROOT / (name + ".execution.json")).write_text(json.dumps(entry, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({k: entry[k] for k in ("name", "exit_code", "elapsed_seconds", "pytest_summary_lines", "cleanup_events", "cleanup_all_allowed", "network_events")} ), flush=True)

unchanged = all(sha((ROOT / entry["path"]).read_bytes()) == entry["sha256"] for entry in freeze["files"])
record = {
    "completed_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "runs": results, "frozen_files_unchanged": unchanged,
    "scope": "Exact supplied repaired helper/tests, plus exact same tests with original helper. No repairs, new tests, preflight, integration or scientific acceptance.",
    "negative_claim_comparison": "Compare actual negative summary to report's 7 failed / 11 passed; outcome was not forced.",
    "tier_issue": "Coordinator observed current baseline1497/1500; these18 tests would1515. Integration remains pending, regardless of standalone test results.",
    "running_processes": False,
}
(ROOT / "execution-result.json").write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
assert unchanged, "Frozen supplied files changed during execution"
