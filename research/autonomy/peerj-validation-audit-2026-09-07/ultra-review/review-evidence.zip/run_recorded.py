from pathlib import Path
import subprocess, sys, json, datetime, time, os

ROOT=Path(__file__).resolve().parent
def run(label, command, cwd=ROOT):
    start=datetime.datetime.now(datetime.timezone.utc).isoformat()
    tick=time.perf_counter()
    result=subprocess.run(command, cwd=cwd, capture_output=True, text=True, encoding='utf-8', errors='replace')
    end=datetime.datetime.now(datetime.timezone.utc).isoformat()
    record=dict(label=label,command=command,cwd=str(cwd),started_at=start,ended_at=end,elapsed_seconds=time.perf_counter()-tick,exit_code=result.returncode,stdout_file=label+'.stdout.txt',stderr_file=label+'.stderr.txt')
    (ROOT/(label+'.stdout.txt')).write_text(result.stdout,'utf-8')
    (ROOT/(label+'.stderr.txt')).write_text(result.stderr,'utf-8')
    with (ROOT/'validation-executions.jsonl').open('a',encoding='utf-8') as stream:
        stream.write(json.dumps(record)+'\n')
    print(json.dumps(record))
    print(result.stdout)
    print(result.stderr)
    return result.returncode

if __name__=='__main__':
    sys.exit(run(sys.argv[1],sys.argv[2:]))
