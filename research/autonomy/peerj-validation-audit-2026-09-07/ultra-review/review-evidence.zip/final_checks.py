from pathlib import Path
import json,hashlib,re,xml.etree.ElementTree as ET,statistics,sys
sys.path.insert(0,'C:/Projects/EMC-Research/.cache/python-deps')
from scipy.stats import mannwhitneyu
from pypdf import PdfReader

ROOT=Path(__file__).resolve().parent;INPUT=ROOT.parent/'input'
manifest=json.loads((ROOT/'evidence-copy'/'manifest.json').read_text('utf-8'))
inventory=[]
for item in manifest['files']:
    blob=(ROOT/'evidence-copy'/item['path']).read_bytes()
    assert len(blob)==item['bytes']
    assert hashlib.sha256(blob).hexdigest()==item['sha256']
    inventory.append(item['path'])
assert len(inventory)==manifest['total_listed_files']
assert sum((ROOT/'evidence-copy'/x).stat().st_size for x in inventory)==manifest['total_listed_bytes']

# A reproducibility comparison excludes only the verifier's variable execution timestamps.
comparisons=[]
for name in ('GSE6481-metadata.json','GSE24369-metadata.json','verification-summary.json'):
    frozen=json.loads((INPUT/'evidence'/'results'/name).read_text('utf-8'))
    actual=json.loads((ROOT/'evidence-copy'/'reproduced-results'/name).read_text('utf-8'))
    assert frozen==actual
    comparisons.append({'name':name,'json_equal':True})

# Illustrative rank test only, explicitly synthetic and unrelated to expression measurements.
def z(v):
    return [(x-statistics.mean(v))/statistics.stdev(v) for x in v]
x=z([-1]*11+[11]);y=z([-1]*5+[5])
test=mannwhitneyu(x,y,alternative='two-sided',method='asymptotic')
assert float(test.pvalue)<0.05
shape={'scope':'Synthetic reviewer-created vectors, n=12 and n=6, each standardized to sample mean 0 and sample SD 1. No biological result.','x':x,'y':y,'U':float(test.statistic),'p':float(test.pvalue),'method':'two-sided asymptotic Mann-Whitney with default tie correction and continuity correction','interpretation':'Separate standardization does not mathematically force a nonsignificant Mann-Whitney result.'}

reader=PdfReader(INPUT/'emc-external-validation-comment-preprint.pdf')
links=[]
for page_no,page in enumerate(reader.pages,1):
    for annot in page.get('/Annots',[]):
        a=annot.get_object().get('/A',{})
        if a.get('/URI'):links.append({'page':page_no,'uri':str(a['/URI'])})
text='\n'.join(page.extract_text() for page in reader.pages)
assert all(marker in text for marker in ('Abstract','The claim requiring clarification','Separate standardization','A reproducible and proportionate interpretation','Data and code availability','Declarations','References'))
results={'manifest_integrity':'passed','reproduced_json_comparisons':comparisons,'synthetic_shape_test':shape,'pdf_pages':len(reader.pages),'pdf_links':links}
(ROOT/'final-check-results.json').write_text(json.dumps(results,indent=2),'utf-8')
print(json.dumps(results,indent=2))

root=ET.parse(INPUT/'evidence'/'sources'/'peerj-21497-article.xml').getroot()
def walk(el,context):
    if el.tag=='sec':
        title=el.find('title')
        context=context+[{'id':el.get('id'),'title':''.join(title.itertext()) if title is not None else ''}]
    if el.tag=='p':
        text=''.join(el.itertext())
        if any(q in text for q in ('within-dataset z-score','GSE6481, directly','baseline comparability')):
            print('SOURCE LOCATOR',json.dumps({'context':context,'text':text},ensure_ascii=False))
    for child in el:walk(child,context)
walk(root,[])
