from pathlib import Path
from datetime import datetime, timezone
import json

ROOT=Path(__file__).resolve().parent
INPUT=ROOT.parent/'input'
request=json.loads((INPUT/'review-input.json').read_text('utf-8'))
started='2026-09-07T21:08:37Z'
ended=datetime.now(timezone.utc).isoformat()
manuscript=(INPUT/'emc-external-validation-comment.md').read_text('utf-8')
central=manuscript.split('## Abstract\n\n',1)[1].split('\n\n**Keywords.',1)[0]
executions=[json.loads(line) for line in (ROOT/'validation-executions.jsonl').read_text('utf-8').splitlines()]
assert all(x['exit_code']==0 for x in executions)

editorial=[{
    'id':'E1',
    'severity':'minor',
    'category':'scientific attribution precision; nonblocking',
    'artifact':'emc-external-validation-comment.md lines 54-62; corresponding preprint PDF page 2',
    'outgoing_passage':'For a nonconstant gene measured in cohort C, the stated transformation is: [gene-wise cohort mean/SD formula] ... It follows from the reported method and does not depend on access to the external expression matrix.',
    'source_evidence':'The original PeerJ XML, Methods / Cross-study comparison and external cohort evaluation, and Results / Cross-cohort analysis and lineage specificity of prognostic biomarkers, say "within-dataset z-score transformation". They do not explicitly give the normalization axis, formula, or centering reference. Figure S6C likewise says within-dataset z-scores. Recomputed gene-wise sample-SD z-scores for all three internal genes from original Data S1 have ranges and patterns consistent with the actual figure; this supports the usual gene-wise interpretation but is not recovery of the external code.',
    'consequence':'The mathematical result is correct, but "the stated transformation" can imply that the original article explicitly specified the exact gene-wise formula. A different normalization axis/reference can preserve some gene-specific location contrasts. This is an attribution qualification, not a refutation of the broader failure-to-establish-comparability conclusion.',
    'smallest_correction':'Introduce the formula with: "If, as the wording and Figure S6C suggest, each gene was centered and scaled across samples separately within each cohort, the transformation is:" Replace the last sentence of line 62 with "Under this interpretation, the limitation follows algebraically without the external expression matrix." The existing request for the exact reference distribution at line 72 can remain.',
    'blocking':False
}]

checked=[
 {'artifact':'review-input.json and all nine listed files','check':'Independently recomputed all nine SHA256 values; all matched. Preserved the supplied five-file digest as the review identifier. The digest aggregation algorithm was not supplied, so no claim of separately recomputing that aggregate is made.','evidence':'input-hash-check.json'},
 {'artifact':'emc-external-validation-comment-evidence.zip, manifest.json, both build stamps','check':'All 13 archive members match the supplied extraction byte-for-byte; all 12 inventory entries pass byte-size/hash checks. PDF build stamp pins the reviewed manuscript hash. Old evidence build source_commit is provenance for the unchanged bundle, not evidence of a different reviewed manuscript.','evidence':'zip-check.json; final-check-results.json'},
 {'artifact':'complete original GSE6481_family.soft.gz','check':'Portable verifier plus independently written full-stream metadata scan reproduce 105 unique GSM records, exact series-roster membership and ten diagnosis counts. No deposited EMC or chondrosarcoma category exists. The count of 19 myxoid liposarcomas cannot identify the article authors\' analysis cohort.','evidence':'GSE6481-independent-check.json; GSE6481-independent-raw-metadata.txt; evidence-copy/reproduced-results/GSE6481-metadata.json'},
 {'artifact':'complete original GSE24369_family.soft.gz','check':'42 unique arrays: six EMC, 17 low-grade fibromyxoid sarcoma, six myxofibrosarcoma, six desmoid fibromatosis, five solitary fibrous tumor and two skeletal-muscle pooled RNA references. Six EMC + 34 other lesions + two references is correct. Arrays were not treated as independently verified unique patients.','evidence':'GSE24369-independent-check.json; GSE24369-independent-raw-metadata.txt'},
 {'artifact':'original PeerJ article XML and original Figure S6 PNG','check':'Read pertinent Methods, Results, Discussion, limitations and supplement captions; visually inspected original Figure S6. Verified n=147 heading, n=19 EMC and n=59 comparators in each S6B plot, and S6C P-values 0.963, 0.888, 1. No plotted coordinates were digitized and no points were used as a patient roster. Confirmed source acknowledges overfitting/C-index 0.10 and declines external prognostic evaluation.','evidence':'peerj-21497-article-paragraphs.json; inspect-sources.stdout.txt; final-checks.stdout.txt'},
 {'artifact':'original Nakayama publisher HTML and PubMed XML','check':'Both identify the actual 2007 Modern Pathology publication and 105 tumors; the publisher full text supplies the same ten-category counts. The supplied identifier-verification record was not used as a substitute for original-source evidence.','evidence':'publisher-3800794-text.txt; pubmed-17464315-paragraphs.json'},
 {'artifact':'original Davis 2017 article XML','check':'Confirms six EMC patients in MI-ONCOSEQ; five of six biopsy samples passed all QC and one had poor RNA yield. The outgoing wording attributes six external profiles to the later article and does not claim that this reviewer confirmed six high-quality external expression profiles. No external sample matrix was available to adjudicate that selection.','evidence':'davis-2017-article-paragraphs.json'},
 {'artifact':'Original supplementary packet retrieved from Europe PMC, bounded external-source check','check':'Named unresolved question: whether the packet contains external S6 sample-by-gene data or analysis code. Retrieved original ZIP with HTTP 200; its Figure S6 hash matches the frozen image. Inventory contains figures, two result-table DOCX files and one XLSX, with no analysis script. The only workbook has one sheet, 9501 rows and 13 columns, comprising a gene-symbol column and 12 internal Si sample columns. Both DOCX texts are internal statistical results. This supports the packet-specific absence statement, not a claim of absence elsewhere.','evidence':'supplement-retrieval.json; supplement-packet-inventory.json; supplement-packet-check.stdout.txt; supplement-followup.stdout.txt'},
 {'artifact':'Algebra and rank-test interpretation','check':'Derived positive affine invariance for nonconstant vectors using recomputed mean and SD. Eight explicit synthetic checks pass for population/sample SD and positive rescaling/shifting. A separate synthetic n=12 versus n=6 example, each standardized to sample mean zero/SD one, gives Mann-Whitney U=61 and asymptotic two-sided P=0.0081564, confirming that standardization does not force the null result. These are synthetic arithmetic illustrations, not biological measurements or reproductions of S6 P-values.','evidence':'synthetic-algebra-check.json; final-check-results.json'},
 {'artifact':'Internal Data S1 and normalization-axis plausibility','check':'Recomputed existing internal PXN/H1FX/TYMS gene-wise z-scores solely to check the stated-method interpretation. Sample-SD ranges are PXN -1.5065 to 2.1324, H1FX -1.1559 to 1.6583, TYMS -1.4591 to 1.5377; these are visually consistent with original S6C. External normalization remains unrecovered.','evidence':'internal-gene-transform-check.json'},
 {'artifact':'Frozen four-page preprint PDF','check':'Rendered all four pages with pdftoppm at 110 dpi and actually inspected each rendered image. Text, formula blocks, references, page numbers and links are readable, with no clipping, collisions, missing glyphs or apparent omissions. Page 4 is references-only with whitespace, which is acceptable. No figure was newly generated for the outgoing manuscript.','evidence':'comment-page-1.png through comment-page-4.png; pdf-text.txt; pdf-info.stdout.txt; final-check-results.json'}
]

review={
 'paper':request['paper'],'reviewed_commit':request['reviewed_commit'],
 'deliverable_digest':request['deliverable_digest'],'document_sha256':request['document_sha256'],
 'blind':True,'blind_definition':'Blind to authoring conversation and prior merit assessments; author identity is visible in the supplied manuscript. This is independent AI review, not anonymous human peer review.',
 'model':'gpt-6-astra','reasoning_effort':'ultra','actual_model':'gpt-6-astra','actual_reasoning_effort':'ultra',
 'started_at':started,'ended_at':ended,'status':'complete','central_claim':central,
 'verdict':'supported',
 'verdict_reason':'The frozen public cohort records cannot identify the published lineage comparison, and the printed sample counts contradict one another. Under the well-supported conventional gene-wise reading, separate cohort z-scoring discards location and scale; the general lack-of-equivalence and patient/platform-confounding criticisms do not depend on resolving the normalization axis. The exact external implementation is not recoverable, so a minor qualification of its attribution is recommended.',
 'submission_merit':{'decision':'merits_submission','reason':'This specific comment identifies an independently reproducible cohort-provenance defect underlying a repeated biological lineage claim, identifies a separate internal count discrepancy, and accurately limits what the cited normalization comparison establishes. The targeted evidence and proportionate request for correction/inputs are useful scientific correspondence even without a new biological or prognostic result. The generic standardization principle is not novel, but its specific application supplements the source audit. The recommendation is to submit as a focused scientific comment; E1 is a nonblocking precision suggestion.','scientific_submission_blocked':False,'venue_acceptance_prediction':None},
 'blockers':[],'p1s':[],'editorial':editorial,
 'p1_classification_note':'No scientific blocker and no separate P1 maintenance issue was identified. Missing regression tests for correct prose were not treated as a finding or submission gate.',
 'checked_evidence':checked,'executed_validation':executions,
 'charitable_alternatives':[
  'A mistaken accession, figure-label typo, or undocumented cohort selection could explain the source discrepancy. The comment explicitly allows these possibilities and correctly does not allege that myxoid liposarcoma was relabeled as EMC.',
  'The original authors may intend only qualitative agreement after putting each cohort on its own standardized scale. That is a legitimate descriptive aim, but a high P-value does not establish equivalence or technical interchangeability. The outgoing comment explicitly preserves the narrower absence-of-detected-differences interpretation.',
  'The phrase within-dataset z-scoring does not explicitly state its axis. Gene-wise standardization is conventional and consistent with all three internal plot patterns, but a global or sample-wise normalization would remove a different set of contrasts. E1 makes this inference explicit without requiring unpublished code to support the comment.',
  'Different patients, disease states and sample processing can yield similar or different expression distributions even on identical assays; unpaired patient cohorts cannot isolate a platform effect. Paired material is proposed as a more direct design, not asserted as existing evidence.',
  'Some S6 inputs may exist outside the supplementary packet or be available on author request. The comment limits its absence claim to the inspected packet and requests clarification.'
 ],
 'novelty_assessment':'The mathematical principle is elementary and established; no statistical-method novelty or new biological discovery should be claimed. The substantive contribution is the verifiable article-specific mismatch between the reported external lineage cohort and the actual deposited cohort, plus its consequences for interpretation. The supplied original article does not acknowledge this accession/count discrepancy. Global priority of the critique was not investigated.',
 'claim_strength_assessment':'Proportionate: distinguishes metadata annotation from true patient histology, avoids inferring the actual analyzed cohort or diagnostic relabeling, distinguishes nonsignificance from equivalence, acknowledges already-published overfitting, and makes no clinical efficacy, safety, treatment or prognostic validation claim.',
 'layout_assessment':'All four actual rendered pages inspected; suitable as a readable preprint/comment. No layout defect requiring correction found. Specific journal formatting or word-limit compliance was outside the supplied scope.',
 'limitations':[
  'The external sample-by-gene expression matrices and analysis scripts were not available. No original GEO fold change or P-value, no external S6C value, and no prognostic model was independently reproduced.',
  'Complete deposited metadata establish annotations and array membership, not audited patient identities or independent pathology. A corrected accession or author clarification could resolve the lineage evidence problem.',
  'The original paper does not specify the z-score axis/reference explicitly; the strong gene-wise reading is corroborated for internal values, not proven for external values.',
  'Only a bounded primary-source supplementary-packet check was performed outside the frozen inputs. No authoring records, prior merit reviews or repository state were inspected, and no correspondence or publication occurred.',
  'The five-file aggregate digest is preserved from review-input.json; all component SHA256 values were checked, but its unspecified aggregation convention was not reverse-engineered.',
  'This single review assesses scientific submission merit, not likelihood of acceptance or exhaustive novelty relative to all subsequent literature. It is an AI review, not independent human peer review.'
 ],
 'errors_and_interruptions':{'interrupted':False,'nonfatal_errors_file':'initial-tool-errors.json','summary':'An unavailable pdftotext command and an unsuccessful web-tool ZIP opener were handled with pypdf and a successful direct primary-source download respectively. All recorded validation subprocesses exited zero. The last verification required 67.13 seconds, ran to completion, and is not reported as a failure.'},
 'input_scope':request['input_scope'],'external_source_scope':'Only the original Europe PMC supplementary packet, to resolve the named packet-contents question; preserved bytes and receipt. Internal gene-wise transformation plausibility was then checked from its existing Data S1.',
 'delegated':False,'publication_or_contacts_performed':False,
 'really_running':False,
 'output_files':['review.md','review.json','review-status.json','validation-executions.jsonl','initial-tool-errors.json']
}

md=f'''# Independent scientific submission review

**Decision: central claim supported; this contribution merits submission as a focused scientific comment.** No scientific blockers or P1 maintenance issues were found. One minor, nonblocking wording qualification is recommended.

Paper: `{review['paper']}`  
Reviewed commit: `{review['reviewed_commit']}`  
Five-file deliverable digest: `{review['deliverable_digest']}`  
Manuscript SHA256: `{review['document_sha256']}`  
Reviewer: gpt-6-astra; ultra reasoning. Started {started}; completed {ended}. Status: complete.

This review was blind to the authoring conversation and prior merit assessments. It was not blind to the named author, whose identity appears in the manuscript. It is an independent AI assessment, not human peer review. No delegation, repository editing, publication or correspondence occurred.

## Central claim, in full

{central}

## Scientific assessment and submission merit

The cohort criticism is supported directly, independently and at the right level of certainty. Both a rerun of the supplied portable verifier and an independently written complete metadata scan recover 105 unique GSM records for GSE6481 with exact agreement to the series roster. Its ten diagnosis counts match manuscript line 42. Neither the deposited diagnosis fields nor the original Nakayama publication identify EMC or another chondrosarcoma category. This is a source-identification failure for the claimed comparison, not evidence that a particular alternative diagnosis was actually analyzed as EMC. Manuscript line 46 makes that distinction explicitly.

The original Figure S6B visibly gives GSE6481 n=147 and, in each of the three comparisons, EMC n=19 and other chondrosarcomas n=59. The total of the group labels is 78. The original article instead reports 128 comparators. These discrepancies are accurately reproduced without digitizing plot coordinates or using visible points as a patient roster. The GSE24369 correction is also exact: six EMC arrays, 34 other-lesion arrays and two pooled muscle references. The comment appropriately avoids asserting that the description error necessarily changes an expression result.

The algebra is correct for a nonconstant gene standardized across samples separately in each cohort. Recomputing its mean and standard deviation after any positive affine transformation leaves every z-score unchanged, for either sample or population SD. Thus location and scale contrasts eliminated by this transformation cannot be recovered from a test of the standardized vectors. Eight explicitly synthetic arithmetic checks pass. The comment also correctly says that standardization does not force matching shapes or a P-value of one. As a direct countercheck, two deliberately synthetic standardized vectors with n=12 and n=6 give Mann–Whitney U=61, asymptotic two-sided P=0.0081564. This is only a mathematical illustration, not biological evidence or reproduction of S6C.

The precise normalization axis deserves the minor qualification below. The original Methods and Results call the procedure a within-dataset z-score transformation but do not explicitly write its axis or centering reference. Gene-wise cohort standardization is the natural reading. Existing internal Data S1 values transformed with sample SD give PXN, H1FX and TYMS ranges and patterns consistent with the original S6C image. That corroborates the interpretation without recovering the external code. Even if the axis proves different, a nonsignificant rank test does not establish a prespecified equivalence claim, and these unpaired patient cohorts do not isolate a platform effect.

The most charitable interpretation is that the original authors intended descriptive similarity after separately putting the cohorts on a standardized scale. Such a description is defensible. Stronger claims that this comparison confirms baseline comparability or assay interchangeability are not established by it. The outgoing comment preserves that narrower descriptive interpretation and explicitly says the audit does not prove platform discordance. It likewise acknowledges the source article's already-published overfitting and refusal to present the external cohorts as meaningful prognostic validation.

This is sufficient scientific substance for a comment. The contribution is an article-specific, reproducible source mismatch affecting a repeatedly used lineage interpretation, accompanied by an exact count discrepancy and a proportionate methodological qualification. It is not a new statistical method or biological discovery, and it does not need to pretend to be one. The comment asks for the actual accession, sample assignments, expression inputs, gene/probe mapping and normalization reference. These are useful, bounded corrections. I did not investigate global priority of the criticism or predict a particular journal's acceptance.

## Findings

**Scientific blockers:** none.  
**P1 maintenance issues:** none.

**E1 — minor, nonblocking attribution precision.** Artifact: manuscript lines 54–62 and PDF page 2. The outgoing introduction calls the per-gene cohort mean/SD formula “the stated transformation,” followed by “It follows from the reported method.” The original article specifies within-dataset z-scoring but not its axis/reference. The gene-wise interpretation is well supported by the context and the internal source/figure comparison; it is nevertheless an interpretation. Global or sample-wise normalization can preserve some gene-specific contrasts that per-gene cohort centering removes. The consequence is overprecision about what was explicitly reported, not a failure of the overall comparability criticism.

Smallest correction: introduce the equation with “If, as the wording and Figure S6C suggest, each gene was centered and scaled across samples separately within each cohort, the transformation is:” and end that paragraph with “Under this interpretation, the limitation follows algebraically without the external expression matrix.” The existing request for the exact reference distribution at line 72 already provides the appropriate follow-up. No new experiment, external matrix, regression test or analysis is required to make this wording change.

## Source fidelity, reproducibility and visual inspection

All nine input SHA256 values match the frozen request. Every evidence ZIP member matches the supplied extraction, all 12 manifest entries match their hashes and byte sizes, and the regenerated metadata and verification-summary JSON are identical to the frozen results. The supplied five-file aggregate digest is retained as the review identifier; its aggregation algorithm was not supplied, so this review does not claim to have recomputed that aggregate independently.

I read the relevant original PeerJ XML paragraphs and supplement caption, the original Nakayama publisher HTML and PubMed record, and the original Davis XML. Davis confirms six patients, with one poor-RNA-quality sample; the outgoing text attributes the later six-profile comparison to the later article and does not falsely assert that the audit confirmed six high-quality external profiles.

One bounded question required an additional original source: whether the supplementary packet itself includes external S6 sample-by-gene data or analysis code. The supplied XML lists the supplements but does not supply their workbook contents. I retrieved the [original Europe PMC supplementary packet](https://www.ebi.ac.uk/europepmc/webservices/rest/PMC13374579/supplementaryFiles), preserved its bytes and HTTP receipt, and inspected its inventory, the sole workbook and both DOCX table texts. The workbook contains one 9501-row, 13-column sheet with gene symbols and 12 internal Si sample columns; the DOCX files contain internal statistical results. The packet has no external sample matrix or analysis script. Its original Figure S6 hash equals the frozen image. This supports the manuscript's explicitly packet-limited absence claim; it says nothing about material held elsewhere.

The frozen four-page PDF was rendered with pdftoppm at 110 dpi, and all four actual page images were inspected. The title, text, inline formula blocks, declarations and references are readable, without clipping, overlap, missing glyphs or apparent omissions. Page numbering and reference hyperlinks are present. A references-only fourth page with whitespace is acceptable. No layout correction is required for this preprint; journal-specific formatting was not part of the evidence supplied.

## Executed validation and retained records

Every recorded validation subprocess completed with exit code 0. `validation-executions.jsonl` preserves exact argument arrays, working directory, actual UTC start/end times, elapsed seconds, exit codes and separate stdout/stderr files. The recorded runs cover input hashes/ZIP extraction/source parsing; portable verifier reproduction; PDF rendering and metadata; independent full-roster counts/publisher and PDF extraction/synthetic algebra; original packet retrieval and contents; internal method plausibility; and final manifest/result/rank-test/PDF-link checks. The final combined check took 67.13 seconds and completed normally.

Two nonfatal preliminary tool errors are retained in `initial-tool-errors.json`: pdftotext was absent, so pypdf was used; the web tool could not open the ZIP endpoint, while a direct ordinary HTTP retrieval succeeded. The responses did not provide exact UTC times for those two calls, and none have been invented. No interruption is concealed as completion.

## Limits

The authors' external expression matrices, full normalization code and sample selection are not recovered. No original GEO fold change, external P-value or prognostic model was independently reproduced. Deposited annotations are not an audit of unique patients or pathology. A corrected accession or author clarification could resolve the lineage discrepancy. The gene-wise z-score axis remains an inference, strongest for the internal cohort; E1 addresses this directly. This single batch is a focused scientific review, not an exhaustive literature audit or a guarantee of journal acceptance.

The complete machine-readable record, checked-evidence list, validation commands and limitations are in `review.json`. Nothing remains running for this review.
'''

(ROOT/'review.json').write_text(json.dumps(review,indent=2,ensure_ascii=False)+'\n','utf-8')
(ROOT/'review.md').write_text(md,'utf-8')
status={k:review[k] for k in ('paper','reviewed_commit','deliverable_digest','document_sha256','blind','model','reasoning_effort','started_at','ended_at','status','verdict','really_running')}
status['submission_merit']=review['submission_merit']['decision']
status['input_scope']=review['input_scope']
status['blockers']=[];status['p1s']=[];status['editorial_count']=len(editorial)
(ROOT/'review-status.json').write_text(json.dumps(status,indent=2)+'\n','utf-8')
print(json.dumps({'status':'complete','ended_at':ended,'decision':review['submission_merit']['decision'],'verdict':review['verdict'],'blockers':0,'p1s':0,'editorial':len(editorial),'outputs':[str(ROOT/'review.md'),str(ROOT/'review.json'),str(ROOT/'review-status.json')]},indent=2))
