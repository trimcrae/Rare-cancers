# Source attribution

The article XML and original Figure S6 are reproduced without alteration from:

Amphun Chaiboonchoe; Jantappapa Chanthercrob; Romgase Sakamula; Thanaphon Likhityungyuen; Sorranart Muangsomboon; Jomjit Chantharasamee; Francis Lee; Krittawat Suwanpukdee; Pannin Thanapipatsiri; Rapin Phimolsarnti; Apichat Asavamongkolkul; Somponnat Sampattavanich; Chandhanarat Chandhanayingyong. **Prognostic biomarkers for enhanced risk stratification in extraskeletal myxoid chondrosarcoma: a retrospective cohort study.** *PeerJ* 14:e21497 (2026). DOI: [10.7717/peerj.21497](https://doi.org/10.7717/peerj.21497).

Copyright © 2026 Chaiboonchoe et al. The article's embedded permissions specify [Creative Commons Attribution 4.0](https://creativecommons.org/licenses/by/4.0/). The original XML retains that statement. The Figure S6 image is the original supplemental member `peerj-14-21497-s008.png`, copied without alteration from the public supplementary archive. No figure was regenerated or annotated.

The two GEO SOFT files are unchanged copies of the public NCBI GEO deposits [GSE6481](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE6481) and [GSE24369](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE24369), including their original platform/sample metadata and tables. Their original contributors and citations remain in the archives. This attribution does not assign a new license to the deposited source material.

GSE6481's linked publication is Nakayama et al., *Modern Pathology* 20:749–759 (2007), [DOI 10.1038/modpathol.3800794](https://doi.org/10.1038/modpathol.3800794), PMID 17464315. The publisher's HTML is not part of this bundle.
