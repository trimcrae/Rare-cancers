from pathlib import Path
import xml.etree.ElementTree as ET
import hashlib, json, zipfile, gzip, re, collections

ROOT = Path(__file__).resolve().parent
INPUT = ROOT.parent/'input'

def xml_paragraphs(path):
    root = ET.parse(path).getroot()
    rows = []
    for n, element in enumerate(root.iter()):
        if element.tag in ('p', 'title', 'article-title', 'AbstractText', 'supplementary-material'):
            text = ''.join(element.itertext())
            rows.append({'index':n, 'tag':element.tag, 'id':element.get('id'), 'text':text})
    return rows

req = json.loads((INPUT/'review-input.json').read_text('utf-8'))
hashes = []
for item in req['inputs']:
    observed = hashlib.sha256((INPUT/item['path']).read_bytes()).hexdigest()
    hashes.append(dict(path=item['path'], expected=item['sha256'], observed=observed, passed=observed==item['sha256']))
assert all(x['passed'] for x in hashes)
(ROOT/'input-hash-check.json').write_text(json.dumps(hashes, indent=2), 'utf-8')

with zipfile.ZipFile(INPUT/'emc-external-validation-comment-evidence.zip') as z:
    members = z.namelist()
    assert all(not x.startswith('/') and '..' not in Path(x).parts for x in members)
    z.extractall(ROOT/'evidence-copy')
    matching = [{'member':name, 'sha256':hashlib.sha256(z.read(name)).hexdigest(), 'matches_supplied_extraction':(INPUT/'evidence'/name).read_bytes()==z.read(name)} for name in members if not name.endswith('/')]
    assert all(x['matches_supplied_extraction'] for x in matching)
(ROOT/'zip-check.json').write_text(json.dumps(matching, indent=2), 'utf-8')

for filename in ['evidence/sources/peerj-21497-article.xml', 'davis-2017-article.xml', 'pubmed-17464315.xml']:
    rows = xml_paragraphs(INPUT/filename)
    target = ROOT/(Path(filename).stem+'-paragraphs.json')
    target.write_text(json.dumps(rows, indent=2, ensure_ascii=False), 'utf-8')
    selected = [x for x in rows if re.search('GSE6481|GSE24369|z.score|comparab|MI-ONCOSEQ|optimism|105|six patients', x['text'], re.I)]
    print('\nSOURCE', filename)
    for row in selected:
        print(f"[{row['index']} {row['tag']} {row['id']}] {row['text']}\n")
print('All nine frozen input hashes matched, and all ZIP members match the supplied extraction.')
