from pathlib import Path
import zipfile,io,xml.etree.ElementTree as ET,json,statistics

ROOT=Path(__file__).resolve().parent
with zipfile.ZipFile(ROOT/'original-supplementary-packet.zip') as packet:
    for name in packet.namelist():
        if name.endswith('.docx'):
            with zipfile.ZipFile(io.BytesIO(packet.read(name))) as doc:
                tree=ET.fromstring(doc.read('word/document.xml'))
                ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
                paragraphs=[''.join(p.itertext()) for p in tree.findall('.//w:p',ns)]
                text='\n'.join(paragraphs)
                (ROOT/(Path(name).stem+'-text.txt')).write_text(text,'utf-8')
                print(name,'\n'+text+'\n')
rows=(ROOT/'peerj-14-21497-s009-sheet1-cells.txt').read_text('utf-8').splitlines()
results=[]
for gene in ('PXN','H1FX','TYMS'):
    matches=[row.split('\t') for row in rows if row.startswith(gene+'\t')]
    assert len(matches)==1
    values=list(map(float,matches[0][1:]))
    mean=statistics.mean(values)
    row={'gene':gene,'source':'peerj-14-21497-s009.xlsx / EMC_Gene-expression_Log2CPM','n':len(values),'purpose':'Check plausibility of gene-wise standardization against original Figure S6C; no new biological inference.','mean':mean}
    for convention in ('population','sample'):
        sd=statistics.pstdev(values) if convention=='population' else statistics.stdev(values)
        standardized=sorted((x-mean)/sd for x in values)
        row[convention+'_sd']={'sd':sd,'sorted_z_scores':standardized}
    results.append(row)
print(json.dumps(results,indent=2))
(ROOT/'internal-gene-transform-check.json').write_text(json.dumps(results,indent=2),'utf-8')
