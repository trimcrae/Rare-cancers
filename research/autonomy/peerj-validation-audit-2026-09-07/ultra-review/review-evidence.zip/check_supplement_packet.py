from pathlib import Path
from urllib.request import urlopen,Request
import json, hashlib, zipfile, xml.etree.ElementTree as ET
from datetime import datetime,timezone

ROOT=Path(__file__).resolve().parent
url='https://www.ebi.ac.uk/europepmc/webservices/rest/PMC13374579/supplementaryFiles'
start=datetime.now(timezone.utc).isoformat()
request=Request(url,headers={'User-Agent':'EMC scientific comment independent source verification'})
with urlopen(request,timeout=35) as response:
    data=response.read()
    receipt={'named_question':'Does the original supplementary packet include external S6 sample-by-gene data or an analysis script? The supplied XML lists supplement names but lacks workbook contents.','url':url,'final_url':response.url,'status':response.status,'headers':dict(response.headers),'started_at':start,'ended_at':datetime.now(timezone.utc).isoformat(),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
packet=ROOT/'original-supplementary-packet.zip';packet.write_bytes(data)
(ROOT/'supplement-retrieval.json').write_text(json.dumps(receipt,indent=2),'utf-8')
print(json.dumps(receipt,indent=2))
inventory=[]
with zipfile.ZipFile(packet) as source:
    for item in source.infolist():
        row={'name':item.filename,'bytes':item.file_size,'sha256':hashlib.sha256(source.read(item)).hexdigest()}
        inventory.append(row)
        print(json.dumps(row))
    workbooks=[x for x in source.namelist() if x.endswith('.xlsx')]
    for name in workbooks:
        blob=source.read(name)
        file=ROOT/Path(name).name;file.write_bytes(blob)
        with zipfile.ZipFile(file) as book:
            ns={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
            shared=[]
            if 'xl/sharedStrings.xml' in book.namelist():
                shared=[''.join(x.itertext()) for x in ET.fromstring(book.read('xl/sharedStrings.xml')).findall('m:si',ns)]
            workbook=ET.fromstring(book.read('xl/workbook.xml'))
            print('WORKBOOK',name)
            for sheet in workbook.findall('m:sheets/m:sheet',ns):print('SHEET NAME',sheet.attrib)
            for member in book.namelist():
                if not (member.startswith('xl/worksheets/sheet') and member.endswith('.xml')):continue
                tree=ET.fromstring(book.read(member))
                dim=tree.find('m:dimension',ns)
                print('MEMBER',member,'dimension',dim.attrib if dim is not None else None)
                rows=[]
                for row in tree.findall('m:sheetData/m:row',ns):
                    values=[]
                    for c in row.findall('m:c',ns):
                        v=c.find('m:v',ns)
                        value=v.text if v is not None else ''.join(c.itertext())
                        if c.get('t')=='s':value=shared[int(value)]
                        values.append((c.get('r'),value))
                    rows.append(values)
                print('FIRST FIVE ROWS',json.dumps(rows[:5],ensure_ascii=False))
                text='\n'.join('\t'.join(str(v) for _,v in row) for row in rows)
                (ROOT/(Path(name).stem+'-'+Path(member).stem+'-cells.txt')).write_text(text,'utf-8')
(ROOT/'supplement-packet-inventory.json').write_text(json.dumps(inventory,indent=2),'utf-8')
