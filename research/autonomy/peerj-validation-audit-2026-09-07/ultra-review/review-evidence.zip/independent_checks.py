from pathlib import Path
import gzip, re, json, collections, statistics, math, hashlib
from html.parser import HTMLParser
import sys
sys.path.insert(0, 'C:/Projects/EMC-Research/.cache/python-deps')
from pypdf import PdfReader

ROOT=Path(__file__).resolve().parent
INPUT=ROOT.parent/'input'
results={}
for accession in ('GSE6481','GSE24369'):
    records=[]; roster=[]; sample=None; raw=[]
    with gzip.open(INPUT/'evidence'/'sources'/(accession+'_family.soft.gz'),'rt',encoding='utf-8') as stream:
        for number,line in enumerate(stream,1):
            if line.startswith('^SAMPLE = '):
                sample={'accession':line.strip().split(' = ',1)[1],'source_line':number,'fields':{}}
                records.append(sample)
            elif line.startswith('^'):
                sample=None
            if line.startswith('!Series_sample_id = '):
                roster.append(line.strip().split(' = ',1)[1])
            if sample and line.startswith(('!Sample_title = ','!Sample_geo_accession = ','!Sample_characteristics_ch1 = ','!Sample_source_name_ch1 = ','!Sample_description = ','!Sample_platform_id = ')):
                key,value=line.rstrip('\r\n').split(' = ',1)
                sample['fields'].setdefault(key,[]).append(value)
                raw.append(f'{number}: {line.strip()}')
    ids=[s['accession'] for s in records]
    assert len(ids)==len(set(ids))==len(roster)==len(set(roster))
    assert set(ids)==set(roster)
    histologies=collections.Counter()
    for record in records:
        diagnostic=[s for s in record['fields']['!Sample_characteristics_ch1'] if s.lower().startswith(('histology:','tissue:'))]
        assert len(diagnostic)==1
        histologies[diagnostic[0].split(':',1)[1].strip()]+=1
    result={'accession':accession,'count':len(records),'histologies':dict(histologies),'series_roster_matches':True,'sample_records':records,'expression_values_evaluated':False}
    results[accession]=result
    (ROOT/(accession+'-independent-raw-metadata.txt')).write_text('\n'.join(raw)+'\n','utf-8')
    (ROOT/(accession+'-independent-check.json')).write_text(json.dumps(result,indent=2),'utf-8')
    print(json.dumps({k:v for k,v in result.items() if k!='sample_records'},indent=2))
    frozen=json.loads((INPUT/'evidence'/'results'/(accession+'-metadata.json')).read_text('utf-8'))
    assert dict(histologies)==frozen['diagnosis_counts']
    assert len(records)==frozen['sample_count']

class Extract(HTMLParser):
    def __init__(self):
        super().__init__(); self.parts=[]; self.ignore=0
    def handle_starttag(self,tag,attrs):
        if tag in ('script','style'): self.ignore+=1
        if tag in ('p','h1','h2','h3','td','th','li'): self.parts.append('\n')
    def handle_endtag(self,tag):
        if tag in ('script','style'): self.ignore-=1
        if tag in ('p','h1','h2','h3','tr','li'): self.parts.append('\n')
    def handle_data(self,data):
        if not self.ignore: self.parts.append(data)
parser=Extract(); parser.feed((INPUT/'publisher-3800794.html').read_text('utf-8'))
publisher=''.join(parser.parts)
(ROOT/'publisher-3800794-text.txt').write_text(publisher,'utf-8')
print('\nPUBLISHER passages containing 105 / myxoid liposarcoma:')
for line in publisher.splitlines():
    if re.search(r'105|myxoid liposarcoma|10 types',line,re.I):print(line)

reader=PdfReader(INPUT/'emc-external-validation-comment-preprint.pdf')
texts=[page.extract_text() for page in reader.pages]
(ROOT/'pdf-text.txt').write_text('\n\n'.join(f'PAGE {i+1}\n{text}' for i,text in enumerate(texts)),'utf-8')
print('PDF text extracted:',len(texts),'pages; text length',sum(len(t) for t in texts))

# Explicitly synthetic reviewer examples, not expression data or biological measurements.
x=[-5,-3,-2,-1,0,0.5,1,2,3,5,8,12]
y=[-2,-1,0,1,3,10]
def z(v,sample):
    sigma=statistics.stdev(v) if sample else statistics.pstdev(v)
    return [(a-statistics.mean(v))/sigma for a in v]
algebra=[]
for v in (x,y):
    for sample in (True,False):
        for a,b in ((7,1000),(0.125,-73)):
            original=z(v,sample);transformed=z([a*t+b for t in v],sample)
            difference=max(abs(c-d) for c,d in zip(original,transformed))
            assert difference<1e-12
            algebra.append({'n':len(v),'sample_sd':sample,'a':a,'b':b,'max_absolute_error':difference})
data={'scope':'Reviewer-created synthetic arithmetic examples only; no biological data or expression measurements.','positive_affine_invariance_checks':algebra}
(ROOT/'synthetic-algebra-check.json').write_text(json.dumps(data,indent=2),'utf-8')
print('Synthetic affine-invariance checks:',len(algebra),'passed.')
