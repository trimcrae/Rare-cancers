from pathlib import Path
import zipfile,json,hashlib,datetime
O=Path(__file__).parent; I=O.parent/'input'
h=lambda b:hashlib.sha256(b).hexdigest()
r=json.loads((I/'review-input.json').read_text()); checks=[]
for p in sorted(I.rglob('*')):
 if p.is_file(): checks.append({'path':str(p.relative_to(I)),'sha256':h(p.read_bytes()),'bytes':p.stat().st_size})
for x in r['inputs']:
 assert h((I/x['path']).read_bytes())==x['sha256'],x
(O/'input-hashes.json').write_text(json.dumps(checks,indent=2))
for name,p in [('full',I/'deliverables/emc-external-validation-comment-evidence.zip'),('verification',I/'deliverables/emc-external-validation-comment-verification.zip'),('rights',I/'evidence/rights-packaging/evidence.zip'),('latex',I/'evidence/latex-packaging/render-evidence.zip')]:
 z=zipfile.ZipFile(p); dest=O/name; dest.mkdir(exist_ok=True)
 inv=[]
 for n in z.namelist():
  target=(dest/n).resolve(); assert target.is_relative_to(dest.resolve())
  if n.endswith('/'):continue
  target.parent.mkdir(parents=True,exist_ok=True); b=z.read(n);target.write_bytes(b);inv.append({'name':n,'sha256':h(b),'bytes':len(b)})
 (O/(name+'-inventory.json')).write_text(json.dumps(inv,indent=2));print(name,json.dumps([x['name'] for x in inv]))
