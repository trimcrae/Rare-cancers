from pathlib import Path
import json,hashlib,zipfile,difflib,subprocess,sys,datetime,ast,re,unicodedata
from pypdf import PdfReader
O=Path(__file__).parent;I=O.parent/'input';V=O/'verification';F=O/'full';R=O/'rights';L=O/'latex'
h=lambda b:hashlib.sha256(b).hexdigest()
def write(n,x):(O/n).write_text(json.dumps(x,indent=2),encoding='utf-8')
def run(label,args):
 t=datetime.datetime.now(datetime.timezone.utc);p=subprocess.run(args,capture_output=True,text=True,encoding='utf-8');(O/(label+'.stdout.txt')).write_text(p.stdout);(O/(label+'.stderr.txt')).write_text(p.stderr);logs.append({'label':label,'command':args,'started':t.isoformat(),'ended':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':p.returncode});assert p.returncode==0,(label,p.stderr)
logs=[]
a=zipfile.ZipFile(I/'deliverables/emc-external-validation-comment-verification.zip');b=zipfile.ZipFile(R/'emc-verification-supplement.zip');assert set(a.namelist())==set(b.namelist())
zc=[]
for n in a.namelist():
 x,y=a.getinfo(n),b.getinfo(n); fields=['date_time','compress_type','compress_size','file_size','CRC','external_attr','create_system','extra','comment','flag_bits']; assert a.read(n)==b.read(n);assert all(getattr(x,k)==getattr(y,k) for k in fields);zc.append({'member':n,'sha256':h(a.read(n)),'bytes':x.file_size,'metadata_equal':True})
write('zip-equivalence.json',{'exact_all_11_members':zc,'private_sha256':h((R/'emc-verification-supplement.zip').read_bytes()),'registered_sha256':h((I/'deliverables/emc-external-validation-comment-verification.zip').read_bytes()),'registered_order':a.namelist(),'private_order':b.namelist()})
manifest=json.loads((V/'manifest.json').read_text());assert set(x['path'] for x in manifest['files'])==set(a.namelist())-{'manifest.json'}
for x in manifest['files']: assert h((V/x['path']).read_bytes())==x['sha256'] and (V/x['path']).stat().st_size==x['bytes']
for x in json.loads((V/'retrieval-sources.json').read_text())['sources']:assert h((F/'sources'/x['file']).read_bytes())==x['sha256'] and (F/'sources'/x['file']).stat().st_size==x['bytes']
run('plan',[sys.executable,'-X','utf8','-B',str(V/'retrieve_sources.py'),'--plan','--sources',str(F/'sources')])
run('offline-source-reuse',[sys.executable,'-X','utf8','-B',str(V/'retrieve_sources.py'),'--sources',str(F/'sources')])
run('offline-verification',[sys.executable,'-X','utf8','-B',str(V/'verify_metadata.py'),'--sources',str(F/'sources'),'--output','review-reproduced'])
comparisons={}
for acc in ['GSE6481','GSE24369']:
 old=json.loads((F/'results'/f'{acc}-metadata.json').read_text());new=json.loads((V/'results'/f'{acc}-metadata.json').read_text());rep=json.loads((V/'review-reproduced'/f'{acc}-metadata.json').read_text());assert new==rep
 for k in new:
  if k=='complete_sample_roster': assert new[k]==[{q:r[q] for q in ['gsm','diagnosis','platform','source_line']} for r in old[k]]
  elif k=='platform_accessions':assert new[k]==sorted(old['platform_counts'])
  else:assert new[k]==old[k],k
 comparisons[acc]={'exact_reproduced_output':True,'all_old_factual_fields_equal':True,'samples':new['sample_count'],'diagnoses':new['diagnosis_counts']}
write('metadata-equivalence.json',comparisons)
old=(F/'verify_metadata.py').read_text();new=(V/'verify_metadata.py').read_text();(O/'verifier-adaptation.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='full',tofile='first-party')))
old=(R/'retrieve_sources-live-tested.py').read_text();new=(V/'retrieve_sources.py').read_text();(O/'downloader-post-live.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='live-tested',tofile='final')))
raw=next((R/'live-original-sources-v2/transport').glob('*.zip')).read_bytes();spec=next(x for x in json.loads((V/'retrieval-sources.json').read_text())['sources'] if 'archive_member' in x)
import io,importlib.util
z=zipfile.ZipFile(io.BytesIO(raw));assert z.namelist().count(spec['archive_member'])==1;assert h(z.read(spec['archive_member']))==spec['sha256'];assert len(raw)<=spec['container_download_max_bytes']==16777216
s=importlib.util.spec_from_file_location('retrieval',V/'retrieve_sources.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
p=O/'transport-helper-check.zip';m.preserve_transport(p,raw);m.preserve_transport(p,raw)
try:m.preserve_transport(p,b'changed non-scientific test bytes');raise AssertionError('No rejection')
except ValueError:pass
assert p.read_bytes()==raw
write('transport-check.json',{'actual_container_sha256':h(raw),'actual_bytes':len(raw),'member':spec['archive_member'],'member_sha256':h(z.read(spec['archive_member'])),'reference_container_is_historical':h(raw)!=spec['container_reference_sha256'],'bounded_bytes':spec['container_download_max_bytes'],'helper_create_reuse_and_mismatch_rejection_passed':True,'final_code_live_end_to_end_tested_by_this_reviewer':False,'network_requests':0})
md=(I/'deliverables/emc-external-validation-comment.md').read_text();tex=(I/'deliverables/emc-external-validation-comment.tex').read_text();assert tex==(L/'emc-external-validation-comment.tex').read_text();assert md==(L/'venue-source.md').read_text(encoding='utf-8-sig')
body=re.sub(r'\A---\n.*?\n---\n','',md,flags=re.S);body=re.sub(r'\[([^\]]+)\]\(([^)]+)\)',r'\1',body);body=re.sub(r'^#+ ','',body,flags=re.M).replace('**','');body=re.sub(r'\*([^*`]+)\*',r'\1',body)
norm=lambda x:re.sub(r'\s+|-','',unicodedata.normalize('NFKC',x))
pdfs={}
for label,path in [('registered',I/'deliverables/emc-external-validation-comment-preprint.pdf'),('tectonic',L/'emc-external-validation-comment.pdf')]:
 reader=PdfReader(path);text='\n'.join(re.sub(r'\n\d+\s*$','',p.extract_text()) for p in reader.pages);(O/(label+'-text.txt')).write_text(text,encoding='utf-8');actual=norm(text);cursor=0;checks=[]
 for n,part in enumerate(re.split(r'`[^`]+`',body)):
  target=norm(part)
  if not target:continue
  pos=actual.find(target,cursor);checks.append({'segment':n,'found':pos>=0,'chars':len(target)})
  if pos>=0:cursor=pos+len(target)
 links=sorted(set(str(x.get_object().get('/A',{}).get('/URI')) for p in reader.pages for x in p.get('/Annots',[]) if x.get_object().get('/A',{}).get('/URI')))
 pdfs[label]={'sha256':h(path.read_bytes()),'pages':len(reader.pages),'prose_segments':checks,'hyperlinks':links,'all_prose_matches':all(x['found'] for x in checks)}
 run('render-'+label,[str(Path('C:/Users/mcrae/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/poppler/Library/bin/pdftoppm.exe')),'-png','-r','85',str(path),str(O/(label+'-page'))])
write('pdf-content-check.json',pdfs);write('executions.json',logs);print(json.dumps({'zip_members_equal':True,'metadata':comparisons,'pdf':pdfs},indent=2))

