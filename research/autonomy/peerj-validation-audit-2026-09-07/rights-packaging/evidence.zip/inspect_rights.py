from pathlib import Path
from datetime import datetime, timezone
from html.parser import HTMLParser
import hashlib
import json
import time
import urllib.request
import urllib.error
import xml.etree.ElementTree as ET
import zipfile

HERE = Path(__file__).resolve().parent
(HERE/'sources').mkdir(exist_ok=True)
ZIP = Path('C:/Users/mcrae/.codex/worktrees/next-emc-paper-20260907/EMC-Research/research/manuscripts/external-validation/emc-external-validation-comment-evidence.zip')
expected = '6710a68ef38a9aa255e06a27d66d07fae72574ea892d6793fe02f317cb420f4e'
original = ZIP.read_bytes()
assert hashlib.sha256(original).hexdigest() == expected
with zipfile.ZipFile(ZIP) as archive:
    members = [{'name':m.filename,'bytes':m.file_size,'sha256':hashlib.sha256(archive.read(m)).hexdigest()} for m in archive.infolist()]
    for name in ('ATTRIBUTION.md','source-manifest.json'):
        (HERE/('bundled-'+name)).write_bytes(archive.read(name))
    xmlbytes = archive.read('sources/peerj-21497-article.xml')
    xml = ET.fromstring(xmlbytes)
    permissions = xml.find('./front/article-meta/permissions')
    (HERE/'bundled-peerj-permissions.xml').write_bytes(ET.tostring(permissions,encoding='utf-8'))
    result_scopes = {}
    for name in ('results/GSE24369-metadata.json','results/GSE6481-metadata.json'):
        result = json.loads(archive.read(name))
        result_scopes[name] = {'keys':list(result),'series_metadata_fields':list(result['series']['fields']),
                              'series_overall_design':result['series']['fields'].get('Series_overall_design'),
                              'example_roster_fields':list(result['complete_sample_roster'][0])}
receipt = {'inspected_utc':datetime.now(timezone.utc).isoformat(),'zip_path':str(ZIP),'zip_bytes':len(original),
           'zip_sha256':expected,'members':members,'extracted_members':['ATTRIBUTION.md','source-manifest.json'],
           'peerj_license_permission_text':' '.join(permissions.itertext()),
           'derived_result_source_text_scope':result_scopes,'zip_unchanged':ZIP.read_bytes()==original}
(HERE/'frozen-bundle-inspection.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')

class VisibleText(HTMLParser):
    def __init__(self):
        super().__init__(); self.ignore=0; self.text=[]
    def handle_starttag(self,tag,attrs):
        if tag in ('script','style'): self.ignore+=1
        if tag in ('p','div','h1','h2','h3','li'): self.text.append('\n')
    def handle_endtag(self,tag):
        if tag in ('script','style'): self.ignore=max(0,self.ignore-1)
    def handle_data(self,data):
        if not self.ignore:self.text.append(data)

urls = [
    ('qeios-publishing-policy.html','https://www.qeios.com/publishing-policy'),
    ('cc-by-4-legalcode.html','https://creativecommons.org/licenses/by/4.0/legalcode.en'),
    ('cc0-legalcode.html','https://creativecommons.org/publicdomain/zero/1.0/legalcode.en'),
]
receipts=[]
for filename,url in urls:
    started=time.perf_counter()
    item={'url':url,'started_utc':datetime.now(timezone.utc).isoformat()}
    try:
        with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0 source-rights-verification'}),timeout=25) as response:
            blob=response.read(4*1024*1024+1)
            assert len(blob)<=4*1024*1024,'Source exceeds bounded metadata size'
            item.update(status=response.status,final_url=response.url,headers=dict(response.headers),bytes=len(blob),sha256=hashlib.sha256(blob).hexdigest(),file='sources/'+filename)
            (HERE/'sources'/filename).write_bytes(blob)
            parser=VisibleText();parser.feed(blob.decode('utf-8',errors='replace'))
            text='\n'.join(' '.join(line.split()) for line in ''.join(parser.text).splitlines() if line.strip())
            (HERE/'sources'/(filename+'.txt')).write_text(text+'\n',encoding='utf-8')
    except Exception as e:
        item.update(error_type=type(e).__name__,error=str(e))
    item.update(finished_utc=datetime.now(timezone.utc).isoformat(),elapsed_seconds=time.perf_counter()-started)
    receipts.append(item)
(HERE/'retrievals.json').write_text(json.dumps(receipts,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'bundle_sha256':expected,'bundle_files':len(members),'retrievals':[{k:v for k,v in r.items() if k!='headers'} for r in receipts],'source_narrative_present_in_derived_rosters':result_scopes},indent=2))
