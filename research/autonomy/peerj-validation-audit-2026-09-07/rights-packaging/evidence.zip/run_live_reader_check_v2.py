from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess
import sys
import time

HERE=Path(__file__).resolve().parent
ROOT=HERE/'verification-supplement'
SOURCES=HERE/'live-original-sources-v2'
require_new = not SOURCES.exists() and not (ROOT/'live-results-v2').exists()
assert require_new, 'Both live source and result directories must be new'
script=ROOT/'retrieve_sources.py'
script_hash=hashlib.sha256(script.read_bytes()).hexdigest()
prior=HERE/'verification-supplement-prior-015847/emc-verification-supplement.zip'
assert hashlib.sha256(prior.read_bytes()).hexdigest()=='0141b4b7673f43b11384aca28c69c35451cae7d81f5f519957d80a05abbadfdc'
commands=[('retrieval',['retrieve_sources.py','--sources','../live-original-sources-v2']),
          ('verification',['verify_metadata.py','--sources','../live-original-sources-v2','--output','live-results-v2'])]
records=[]
for label,args in commands:
    command=[sys.executable,'-X','utf8','-B',*args]
    record={'phase':label,'command':'python -X utf8 -B '+' '.join(args),'started_utc':datetime.now(timezone.utc).isoformat()}
    started=time.perf_counter()
    with (HERE/('live-v2-'+label+'.stdout.txt')).open('wb') as stdout, (HERE/('live-v2-'+label+'.stderr.txt')).open('wb') as stderr:
        completed=subprocess.run(command,cwd=ROOT,stdout=stdout,stderr=stderr)
    record.update(exit_code=completed.returncode,finished_utc=datetime.now(timezone.utc).isoformat(),elapsed_seconds=time.perf_counter()-started,
                  stdout_file='live-v2-'+label+'.stdout.txt',stderr_file='live-v2-'+label+'.stderr.txt')
    records.append(record)
    result={'fresh_source_directory_verified_before_run':True,'retrieval_script_sha256':script_hash,'commands':records,'retry_attempts':0,
            'prior_zip_preserved':True,'status':'passed' if len(records)==2 and completed.returncode==0 else 'retrieval_passed_verification_not_run' if completed.returncode==0 else 'failed'}
    (HERE/'live-reader-v2-execution.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(record),flush=True)
    if completed.returncode:
        break
