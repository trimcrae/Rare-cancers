from pathlib import Path
import hashlib
import json
import shutil
import zipfile

HERE=Path(__file__).resolve().parent
OUT=HERE/'verification-supplement'
assert not OUT.exists()
OUT.mkdir()
LOCAL=HERE/'local-original-sources'
LOCAL.mkdir(exist_ok=True)
FULL=Path('C:/Users/mcrae/.codex/worktrees/next-emc-paper-20260907/EMC-Research/research/manuscripts/external-validation/emc-external-validation-comment-evidence.zip')
frozen_sha='6710a68ef38a9aa255e06a27d66d07fae72574ea892d6793fe02f317cb420f4e'
assert hashlib.sha256(FULL.read_bytes()).hexdigest()==frozen_sha
with zipfile.ZipFile(FULL) as z:
    original_verifier=z.read('verify_metadata.py')
    text=original_verifier.decode('utf-8')
    manifest=json.loads(z.read('source-manifest.json'))
    sources=[]
    for row in manifest['sources']:
        blob=z.read(row['file'])
        assert hashlib.sha256(blob).hexdigest()==row['sha256']
        name=Path(row['file']).name
        local=LOCAL/name
        if local.exists(): assert local.read_bytes()==blob
        else: local.write_bytes(blob)
        item={'file':name,'bytes':len(blob),'sha256':row['sha256'],'url':row['retrieval']['url'],'landing_url':row['landing_url'],
              'rights':'CC BY 4.0; original third-party rights unchanged' if row['name'].startswith('PeerJ') else 'NCBI/GEO reuse and distribution guidance; possible submitter rights reserved; no CC0 grant asserted',
              'terms_url':'https://creativecommons.org/licenses/by/4.0/' if row['name'].startswith('PeerJ') else 'https://www.ncbi.nlm.nih.gov/home/about/policies/'}
        if row['name']=='PeerJ Figure S6':
            item.update(container_bytes=row['retrieval']['bytes'],container_sha256=row['retrieval']['sha256'],archive_member=row['retrieval']['archive_member'])
        sources.append(item)
    for acc in ('GSE6481','GSE24369'):
        (HERE/(acc+'-reviewed-full-metadata.json')).write_bytes(z.read('results/'+acc+'-metadata.json'))

def change(old,new):
    global text
    assert text.count(old)==1,(old,text.count(old))
    text=text.replace(old,new)

text=text.replace("'sources/", "'")
change('def verify_geo(accession):','def verify_geo(accession, source_dir):')
change("path = ROOT/'sources'/(accession+'_family.soft.gz')","path = source_dir/(accession+'_family.soft.gz')")
change("'series':series[0],'platforms':platforms,'complete_sample_roster':rows,","'platform_accessions':sorted(platform_counts),'complete_sample_roster':[{k:r[k] for k in ('gsm','diagnosis','platform','source_line')} for r in rows],")
change("parser.add_argument('--output', default='results', help='Output directory relative to this bundle')","parser.add_argument('--output', default='results', help='Output directory relative to this supplement')\n    parser.add_argument('--sources', default='../local-original-sources', help='Separate original-source directory, relative to this supplement or absolute')")
change("args = parser.parse_args()\n    rel", "args = parser.parse_args()\n    source_dir = (ROOT/args.sources).resolve()\n    require(not source_dir.is_relative_to(ROOT), 'Original sources must stay outside this supplement directory')\n    rel")
change("(ROOT/'source-manifest.json')","(ROOT/'retrieval-sources.json')")
change("blob = (ROOT/relative).read_bytes()","blob = (source_dir/relative).read_bytes()")
change("{acc:verify_geo(acc) for acc in EXPECTED_COUNTS}","{acc:verify_geo(acc, source_dir) for acc in EXPECTED_COUNTS}")
change("'command':'python -X utf8 -B verify_metadata.py --output '+args.output,","'command':'python -X utf8 -B verify_metadata.py --sources '+args.sources+' --output '+args.output,")
change("'scope':'Source integrity, deposited metadata and complete sample rosters.'","'scope':'Factual sample identifiers, diagnoses, platforms and audit counts; original source narrative excluded.'")
(OUT/'verify_metadata.py').write_text(text,encoding='utf-8',newline='\n')
(OUT/'retrieval-sources.json').write_text(json.dumps({'schema_version':1,'source_rights_notice':'These are externally retrieved originals, excluded from this supplement. No rights in them are waived or relicensed.','sources':sources},indent=2)+'\n',encoding='utf-8')
(HERE/'supplement-preparation.json').write_text(json.dumps({'frozen_full_zip_sha256':frozen_sha,'original_verifier_sha256':hashlib.sha256(original_verifier).hexdigest(),'adapted_verifier_sha256':hashlib.sha256(text.encode()).hexdigest(),'offline_sources':'Original four files copied byte-for-byte from the frozen ZIP into a separate local directory; no live source download.', 'retained_scientific_checks':'All hash, sample roster, independent label, title-number, platform and diagnosis-count checks retained; only file location and emitted factual schema adapted.'},indent=2)+'\n',encoding='utf-8')
print('Prepared source-free verification supplement and separate retained-source replay directory.')
