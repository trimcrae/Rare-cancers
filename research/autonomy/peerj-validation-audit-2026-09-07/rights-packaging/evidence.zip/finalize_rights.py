from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

HERE=Path(__file__).resolve().parent
inspection=json.loads((HERE/'frozen-bundle-inspection.json').read_text())
members={x['name']:x for x in inspection['members']}
groups={
    'GEO_original': {'members':['sources/GSE6481_family.soft.gz','sources/GSE24369_family.soft.gz'],
                    'status':'NCBI/GEO use and distribution guidance with retained third-party rights; accession-specific CC0 grant not found in inspected metadata',
                    'recommendation':'Retrieve original archives from official source URLs; do not include originals under a blanket CC0 claim'},
    'PeerJ_CC_BY': {'members':['sources/peerj-21497-article.xml','sources/peerj-21497-figure-s6.png'],
                   'status':'Third-party CC BY 4.0 sources, unchanged, with original attribution',
                   'recommendation':'Preserve CC BY terms; official-source retrieval is the minimal Qeios supplement option'},
    'mixed_roster_extracts': {'members':['results/GSE24369-metadata.json','results/GSE6481-metadata.json'],
                   'status':'New audit structure plus source factual metadata and copied Series_overall_design paragraphs',
                   'recommendation':'Do not label the existing files exclusively new authorship; use separate factual outputs without copied narrative, and reconstruct full extracts locally'},
    'new_code': {'members':['verify_metadata.py'],
                   'status':'New standard-library implementation; no third-party code dependency bundled; no license grant made by this assessment',
                   'recommendation':'Rights holder may elect license for rights held; add retrieval instructions or downloader in a new distribution artifact'},
    'new_factual_results': {'members':['results/verification-summary.json','results/execution.json'],
                   'status':'New audit counts/status and execution metadata with factual source labels',
                   'recommendation':'Include as new verification outputs with provenance; any dedication limited to rights actually held'},
    'new_provenance_and_prose': {'members':['source-manifest.json','manifest.json','README.md','ATTRIBUTION.md'],
                   'status':'New organization/explanation and bibliographic/source-rights information; no grant of rights in described sources',
                   'recommendation':'Adapt a separately named wrapper for source retrieval; preserve source credits and separate rights statements'},
}
rows=[]
for group,details in groups.items():
    for name in details['members']:
        rows.append(dict(members[name],category=group,status=details['status'],recommendation=details['recommendation']))
assert len(rows)==len(members)==13 and {r['name'] for r in rows}==set(members)
zip_path=Path(inspection['zip_path'])
assert hashlib.sha256(zip_path.read_bytes()).hexdigest()==inspection['zip_sha256']
result={'completed_utc':datetime.now(timezone.utc).isoformat(),'scope':'Read-only rights and distribution classification; no legal assurance or license grant',
        'frozen_zip_sha256':inspection['zip_sha256'],'frozen_zip_unchanged':True,'per_member_classification':sorted(rows,key=lambda r:r['name']),
        'policy_sources':{'Qeios':'https://www.qeios.com/publishing-policy','NCBI':'https://www.ncbi.nlm.nih.gov/home/about/policies/',
                          'GEO':'https://www.ncbi.nlm.nih.gov/geo/info/disclaimer.html','GEO_citation':'https://www.ncbi.nlm.nih.gov/geo/info/linking.html',
                          'CC_BY_4':'https://creativecommons.org/licenses/by/4.0/legalcode.en','CC0':'https://creativecommons.org/publicdomain/zero/1.0/legalcode.en'},
        'Qeios_scope':'Associated data is CC0; data may include code/methods/software. No explicit third-party CC BY exception located in the reviewed policy.',
        'minimal_option':'Preserve full reviewed ZIP; create separate first-party verification/retrieval supplement with source URLs/hashes, original-rights notices, and new factual outputs; readers retrieve original sources locally.',
        'alternate_option_limit':'Separate mixed-license hosting preserves individual source terms but is not a demonstrated exception to Qeios broad associated-data wording.',
        'source_license_ownership_not_granted':True,'new_artifact_built':False,'frozen_inputs_modified':False,'repository_modified':False,
        'upload_or_external_correspondence':False,'scientific_analysis_or_review_changed':False,
        'ordinary_access_failures':['Direct GEO Disclaimer and FAQ web requests displayed reCAPTCHA; no challenge was retried. Official-URL indexed text was transparently identified by the independent worker.',
                                    'A web find for Copyright on the PeerJ article returned no matching text; classification instead uses the actual bundled original XML permissions.']}
(HERE/'rights-classification.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
entries=[]
for path in sorted(HERE.rglob('*')):
    if path.is_file() and path.name!='manifest.json':
        blob=path.read_bytes();entries.append({'path':path.relative_to(HERE).as_posix(),'bytes':len(blob),'sha256':hashlib.sha256(blob).hexdigest()})
(HERE/'manifest.json').write_text(json.dumps({'created_utc':datetime.now(timezone.utc).isoformat(),'files':entries,'excludes':'manifest.json'},indent=2)+'\n',encoding='utf-8')
print(json.dumps({'all_13_members_classified':True,'frozen_zip_unchanged':True,'private_evidence_files':len(entries),
                  'manifest_sha256':hashlib.sha256((HERE/'manifest.json').read_bytes()).hexdigest()},indent=2))
