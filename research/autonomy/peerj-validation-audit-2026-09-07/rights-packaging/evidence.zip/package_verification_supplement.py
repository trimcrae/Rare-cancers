from pathlib import Path
from datetime import datetime, timezone
import hashlib
import io
import json
import re
import zipfile

HERE=Path(__file__).resolve().parent
ROOT=HERE/'verification-supplement'
OUT=HERE/'emc-verification-supplement.zip'
assert not OUT.exists()
preparation=json.loads((HERE/'supplement-preparation.json').read_text())
inspection=json.loads((HERE/'frozen-bundle-inspection.json').read_text())
assert hashlib.sha256(Path(inspection['zip_path']).read_bytes()).hexdigest()==preparation['frozen_full_zip_sha256']
equivalence={}
for acc in ('GSE6481','GSE24369'):
    before=json.loads((HERE/(acc+'-reviewed-full-metadata.json')).read_text())
    after=json.loads((ROOT/'results'/(acc+'-metadata.json')).read_text())
    fields=('sample_count','diagnosis_counts','platform_counts','sample_type_counts','checks','expression_values_parsed_or_computed')
    for key in fields: assert before[key]==after[key],(acc,key)
    expected=[{k:r[k] for k in ('gsm','diagnosis','platform','source_line')} for r in before['complete_sample_roster']]
    assert expected==after['complete_sample_roster']
    assert 'series' not in after and 'platforms' not in after
    assert all(set(r)=={'gsm','diagnosis','platform','source_line'} for r in after['complete_sample_roster'])
    equivalence[acc]={'sample_count':after['sample_count'],'all_counts_and_checks_identical':True,'all_factual_roster_rows_identical':True,'compared_rows':len(expected),'omitted_fields':['series','platforms','roster.title','roster.source_name','roster.characteristics','roster.diagnosis_field']}
run=json.loads((ROOT/'results/execution.json').read_text())
assert run['status']=='passed' and run['exit_code']==0
sources=json.loads((ROOT/'retrieval-sources.json').read_text())['sources']
omissions=[{'file':r['file'],'bytes':r['bytes'],'sha256':r['sha256'],'included':False,'reproduction':'Reader obtains original separately; rights unchanged'} for r in sources]
record={'prepared_utc':datetime.now(timezone.utc).isoformat(),'derivation':{'reviewed_full_archive_sha256':preparation['frozen_full_zip_sha256'],'reviewed_verifier_sha256':preparation['original_verifier_sha256'],'adaptation':'Same scientific verification predicates; separate original-source directory and factual-only emitted metadata.'},
        'actual_offline_replay':run,'source_reuse':'Fresh local replay used byte-identical originals copied from the reviewed full archive into a separate local directory.',
        'retrieval_validation':{'command':'python -X utf8 -B retrieve_sources.py --plan --sources ../local-original-sources','exit_code':0,'mode':'plan_only','network_requests':0,'files_written':0,'live_downloader_executed':False,'logic_review':'HTTPS URLs, frozen byte/hash validation, named Figure S6 archive-member extraction, existing-file mismatch refusal and separate destination inspected.'},
        'output_equivalence_to_reviewed_audit':equivalence,'omitted_original_sources':omissions,'narrative_source_fields_distributed':False,
        'license_scope':'Prepared first-party CC0 notice excludes rights in original sources; no source license is waived or changed.',
        'packaging':'Sorted archive paths; fixed 2026-09-07 00:00:00 timestamps; regular file mode 0644; ZIP_DEFLATED level 9. Packaging is deterministic for the retained files.',
        'live_network_retrieval_unverified':True}
(ROOT/'reproduction.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
for path in ROOT.rglob('*'):
    if path.is_file():
        assert path.suffix not in {'.gz','.xml','.png','.jpg','.zip'},path.name
        text=path.read_text(encoding='utf-8')
        assert not re.search(r'C:[/\\]|Users[/\\]|mcrae|\.codex|worktree',text,re.I),path.name
        if path.parent.name=='results':
            assert 'Series_overall_design' not in text
            assert 'RNA was extracted from 17 LGFMS' not in text
            assert 'Gene expression of 105 soft tissue tumor samples consisting of' not in text
files=[]
for path in sorted(ROOT.rglob('*')):
    if path.is_file() and path.name!='manifest.json':
        blob=path.read_bytes();files.append({'path':path.relative_to(ROOT).as_posix(),'bytes':len(blob),'sha256':hashlib.sha256(blob).hexdigest()})
manifest={'schema_version':1,'files':files,'self_excluded':'manifest.json','original_source_files_included':0,'narrative_source_extracts_included':False}
(ROOT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
def zipped():
    output=io.BytesIO()
    with zipfile.ZipFile(output,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for path in sorted(ROOT.rglob('*')):
            if not path.is_file():continue
            info=zipfile.ZipInfo(path.relative_to(ROOT).as_posix(),date_time=(2026,9,7,0,0,0))
            info.create_system=3;info.external_attr=0o100644<<16;info.compress_type=zipfile.ZIP_DEFLATED
            archive.writestr(info,path.read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
    return output.getvalue()
first,second=zipped(),zipped()
assert first==second
with zipfile.ZipFile(io.BytesIO(first)) as archive:
    assert archive.testzip() is None
    assert len(archive.namelist())==len(files)+1
    for entry in files:assert hashlib.sha256(archive.read(entry['path'])).hexdigest()==entry['sha256']
OUT.write_bytes(first)
receipt={'finished_utc':datetime.now(timezone.utc).isoformat(),'zip_file':OUT.name,'bytes':len(first),'sha256':hashlib.sha256(first).hexdigest(),
         'manifest_sha256':hashlib.sha256((ROOT/'manifest.json').read_bytes()).hexdigest(),'members':len(files)+1,'deterministic_double_build_identical':True,'zip_integrity_passed':True,
         'frozen_full_zip_unchanged':True,'actual_replay':run,'all_original_sources_omitted':True,'copied_narrative_outputs_omitted':True,
         'exact_output_equivalence':equivalence,'remaining_limit':'Live reader download execution was not run; --plan and retrieval code/URL logic were inspected. No external release/license transaction occurred.'}
(HERE/'verification-supplement-build-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps(receipt,indent=2))
