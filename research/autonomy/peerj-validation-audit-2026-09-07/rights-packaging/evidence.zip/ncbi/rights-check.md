# Bounded NCBI/GEO rights-source classification

2026-09-07. This is a reading of cited primary policies and retained metadata, not legal assurance or a grant of rights. No upload, correspondence, Git edit, source replacement, or expression analysis was performed.

## Official reuse scope and caveat

1. **GEO Disclaimer — GEO Availability:** https://www.ncbi.nlm.nih.gov/geo/info/disclaimer.html

   Exact supporting language: **“NCBI places no restrictions on the use or distribution of the GEO data.”** The same paragraph immediately says submitters may retain patent, copyright or other intellectual-property claims, which NCBI does not evaluate; NCBI therefore cannot give unrestricted permission for use, copying or distribution. The Copyright Status section allows downloading/reproduction unless otherwise stated but preserves authors’/publishers’ rights in protected contributed material. This is more than an access-only statement, but it is not an unrestricted rights transfer.

2. **NCBI Website and Data Usage Policies — Molecular Data Usage:** https://www.ncbi.nlm.nih.gov/home/about/policies/

   Gene-expression databases are explicitly within this section. NCBI states that it imposes no use/distribution restrictions and does not accept submissions requesting reuse/redistribution restrictions. Its decisive qualification is **“there is no transfer of rights from submitters to NCBI”**. NCBI consequently has no rights to transfer to another party and cannot give unrestricted permission. Separately, the webpage-public-domain rule applies to information created by or for the US government; it does not make all submitted material public domain. The page explicitly recognizes protected contributed/licensed content.

3. **GEO FAQ — public release and use:** https://www.ncbi.nlm.nih.gov/geo/info/faq.html

   Submitters are told that public release enables access, downloading and reuse. The FAQ directs users to the copyright/data disclaimers. It describes GEO Series as original submitter-supplied study records. These statements do not supply an accession-specific CC0 or CC BY license.

4. **GEO Citing and linking:** https://www.ncbi.nlm.nih.gov/geo/info/linking.html

   GEO asks downstream users to cite the original study and accession, in addition to a GEO database paper where applicable. Attribution guidance is separate from a license grant.

## Accession-specific inspection

The retained `GSE6481` metadata SOFT text and `GSE24369` family SOFT archive metadata were scanned for explicit field names involving license/copyright/rights and for copyright, license, redistribution, reuse, restriction, terms-of-use, public-domain, CC BY and CC0 language. Sample/platform/expression tables were skipped. **Neither inspected metadata set contained an explicit license grant or a matching rights/restriction notice.** Absence of such a notice does not establish ownership, a waiver, or a license for every archive component.

`retained-soft-rights-scan.json` records source paths/hashes, the exact scan outcome and attribution metadata. GSE6481 identifies PMID17464315 and its contributor list; GSE24369 identifies PMID21536545 and its contributor list. Both include Affymetrix platform material. This inspection does not determine rights in external publications, manufacturer websites, table annotations or separately supplied raw files.

## Consequence for packaging

The supported classification is **public GEO data under NCBI/GEO reuse and distribution guidance, with third-party rights reserved; no accession-specific CC0 grant found**. The policies support ordinary data reuse and contemplate redistribution, while stopping short of unrestricted permission or transfer of submitter rights. They do not establish that an entire family SOFT archive, or copied narrative study-description paragraphs, can be covered by a new uploader’s blanket CC0 dedication.

The proposed first-party verifier/retrieval instructions, exact source URLs and hashes, and factual counts avoid carrying the third-party source files and copied narrative extracts into the distributed package. That conclusion does not decide the rights status of each possible factual extract or the receiving platform’s terms, which the coordinator is checking separately.

## Retrieval provenance and limits

The ordinary NCBI policy URL returned HTTP200, 38,936 bytes, untruncated, at 2026-09-07T21:21:45.631988+00:00 through 21:21:45.823029+00:00. Retained as `ncbi-policies.html`; SHA256 `8ad8f6f186ca51ec73a5fb8935ecfa17b8cbaad300b7025b381898ab72621869`. `policy-retrieval.json` preserves headers, URLs, status and times.

Direct web-tool requests to the GEO Disclaimer and FAQ displayed reCAPTCHA. Those challenged routes were not retried. Exact official-URL search results supplied the cited policy/FAQ text, reporting last-modified July8,2026. The citation page was likewise read through an official-URL search result. These cached representations were used transparently; no origin HTTP success or byte hash is claimed for them.
