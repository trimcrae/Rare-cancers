# Initial live reader retrieval — preserved failure

The unchanged reader-facing `retrieve_sources.py` from the 15,847-byte supplement was executed once into the previously absent `live-original-sources` directory. It exited 1 after 5.897 seconds on 2026-09-07 at 21:37:17 UTC. No retries or challenge bypass occurred. The downstream verifier was not run because retrieval did not complete.

Both GEO archives and the PeerJ XML returned HTTP 200 and matched their exact frozen sizes and SHA256s. Europe PMC's supplementary ZIP returned HTTP 200 and the expected 4,457,390 bytes, but its observed SHA256 was `1b78e44db4fcf135aa4fc81c796a26c5150aa469160a2a5de30df973690e2916`, compared with the earlier container hash `cbbb84beccbb2a78f06bca1893c5838e7767a875a4ac740f7f921ea1f12bcedf`. The downloader stopped before extracting the Figure S6 member. Its bytes were not written or inspected, and no member-equivalence claim is made for this failed request.

The earlier retained ZIP records Figure S6's member timestamp as 2026-09-07 16:19:02, close to that earlier 15:19 UTC source retrieval with an hour offset. This supports a hypothesis of generated-container metadata, but the changed response was not retained as bytes, so the exact source of the container hash difference has not been proven. The member's frozen size (833,332) and SHA256 (`29932259e722fa46b84f01e2b662bcd58b66a108db669eca5035913eb9d8df03`) remain unchanged requirements.

Evidence: `live-reader-execution.json`, `live-retrieval.stderr.txt`, `live-original-sources/retrieval-receipt.json`. The earlier supplement ZIP and build receipt are preserved under `verification-supplement-prior-015847/`, with ZIP SHA256 `0141b4b7673f43b11384aca28c69c35451cae7d81f5f519957d80a05abbadfdc`.
