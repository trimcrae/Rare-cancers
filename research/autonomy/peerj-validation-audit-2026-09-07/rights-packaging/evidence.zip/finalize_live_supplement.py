from pathlib import Path
from datetime import datetime, timezone
import hashlib
import io
import json
import re
import shutil
import zipfile

HERE=Path(__file__).resolve().parent
ROOT=HERE/'verification-supplement'
PRIOR=HERE/'verification-supplement-prior-015847'
ZIP=HERE/'emc-verification-supplement.zip'
prior_zip=(PRIOR/'emc-verification-supplement.zip').read_bytes()
assert hashlib.sha256(prior_zip).hexdigest()=='0141b4b7673f43b11384aca28c69c35451cae7d81f5f519957d80a05abbadfdc'
assert ZIP.read_bytes()==prior_zip
failed=json.loads((HERE/'live-reader-execution.json').read_text())
live=json.loads((HERE/'live-reader-v2-execution.json').read_text())
http=json.loads((HERE/'live-original-sources-v2/retrieval-receipt.json').read_text())
initial_http=json.loads((HERE/'live-original-sources/retrieval-receipt.json').read_text())
reuse=json.loads((HERE/'transport-reuse-check.json').read_text())
assert failed['status']=='failed' and live['status']=='passed'
assert len(http['records'])==4 and all(x['http_status']==200 and x['status']=='downloaded_and_verified' for x in http['records'])
sources=json.loads((ROOT/'retrieval-sources.json').read_text())['sources']
for src,r in zip(sources,http['records']):
    assert src['file']==r['file'] and src['bytes']==r['bytes'] and src['sha256']==r['sha256']

# Preserve the exact successful live-tested code separately from its small,
# locally tested interruption-recovery follow-up.
final_script=(ROOT/'retrieve_sources.py').read_text()
helper="def preserve_transport(path,blob):\n    if path.exists():\n        require(path.read_bytes()==blob,'Existing hash-named transport differs; file left unchanged')\n    else:\n        with path.open('xb') as stream:\n            stream.write(blob)\n\n"
assert final_script.count(helper)==1
live_script=final_script.replace(helper,'').replace('                preserve_transport(transport_file,raw)',"                with transport_file.open('xb') as stream:\n                    stream.write(raw)")
assert hashlib.sha256(live_script.encode()).hexdigest()==live['retrieval_script_sha256']
(HERE/'retrieve_sources-live-tested.py').write_text(live_script,encoding='utf-8',newline='\n')

src=(ROOT/'live-results-v2').resolve()
dst=(HERE/'live-verification-results-v2').resolve()
assert src.is_relative_to(ROOT.resolve()) and dst.parent==HERE.resolve() and not dst.exists()
src.rename(dst)
comparisons={}
for acc in ('GSE6481','GSE24369'):
    reviewed=json.loads((HERE/(acc+'-reviewed-full-metadata.json')).read_text())
    actual=json.loads((dst/(acc+'-metadata.json')).read_text())
    for key in ('sample_count','diagnosis_counts','platform_counts','sample_type_counts','checks','expression_values_parsed_or_computed'):
        assert actual[key]==reviewed[key],(acc,key)
    projection=[{k:r[k] for k in ('gsm','diagnosis','platform','source_line')} for r in reviewed['complete_sample_roster']]
    assert actual['complete_sample_roster']==projection
    assert 'series' not in actual and 'platforms' not in actual
    comparisons[acc]={'compared_rows':len(projection),'all_factual_roster_rows_identical':True,'all_counts_and_checks_identical':True}
for path in dst.iterdir():
    assert path.is_file() and path.suffix=='.json'
    shutil.copyfile(path,ROOT/'results'/path.name)

record=json.loads((ROOT/'reproduction.json').read_text())
record['prior_offline_replay']=record.pop('actual_offline_replay')
record['prior_source_reuse']=record.pop('source_reuse')
record['prepared_utc']=datetime.now(timezone.utc).isoformat()
record['live_network_retrieval_unverified']=False
record['retrieval_validation']={'mode':'successful_live_download_and_verification_with_preserved_initial_failure','initial_failed_run':failed['commands'][0],
    'initial_failure':'Only the supplementary transport hash differed; no Figure S6 bytes were captured or claimed equivalent in that failed run.',
    'initial_transport_observation':initial_http['records'][-1],
    'successful_live_run':live['commands'],'successful_http_receipt':http,
    'live_tested_downloader_sha256':live['retrieval_script_sha256'],
    'final_downloader_sha256':hashlib.sha256(final_script.encode()).hexdigest(),
    'post_live_local_repair':'Reuse an existing hash-named transport only when its bytes match exactly; fresh download/member-validation path unchanged.',
    'post_live_local_check':reuse,'live_downloader_executed':True,
    'repair':'Exact original file hashes and unique named Figure S6 size/hash remain mandatory. Container reference hash/size are historical transport observations; actual transport is recorded and capped at 16 MiB.'}
record['actual_live_output_execution']=json.loads((ROOT/'results/execution.json').read_text())
record['live_output_equivalence_to_reviewed_audit']=comparisons
record['prior_distribution_zip_sha256']=hashlib.sha256(prior_zip).hexdigest()
(ROOT/'reproduction.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')

for path in ROOT.rglob('*'):
    if path.is_file():
        assert path.suffix not in {'.gz','.xml','.png','.jpg','.zip'},path.name
        text=path.read_text(encoding='utf-8')
        assert not re.search(r'C:[/\\]|Users[/\\]|mcrae|\.codex|worktree',text,re.I),path.name
        if path.parent.name=='results':assert 'Series_overall_design' not in text
files=[]
for path in sorted(ROOT.rglob('*')):
    if path.is_file() and path.name!='manifest.json':
        data=path.read_bytes();files.append({'path':path.relative_to(ROOT).as_posix(),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
manifest={'schema_version':1,'files':files,'self_excluded':'manifest.json','original_source_files_included':0,'narrative_source_extracts_included':False}
(ROOT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
def build():
    output=io.BytesIO()
    with zipfile.ZipFile(output,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for path in sorted(ROOT.rglob('*')):
            if not path.is_file():continue
            info=zipfile.ZipInfo(path.relative_to(ROOT).as_posix(),date_time=(2026,9,7,0,0,0))
            info.create_system=3;info.external_attr=0o100644<<16;info.compress_type=zipfile.ZIP_DEFLATED
            z.writestr(info,path.read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
    return output.getvalue()
new=build();assert new==build()
with zipfile.ZipFile(io.BytesIO(new)) as z, zipfile.ZipFile(io.BytesIO(prior_zip)) as old:
    assert z.testzip() is None
    differences=[]
    for name in sorted(set(z.namelist())|set(old.namelist())):
        a=old.read(name) if name in old.namelist() else None
        b=z.read(name) if name in z.namelist() else None
        if a!=b:differences.append({'file':name,'old_bytes':len(a) if a is not None else None,'new_bytes':len(b) if b is not None else None,
                                  'old_sha256':hashlib.sha256(a).hexdigest() if a is not None else None,'new_sha256':hashlib.sha256(b).hexdigest() if b is not None else None})
    for item in files:assert hashlib.sha256(z.read(item['path'])).hexdigest()==item['sha256']
ZIP.write_bytes(new)
frozen=json.loads((HERE/'frozen-bundle-inspection.json').read_text())
assert hashlib.sha256(Path(frozen['zip_path']).read_bytes()).hexdigest()==frozen['zip_sha256']
receipt={'finished_utc':datetime.now(timezone.utc).isoformat(),'zip_file':ZIP.name,'bytes':len(new),'sha256':hashlib.sha256(new).hexdigest(),
         'manifest_sha256':hashlib.sha256((ROOT/'manifest.json').read_bytes()).hexdigest(),'members':len(files)+1,'deterministic_double_build_identical':True,
         'zip_integrity_and_member_hashes_passed':True,'prior_zip_preserved':hashlib.sha256(prior_zip).hexdigest(),'prior_zip_bytes':len(prior_zip),
         'frozen_full_zip_unchanged':frozen['zip_sha256'],'actual_live_commands':live['commands'],'failed_initial_run':failed,
         'exact_output_equivalence':comparisons,'post_live_local_reuse_repair_test':reuse,'all_distribution_differences':differences,
         'original_sources_and_narrative_omitted':True,'private_paths_absent_from_distribution':True,'repository_writes':False,'uploads':False,
         'remaining_limit':'The final interruption-reuse helper was tested locally after the successful live run; both exact code hashes and that boundary are retained.'}
(HERE/'verification-supplement-build-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in receipt.items() if k not in {'all_distribution_differences','failed_initial_run'}},indent=2))
