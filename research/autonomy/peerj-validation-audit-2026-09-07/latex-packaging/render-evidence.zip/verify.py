import pathlib,re,json,hashlib,unicodedata,datetime,subprocess
from pypdf import PdfReader
import convert
p=pathlib.Path(__file__).parent
original=(p/'frozen-original.md').read_text(encoding='utf-8-sig'); source=(p/'venue-source.md').read_text(encoding='utf-8-sig')
expected=original
for a,b in convert.REPAIRS: expected=expected.replace(a,b)
availability=json.loads((p/'availability-replacement.json').read_text()); expected=expected.replace(availability['old'],availability['new'])
domain=json.loads((p/'domain-condition-replacement.json').read_text()); expected=expected.replace(domain['old'],domain['new'])
assert source==expected, 'Unexpected source edit'
tex=(p/'emc-external-validation-comment.tex').read_text(encoding='utf-8'); assert tex==convert.convert(source)
r=PdfReader(p/'emc-external-validation-comment.pdf')
text='\n'.join(re.sub(r'\n\d+\s*$','',x.extract_text()) for x in r.pages)
(p/'pdf-text.txt').write_text(text,encoding='utf-8')
def norm(x): return re.sub(r'\s+|-','',unicodedata.normalize('NFKC',x))
body=re.sub(r'\A---\n.*?\n---\n','',source,flags=re.S)
body=re.sub(r'\[([^\]]+)\]\(([^)]+)\)',r'\1',body)
body=re.sub(r'^#+ ','',body,flags=re.M); body=body.replace('**','')
body=re.sub(r'\*([^*`]+)\*',r'\1',body)
parts=re.split(r'`[^`]+`',body)
actual=norm(text); cursor=0; checks=[]
for n,part in enumerate(parts):
 target=norm(part)
 if not target: continue
 pos=actual.find(target,cursor); checks.append(dict(segment=n,found=pos>=0,characters=len(target)))
 if pos<0: print('MISSING',n,repr(target[:160]))
 else: cursor=pos+len(target)
links=sorted(set(str(a.get_object().get('/A',{}).get('/URI')) for page in r.pages for a in page.get('/Annots',[]) if a.get_object().get('/A',{}).get('/URI')))
expectedlinks=sorted(set(re.findall(r'\]\(([^)]+)\)',source)))
assert links==expectedlinks,(links,expectedlinks)
report=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),pages=len(r.pages),exact_two_E1_plus_availability_and_domain_restoration_only=source==expected,deterministic_tex_matches=True,prose_comparison='All non-code-math source segments located in order in PDF extraction after NFKC normalization and removal of whitespace/hyphens; math checked separately visually and against explicit converter mapping.',prose_segments=checks,all_prose_segments_match=all(c['found'] for c in checks),hyperlinks_exact=links==expectedlinks,hyperlinks=links,math_mapping=convert.MATH,visual_QA='All four 105-dpi page PNGs inspected: readable title, all prose and references, two displayed equations and four inline expressions; no clipping, overlap or missing glyph observed.',build='Tectonic 0.17.0, actual exit 0; first attempt fontspec missing named font preserved, resolved by portable lmodern package; no source wording change.',limits='Deterministic source-to-TeX conversion, not a claim of byte-identical PDFs across engines or timestamps. No independent scientific review performed.')
(p/'content-equivalence-receipt.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
files=[x for x in p.iterdir() if x.is_file() and x.name!='hashes.json']+[p/'tectonic/tectonic.exe']
(p/'hashes.json').write_text(json.dumps({str(x.relative_to(p)):dict(bytes=x.stat().st_size,sha256=hashlib.sha256(x.read_bytes()).hexdigest()) for x in files},indent=2))
print(json.dumps(dict(pages=len(r.pages),all_prose_segments_match=report['all_prose_segments_match'],hyperlinks_exact=True)))
