import pathlib,json,difflib
p=pathlib.Path(__file__).parent
old='each gene was centered and scaled'; new='each nonconstant gene was centered and scaled'
s=(p/'venue-source.md').read_text(encoding='utf-8'); assert s.count(old)==1; s=s.replace(old,new); (p/'venue-source.md').write_text(s,encoding='utf-8',newline='\n')
(p/'domain-condition-replacement.json').write_text(json.dumps(dict(old=old,new=new,reason='Restore original necessary nonconstant-gene condition omitted in reviewer wording'),indent=2))
v=(p/'verify.py').read_text(encoding='utf-8-sig'); v=v.replace("assert source==expected, 'Unexpected source edit'", "domain=json.loads((p/'domain-condition-replacement.json').read_text()); expected=expected.replace(domain['old'],domain['new'])\nassert source==expected, 'Unexpected source edit'"); v=v.replace('exact_two_E1_plus_availability_replacements_only=', 'exact_two_E1_plus_availability_and_domain_restoration_only='); (p/'verify.py').write_text(v,encoding='utf-8')
o=(p/'frozen-original.md').read_text(encoding='utf-8-sig'); (p/'source-changes.diff').write_text(''.join(difflib.unified_diff(o.splitlines(True),s.splitlines(True),fromfile='frozen-original.md',tofile='venue-source.md')),encoding='utf-8')
