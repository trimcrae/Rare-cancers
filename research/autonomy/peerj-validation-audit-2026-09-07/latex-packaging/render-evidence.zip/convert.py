"""Deterministic, deliberately narrow converter for this manuscript. Reject unknown code math."""
import pathlib,re,json,hashlib,sys
P=pathlib.Path(__file__).parent
ORIGINAL=pathlib.Path(r'C:/Users/mcrae/.codex/worktrees/next-emc-paper-20260907/EMC-Research/research/manuscripts/external-validation/emc-external-validation-comment.md')
REPAIRS=[('For a nonconstant gene measured in cohort C, the stated transformation is:', 'If, as the wording and Figure S6C suggest, each gene was centered and scaled across samples separately within each cohort, the transformation is:'),('It follows from the reported method and does not depend on access to the external expression matrix.', 'Under this interpretation, the limitation follows algebraically without the external expression matrix.')]
def sha(b): return hashlib.sha256(b).hexdigest()
def esc(s):
 return ''.join({'&':r'\&','%':r'\%','$':r'\$','#':r'\#','_':r'\_','{':r'\{','}':r'\}','~':r'\textasciitilde{}','^':r'\textasciicircum{}','\\':r'\textbackslash{}'}.get(c,c) for c in s)
MATH={'z_C(x_i) = (x_i - mean_C(x)) / s_C(x)':r'z_C(x_i) = \frac{x_i-\operatorname{mean}_C(x)}{s_C(x)}','a*x_i + b':r'a x_i + b','a > 0':r'a > 0','a*mean_C(x) + b':r'a\operatorname{mean}_C(x)+b','a*s_C(x)':r'a s_C(x)','z_C(a*x_i + b) = z_C(x_i)':r'z_C(a x_i+b)=z_C(x_i)'}
def inline(s):
 pattern=r'(`[^`]+`|\[[^\]]+\]\([^)]+\)|\*\*[^*]+\*\*|\*[^*]+\*)'
 out=[]
 for t in re.split(pattern,s):
  if t.startswith('`'): out.append(r'\('+MATH[t[1:-1]]+r'\)')
  elif re.fullmatch(r'\[[^\]]+\]\([^)]+\)',t):
   label,url=re.fullmatch(r'\[([^\]]+)\]\(([^)]+)\)',t).groups(); out.append(r'\href{'+url+'}{'+esc(label)+'}')
  elif t.startswith('**'): out.append(r'\textbf{'+esc(t[2:-2])+'}')
  elif t.startswith('*'): out.append(r'\emph{'+esc(t[1:-1])+'}')
  else: out.append(esc(t))
 return ''.join(out)
def convert(src):
 body=re.sub(r'\A---\r?\n.*?\r?\n---\r?\n','',src,flags=re.S).strip()
 chunks=re.split(r'\n\s*\n',body); out=[]; refs=False
 for chunk in chunks:
  c=' '.join(chunk.splitlines())
  if c.startswith('# '): out.append(r'{\LARGE\bfseries '+inline(c[2:])+r'\par}\vspace{1em}')
  elif c.startswith('## '):
   out.append(r'\section*{'+esc(c[3:])+'}')
   refs=c=='## References'
  elif re.fullmatch(r'`[^`]+`\.',c): out.append(r'\['+MATH[c[1:-2]]+r'.\]')
  elif refs:
   for line in chunk.splitlines():
    m=re.fullmatch(r'(\d+)\. (.*)',line); assert m,line
    out.append(r'\noindent\hangindent=1.5em\hangafter=1 '+m[1]+'. '+inline(m[2])+r'\par\smallskip')
  else: out.append(inline(c)+r'\par')
 return r'''\documentclass[11pt]{article}
\usepackage[a4paper,margin=25mm]{geometry}
\usepackage[T1]{fontenc}
\usepackage{lmodern}
\usepackage{amsmath}
\usepackage{microtype}
\usepackage[colorlinks=true,urlcolor=blue,linkcolor=blue]{hyperref}
\setlength{\parindent}{0pt}
\setlength{\parskip}{0.65em}
\setlength{\emergencystretch}{3em}
\begin{document}
'''+ '\n\n'.join(out)+'\n\\end{document}\n'
if __name__=='__main__':
 if '--input' in sys.argv:
  src=pathlib.Path(sys.argv[sys.argv.index('--input')+1]).read_text(encoding='utf-8-sig')
 else:
  original=ORIGINAL.read_bytes(); (P/'frozen-original.md').write_bytes(original)
  src=original.decode('utf-8-sig')
  for a,b in REPAIRS: assert src.count(a)==1; src=src.replace(a,b)
  (P/'venue-source.md').write_text(src,encoding='utf-8',newline='\n')
  (P/'source-repair-receipt.json').write_text(json.dumps(dict(original_path=str(ORIGINAL),original_sha256=sha(original),repairs=REPAIRS,only_two_replacements=True),indent=2))
 tex=convert(src); (P/'emc-external-validation-comment.tex').write_text(tex,encoding='utf-8',newline='\n')
 print('Converted deterministically; source characters',len(src),'TeX characters',len(tex))
