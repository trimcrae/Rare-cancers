import urllib.request,re,pathlib,json,hashlib,datetime,zipfile
p=pathlib.Path(__file__).parent
u='https://github.com/tectonic-typesetting/tectonic/releases/expanded_assets/tectonic%400.17.0'
with urllib.request.urlopen(u,timeout=60) as r: b=r.read()
(p/'release-assets.html').write_bytes(b)
links=re.findall(r'href="([^"]+)"',b.decode())
print('\n'.join(x for x in links if 'windows' in x))
u='https://github.com'+next(x for x in links if 'x86_64-pc-windows-msvc.zip' in x)
with urllib.request.urlopen(u,timeout=60) as r: b=r.read(); final=r.url; headers=dict(r.headers)
(p/'tectonic.zip').write_bytes(b)
(p/'download-receipt.json').write_text(json.dumps(dict(url=u,final_url=final,headers=headers,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest()),indent=2))
with zipfile.ZipFile(p/'tectonic.zip') as z: z.extractall(p/'tectonic')
