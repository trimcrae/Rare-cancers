Private Qeios LaTeX rendition (no repository writes)

Final editable upload source: emc-external-validation-comment.tex
QA PDF: emc-external-validation-comment.pdf (4 pages)
Canonical private manuscript: venue-source.md

Only changes from frozen-original.md: the two exact E1 replacements from the independent review, plus the coordinator's exact availability paragraph. source-changes.diff is the complete textual diff. source-repair-receipt.json records the earlier E1-only preparation; availability-replacement.json and content-equivalence-receipt.json establish the final three replacements. No YAML is rendered. Title punctuation is preserved. Math uses editable LaTeX, not screenshots.

Rebuild (run in this directory; substitute the bundled Python absolute path if needed):
python -X utf8 convert.py --input venue-source.md
.\tectonic\tectonic.exe --keep-logs --keep-intermediates --outdir . emc-external-validation-comment.tex
pdftoppm -r 105 -png emc-external-validation-comment.pdf page
python -X utf8 verify.py

convert.py is a deterministic narrow converter for this manuscript's syntax, not a general Markdown parser. --input is required to preserve the finalized availability wording; running without it intentionally recreates the earlier E1-only source from the repository original. Output TeX requires standard article, geometry, fontenc, lmodern, amsmath, microtype and hyperref packages. It compiled with official Tectonic 0.17.0; no system or managed-runtime installation was performed. The initial named-font lookup failed and is preserved in build-attempt1-console.log; portable lmodern resolved it. Actual successful final build output is build-console.log (EXIT=0) and the TeX .log. download-receipt.json gives official binary URL, HTTP headers and ZIP SHA256. hashes.json includes the binary hash and artifact hashes.

Final QA: all four actual PNG pages inspected after the availability replacement. No observed clipping, overlap, missing glyph, or unreadable equation. All source prose segments occur in order in PDF extraction after whitespace/hyphen and Unicode ligature normalization; all six unique hyperlinks match exactly. Explicit formula mappings and visual inspection cover the two displayed and four inline mathematical expressions. The source diff check accepts only the authorized three replacements. This is packaging QA, not another scientific review. Nothing was submitted or sent to anyone. Compilation completed; nothing remains running.
