import pathlib,importlib.util,subprocess,time,json,datetime,hashlib
p=pathlib.Path(__file__).parent
repo=pathlib.Path(r'C:/Users/mcrae/.codex/worktrees/next-emc-paper-20260907/EMC-Research')
spec=importlib.util.spec_from_file_location('runtime',r'C:/Projects/EMC-Research/.cache/full_preflight_runtime.py'); runtime=importlib.util.module_from_spec(spec); spec.loader.exec_module(runtime)
# Verify environment() will not rewrite shared existing adapters before calling it.
for a,b in [(runtime.RUNTIME/'native/git/usr/bin/sh.exe',runtime.ROOT/'.cache/full-preflight-runtime/bin/bash.exe'),(runtime.RUNTIME/'python/python.exe',runtime.ROOT/'.cache/full-preflight-runtime/bin/python3.exe')]:
 assert b.exists() and a.read_bytes()==b.read_bytes(), 'Would alter shared runtime; refusing'
adapters,env=runtime.environment()
env['PYTEST_DEBUG_TEMPROOT']=str(p/'pytest-temp'); (p/'pytest-temp').mkdir(exist_ok=True)
env['PYTHONDONTWRITEBYTECODE']='1'
tests=[('timezone','test_realised_spend.py::test_committed_artifacts_are_readable_and_sum'),('separators','test_one_geometry_screen_loading.py::test_the_scanner_covers_the_whole_repository_not_only_modalities'),('signals','test_restore_wedge_guard.py::test_the_alarm_is_always_disarmed_even_on_an_exception'),('shell','test_publish_does_not_revert_another_jobs_artifact.py::test_a_file_created_by_this_run_publishes')]
rows=[]
for name,test in tests:
 cmd=[str(adapters/'python3.exe'),'-X','utf8','-m','pytest','research/modalities/tests/'+test,'-vv','--tb=short','-p','no:cacheprovider']
 start=datetime.datetime.now(datetime.timezone.utc).isoformat(); t=time.monotonic()
 r=subprocess.run(cmd,cwd=repo,env=env,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=120)
 (p/(name+'.stdout.txt')).write_text(r.stdout,encoding='utf-8'); (p/(name+'.stderr.txt')).write_text(r.stderr,encoding='utf-8')
 row=dict(name=name,command=cmd,cwd=str(repo),started_utc=start,elapsed_seconds=time.monotonic()-t,exit_code=r.returncode); rows.append(row)
 (p/'executions.json').write_text(json.dumps(rows,indent=2)); print(name,r.returncode,r.stdout[-1700:],flush=True)
