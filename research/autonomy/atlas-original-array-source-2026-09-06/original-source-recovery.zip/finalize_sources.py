from pathlib import Path
import csv,json,gzip,hashlib,shutil,collections
p=Path(__file__).parent;root=p.parents[1];src=root/'research/autonomy/atlas-primary-provenance-2026-09-06'
want='CD276 SSTR2 PRAME FAP CD248 CSPG4 MSLN L1CAM GPC3 ALPP CDH17 CHRNA6'.split()
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
inputs=[(src/'GSE24369.soft.gz','GSE24369.soft.gz','https://ftp.ncbi.nlm.nih.gov/geo/series/GSE24nnn/GSE24369/soft/GSE24369_family.soft.gz'),(src/'E-GEOD-4303-GPL3290.matrix.gz','GSE4303-GPL3290-source-matrix.gz','https://ftp.ncbi.nlm.nih.gov/geo/series/GSE4nnn/GSE4303/matrix/GSE4303-GPL3290_series_matrix.txt.gz'),(root/'research/modalities/accession-symbol-cache.json','accession-symbol-cache.json',None),(root/'research/modalities/emc-expression-panels-inputs.json','legacy-panel-inputs.json',None)]
receipts=[]
for f,n,u in inputs:
    shutil.copyfile(f,p/n);assert sha(f)==sha(p/n)
    receipts.append({'original_path':str(f.resolve()),'cache_file':n,'source_url':u,'sha256':sha(f),'bytes':f.stat().st_size,'retrieval':'byte-identical reuse; original retrieval record in atlas-primary-provenance packet where applicable'})
external=Path('C:/Users/mcrae/.codex/worktrees/atlas-provenance-20260906/EMC-Research/research/autonomy/atlas-primary-provenance-2026-09-06/GSE4303.soft.gz')
assert sha(external)=='228f80e4cd78f7ecdfd4433e86c01bcd1a01fe558cdb1d6ba76e9d659e89c294'
receipts.append({'original_path':str(external),'cache_file':None,'source_url':'https://ftp.ncbi.nlm.nih.gov/geo/series/GSE4nnn/GSE4303/soft/GSE4303_family.soft.gz','sha256':sha(external),'bytes':external.stat().st_size,'retrieval':'verified retained original; not duplicated'})
(p/'source-reuse-manifest.json').write_text(json.dumps(receipts,indent=2)+'\n')
mapping=[]
for r in csv.DictReader((p/'GPL6244-original-annotation.tsv').open(),delimiter='\t'):
    assignments=[a.split(' // ') for a in r['gene_assignment'].split(' /// ')]
    syms=sorted(set(a[1] for a in assignments if len(a)>1))
    if set(syms)&set(want):mapping.append({'probe_id':r['ID'],'all_assigned_symbols':syms,'target_symbols':sorted(set(syms)&set(want)),'gene_assignment':r['gene_assignment'],'unique_gene':len(syms)==1})
assert len(mapping)==12 and all(r['unique_gene'] for r in mapping)
(p/'GPL6244-fixed12-probe-map.json').write_text(json.dumps(mapping,indent=2)+'\n')
rosters=[]
for name,gse in [('GSE24369.soft-sample-metadata.json','GSE24369'),('GSE4303.soft-sample-metadata.json','GSE4303')]:
    for s in json.loads((p/name).read_text()):
        f=s['fields'];plat=f.get('!Sample_platform_id',[''])[0]
        if gse=='GSE4303' and plat!='GPL3290':continue
        rosters.append({'gse':gse,'gsm':s['gsm'],'platform':plat,'title':f.get('!Sample_title',[''])[0],'characteristics_ch1':f.get('!Sample_characteristics_ch1',[]),'source_ch1':f.get('!Sample_source_name_ch1',[]),'source_ch2':f.get('!Sample_source_name_ch2',[]),'processing':f.get('!Sample_data_processing',[]),'VALUE_definition':f.get('#VALUE',[])})
(p/'sample-rosters.json').write_text(json.dumps(rosters,indent=2)+'\n')
legacy=json.loads((p/'legacy-panel-inputs.json').read_text()); lm={}
for name,d in legacy['targets'].items():
    lm[name]={'matrix_url':d['url'],'compressed_bytes':d['compressed_bytes'],'source_hash_present':any('sha' in k.lower() for k in d),'sample_ids':[s['gsm'] for s in d['samples']],'mapping_diagnostic':d['probe_symbol_mapping'],'targets':{g:{k:v for k,v in d['genes'].get(g,{}).items() if k in ['probe_ids','n_probes_mapping']} for g in want},'transform_policy':'source-probe mean, available probes per sample, rounded4; z and percentile are separate fields; CHRNA6 absent from prior requested panel'}
(p/'legacy-origin-metadata.json').write_text(json.dumps(lm,indent=2)+'\n')
print(json.dumps({'source_count':len(receipts),'GPL6244_fixed12':{r['target_symbols'][0]:r['probe_id'] for r in mapping},'roster_counts':dict(collections.Counter(r['gse'] for r in rosters))},indent=2))
