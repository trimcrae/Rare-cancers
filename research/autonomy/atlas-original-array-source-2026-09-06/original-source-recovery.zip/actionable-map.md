# Original array source reconstruction, frozen before outcomes

**GSE24369 supports an executable original-scale per-gene rank analysis. GSE4303 supports observed tumor/reference-ratio ranks only, conditional on unresolved reference compatibility.** No target values or contrasts were printed, selected for direction, or computed in this task. No network request was required; exact original source archives were reused.

## GSE24369 / GPL6244

The retained 20,240,336-byte `GSE24369.soft.gz` contains all42 sample tables and the complete GPL6244 annotation. Original SHA256 `98c83c8ca23b7052cf0d4d0099a7bf1af6c3c972276038c3a633e2a5349b3c37`. The sample-table VALUE definition explicitly states **RMA log2 signal**. Metadata document RMA background correction, normalization and probe summarization with Affymetrix Expression Console. This is source evidence, stronger than the old script's fraction-negative heuristic.

The source `gene_assignment` column can be parsed directly as `accession // symbol // description // location // Entrez`, with alternative assignments separated by ` /// `. All12 requested genes have exactly one transcript-cluster ID and one unique assigned symbol across all assignments; no accession bridge or outcome-driven probe aggregation is needed:

| Gene | GPL6244 transcript-cluster ID |
|---|---|
| CD276 | 7984743 |
| SSTR2 | 8009526 |
| PRAME | 8074856 |
| FAP | 8056257 |
| CD248 | 7949588 |
| CSPG4 | 7990545 |
| MSLN | 7992071 |
| L1CAM | 8175871 |
| GPC3 | 8175234 |
| ALPP | 8049123 |
| CDH17 | 8151795 |
| CHRNA6, separate context | 8150550 |

Exact assignments and alternative transcript accessions are in `GPL6244-fixed12-probe-map.json`; full annotation is a derived verbatim-line extraction backed by the original gzip. These are source-era annotations, not sequence-level revalidation against a current genome.

Correct metadata roster: EMC GSM600934–600939 (6); LGFMS GSM600940–600956 (17); myxofibrosarcoma GSM600957–600962 (6); desmoid fibromatosis GSM600928–600933 (6); SFT GSM600963–600967 (5); skeletal-muscle RNA pools GSM600968–600969 (2). The source does NOT call the MFS group generic fibrosarcoma. The old35-sample classified comparator analysis omitted SFT and muscle pools; the raw source is42 samples. Do not silently preserve the old classification bug or silently add comparator histologies: freeze the new question's comparator policy explicitly. Muscle pools are not independent normal patients.

Executable reconstruction after freeze: stream each GSM's sample table from the cached family; select the exact12 IDs, retain source VALUE strings and missing tokens, join by exact GSM to the frozen roster, and calculate per-gene EMC/comparator probability of superiority with half credit for exact ties. Preserve supplied numerical precision rather than rounding4. No samplewise across-gene standardization; no new RMA normalization needed for this question. Because each gene has one cluster, no cross-probe scale transformation or probe-choice ambiguity arises. Gene-level ranking across patients is unchanged by a single common monotone transform, but comparison of ranks between genes is not justified by this fact.

## Legacy cached values: useful provenance, inferior reconstruction input

`emc_expression_panels.py` lines1487–1503 averages available mapped probes on the source scale per sample, then rounds4; it separately stores array percentile. Later `z_vs_array` calculations use sample backgrounds. Thus `genes[g]['values']` really are source-scale summaries and are not the z-values. The fixed11 in GPL6244 each use the same single probe as direct annotation above. CHRNA6 is absent from this historical requested panel and must be recovered from the original source.

The legacy input records matrix URL and compressed byte length but no matrix-content SHA256. Its annotation bridge uses first-resolving accessions and can suppress alternative symbols. For a new reproducible analysis, prefer the hash-verified original family/matrix to assuming this rounded cache is source-identical. If the cache is used for a separately labelled check, equality after rounding4 must receive half-tie credit, with potential rounding-created ties acknowledged. Do not recompute samplewise z-comparisons or reuse old signs as if they were per-gene rank effects.

## GSE4303 / GPL3290

The existing processed16-column matrix is byte-identically copied as `GSE4303-GPL3290-source-matrix.gz`; despite the old local filename beginning E-GEOD, its retrieval receipt identifies the actual NCBI source https://ftp.ncbi.nlm.nih.gov/geo/series/GSE4nnn/GSE4303/matrix/GSE4303-GPL3290_series_matrix.txt.gz . SHA256 `54ccc12e6e54192460dd3dbf1f011b37236ec52b1b2139ffef53298b5f6d2299`. Full144,169,148-byte family remains at its exact retained worktree path, verified SHA256 `228f80e4cd78f7ecdfd4433e86c01bcd1a01fe558cdb1d6ba76e9d659e89c294`; it was read once for metadata/platform extraction and not downloaded or duplicated.

Source VALUE is explicitly **log2 channel2/channel1 normalized mean ratio**, field RAT2N_MEAN. All candidate samples use Cy3 reference / Cy5 tumor. The10 EMCs have reference CRH-mRNA; DFSP GSM89883,GSM89898,GSM89924 have CRH; GIST GSM91381,GSM91397,GSM91405 have UHR. EMC expression Methods describe Stratagene reference mRNA; original DFSP expression Methods describe an11-cell-line reference pool. Prior primary-source packet `memo.md`, `linn.html`, `web-path1792-methods.json` and `gsm-platform-evidence.json` resolve orientation, not common composition or calibration. Same array does not resolve a diagnosis-confounded reference. GIST must remain a separate reference-design diagnostic; no silent six-comparator biological contrast.

GPL3290 is43008 spotted cDNA features with GB_LIST EST accession annotation, without source gene-symbol assignments. The exact current committed accession cache associates13 spots with8 target genes (all target assignments arise from its UniGene archive stratum): PRAME16280; FAP1788,35124; CSPG415375; MSLN15383,34359; L1CAM35527,39649; GPC33628; ALPP2729; CDH1710718,30520,36233. CD276,SSTR2,CD248 and CHRNA6 have no resolved target mapping in this cache, which is not proof of absent transcript or absent probe sequence. `GPL3290-target-mapping-cache-candidates.json` preserves every GB_LIST accession, all source-specific assignments and unassigned accessions. The13 candidate spots have no conflicting resolved symbols, but ALPP spot2729 includes an unresolved accession AA150487 alongside AA156691→ALPP. The cache does not contain original accession-response bytes, so this is a provenance-qualified legacy bridge, not independently revalidated sequence mapping.

Frozen policy proposal: retain all uniquely resolved target-associated probes, flag unresolved alternatives, and show probe-specific effects before any gene aggregate. If aggregating, use a prespecified common set and a fixed arithmetic mean of source logratios; do not take a best probe or let available-probe membership vary silently across samples. An average of logratios is not invariant to taking the logarithm after averaging raw intensities. A gene-specific shared monotone transform only preserves ranks for the same defined measurement. Preserve missingness per probe/sample; do not equate missing mapping or missing observed value with zero expression.

The full archive also contains raw channels if a separate reference diagnostic is authorized. Neither high reference-profile correlation nor batch correction establishes equivalent reference composition. Until this discrepancy is resolved, any per-gene result is an observed-ratio effect, not independent tumor-abundance validation. Patient-source caveats (STT3696 vs STT3714 label mismatch, STT2528 recurrence, unresolved intercohort overlap) remain as recorded in the prior primary provenance memo; this task does not reopen them through broad searches.

## Outputs and validation

`source-reuse-manifest.json` pins original paths, exact cache copies, source URLs and verified hashes. `sample-rosters.json` preserves exact42+16 records and VALUE definitions. `legacy-origin-metadata.json` records probe lists/origin diagnostics without values. `file-manifest.json` hashes the final packet. Source parsing and unique12 Affymetrix mappings were checked; no contrast or numeric target outcome test was run. No tracked changes, correspondence, spending or asynchronous process.
