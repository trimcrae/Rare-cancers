# Fixed therapeutic-address atlas prior-art audit — 2026-09-06

No new tumor RNA outcomes were opened. Fixed11 and separate CHRNA6 membership were unchanged. This is a bounded prior-art check, not an exhaustive absence claim.

## Material established evidence

**CHRNA6:** Dulken et al., Modern Pathology2024, DOI [10.1016/j.modpat.2024.100464](https://doi.org/10.1016/j.modpat.2024.100464), PMID38447752. Primary publisher Methods explicitly reuse GSE24369 (RMA/oligo, limma); same six EMC discovery specimens are not an independent replication cohort. Separate tissue validation used RNA chromogenic ISH in25EMC and685mimics, with69mimics showing only limited subthreshold expression. This is RNA CISH, **not CHRNA6 protein IHC** or surface receptor validation. Cases were retrieved from Stanford/Rutgers pathology archives. A new overlap-controlled Hofvander RNAseq contrast adds a different cohort/platform and fixed comparator definition; it does not discover CHRNA6 or independently validate its protein. Primary Methods source: https://www.sciencedirect.com/science/article/abs/pii/S0893395224000449 ; core primary abstract retained as dulken2024.json.

**PRAME:** Cammareri et al., Virchows Archiv483:145–156(2023), DOI [10.1007/s00428-023-03606-6](https://doi.org/10.1007/s00428-023-03606-6). Whole-section QR005 IHC. Exact publisher supplementary workbook recovered, genuine ZIP/XML XLSX. Sheet1 rows128–132 contains FIVE EMC (source spelling Extraeskeletal), all negative in both readers' columns. Case2 has EWSR1::NR4A3 RNAseq, cases3–5 NR4A3-positive FISH, case1 ancillary field blank. Negative is0% under primary abstract definition; empty percentage cells were not converted into observed numeric values. This is direct negative protein tissue evidence, not missing evidence. It does not establish absence across EMC or absence of PRAME peptide-HLA presentation. Any RNA enrichment must retain this discordance and cannot be called protein confirmation.
Exact XLSX: https://media.springernature.com/original/springer-static/esm/art%3A10.1007%2Fs00428-023-03606-6/MediaObjects/428_2023_3606_MOESM1_ESM.xlsx ; publisher Supplementary Information link96, source row extract retained.

**SSTR2:** Friedberg et al., Cancer86:1621–7(1999), PMID10526294, https://pubmed.ncbi.nlm.nih.gov/10526294/ . Primary case2 describes historical high-grade myxoid chondrosarcoma of thigh with somatostatin tracer uptake; pathology wording does not establish molecularly confirmed EMC. The17patient sarcoma scintigraphy cohort cannot supply an EMC-specific SSTR2-IHC prevalence. Scintigraphic binding/occupancy is not treatment efficacy. Preserve as historical suggestive receptor-imaging evidence with subtype uncertainty. Other retrieved intracranial-sarcoma table (PMC10288519) lists its EMC SSTR2 as NA, not negative. A fixed EMC RNA contrast adds transcript evidence but cannot resolve receptor subtype protein density or radioligand suitability.

**CD248:** Diaz et al. first-in-human MORAb004 study, Clin Cancer Res21:1281–8(2015), https://pmc.ncbi.nlm.nih.gov/articles/PMC4612616/ . Primary Table4 patient102-014 is labelled Myxoid chordrosarcoma, with stable disease and+10%best size change; this is not an objective response, and exact EMC subtype is not established there. Illustrated IHC biopsies in Fig2 are other patients, so this does not verify EMC tumor-cell CD248 protein. Rouleau et al.2008 DOI10.1158/1078-0432.CCR-08-0499 surveys sarcoma tumor, stroma and vascular compartments, but no direct EMC-specific tissue row was verified in this bounded task. Bulk RNA cannot separate those compartments. PMC normal web access returned captcha, EPMC fullTextXML404; primary indexed table text was accessible. No access bypass used.

## Complete fixed-panel status

| Target | Prior direct EMC tissue status verified in this bounded audit | What independent rank analysis adds / does not add |
|---|---|---|
| CD276/B7-H3 | No primary EMC-specific protein tissue result verified; patent cancer lists excluded | Cohort-specific RNA contrast; no tumor-surface density or ADC/CAR suitability |
| SSTR2 | Historical myxoid-CS receptor imaging with subtype uncertainty; no confirmed EMC-specific IHC cohort verified | RNA context; not receptor imaging or therapeutic validation |
| PRAME | Direct QR005 IHC negative0/5EMC;4documentedNR4A3confirmed | RNA/protein discordance assessment; not novel marker discovery or peptide-HLA proof |
| FAP | No direct EMC-specific FAP IHC/FAPI cohort verified in bounded search | Bulk RNA contrast; stromal vs malignant-cell origin unresolved |
| CD248 | Historical myxoid-CS phaseI patient; no verified EMC-cell IHC result | Bulk RNA contrast; cannot assign stromal/pericyte/tumor origin |
| CSPG4 | Existing primary-tissue audit found no verified EMC-specific spatial/protein result; named unresolved subtype tables retained | RNA comparison; not protein target validation |
| MSLN | No direct EMC-specific tissue result verified in bounded exact-term search | RNA contrast only |
| L1CAM | No direct EMC-specific tissue result verified in bounded exact-term search | RNA contrast only |
| GPC3 | No direct EMC-specific tissue result verified; conventional bone-CS evidence cannot substitute | RNA contrast only |
| ALPP | No direct EMC-specific tissue result verified in bounded exact-term search | RNA contrast only; HPA antibody multi-gene warning remains separate |
| CDH17 | No direct EMC-specific tissue result verified in bounded exact-term search | RNA contrast only |
| CHRNA6, separate | Established EMC RNA-CISH marker; GSE24369 discovery reused | Independent RNAseq/context-control replication, not discovery or protein validation |

CSPG4 audit reused: research/autonomy/cspg4-primary-tissue-evidence-2026-09-06/memo.md. Leuci2020PMC7710537 cohorts disclosed noEMC; Nota2022PMC9468862 is conventional/dedifferentiated bone chondrosarcoma. Cattaruzza2013PMC3656611 and Benassi2009PMID18634019 unresolved subtype information must remain unresolved; no unchanged failed-source retries undertaken.

## Hofvander novelty boundary

Hofvander et al.2026 DOI10.1158/1078-0432.CCR-25-3740 full main XML contains no exact fixed12gene-symbol matches (case-insensitive bounded token search). Main figures concern global diagnostic clustering, genomic complexity and CINSARC/prognosis; supplementary table inventories concern sample metadata, fusions and random-forest classifications, not this fixed therapeutic-address panel. Author repository tree includes diagnostic/clustering, MDM2/LMS markers and prognostic scripts. No prior fixed11+CHRNA6 EMC-versus-LGFMS therapeutic-address contrast was identified in the inspected main article, repository inventory and supplement schemas. Individual supplementary plot labels were not all re-read, so do not claim exhaustive absence. The cohort itself and its diagnostic clustering are published; reuse must be explicit.

The defensible contribution is an overlap-controlled fixed-panel, within-cohort rank-effect analysis with prespecified histology comparators and independent-platform replication, coupled to external protein/localization context and negative evidence. It is not de novo target discovery, normal-sparing or treatment selection. CHRNA6 serves an already established RNA-marker control; PRAME negative IHC is a required discordant layer. GSE24369 adds no new CHRNA6 patients. Stop any stronger novelty or targetability claim unless direct tissue/compartment or clinical evidence actually supports it.

## Search scope and limits

Targeted exact phrases included extraskeletal myxoid plus each fixed gene/name group, CHRNA6+GSE24369, endosialin/myxoid, MORAb004/myxoid, and the named somatostatin-imaging study. Patents, review cancer lists, conventional chondrosarcoma, comparator/differential mentions and cell-only studies were not counted as EMC tissue validation. Negative search status means not verified in this bounded audit, never absent from all literature. Sources are primary publisher/PubMed indexed text or exact public supplements; no new tumor RNA matrix values accessed.
