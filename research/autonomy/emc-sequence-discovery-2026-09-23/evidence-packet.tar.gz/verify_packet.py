"""Independent source/hash and arithmetic checks; does not import the scout."""
import csv
import gzip
import hashlib
import io
import json
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parent
checks=[]
def check(name,condition,detail=None):
    checks.append({'name':name,'passed':bool(condition),'detail':detail})
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
for filename in ['nuccore-retrieval.json','sra-retrieval.json','access-retrieval.json','candidate-reference-retrieval.json']:
    data=json.loads((ROOT/filename).read_text())
    rows=data if isinstance(data,list) else data.get('retrievals',[data])
    for row in rows:
        if 'path' in row and 'sha256' in row:
            check('source_hash:'+row['path'],digest(ROOT/row['path'])==row['sha256'])
for row in json.loads((ROOT/'local-input-manifest.json').read_text()):
    check('local_copy_hash:'+row['repository_path'],digest(ROOT/'sources/local'/Path(row['repository_path']).name)==row['sha256'])

summary=json.loads((ROOT/'sources/sra/summaries.json').read_text())['result']
controlled=0;runs=set()
for uid in summary['uids']:
    x=ET.fromstring('<r>'+summary[uid]['expxml']+'</r>')
    controlled+=x.find('.//ControlledAccess') is not None
    y=ET.fromstring('<r>'+summary[uid]['runs']+'</r>')
    runs.update(r.get('acc') for r in y)
check('sra_exact_disease_query_inventory',len(summary['uids'])==43 and controlled==22,{'experiment_records':len(summary['uids']),'controlled_access_experiments':controlled,'unique_runs':len(runs),'not_a_patient_count':True})

text=gzip.decompress((ROOT/'sources/access/GSM2113301_fusions.txt.gz').read_bytes()).decode()
lines=[line for line in text.splitlines() if line.strip()]
rows=[r for r in csv.DictReader(lines[1:],delimiter='\t') if 'NR4A3' in r["5'-3'Gene_Partners"]]
seams={r['Fusion_Sequence'].split('-')[0][-16:]+'|'+r['Fusion_Sequence'].split('-')[1][:16] for r in rows}
check('publisher_annotations_are_two_sequence_joins',len(rows)==16 and len(seams)==2,{'annotation_rows':len(rows),'distinct_32nt_seams':sorted(seams)})
cryptic=json.loads((ROOT/'sources/local/nr4a3-intron2-cryptic-exon.json').read_text())['resolved_cryptic_exon']['sequence']
native=ET.parse(ROOT/'sources/nuccore/NM_173200.gb.xml').getroot()[0]
native_seq=native.findtext('GBSeq_sequence').upper()
check('alternative_exon_is_known_normal_isoform_sequence',len(cryptic)==72 and cryptic in native_seq,{'reference':native.findtext('GBSeq_accession-version'),'length_nt':len(cryptic),'zero_based_position':native_seq.find(cryptic)})
alternative=[r for r in rows if r['Fusion_Sequence'].split('-')[1].startswith('GCCCTCATCACCTTTT')]
check('publisher_alternative_join_has_known_72nt_exon',len(alternative)==4 and all(r['Fusion_Sequence'].split('-')[1]==cryptic for r in alternative),{'annotation_rows':len(alternative),'limit':'The table stops at the 72nt exon; downstream transcript continuation is not shown. Initial verification incorrectly expected a downstream exon and is preserved in verification-initial.json.'})

benchmark=json.loads((ROOT/'benchmark-results.json').read_text())
check('benchmark_completed',benchmark['passed'] and all(r['passed'] for r in benchmark['checks']),{'checks':len(benchmark['checks']),'meaning':'Instrument checks, not biological validation'})
if (ROOT/'stream-pilot-result.json').exists():
    stream=json.loads((ROOT/'stream-pilot-result.json').read_text())
    check('stream_storage_bound',stream['compressed_bytes_read']<=64*1024*1024 and not stream['raw_file_saved'],{'compressed_bytes':stream['compressed_bytes_read'],'stopped_because':stream['stopped_because']})
    # Count preserved read examples with a literal seam, independently of classifier.
    literal='GTGGAATGGTTTGATGATATGCCCTGCGTCCA'
    rc=literal.translate(str.maketrans('ACGT','TGCA'))[::-1]
    examples=stream['screen']['examples']
    n=sum(literal in r['sequence'].upper() or rc in r['sequence'].upper() for r in examples)
    check('retained_known_seam_read_examples',n>0 if stream['screen']['counts'].get('known_partner_context',0)>0 else True,{'literal_seam_examples':n,'all_retained_examples':len(examples),'not_independent_molecule_count':True})
result={'passed':all(c['passed'] for c in checks),'checks':checks,'scope':'Source integrity, independently parsed counts and exact sequence identity. No independent agent review or clinical validation.'}
(ROOT/'verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'passed':result['passed'],'checks':len(checks),'failed':[c for c in checks if not c['passed']]},indent=2))
if not result['passed']:raise SystemExit(1)
