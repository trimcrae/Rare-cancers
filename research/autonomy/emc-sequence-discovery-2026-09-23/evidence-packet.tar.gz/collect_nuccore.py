"""Bounded read-only NCBI retrieval; saves source bytes, URLs and checksums.

No raw reads, full genomes, model calls, or third-party dependencies.
"""
import datetime as dt
import hashlib
import json
from pathlib import Path
import time
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
DEST = ROOT / "sources" / "nuccore"
DEST.mkdir(parents=True, exist_ok=True)
BASE = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/"
LIMIT = 2_000_000
queries = {
    "nr4a3_fusion": 'NR4A3[All Fields] AND (fusion[All Fields] OR chondrosarcoma[All Fields])',
    "chn_fusion": 'CHN[All Fields] AND (EWS[All Fields] OR TAF2N[All Fields] OR chondrosarcoma[All Fields])',
    "emc_disease": '"extraskeletal myxoid chondrosarcoma"[All Fields]',
}
receipt = {"started_utc": dt.datetime.now(dt.timezone.utc).isoformat(), "queries": {}, "retrievals": []}

def get(name, endpoint, parameters):
    url = BASE + endpoint + "?" + urllib.parse.urlencode(parameters)
    record = {"name": name, "url": url, "retrieved_utc": dt.datetime.now(dt.timezone.utc).isoformat()}
    try:
        request = urllib.request.Request(url, headers={"User-Agent": "EMC-bounded-public-sequence-audit/1.0"})
        with urllib.request.urlopen(request, timeout=40) as response:
            data = response.read(LIMIT + 1)
            record["status"] = response.status
        if len(data) > LIMIT:
            raise ValueError("Response exceeded 2 MB cap")
        path = DEST / name
        path.write_bytes(data)
        record.update(path=str(path.relative_to(ROOT)), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
        return data
    except Exception as exc:
        record["error"] = str(exc)
        return None
    finally:
        receipt["retrievals"].append(record)
        (ROOT / "nuccore-retrieval.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
        time.sleep(0.4)

uids = set()
for key, query in queries.items():
    payload = get(key + ".json", "esearch.fcgi", {"db": "nuccore", "term": query, "retmode": "json", "retmax": "100"})
    if payload:
        result = json.loads(payload)["esearchresult"]
        receipt["queries"][key] = {"term": query, "count": int(result["count"]), "ids": result["idlist"], "querytranslation": result.get("querytranslation"), "truncated": int(result["count"]) > len(result["idlist"])}
        uids.update(result["idlist"])
if uids:
    payload = get("summaries.json", "esummary.fcgi", {"db": "nuccore", "id": ",".join(sorted(uids)), "retmode": "json"})
    if payload:
        summaries = json.loads(payload)["result"]
        candidates = []
        for uid in summaries["uids"]:
            row = summaries[uid]
            title = row.get("title", "")
            relevant = any(word in title.lower() for word in ("fusion", "chimer", "chondrosarcoma"))
            if relevant and int(row.get("slen", 0)) <= 30_000:
                candidates.append({"uid": uid, "accession": row.get("accessionversion"), "title": title, "length": row.get("slen")})
        receipt["small_title_candidates"] = candidates
        if candidates:
            get("candidates.gb.xml", "efetch.fcgi", {"db": "nuccore", "id": ",".join(x["uid"] for x in candidates), "rettype": "gb", "retmode": "xml"})
receipt["finished_utc"] = dt.datetime.now(dt.timezone.utc).isoformat()
(ROOT / "nuccore-retrieval.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"counts": {k:v["count"] for k,v in receipt["queries"].items()}, "candidates": receipt.get("small_title_candidates", []), "errors": [r for r in receipt["retrievals"] if "error" in r]}, indent=2))
