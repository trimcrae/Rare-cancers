"""Record-aware NR4A3 acceptor scout, a screening instrument, not a fusion caller.

Uses four pinned acceptor starts, retains unknown upstream contexts, and reads
four-line FASTQ records. Cannot discover a different NR4A3 acceptor position.
Requires full-reference alignment and independent confirmation for novel calls.
"""
import collections
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
REPO = Path('C:/Projects/EMC-Research')
REF = ROOT / 'sources/local/aso-premrna-sequences.json'
COMP = str.maketrans('ACGTN', 'TGCAN')

def rc(s):
    return s.translate(COMP)[::-1]

class Scout:
    def __init__(self, reference=REF, flank=16):
        self.flank = flank
        self.genes = json.loads(Path(reference).read_text(encoding='utf-8'))['genes']
        self.acceptors = {}
        self.normal = {}
        self.donors = collections.defaultdict(list)
        self.counts = collections.Counter()
        self.contexts = collections.Counter()
        self.examples = []
        for gene, data in self.genes.items():
            if gene == 'NR4A3':
                continue
            for rank, (a,b) in enumerate(data['exon_spans_0based_inclusive'], 1):
                exon = data['sequence'][a:b+1].upper()
                if len(exon) >= flank:
                    self.donors[exon[-flank:]].append(f'{gene}_exon{rank}')
        g = self.genes['NR4A3']
        for rank in (2,3):
            a,b = g['exon_spans_0based_inclusive'][rank-1]
            pa,pb = g['exon_spans_0based_inclusive'][rank-2]
            label = f'NR4A3_exon{rank}_start'
            self.acceptors[label] = g['sequence'][a:a+flank].upper()
            self.normal[label] = {g['sequence'][a-flank:a].upper(), g['sequence'][pb-flank+1:pb+1].upper()}
        _,b = g['exon_spans_0based_inclusive'][1]
        self.acceptors['NR4A3_intron2_start'] = g['sequence'][b+1:b+1+flank].upper()
        self.normal['NR4A3_intron2_start'] = {g['sequence'][b-flank+1:b+1].upper()}
        cryptic = json.loads((ROOT/'sources/local/nr4a3-intron2-cryptic-exon.json').read_text(encoding='utf-8'))['resolved_cryptic_exon']['sequence'].upper()
        location = g['sequence'].upper().find(cryptic)
        if location < flank:
            raise ValueError('Annotated alternative exon missing from pinned genomic reference')
        label = 'NR4A3_alternative_exon_72nt_start'
        self.acceptors[label] = cryptic[:flank]
        self.normal[label] = {g['sequence'][location-flank:location].upper()}
        # A normal alternative transcript can contain the same internal exon.
        # Add its native splice contexts; do not confuse an internal splice with a fusion.
        native = ET.parse(ROOT/'sources/nuccore/NM_173200.gb.xml').getroot()[0].findtext('GBSeq_sequence').upper()
        for label, seed in self.acceptors.items():
            location = native.find(seed)
            while location >= 0:
                if location >= flank:
                    self.normal[label].add(native[location-flank:location])
                location = native.find(seed,location+1)

    def inspect(self, sequence):
        """Return events, preserving ambiguous donor matches instead of first-match wins."""
        seq = sequence.upper()
        events = []
        for strand, oriented in [('+',seq),('-',rc(seq))]:
            for site, seed in self.acceptors.items():
                position = oriented.find(seed)
                while position >= 0:
                    if position < self.flank:
                        category, tail, donors = 'insufficient_upstream', '', []
                    else:
                        tail = oriented[position-self.flank:position]
                        donors = self.donors.get(tail, [])
                        category = ('normal_reference_context' if tail in self.normal[site] else
                                    'known_partner_context' if len(donors)==1 else
                                    'ambiguous_partner_context' if donors else 'unassigned_context')
                    events.append({'site':site,'strand':strand,'position':position,'upstream':tail,'category':category,'donors':donors})
                    position = oriented.find(seed, position+1)
        return events

    def scan_fastq(self, handle):
        """Scan standard four-line FASTQ. Reject malformed/truncated input."""
        while True:
            header = handle.readline()
            if not header:
                break
            sequence, plus, quality = [handle.readline().rstrip('\r\n') for _ in range(3)]
            if not header.startswith('@') or not plus.startswith('+') or len(sequence)!=len(quality) or not sequence:
                raise ValueError('Malformed or truncated four-line FASTQ record')
            if set(sequence.upper())-set('ACGTN') or any(ord(c)<33 or ord(c)>126 for c in quality):
                raise ValueError('Invalid FASTQ sequence or quality character')
            self.counts['records'] += 1
            events = self.inspect(sequence)
            if events:
                self.counts['records_with_anchor'] += 1
            for event in events:
                self.counts[event['category']] += 1
                key = (event['site'],event['category'],event['upstream'],','.join(event['donors']))
                self.contexts[key] += 1
            if events and len(self.examples)<30:
                self.examples.append({'read_id':header.strip()[1:],'sequence':sequence,'quality':quality,'events':events})
        return {'counts':dict(self.counts),'contexts':[{'site':k[0],'category':k[1],'upstream':k[2],'donors':k[3],'occurrences':v} for k,v in sorted(self.contexts.items())], 'examples':self.examples,
                'limits':['Occurrences are not unique molecules or patients','Only four exact NR4A3 acceptor seeds are screened','Unknown context is not a fusion call','No genome-wide uniqueness, base-quality threshold, deduplication or statistical recurrence inference'],
                'reference_sha256':hashlib.sha256(REF.read_bytes()).hexdigest()}
