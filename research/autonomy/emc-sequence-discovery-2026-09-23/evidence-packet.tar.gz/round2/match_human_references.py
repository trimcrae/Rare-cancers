"""Whole-read exact matches to the bait-filtered human RefSeq transcriptome."""
import collections,gzip,hashlib,json,re,sys,time
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
from fish_reads import trie_pattern,rc

def main():
    capture=json.loads((ROOT/'human-reference-capture-result.json').read_text())
    if not capture.get('full_file_md5_verified'):raise ValueError('Reference capture is incomplete or unverified')
    records=[];snapshots=[];queries={}
    for f in sorted(ROOT.glob('*.matches.jsonl')):
        data=f.read_bytes();snapshots.append({'path':f.name,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
        for line in data.splitlines():
            try:r=json.loads(line)
            except json.JSONDecodeError:continue
            records.append(r)
            for s in [r['sequence'],rc(r['sequence'])]:queries.setdefault(s,[])
    seeds=collections.defaultdict(set)
    for q in queries:
        candidates=[q[i:i+24] for i in range(0,len(q)-23,4)]
        seed=max(candidates,key=lambda s:len({s[i:i+3] for i in range(22)}))
        seeds[seed].add(q)
    # Lookahead preserves overlapping equal-length seed matches.
    pattern=re.compile('(?=('+trie_pattern(seeds)+'))')
    examined=0;matched_references=0
    def visit(header,parts):
        nonlocal examined,matched_references
        if not header:return
        examined+=1;ref=''.join(parts);candidate_queries=set()
        for seed in {m.group(1) for m in pattern.finditer(ref)}:candidate_queries.update(seeds[seed])
        any_match=False
        for q in candidate_queries:
            at=ref.find(q)
            if at>=0:
                queries[q].append({'accession':header.split()[0][1:],'definition':header[1:],'start_0based':at});any_match=True
        matched_references+=any_match
    path=ROOT/'sources/human-refseq-bait-transcripts.fasta.gz'
    with gzip.open(path,'rt',encoding='ascii') as source:
        header=None;parts=[]
        for line in source:
            line=line.strip()
            if line.startswith('>'):visit(header,parts);header=line;parts=[]
            else:parts.append(line)
        visit(header,parts)
    matched=[];counts=collections.Counter()
    for r in records:
        placements=[]
        for strand,q in [('+',r['sequence']),('-',rc(r['sequence']))]:
            placements.extend(dict(x,strand=strand) for x in queries[q])
        if placements:
            counts[r['run']]+=1
            matched.append({'run':r['run'],'id':r['id'],'mate':r['mate'],'reference_matches':len(placements),'placements':placements[:10]})
    result={'method':'Full retained read exact match, both strands, against the complete GRCh38.p14 RefSeq RNA FASTA after lossless-for-exact-matches bait filtering. Includes NM/NR curated and XM/XR predicted records; not proof of experimentally validated normal isoforms or genome-wide unique alignment. Does not explain sequence variants or adapter-bearing reads.','reference_source':capture,'snapshots':snapshots,'retained_reference_transcripts_examined':examined,'transcripts_matching_reads':matched_references,'read_records':len(records),'exact_match_records':len(matched),'counts_by_run':dict(counts),'matches':matched}
    (ROOT/'human-reference-matches-current.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ['retained_reference_transcripts_examined','transcripts_matching_reads','read_records','exact_match_records','counts_by_run']}))
if __name__=='__main__':main()
