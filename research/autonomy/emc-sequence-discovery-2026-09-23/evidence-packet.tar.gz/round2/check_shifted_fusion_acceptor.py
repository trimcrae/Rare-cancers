"""Post hoc exact-read check of the single observed 42nt acceptor shift.

This candidate model is not a source-validated fusion transcript.
"""
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def main():
    known = json.loads((ROOT / 'known-fusion-alignment-current.json').read_text())
    gene = json.loads((ROOT.parent / 'sources/local/aso-premrna-sequences.json').read_text())['genes']['NR4A3']
    left = next(m['sequence'][:250] for m in known['models'] if m['name'] == 'canonical')
    right = gene['sequence'].upper()[6198:6498]
    model = left + right
    rc = lambda s: s.translate(str.maketrans('ACGTN', 'TGCAN'))[::-1]
    hits, sources = [], []
    for path in sorted(ROOT.glob('*.matches.jsonl')):
        data = path.read_bytes()
        sources.append({'file': path.name, 'sha256': hashlib.sha256(data).hexdigest()})
        for line in data.splitlines():
            r = json.loads(line)
            for strand, seq, quality in [('+', r['sequence'], r['quality']),
                                         ('-', rc(r['sequence']), r['quality'][::-1])]:
                start = model.find(seq)
                if start < 0 or not start < 250 < start + len(seq):
                    continue
                seam = 250 - start
                minimum_q = min(ord(c) - 33 for c in quality[max(0, seam - 20):seam + 20])
                hits.append({'source_read': r, 'strand': strand, 'model_start': start,
                             'left_anchor_nt': seam, 'right_anchor_nt': len(seq) - seam,
                             'minimum_20nt_flank_quality': minimum_q,
                             'qualifies': min(seam, len(seq) - seam) >= 20 and minimum_q >= 20})
    result = {'utc': datetime.now(timezone.utc).isoformat(), 'candidate': 'H11 exploratory shifted fusion acceptor',
              'trigger': 'SRR3380705.14843896 mate 2, identified in final unresolved-read alignment',
              'model_status': 'Post hoc computational model; not an experimentally validated transcript',
              'model_sequence': model, 'seam_position': 250,
              'seam_20nt_each_side': left[-20:] + right[:20],
              'nr4a3_acceptor_offset': 6198, 'shift_from_canonical_nt': 42,
              'source_snapshots': sources, 'hits': hits,
              'qualifying_fragment_ids': sorted({x['source_read']['id'].split()[0] for x in hits if x['qualifies']}),
              'interpretation': 'One high-quality full-read exact match across EWSR1 and the shifted NR4A3 acceptor. No second supporting fragment in the retained data. The NR4A3 acceptor itself occurs in GTEx junctions, but this does not establish prior observation of the EWSR1 fusion join. Fusion-join novelty and biological authenticity remain unresolved. Insufficient evidence for a paper or therapeutic claim.'}
    (ROOT / 'H11-shifted-fusion-acceptor.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'matching_records': len(hits), 'qualifying_fragments': result['qualifying_fragment_ids']}))

if __name__ == '__main__':
    main()
