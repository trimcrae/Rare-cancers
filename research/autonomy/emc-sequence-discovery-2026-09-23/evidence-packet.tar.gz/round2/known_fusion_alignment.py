"""Exact full-read checks of source-documented EWSR1-NR4A3 junctions.

The 72nt exon's downstream continuation is a separately labelled model; the
deposited V1-34 fusion report alone does not establish it.
"""
import collections,hashlib,json,sys
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent;PARENT=ROOT.parent
sys.path.insert(0,str(PARENT));from junction_scout import rc

def main():
    genes=json.loads((PARENT/'sources/local/aso-premrna-sequences.json').read_text())['genes']
    def cdna(gene,first,last=None):
        g=genes[gene];return ''.join(g['sequence'][a:b+1] for a,b in g['exon_spans_0based_inclusive'][first:last]).upper()
    left=cdna('EWSR1',0,12)[-250:];right=cdna('NR4A3',2)[:250]
    alt=json.loads((PARENT/'sources/local/nr4a3-intron2-cryptic-exon.json').read_text())['resolved_cryptic_exon']['sequence'].upper()
    assert left.endswith('GTGGAATGGTTTGATG') and right.startswith('ATATGCCCTGCGTCCA') and len(alt)==72
    models=[('canonical',left+right,[len(left)],'source documented'),('alternative_exon_entry',left+alt,[len(left)],'source documented up to end of the 72nt exon'),('alternative_exon_continuation_model',left+alt+right,[len(left),len(left)+72],'downstream continuation model; require read spanning both seams to phase fusion to continuation')]
    outputs=[];snapshots=[]
    for file in sorted(ROOT.glob('*.matches.jsonl')):
        data=file.read_bytes();snapshots.append({'file':file.name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
        for line in data.splitlines():
            try:r=json.loads(line)
            except json.JSONDecodeError:continue
            for strand,s,q in [('+',r['sequence'],r['quality']),('-',rc(r['sequence']),r['quality'][::-1])]:
                for name,ref,seams,status in models:
                    start=ref.find(s)
                    if start<0:continue
                    support=[]
                    for seam in seams:
                        pos=seam-start
                        if 20<=pos<=len(s)-20:
                            support.append({'seam':seam,'read_position':pos,'minimum_flank_quality':min(ord(c)-33 for c in q[pos-20:pos+20])})
                    if not support:continue
                    outputs.append({'run':r['run'],'id':r['id'],'fragment_id':r['id'].split()[0],'mate':r['mate'],'strand':strand,'model':name,'model_status':status,'start_in_model':start,'read_length':len(s),'supported_seams':support,'all_model_seams_phased':len(support)==len(seams),'all_flanks_q20':all(x['minimum_flank_quality']>=20 for x in support)})
    summaries=[]
    for run in sorted({r['run'] for r in outputs}):
        for name,_,_,_ in models:
            rows=[r for r in outputs if r['run']==run and r['model']==name and r['all_model_seams_phased'] and r['all_flanks_q20']]
            summaries.append({'run':run,'model':name,'qualifying_read_records':len(rows),'fragment_ids':len({r['fragment_id'] for r in rows}),'distinct_oriented_read_starts':len({r['start_in_model'] for r in rows})})
    out={'method':'Exact full-length retained reads; minimum 20nt on each side of seam, minimum Phred20 throughout these flanks. Distinct fragment IDs and oriented starts are reported separately; neither establishes unique original RNA molecules.','models':[{'name':n,'sequence':r,'seams':s,'status':t} for n,r,s,t in models],'snapshots':snapshots,'summaries':summaries,'supporting_records':outputs}
    (ROOT/'known-fusion-alignment-current.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(summaries))
if __name__=='__main__':main()
