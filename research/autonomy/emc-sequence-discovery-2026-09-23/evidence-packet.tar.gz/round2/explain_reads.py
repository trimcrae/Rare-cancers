"""Small transparent seeded local alignment for triage, not a genome-wide caller.

Matches +2, mismatches -3, linear gaps -4. Only windows supported by an exact
24nt seed in the bounded normal-reference set are aligned. No DLL/runtime install.
"""
import json,sys
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT));from analyze_matches import references,index_refs,rc

def local(target,query):
    n=len(query);h=[[0]*(n+1) for _ in range(len(target)+1)];best=(0,0,0)
    for i,a in enumerate(target,1):
        for j,b in enumerate(query,1):
            value=max(0,h[i-1][j-1]+(2 if a==b else -3),h[i-1][j]-4,h[i][j-1]-4)
            h[i][j]=value
            if value>best[0]:best=(value,i,j)
    score,i,j=best;end_i,end_j=i,j;ts=[];qs=[]
    while i and j and h[i][j]>0:
        if h[i][j]==h[i-1][j-1]+(2 if target[i-1]==query[j-1] else -3):ts.append(target[i-1]);qs.append(query[j-1]);i-=1;j-=1
        elif h[i][j]==h[i-1][j]-4:ts.append(target[i-1]);qs.append('-');i-=1
        else:ts.append('-');qs.append(query[j-1]);j-=1
    ts=''.join(ts[::-1]);qs=''.join(qs[::-1])
    return {'score':score,'target_start':i,'target_end':end_i,'query_start':j,'query_end':end_j,'target_alignment':ts,'query_alignment':qs,'matches':sum(a==b for a,b in zip(ts,qs)),'mismatches':sum(a!=b and a!='-' and b!='-' for a,b in zip(ts,qs)),'gap_columns':sum(a=='-' or b=='-' for a,b in zip(ts,qs))}

def main(run=None):
    refs=references();index=index_refs(refs);data=json.loads((ROOT/'analysis-current.json').read_text());outputs=[]
    for r in data['non_exact_records']:
        if r['category']!='unresolved_bait_read':continue
        if run is not None and r['run']!=run:continue
        best=None
        for strand,seq in [('+',r['sequence']),('-',rc(r['sequence']))]:
            offsets=set()
            for i in range(len(seq)-23):
                for name,pos in index.get(seq[i:i+24],[]):offsets.add((name,pos-i))
            for name,offset in offsets:
                start=max(0,offset-20);end=min(len(refs[name]),offset+len(seq)+20)
                if end<=start:continue
                result=local(refs[name][start:end],seq)
                result.update(reference=name,strand=strand,reference_window_start=start)
                result['target_start']+=start;result['target_end']+=start
                if best is None or result['score']>best['score']:best=result
        outputs.append({'read':r['id'],'mate':r['mate'],'minimum_base_quality':r['minimum_base_quality'],'best_seeded_normal_alignment':best,'limit':'Only bounded normal references. A partial match neither proves a chimera nor rules one out.'})
    output_name=f'unresolved-alignments-{run}.json' if run else 'unresolved-alignments-current.json'
    (ROOT/output_name).write_text(json.dumps(outputs,indent=2)+'\n')
    print(json.dumps([{'read':x['read'],'mate':x['mate'],'best':{k:x['best_seeded_normal_alignment'][k] for k in ['reference','score','query_start','query_end','mismatches','gap_columns']} if x['best_seeded_normal_alignment'] else None} for x in outputs],indent=2))
if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('--run')
    main(parser.parse_args().run)
