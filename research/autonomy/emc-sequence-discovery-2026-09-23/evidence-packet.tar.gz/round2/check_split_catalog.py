"""Check exact small-indel split explanations against primary Ensembl records.

No genotype, tumor-specificity, or clinical interpretation is performed.
"""
import collections
import hashlib
import json
import urllib.request
import urllib.error
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def main():
    frozen = ROOT / 'usz-final-analysis.json'
    source = json.loads(frozen.read_text())
    gene = json.loads((ROOT.parent / 'sources/local/aso-premrna-sequences.json').read_text())['genes']['NR4A3']
    seq, origin = gene['sequence'].upper(), gene['genomic_start']
    groups = collections.defaultdict(list)
    for r in source['exact_split_records']:
        s = r['solutions'][0]
        if abs(s['jump']) <= 10:
            groups[(s['jump'], s['left_end'] // 100)].append(r)
    output = []
    for (jump, region), rows in groups.items():
        positions = [v['left_end'] for r in rows for v in r['solutions']]
        lo, hi = min(positions) + origin - 40, max(positions) + origin + 40
        url = f'https://rest.ensembl.org/overlap/region/human/9:{lo}-{hi}?feature=variation;content-type=application/json'
        path = ROOT / 'sources' / f'usz-split-variation-{lo}-{hi}.json'
        receipt_path = path.with_suffix('.retrieval.json')
        if not path.exists() and receipt_path.exists():
            receipt = json.loads(receipt_path.read_text())
            if receipt.get('failed_attempts'):
                output.append({'jump_nt': jump, 'genomic_region': [lo, hi],
                               'read_records': len(rows), 'status': 'catalog_retrieval_failed',
                               'retrieval_receipt': receipt_path.name,
                               'distinct_oriented_intervals': sorted({(s['strand'], s['left_start'], s['right_end']) for r in rows for s in r['solutions']}),
                               'known_allele_explanations': []})
                continue
        if not path.exists():
            req = urllib.request.Request(url, headers={'User-Agent': 'EMC-research-bounded-public-data/1.0'})
            attempts = []
            for attempt in range(3):
                try:
                    with urllib.request.urlopen(req, timeout=45) as response:
                        payload = response.read(2_000_001)
                    break
                except (urllib.error.URLError, TimeoutError) as exc:
                    attempts.append({'utc': datetime.now(timezone.utc).isoformat(), 'error': str(exc)})
                    if attempt == 2:
                        receipt_path.write_text(json.dumps({'url': url, 'failed_attempts': attempts}, indent=2) + '\n')
                        raise
                    time.sleep(3)
            assert len(payload) <= 2_000_000
            json.loads(payload)
            path.write_bytes(payload)
            receipt_path.write_text(json.dumps({'url': url, 'utc': datetime.now(timezone.utc).isoformat(),
                'sha256': hashlib.sha256(payload).hexdigest(), 'failed_attempts': attempts}, indent=2) + '\n')
        variants = json.loads(path.read_text())
        hits = []
        for v in variants:
            if v.get('assembly_name') != 'GRCh38' or v.get('strand') != 1:
                continue
            a, b = v['start'] - origin, v['end'] - origin + 1
            if a < 0 or b < a or b > len(seq):
                continue
            ref = v['alleles'][0].replace('-', '')
            if seq[a:b] != ref:
                continue
            for allele in v['alleles'][1:]:
                alt = allele.replace('-', '')
                if set(alt) - set('ACGT') or len(ref) == len(alt):
                    continue
                modified = seq[:a] + alt + seq[b:]
                matching = []
                for r in rows:
                    q = r['sequence']
                    reverse = q.translate(str.maketrans('ACGT', 'TGCA'))[::-1]
                    if q in modified or reverse in modified:
                        matching.append({'id': r['id'], 'mate': r['mate']})
                if matching:
                    hits.append({'id': v['id'], 'start': v['start'], 'end': v['end'],
                                 'ref': ref, 'alt': alt, 'matching_records': matching})
        starts = sorted({(s['strand'], s['left_start'], s['right_end']) for r in rows for s in r['solutions']})
        output.append({'jump_nt': jump, 'genomic_region': [lo, hi], 'source': path.name,
                       'source_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                       'read_records': len(rows), 'fragment_ids': len({r['id'].split()[0] for r in rows}),
                       'distinct_oriented_intervals': starts, 'known_allele_explanations': hits,
                       'records': [{'id': r['id'], 'mate': r['mate']} for r in rows]})
    result = {'utc': datetime.now(timezone.utc).isoformat(), 'input_sha256': hashlib.sha256(frozen.read_bytes()).hexdigest(),
              'groups': output, 'scope': 'Single catalog allele applied to pinned genomic reference; exact full-read explanation. Catalog absence does not prove novelty. Read/fragment counts do not establish independent molecules. No tumor-specificity or genotype claim.'}
    (ROOT / 'usz-small-indel-catalog-check.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps([{'jump': x['jump_nt'], 'region': x['genomic_region'], 'records': x['read_records'],
                      'intervals': len(x['distinct_oriented_intervals']),
                      'catalog_ids': [h['id'] for h in x['known_allele_explanations']]} for x in output]))

if __name__ == '__main__':
    main()
