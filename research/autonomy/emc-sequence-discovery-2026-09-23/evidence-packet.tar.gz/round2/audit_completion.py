"""Reconcile the final decision's quantitative claims with retained source evidence.

This audit does not prove biological absence or independently peer-review the science.
"""
import collections
import csv
import gzip
import hashlib
import json
import shutil
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PARENT = ROOT.parent

def read(name):
    return json.loads((ROOT / name).read_text())

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    rc = lambda s: s.translate(str.maketrans('ACGTN', 'TGCAN'))[::-1]
    checks, raw, transport = [], [], []
    for run in ['SRR3380704', 'SRR3380705', 'SRR33903995']:
        metadata_path = PARENT / 'sources/access' / (run + '.json')
        metadata = json.loads(metadata_path.read_text())[0]
        for mate in (1, 2):
            receipt = read(f'{run}_R{mate}.result.json')
            path = ROOT / f'{run}_R{mate}.matches.jsonl'
            rows = [json.loads(line) for line in path.read_bytes().splitlines()]
            assert receipt['source_metadata_sha256'] == sha(metadata_path)
            assert receipt['matches_sha256'] == sha(path)
            assert len(rows) == receipt['bait_records']
            for r in rows:
                assert r['run'] == run and r['mate'] == mate
                assert len(r['sequence']) == len(r['quality'])
                assert r['bait'] in r['sequence']
            complete = receipt.get('full_file_md5_verified') is True
            if run != 'SRR3380704':
                assert complete and receipt['stopped_because'] == 'eof'
                assert receipt['records'] == int(metadata['read_count'])
                assert receipt['compressed_bytes'] == int(metadata['fastq_bytes'].split(';')[mate - 1])
                assert receipt['compressed_md5'] == metadata['fastq_md5'].split(';')[mate - 1]
            else:
                assert not complete and receipt['records'] < int(metadata['read_count'])
            transport.append({'run': run, 'mate': mate, 'records': receipt['records'],
                              'retained_records': len(rows), 'complete_md5_verified': complete})
            raw.extend(rows)
    checks.append('All six retained-file hashes, metadata hashes, record/quality lengths and retained counts verified; four complete files match ENA sizes, record counts and MD5 receipts; original V1 prefixes remain partial.')
    assert sum(x['records'] for x in transport) == 132380492
    assert len(raw) == 5497
    models = read('known-fusion-alignment-current.json')['models']
    recomputed = []
    for run in ['SRR3380705', 'SRR33903995']:
        frozen = read('v1-replication-final-analysis.json' if run == 'SRR3380705' else 'usz-final-analysis.json')
        for model in models:
            qualified = []
            for r in raw:
                if r['run'] != run:
                    continue
                for seq, quality in [(r['sequence'], r['quality']), (rc(r['sequence']), r['quality'][::-1])]:
                    start = model['sequence'].find(seq)
                    if start < 0:
                        continue
                    positions = [seam - start for seam in model['seams']]
                    if not all(20 <= pos <= len(seq) - 20 for pos in positions):
                        continue
                    if not all(min(ord(q) - 33 for q in quality[pos - 20:pos + 20]) >= 20 for pos in positions):
                        continue
                    qualified.append((r['id'].split()[0], start))
            observed = {'run': run, 'model': model['name'], 'qualifying_read_records': len(qualified),
                        'fragment_ids': len({x[0] for x in qualified}),
                        'distinct_oriented_read_starts': len({x[1] for x in qualified})}
            expected = next(x for x in frozen['known_fusion_summaries'] if x['model'] == model['name'])
            assert observed == expected
            recomputed.append(observed)
    checks.append('Recomputed strict known-fusion counts directly from retained sequences and qualities; all frozen summaries agree.')
    seam = read('H05-repeat-junction-initial.json')
    # The candidate seam is specified independently of the frozen hit lists.
    motif = 'GCCCTTGTCCGAGCTTTAACAGGAACCTTCTCAGCCCTCT'
    hit_rows = [r for r in raw if motif in r['sequence'] or motif in rc(r['sequence'])]
    assert len(hit_rows) == 2
    assert {r['id'].split()[0] for r in hit_rows} == {'SRR3380704.11936220'}
    checks.append('H05 exact seam recomputed across all 5,497 retained records: two mates from one original fragment; zero in either completed later run.')
    gtex_path = ROOT / 'sources/nr4a3-gtex-junction-background.txt'
    assert sha(gtex_path) == read('nr4a3-gtex-junction-background-retrieval.json')['sha256']
    gtex = list(csv.DictReader(gtex_path.read_text().splitlines(), delimiter='\t'))
    for start, end, samples, coverage in [(99823946, 99825658, 101, 113), (99826802, 99828082, 1019, 1779)]:
        hits = [r for r in gtex if r['start'] == str(start) and r['end'] == str(end) and r['strand'] == '+']
        assert len(hits) == 1
        assert int(hits[0]['samples_count']) == samples and int(hits[0]['coverage_sum']) == coverage
    checks.append('Both normal-background splice counts checked against the hash-verified primary GTEx response, with assembly/coordinate limitations retained.')
    h11 = read('H11-shifted-fusion-acceptor.json')
    assert h11['qualifying_fragment_ids'] == ['SRR3380705.14843896']
    assert len(h11['hits']) == 1 and h11['hits'][0]['qualifies']
    events = read('all-runs-exact-event-recurrence.json')
    assert events['source_sha256'] == sha(ROOT / 'exact-split-triage-current.json')
    assert all(r['fragments'] == 1 for r in events['groups'] if r['jump_nt'] < -10)
    checks.append('All large repeat-like exact-split groups remain single-fragment observations; H11 remains one fragment. No novelty or biological validation inferred.')
    preserved = read('usz-analysis-preservation.json')
    for item in preserved['files']:
        path = ROOT / item['preserved']
        assert sha(path) == item['compressed_sha256']
        recovered = gzip.decompress(path.read_bytes())
        assert hashlib.sha256(recovered).hexdigest() == item['uncompressed_sha256']
    checks.append('All five archived USZ analysis outputs decompress to their original hashes; premature mixed-generation snapshot remains explicitly invalid.')
    assert read('blast-expanded-analysis.json')['source_sha256'] == sha(ROOT / 'sources/blast-expanded-complete.json')
    assert read('blast-expanded-analysis.json')['queries_verified'] == 16
    assert len(read('unresolved-alignments-SRR3380705.json')) == 135
    assert shutil.disk_usage(ROOT).free > 10 * 1024**3
    output = {'utc': datetime.now(timezone.utc).isoformat(), 'audit_status': 'passed', 'checks': checks,
              'transport': transport, 'known_fusion_recomputed': recomputed,
              'total_records': 132380492, 'total_bait_retained': 5497,
              'decision': 'No-go: no candidate meets the combined novelty, independent-support and utility threshold under currently accessible data and validation resources.',
              'requirements': [
                  {'requirement': 'Actual sequence investigation with known positive controls', 'evidence': 'Completed four full source streams, two preserved partial streams, exact known-fusion recovery and original known-answer checks.'},
                  {'requirement': 'Check apparent novelty and replication', 'evidence': 'Normal RefSeq, catalogue, GTEx and BLAST comparisons; completed second V1 run; retained single-fragment candidates rather than unsupported novelty claims.'},
                  {'requirement': 'Paper-worthy finding or defensible fruitlessness judgment', 'evidence': 'DECISION.md explains the no-go, residual hypotheses, data-access limits and conditions for reopening. This is a scientific judgment, not an exhaustive absence theorem.'},
                  {'requirement': 'Accurate scope and operating-state reporting', 'evidence': 'Four full files versus two partial files distinguished; two models versus independent patients distinguished; terminal collector and analysis handles observed; pending workers and unresolved remote query explicitly disclosed.'}],
              'limits': ['Not independent peer review or an exhaustive genome-wide analysis.', 'Source-stream MD5s are recorded by the observed completed collectors; raw FASTQ files were not retained for a second offline hash pass.', 'No wet-lab, clinical, somatic-origin or therapeutic-effect claim.', 'An unresolved reference query cannot supply missing replication; waiting is not treated as a negative result.']}
    (ROOT / 'completion-audit.json').write_text(json.dumps(output, indent=2) + '\n')
    print(json.dumps({'status': output['audit_status'], 'checks': len(checks), 'records': output['total_records'], 'retained': len(raw)}))

if __name__ == '__main__':
    main()
