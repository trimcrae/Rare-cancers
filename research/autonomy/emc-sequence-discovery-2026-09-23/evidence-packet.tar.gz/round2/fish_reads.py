"""Broad NR4A3 exact-bait collection; keeps source reads for subsequent alignment.

Memory-only gzip streaming. A retained read is NOT a fusion call.
"""
import argparse, datetime as dt, gzip, hashlib, io, json, re, sys, time, urllib.request
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
PARENT=ROOT.parent
sys.path.insert(0,str(PARENT))
from junction_scout import Scout,rc
from resilient_reader import Reader,EndBudget

def trie_pattern(words):
    root={}
    for word in words:
        node=root
        for c in word:node=node.setdefault(c,{})
        node['']=None
    def emit(node):
        branches=[re.escape(c)+emit(n) for c,n in node.items() if c]
        if '' in node:branches.append('')
        return branches[0] if len(branches)==1 else '(?:'+'|'.join(branches)+')'
    return emit(root)

def bait_sequences():
    g=json.loads((PARENT/'sources/local/aso-premrna-sequences.json').read_text())['genes']['NR4A3']
    seq=g['sequence'].upper()
    exons=[seq[a:b+1] for a,b in g['exon_spans_0based_inclusive']]
    cryptic=json.loads((PARENT/'sources/local/nr4a3-intron2-cryptic-exon.json').read_text())['resolved_cryptic_exon']['sequence']
    # Overlapping 24nt baits every 16nt within each exon, plus exact known acceptors.
    words=set()
    for exon in exons+[cryptic]:
        for i in range(0,len(exon)-23,16):words.add(exon[i:i+24])
        if len(exon)>=24:words.add(exon[-24:])
    words.update(Scout().acceptors.values())
    return sorted(words|{rc(s) for s in words})


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--run',required=True);ap.add_argument('--mate',type=int,choices=[1,2],required=True);ap.add_argument('--seconds',type=int,default=3600);ap.add_argument('--max-bytes',type=int,default=2500000000);ap.add_argument('--benchmark-only',action='store_true');args=ap.parse_args()
    words=bait_sequences();pattern=re.compile(trie_pattern(words));t0=time.monotonic()
    # Ensure raw positive examples and reverse complements are actually baited.
    examples=json.loads((PARENT/'sources/local/emc-fusion-read-scan.json').read_text())['runs'][0]['junctions_found'][0]['example_reads']
    if not all(pattern.search(s) and pattern.search(rc(s)) for s in examples):raise ValueError('bait known-answer failure')
    if args.benchmark_only:
        for _ in range(10000):pattern.search('ACGT'*38)
        print(json.dumps({'baits':len(words),'negative_sequences':10000,'seconds':time.monotonic()-t0,'known_examples_passed':True}));return
    name=f'{args.run}_R{args.mate}'
    if (ROOT/(name+'.matches.jsonl')).exists() or (ROOT/(name+'.result.json')).exists():raise FileExistsError('Preserve prior attempts before rerunning this run/mate')
    metadata=PARENT/'sources/access'/f'{args.run}.json'
    meta=json.loads(metadata.read_text())[0]
    url='https://'+meta['fastq_ftp'].split(';')[args.mate-1]
    expected_md5=meta.get('fastq_md5','').split(';')
    result={'run':args.run,'mate':args.mate,'url':url,'started_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'source_metadata_sha256':hashlib.sha256(metadata.read_bytes()).hexdigest(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'bait_count':len(words),'bait_sha256':hashlib.sha256('\n'.join(words).encode()).hexdigest(),'records':0,'bait_records':0,'retained_bytes':0,'sampling':'sequential file stream; partial unless EOF and integrity verified','stopped_because':None}
    def checkpoint(reader=None):
        result['elapsed_seconds']=round(time.monotonic()-t0,3)
        result['compressed_bytes']=reader.n if reader else 0
        result['reconnections']=reader.reconnections if reader else []
        result['reader_sha256']=hashlib.sha256((ROOT/'resilient_reader.py').read_bytes()).hexdigest()
        out=ROOT/(name+'.progress.json');tmp=ROOT/(name+'.progress.tmp');tmp.write_text(json.dumps(result,indent=2)+'\n');tmp.replace(out)
    reader=None
    try:
        with urllib.request.urlopen(url,timeout=35) as response, (ROOT/(name+'.matches.jsonl')).open('w',encoding='utf-8') as out:
            reader=Reader(response,args.max_bytes,t0+args.seconds,url,int(meta['fastq_bytes'].split(';')[args.mate-1]))
            with io.TextIOWrapper(gzip.GzipFile(fileobj=io.BufferedReader(reader,65536)),encoding='ascii') as text:
                while True:
                    header=text.readline()
                    if not header:result['stopped_because']='eof';break
                    seq,plus,qual=[text.readline().rstrip('\r\n') for _ in range(3)]
                    if not header.startswith('@') or not plus.startswith('+') or not seq or len(seq)!=len(qual):raise ValueError('malformed/truncated record')
                    result['records']+=1
                    hit=pattern.search(seq)
                    if hit:
                        row={'run':args.run,'mate':args.mate,'record_number':result['records'],'id':header.strip()[1:],'sequence':seq,'quality':qual,'bait':hit.group()}
                        line=json.dumps(row,separators=(',',':'))+'\n';out.write(line);result['bait_records']+=1;result['retained_bytes']+=len(line.encode())
                        if result['bait_records']>=20000 or result['retained_bytes']>=30000000:raise EndBudget('retention_budget')
                    if result['records']%100000==0:out.flush();checkpoint(reader)
    except EndBudget as e:result['stopped_because']=str(e)
    except Exception as e:result.update(stopped_because='error',error=repr(e))
    if reader:
        result['compressed_sha256']=reader.digest.hexdigest();result['compressed_md5']=reader.md5.hexdigest()
        result['expected_md5']=expected_md5[args.mate-1] if len(expected_md5)>=args.mate else None
        result['full_file_md5_verified']=result['stopped_because']=='eof' and result['compressed_md5']==result['expected_md5']
    checkpoint(reader);result['finished_utc']=dt.datetime.now(dt.timezone.utc).isoformat()
    result['matches_sha256']=hashlib.sha256((ROOT/(name+'.matches.jsonl')).read_bytes()).hexdigest() if (ROOT/(name+'.matches.jsonl')).exists() else None
    (ROOT/(name+'.result.json')).write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
