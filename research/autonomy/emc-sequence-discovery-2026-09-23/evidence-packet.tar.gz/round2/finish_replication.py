"""Bounded continuation of the already-running replication, without new downloads.

Waits for terminal collector receipts, runs the four exact-analysis stages once,
and freezes results only for verified complete files. It makes no discovery call.
"""
import hashlib
import json
import subprocess
import sys
import time
from datetime import datetime, timezone, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def main():
    deadline = datetime(2026, 9, 24, 3, 20, tzinfo=timezone.utc)
    receipt_paths = [ROOT / f'SRR3380705_R{mate}.result.json' for mate in (1, 2)]
    marker = ROOT / 'replication-finish-started.json'
    with marker.open('x') as out:
        json.dump({'utc': datetime.now(timezone.utc).isoformat(), 'deadline': deadline.isoformat(),
                   'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}, out, indent=2)
    while not all(path.exists() for path in receipt_paths):
        if datetime.now(timezone.utc) >= deadline:
            raise TimeoutError('Collector receipts did not both arrive before continuation deadline; do not relaunch streams')
        time.sleep(20)
    # Receipts are small, but allow terminal writes to close before reading.
    time.sleep(2)
    receipts = [json.loads(path.read_text()) for path in receipt_paths]
    print('Both terminal collector receipts are present.', flush=True)
    for name in ('analyze_matches.py', 'split_triage.py', 'known_fusion_alignment.py', 'match_human_references.py'):
        remaining = (deadline - datetime.now(timezone.utc)).total_seconds()
        if remaining <= 0:
            raise TimeoutError('Continuation deadline reached')
        with (ROOT / ('replication-' + name + '.log')).open('w') as log:
            subprocess.run([sys.executable, str(ROOT / name)], cwd=ROOT, stdout=log,
                           stderr=subprocess.STDOUT, timeout=min(300, remaining), check=True)
        print(name + ' completed.', flush=True)
    complete = all(r.get('stopped_because') == 'eof' and r.get('full_file_md5_verified') for r in receipts)
    if complete:
        subprocess.run([sys.executable, str(ROOT / 'freeze_run_analysis.py'),
                        'SRR3380705', 'v1-replication-final-analysis.json'], cwd=ROOT, check=True, timeout=60)
    status = {'utc': datetime.now(timezone.utc).isoformat(), 'both_files_complete_verified': complete,
              'collectors': [{'mate': r['mate'], 'stop': r['stopped_because'], 'records': r['records'],
                              'full_file_md5_verified': r.get('full_file_md5_verified', False)} for r in receipts],
              'four_analysis_stages_completed': True,
              'next_action': 'Review H05 fragment/start evidence and remaining candidates, then make the scientific go/no-go decision. This process makes no discovery or fruitlessness claim.'}
    (ROOT / 'replication-finish-result.json').write_text(json.dumps(status, indent=2) + '\n')
    print(json.dumps(status), flush=True)

if __name__ == '__main__':
    main()
