"""Exact two-block NR4A3 triage. Split support is not a biological event call."""
import hashlib,json,sys
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from analyze_matches import references,rc

def occurrences(target,query):
    at=target.find(query)
    while at>=0:
        yield at
        at=target.find(query,at+1)

def main():
    ref=references()['NR4A3:genomic']
    source=ROOT/'analysis-current.json';data=json.loads(source.read_text());out=[]
    for row in data['non_exact_records']:
        if row['category']!='unresolved_bait_read':continue
        solutions=[]
        for strand,seq in [('+',row['sequence']),('-',rc(row['sequence']))]:
            for split in range(20,len(seq)-19):
                left=list(occurrences(ref,seq[:split]));right=list(occurrences(ref,seq[split:]))
                for a in left:
                    for b in right:
                        solutions.append({'strand':strand,'split':split,'left_start':a,'left_end':a+split,'right_start':b,'right_end':b+len(seq)-split,'jump':b-(a+split)})
        if solutions:
            out.append({'id':row['id'],'mate':row['mate'],'minimum_base_quality':row['minimum_base_quality'],'sequence':row['sequence'],'solutions':solutions})
    result={'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'reference_sha256':hashlib.sha256(ref.encode()).hexdigest(),'coordinates':'0-based half-open offsets in pinned NR4A3 genomic sequence; negative jump can be repeat ambiguity or backsplice/duplication; not proof of circular RNA','minimum_block_nt':20,'records':out}
    (ROOT/'exact-split-triage-current.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps([{'id':r['id'],'mate':r['mate'],'minq':r['minimum_base_quality'],'jumps':sorted({x['jump'] for x in r['solutions']}),'solutions':len(r['solutions'])} for r in out],indent=2))
if __name__=='__main__':main()
