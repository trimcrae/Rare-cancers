"""Stream the human RefSeq RNA FASTA; retain only transcripts matching our baits.

Because the same strand-symmetric baits captured the raw reads, every exact
reference explanation of a retained read must also contain a capture bait.
This is an exact-match completeness property, not sensitivity to mismatches.
"""
import datetime as dt,gzip,hashlib,io,json,re,sys,time,urllib.request
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
from fish_reads import bait_sequences,trie_pattern
from resilient_reader import Reader,EndBudget

def main():
    meta=json.loads((ROOT/'refseq-transcriptome-metadata.json').read_text())
    url=meta['url'];expected=int(meta['length']);expected_md5=meta['expected_md5_line'][0].split()[0]
    pattern=re.compile(trie_pattern(bait_sequences()));t0=time.monotonic()
    outpath=ROOT/'sources/human-refseq-bait-transcripts.fasta.gz'
    if outpath.exists():raise FileExistsError('Preserve existing capture')
    result={'source_url':url,'started_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'source_expected_md5':expected_md5,'source_expected_bytes':expected,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'transcripts_examined':0,'transcripts_retained':0,'retained_uncompressed_bytes':0,'status':None,'limit':'600 seconds; at most 30MB uncompressed retained references; source FASTA not stored'}
    reader=None
    try:
        with urllib.request.urlopen(url,timeout=35) as response,gzip.open(outpath,'wt',encoding='ascii',newline='\n') as out:
            reader=Reader(response,expected+1,t0+600,url,expected)
            def visit(header,parts):
                if not header:return
                sequence=''.join(parts).upper();result['transcripts_examined']+=1
                if pattern.search(sequence):
                    record=header+'\n'+sequence+'\n'
                    if result['retained_uncompressed_bytes']+len(record)>30000000:raise EndBudget('reference_retention_budget')
                    out.write(record);result['transcripts_retained']+=1;result['retained_uncompressed_bytes']+=len(record)
            with io.TextIOWrapper(gzip.GzipFile(fileobj=io.BufferedReader(reader)),encoding='ascii') as source:
                header=None;parts=[]
                for line in source:
                    line=line.rstrip('\r\n')
                    if line.startswith('>'):visit(header,parts);header=line;parts=[]
                    else:parts.append(line)
                visit(header,parts)
            result['status']='eof'
    except Exception as error:result.update(status='error',error=repr(error))
    result.update(finished_utc=dt.datetime.now(dt.timezone.utc).isoformat(),elapsed_seconds=round(time.monotonic()-t0,3))
    if reader:result.update(compressed_bytes=reader.n,source_md5=reader.md5.hexdigest(),source_sha256=reader.digest.hexdigest(),reconnections=reader.reconnections,full_file_md5_verified=result['status']=='eof' and reader.md5.hexdigest()==expected_md5)
    result['retained_gzip_bytes']=outpath.stat().st_size;result['retained_sha256']=hashlib.sha256(outpath.read_bytes()).hexdigest()
    (ROOT/'human-reference-capture-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
if __name__=='__main__':main()
