"""Reconnect a live compressed stream without discarding its gzip decoder state.

This cannot resume a terminated process. Full source MD5 remains the caller's
integrity check at EOF. Wrong Range responses are rejected, never appended.
"""
import hashlib,io,re,time,urllib.request

class EndBudget(Exception):pass

class Reader(io.RawIOBase):
    def __init__(self,response,cap,deadline,url,expected_bytes,opener=urllib.request.urlopen):
        self.response=response;self.cap=cap;self.deadline=deadline;self.url=url
        self.expected_bytes=expected_bytes;self.opener=opener;self.n=0
        self.digest=hashlib.sha256();self.md5=hashlib.md5();self.reconnections=[]
    def readable(self):return True
    def reconnect(self,reason):
        if len(self.reconnections)>=5:raise OSError('five reconnections exhausted')
        self.response.close()
        event={'offset':self.n,'reason':reason,'status':'attempting'}
        self.reconnections.append(event)
        req=urllib.request.Request(self.url,headers={'Range':f'bytes={self.n}-','Accept-Encoding':'identity'})
        response=self.opener(req,timeout=35)
        value=response.headers.get('Content-Range','')
        match=re.fullmatch(r'bytes (\d+)-(\d+)/(\d+)',value)
        if response.status!=206 or not match or int(match[1])!=self.n or int(match[3])!=self.expected_bytes or int(match[2])!=self.expected_bytes-1:
            response.close();event['status']='rejected';raise ValueError('resume response has wrong status, byte range or object length')
        self.response=response;event['status']='accepted';event['content_range']=value
    def readinto(self,b):
        while True:
            if time.monotonic()>self.deadline:raise EndBudget('wall_budget')
            if self.n==self.expected_bytes:return 0
            if self.n>=self.cap:raise EndBudget('transfer_budget')
            try:
                data=self.response.read(min(len(b),self.cap-self.n,self.expected_bytes-self.n,65536))
            except (OSError,EOFError) as error:
                self.reconnect(repr(error));continue
            if not data:
                self.reconnect('premature EOF');continue
            b[:len(data)]=data;self.n+=len(data);self.digest.update(data);self.md5.update(data)
            return len(data)
    def close(self):
        if not self.closed:self.response.close()
        super().close()
