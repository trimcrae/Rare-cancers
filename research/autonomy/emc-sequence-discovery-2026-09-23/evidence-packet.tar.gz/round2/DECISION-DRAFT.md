# EMC sequence-discovery decision — draft, replication pending

This is a decision about the proposed open-ended public EMC sequence-mining campaign. It is not a conclusion that EMC research, computational biology, or parallel agents are fruitless. The final V1-34 run is still being collected; no final go/no-go decision is recorded here.

## What would justify a paper

The original question was whether accessible EMC data contain recurrent transcript features missed by existing annotations or target designs. A useful result needs a nontrivial new observation, credible evidence separating it from known human sequences and technical artifacts, and a coherent biological or methodological contribution. A pile of unexplained short reads does not meet that standard. Neither do repeated database annotations, two mates from one fragment, or multiple run accessions from one sample.

## Evidence already settled

- **Known fusion recovered.** The complete USZ-23_EMC3 dataset contains 53,890,034 read records, with both source MD5s verified. The strict exact-read junction check finds 102 qualifying reads, 88 fragment IDs and 22 oriented starts across the established EWSR1–NR4A3 join. Those counts are not unique original molecules. See `usz-final-analysis.json`.
- **Known alternative exon.** The publisher's V1-34 fusion output has two distinct entry joins after collapsing annotation rows. The 72-nt alternative exon already occurs in the repository's evidence and normal RefSeq NM_173200.3. Its recovery would confirm known biology, not discover a new target.
- **Variants, not novel events.** Full-read explanations include catalogued rs3837280, rs753648433, rs202143889 and rs1180697223. A recurrent UTR mismatch corresponds to rs141819687. These checks do not establish a genotype, somatic origin or clinical consequence. Some short-indel groups remain unassigned; they have one oriented read interval, and one catalogue lookup failed.
- **Apparent novel splice already observed outside this model.** The H06 upstream junction is called in 101 GTEx samples, with 113 junction reads. The USZ evidence is four read IDs but one distinct oriented sequence. GTEx samples are not necessarily distinct donors, and its calls are not functional isoform validation. See `H06-upstream-splice-disposition.json`.
- **H05 repeat remains provisional.** Two mates from one V1-34 fragment support a 70-nt within-exon repeat. They agree over 84 nt and have adequate junction-flank quality. The event is not phased to EWSR1, all microhomology-equivalent placements lack canonical GT/AG boundaries, and RT/library artifacts remain plausible. The completed independent model has no exact seam hit. Technical replication in the other V1-34 run is the remaining direct test.

## Why more agents may not solve the current constraint

The [Anthropic report](https://www.anthropic.com/news/claude-discovers-novel-enzyme-system) describes searching a large, diverse collection of reverse transcriptases, followed by laboratory experiments. Here, the usable confirmed whole-transcriptome material located for this pilot consists of two deposited EMC models, with two sequencing runs from one of them. Broader searches returned controlled-access data, targeted expression assays, other chondrosarcoma types, and incompletely identified samples. More model calls do not create independent specimens, long-read phasing or laboratory validation.

The broader search returned 518 experiment summaries. Selected relevant hits received additional source review, including 61 experiment records from six further studies. This is not an exhaustive census or proof that no other public EMC data exist. See `expanded-dataset-disposition.json` and `remaining-candidate-study-disposition.json`.

## Useful work retained, and its limits

The packet preserves record-aware streaming, known-answer checks, accession provenance, exact read/quality evidence, normal-reference comparisons, and negative candidate dispositions. It also demonstrates two defects in a legacy scanner: overlap double-counting and matching synthetic quality-line text. These defects do not supply a correction factor for historical counts and are not by themselves a publishable new method.

The human RefSeq RNA comparison examined a verified source containing 186,185 transcripts; bait filtering retained 51 references while preserving possible exact full-read matches within that FASTA. This is not whole-genome alignment, exhaustive variant calling, or evidence that all unresolved reads are artifacts. Original V1-34 reads were examined only through partial prefixes after transport failures; the final technical run must be reported according to its actual completion state.

## Completion still required

1. Reconcile both SRR3380705 collector exits and verify EOF, expected source MD5s, record counts and retained-file hashes where available.
2. Inspect the supervisor's final analysis, H05 fragment/start evidence and both known fusion entry joins; preserve any new candidate before judging it.
3. Record the status and evidential limits of the two pending remote BLAST requests without treating waiting or missing output as a negative result.
4. Make and document the scientific decision from the completed evidence, preserve an integrity manifest, and reconcile actual process activity before closing the goal.

No manuscript, clinical registry, shared repository queue, correspondence or publication has been changed by this packet. No successful parallel-worker result is claimed.
