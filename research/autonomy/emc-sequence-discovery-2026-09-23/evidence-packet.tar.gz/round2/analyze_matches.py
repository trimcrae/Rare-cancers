"""Bounded interpretation of retained reads; all putative anomalies stay provisional."""
import collections, gzip, hashlib, json, sys, xml.etree.ElementTree as ET
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent;PARENT=ROOT.parent
sys.path.insert(0,str(PARENT));from junction_scout import Scout,rc

def references():
    genes=json.loads((PARENT/'sources/local/aso-premrna-sequences.json').read_text())['genes']
    refs={}
    for name,g in genes.items():
        seq=g['sequence'].upper();refs[name+':genomic']=seq
        refs[name+':cdna']=''.join(seq[a:b+1] for a,b in g['exon_spans_0based_inclusive'])
    for x in ET.parse(ROOT/'sources/normal-nr4a-transcripts.xml').getroot():
        refs[x.findtext('GBSeq_accession-version')]=x.findtext('GBSeq_sequence').upper()
    if (ROOT/'sources/offtarget-normal-transcripts.xml').exists():
        for x in ET.parse(ROOT/'sources/offtarget-normal-transcripts.xml').getroot():
            refs[x.findtext('GBSeq_accession-version')]=x.findtext('GBSeq_sequence').upper()
    if (ROOT/'sources/all-nr4a-refseq.xml').exists():
        for x in ET.parse(ROOT/'sources/all-nr4a-refseq.xml').getroot():
            refs[x.findtext('GBSeq_accession-version')]=x.findtext('GBSeq_sequence').upper()
    capture_path=ROOT/'human-reference-capture-result.json'
    if capture_path.exists():
        capture=json.loads(capture_path.read_text())
        if not capture.get('full_file_md5_verified'):raise ValueError('Unverified full human reference capture')
        def add(name,parts):
            if name:
                sequence=''.join(parts)
                if name in refs and refs[name]!=sequence:raise ValueError('Conflicting same-version reference: '+name)
                refs[name]=sequence
        with gzip.open(ROOT/'sources/human-refseq-bait-transcripts.fasta.gz','rt') as source:
            name=None;parts=[]
            for line in source:
                line=line.strip()
                if line.startswith('>'):add(name,parts);name=line.split()[0][1:];parts=[]
                else:parts.append(line)
            add(name,parts)
    return refs

def index_refs(refs,k=24):
    index=collections.defaultdict(list)
    for name,seq in refs.items():
        for i in range(len(seq)-k+1):index[seq[i:i+k]].append((name,i))
    return index

def contiguous_placements(seq,refs,index,k=24):
    offsets=set()
    for q in range(0,len(seq)-k+1,8):
        for name,t in index.get(seq[q:q+k],[]):offsets.add((name,t-q))
    answer=[]
    for name,start in offsets:
        ref=refs[name]
        if start<0 or start+len(seq)>len(ref):continue
        mismatch=[i for i,(a,b) in enumerate(zip(seq,ref[start:start+len(seq)])) if a!=b]
        if len(mismatch)<=2:answer.append({'reference':name,'start_0based':start,'mismatch_positions':mismatch})
    return sorted(answer,key=lambda r:len(r['mismatch_positions']))

def main():
    refs=references();index=index_refs(refs);scout=Scout();rows=[];summaries=[]
    for path in sorted(ROOT.glob('*.matches.jsonl')):
        data=path.read_bytes();counts=collections.Counter();fragment_classes=collections.defaultdict(set)
        for line in data.splitlines():
            try:r=json.loads(line)
            except json.JSONDecodeError:continue # live output may have one incomplete final line
            seq=r['sequence'].upper();events=scout.inspect(seq)
            placements=[]
            for strand,s in [('+',seq),('-',rc(seq))]:
                for placement in contiguous_placements(s,refs,index):
                    placement['strand']=strand;placements.append(placement)
            exact=[x for x in placements if not x['mismatch_positions']]
            fusion=[e for e in events if e['category']=='known_partner_context']
            # Observed shared Illumina adapter prefix in these raw files. This is
            # a conservative exact check, not general-purpose adapter trimming.
            adapter_start=seq.find('AGATCGGAAGAG')
            adapter_explanation=None
            if adapter_start>=50:
                prefix=seq[:adapter_start]
                for strand,s in [('+',prefix),('-',rc(prefix))]:
                    hits=contiguous_placements(s,refs,index)
                    exact_prefix=[x for x in hits if not x['mismatch_positions']]
                    if exact_prefix:
                        adapter_explanation={'adapter_start':adapter_start,'prefix_length':len(prefix),'strand':strand,'exact_prefix_placements':exact_prefix[:8]};break
            if exact:category='normal_reference_exact'
            elif fusion:category='known_junction_screen'
            elif adapter_explanation:category='normal_reference_prefix_plus_adapter'
            elif placements:category='normal_reference_with_1_or_2_mismatches'
            else:category='unresolved_bait_read'
            counts[category]+=1
            # Legacy SRA /1 and /2 and optional description are normalized only for matching mates.
            rid=r['id'].split()[0];fragment=rid[:-2] if rid.endswith(('/1','/2')) else rid
            fragment_classes[category].add(fragment)
            if category!='normal_reference_exact':
                r.update(category=category,events=events,normal_placements=placements[:8],fragment_id=fragment,
                         minimum_base_quality=min(ord(c)-33 for c in r['quality']),adapter_explanation=adapter_explanation)
                rows.append(r)
        summaries.append({'file':path.name,'snapshot_bytes':len(data),'snapshot_sha256':hashlib.sha256(data).hexdigest(),'class_counts':dict(counts),'distinct_fragment_ids_by_class':{k:len(v) for k,v in fragment_classes.items()}})
    output={'scope':'Retained exact-bait reads only. Reference set is incomplete and includes labelled NM curated and XM predicted RefSeq accessions. Reference matches are not proof of experimentally validated isoforms. Mismatch-tolerant placements are possible explanations, not genotype calls. Adapter class requires an exact >=50nt reference prefix followed by AGATCGGAAGAG. Known-junction screen requires alignment and read-start review. No novelty asserted.','files':summaries,'non_exact_records':rows}
    (ROOT/'analysis-current.json').write_text(json.dumps(output,indent=2)+'\n')
    print(json.dumps({'files':summaries,'non_exact_records':len(rows),'known_junction_records':sum(r['category']=='known_junction_screen' for r in rows),'unresolved_records':sum(r['category']=='unresolved_bait_read' for r in rows)},indent=2))
if __name__=='__main__':main()
