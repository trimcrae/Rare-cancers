"""Synthetic transport failures: byte-perfect gzip recovery and unsafe-range rejection."""
import gzip,hashlib,io,json,random,sys,time
from pathlib import Path
sys.dont_write_bytecode=True
from resilient_reader import Reader,EndBudget
ROOT=Path(__file__).resolve().parent

class Response:
    def __init__(self,data,offset=0,fault=False,status=206,wrong_offset=False):
        self.data=data;self.at=offset;self.fault=fault;self.calls=0;self.status=status
        self.headers={'Content-Range':f'bytes {offset+int(wrong_offset)}-{len(data)-1}/{len(data)}'}
    def read(self,n):
        self.calls+=1
        if self.fault and self.calls==2:raise TimeoutError('synthetic connection timeout')
        out=self.data[self.at:self.at+min(n,107)];self.at+=len(out);return out
    def close(self):pass

def main():
    rng=random.Random(5101)
    raw=''.join(f'@synthetic_{i}\n'+''.join(rng.choice('ACGT') for _ in range(101))+'\n+\n'+'I'*101+'\n' for i in range(500)).encode()
    compressed=gzip.compress(raw,mtime=0);checks=[]
    def opener(req,timeout):
        offset=int(req.get_header('Range').split('=')[1].split('-')[0]);return Response(compressed,offset)
    reader=Reader(Response(compressed,fault=True),len(compressed)+1,time.monotonic()+30,'https://synthetic.invalid',len(compressed),opener)
    with gzip.GzipFile(fileobj=io.BufferedReader(reader)) as f:actual=f.read()
    checks.append({'name':'timeout recovery produces byte-identical decompressed FASTQ','passed':actual==raw})
    checks.append({'name':'MD5 includes each compressed byte once','passed':reader.md5.hexdigest()==hashlib.md5(compressed).hexdigest()})
    checks.append({'name':'one accepted reconnect at the returned-byte offset','passed':reader.reconnections[0]['offset']==107 and len(reader.reconnections)==1})
    for name,status,wrong in [('ignored range rejected',200,False),('shifted range rejected',206,True)]:
        def bad(req,timeout):return Response(compressed,107,status=status,wrong_offset=wrong)
        r=Reader(Response(compressed,fault=True),len(compressed)+1,time.monotonic()+30,'https://synthetic.invalid',len(compressed),bad)
        passed=False
        try:
            with gzip.GzipFile(fileobj=io.BufferedReader(r)) as f:f.read()
        except ValueError:passed=True
        checks.append({'name':name,'passed':passed})
    r=Reader(Response(compressed),50,time.monotonic()+30,'https://synthetic.invalid',len(compressed),opener)
    passed=False
    try:
        r.read(100) # RawIO may return the remaining short chunk first.
        r.read(100)
    except EndBudget:passed=True
    checks.append({'name':'transfer limit interrupts before full stream','passed':passed and r.n==50})
    result={'data':'Explicitly synthetic transport fixture; no biological findings','checks':checks,'passed':all(c['passed'] for c in checks)}
    (ROOT/'stream-recovery-checks.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
    if not result['passed']:raise SystemExit(1)
if __name__=='__main__':main()
