"""Freeze a completed run only after cross-stage retained-source hash agreement."""
import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('run')
    parser.add_argument('output')
    args = parser.parse_args()
    names = ['analysis-current.json', 'known-fusion-alignment-current.json',
             'human-reference-matches-current.json', 'exact-split-triage-current.json']
    data = {name: json.loads((ROOT / name).read_text()) for name in names}
    basic, fusion, human, split = [data[name] for name in names]
    assert split['source_sha256'] == digest(ROOT / names[0]), 'Split stage used different basic analysis'
    checks = []
    raw = []
    for mate in (1, 2):
        filename = f'{args.run}_R{mate}.matches.jsonl'
        receipt = json.loads((ROOT / f'{args.run}_R{mate}.result.json').read_text())
        assert receipt['stopped_because'] == 'eof'
        assert receipt['full_file_md5_verified'] is True
        sha = digest(ROOT / filename)
        assert sha == receipt['matches_sha256']
        b = next(x for x in basic['files'] if x['file'] == filename)
        f = next(x for x in fusion['snapshots'] if x['file'] == filename)
        h = next(x for x in human['snapshots'] if x['path'] == filename)
        assert b['snapshot_sha256'] == f['sha256'] == h['sha256'] == sha, filename
        rows = [json.loads(line) for line in (ROOT / filename).read_text().splitlines()]
        assert len(rows) == receipt['bait_records'] == sum(b['class_counts'].values())
        checks.append({'file': filename, 'sha256': sha, 'records_scanned': receipt['records'],
                       'records_retained': len(rows), 'source_md5_verified': True,
                       'all_three_stage_hashes_agree': True})
        raw.extend(rows)
    rc = lambda seq: seq.translate(str.maketrans('ACGTN', 'TGCAN'))[::-1]
    seams = {'H05': 'GCCCTTGTCCGAGCTTTAACAGGAACCTTCTCAGCCCTCT',
             'H06': 'GAGGAGCCCCGGTCACAATGAGCCCACTGCGGAAGAGGGC'}
    hits = {}
    for name, seam in seams.items():
        hits[name] = []
        for r in raw:
            for strand, seq in [('+', r['sequence']), ('-', rc(r['sequence']))]:
                if seam in seq:
                    hits[name].append({'id': r['id'], 'mate': r['mate'], 'strand': strand,
                                       'offset': seq.index(seam), 'oriented_sequence': seq})
    output = {'utc': datetime.now(timezone.utc).isoformat(), 'run': args.run,
              'source_checks': checks, 'split_source_hash_matches': True,
              'files': [x for x in basic['files'] if x['file'].startswith(args.run + '_')],
              'known_fusion_summaries': [x for x in fusion['summaries'] if x['run'] == args.run],
              'known_fusion_records': [x for x in fusion['supporting_records'] if x['run'] == args.run],
              'human_reference_exact_records': human['counts_by_run'].get(args.run, 0),
              'exact_split_records': [x for x in split['records'] if x['id'].startswith(args.run + '.')],
              'candidate_seam_hits': hits,
              'analysis_source_hashes': {n: digest(ROOT / n) for n in names},
              'scope': 'Complete source streams; targeted bait retention, not genome-wide discovery. Fragment IDs and starts do not establish original molecules. No clinical or experimental validation.'}
    target = ROOT / args.output
    assert not target.exists(), 'Refusing to overwrite a frozen analysis'
    target.write_text(json.dumps(output, indent=2) + '\n')
    print(json.dumps({'output': target.name, 'checks': checks, 'fusion': output['known_fusion_summaries'],
                      'candidate_read_counts': {k: len(v) for k, v in hits.items()}}))

if __name__ == '__main__':
    main()
