"""Memory-only bounded real-read pilot. No complete FASTQ is saved."""
import datetime as dt
import gzip
import hashlib
import io
import json
import time
import urllib.request
import sys
sys.dont_write_bytecode=True
from junction_scout import Scout, ROOT

class BudgetReached(Exception):
    pass

class Limited(io.RawIOBase):
    def __init__(self,response,limit,deadline):
        self.response=response;self.limit=limit;self.deadline=deadline;self.n=0;self.digest=hashlib.sha256()
    def readable(self): return True
    def readinto(self,b):
        if time.monotonic()>=self.deadline:raise BudgetReached('wall_budget')
        remaining=self.limit-self.n
        if remaining<=0:raise BudgetReached('compressed_byte_budget')
        data=self.response.read(min(len(b),remaining,65536))
        b[:len(data)]=data;self.n+=len(data);self.digest.update(data)
        return len(data)

run=json.loads((ROOT/'sources/access/SRR33903995.json').read_text())[0]
url='https://'+run['fastq_ftp'].split(';')[0]
started=dt.datetime.now(dt.timezone.utc).isoformat();t0=time.monotonic()
scout=Scout();reader=None
result={'run':'SRR33903995','read_end':1,'url':url,'started_utc':started,'max_compressed_bytes':64*1024*1024,'max_seconds':180,'sampling':'nonrandom file prefix','raw_file_saved':False}
try:
    with urllib.request.urlopen(url,timeout=25) as response:
        reader=Limited(response,result['max_compressed_bytes'],t0+180)
        with io.TextIOWrapper(gzip.GzipFile(fileobj=io.BufferedReader(reader,65536)),encoding='ascii') as text:
            scout.scan_fastq(text)
    result['stopped_because']='eof'
except BudgetReached as exc:result['stopped_because']=str(exc)
except Exception as exc:result.update(stopped_because='error',error=repr(exc))
result.update(elapsed_seconds=round(time.monotonic()-t0,3),finished_utc=dt.datetime.now(dt.timezone.utc).isoformat(),compressed_bytes_read=reader.n if reader else 0,compressed_prefix_sha256=reader.digest.hexdigest() if reader else None)
# Empty-stream call only serializes retained counters; it does not scan further input.
result['screen']=scout.scan_fastq(io.StringIO(''))
result['interpretation']='Screening only. No novel fusion, patient frequency, efficacy or biological absence claim. Partial final records at the budget boundary are excluded.'
(ROOT/'stream-pilot-result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='screen'}|{'counts':result['screen']['counts'],'contexts':result['screen']['contexts']},indent=2))
