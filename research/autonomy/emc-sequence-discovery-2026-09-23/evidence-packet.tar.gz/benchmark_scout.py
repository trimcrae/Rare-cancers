"""Known-answer benchmark with archived biological examples and labeled synthetic controls."""
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET
sys.dont_write_bytecode = True
from junction_scout import Scout, ROOT, REPO, rc

source = ROOT/'sources/local'
source.mkdir(parents=True,exist_ok=True)
manifest = []
for name in ['aso-premrna-sequences.json','emc_fusion_read_scan.py','emc-fusion-read-scan.json','nr4a3-intron2-cryptic-exon.json']:
    data=(REPO/'research/modalities'/name).read_bytes()
    (source/name).write_bytes(data)
    manifest.append({'repository_path':'research/modalities/'+name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
(ROOT/'local-input-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
archived=json.loads((source/'emc-fusion-read-scan.json').read_text())['runs'][0]['junctions_found'][0]['example_reads']

def record(name,seq,quality=None):
    return '@'+name+'\n'+seq+'\n+\n'+(quality or 'I'*len(seq))+'\n'

scout=Scout()
seed=scout.acceptors['NR4A3_exon3_start']
normal=next(iter(sorted(scout.normal['NR4A3_exon3_start'])))+seed+'ACGT'
unknown='ACACACACACACACAC'+seed+'ACGT'
cases=[]
for i, seq in enumerate(archived):
    cases.append((f'archived_example_{i}',seq,'known_partner_context','archived, not independent biological replication'))
cases.extend([('reverse_complement',rc(archived[0]),'known_partner_context','synthetic orientation control'),('normal',normal,'normal_reference_context','synthetic reference control'),('unknown_upstream',unknown,'unassigned_context','synthetic retention control'),('short_upstream',seed+'ACGT','insufficient_upstream','synthetic boundary control')])
checks=[]
for name,seq,expected,label in cases:
    events=scout.inspect(seq)
    observed={e['category'] for e in events}
    checks.append({'name':name,'provenance':label,'expected':expected,'observed':sorted(observed),'passed':expected in observed})
publisher = json.loads((ROOT/'v1-34-positive-control.json').read_text())
for seam in sorted(set(r['seam_16nt'] for r in publisher['rows'])):
    events=scout.inspect(seam.replace('|',''))
    checks.append({'name':'publisher_seam_'+seam,'provenance':'GSM2113301 publisher-processed fusion output; not independently confirmed reads','passed':any(e['category']=='known_partner_context' for e in events)})
native = ET.parse(ROOT/'sources/nuccore/NM_173200.gb.xml').getroot()[0].findtext('GBSeq_sequence').upper()
native_events = scout.inspect(native)
checks.append({'name':'normal_alternative_transcript_not_fusion','provenance':'NM_173200.3 reference mRNA','passed':not any(e['category'] in ['known_partner_context','unassigned_context','ambiguous_partner_context'] for e in native_events)})

# ACGT is legal Phred+33 quality text. It must never be treated as sequence.
quality_seq=archived[0]
quality_result=Scout().scan_fastq(io.StringIO(record('quality_only','N'*len(quality_seq),quality_seq)))
checks.append({'name':'quality_line_not_sequence','provenance':'synthetic FASTQ, quality range 32..51','passed':quality_result['counts'].get('records_with_anchor',0)==0})

# Exact reproduction of the old scanner's overlap window with its unchanged defaults.
spec=importlib.util.spec_from_file_location('legacy_scanner',source/'emc_fusion_read_scan.py')
legacy=importlib.util.module_from_spec(spec);spec.loader.exec_module(legacy)
filler=record('negative','N'*151).encode()
positive=record('one_positive',archived[0]).encode()
n=(legacy.CHUNK-2*len(positive))//len(filler)
stream=filler*n+positive+filler*20
legacy_scanner=legacy.JunctionScanner(legacy.load_genes(str(source/'aso-premrna-sequences.json')))
legacy_scanner.scan_stream(io.BytesIO(stream))
legacy_count=sum(r['n_reads'] for r in legacy_scanner.junctions.values())
new=Scout().scan_fastq(io.StringIO(stream.decode()))
new_count=new['counts'].get('known_partner_context',0)
checks.append({'name':'chunk_overlap_counts_once','provenance':'synthetic FASTQ with exactly one archived positive inserted near default 8MiB boundary','expected':1,'record_aware_count':new_count,'legacy_count':legacy_count,'passed':new_count==1})
quality_legacy=legacy.JunctionScanner(legacy.load_genes(str(source/'aso-premrna-sequences.json')))
quality_legacy.scan_stream(io.BytesIO(record('quality_only','N'*len(quality_seq),quality_seq).encode()))

deposits=[]
for item in ET.parse(ROOT/'sources/nuccore/candidates.gb.xml').getroot():
    seq=item.findtext('GBSeq_sequence','').upper()
    deposits.append({'accession':item.findtext('GBSeq_accession-version'),'length':len(seq),'events':scout.inspect(seq),'provenance':'public GenBank sequence; not new discovery; records already surveyed in repository'})
result={'checks':checks,'passed':all(c['passed'] for c in checks),'legacy_quality_line_false_junctions':sum(r['n_reads'] for r in quality_legacy.junctions.values()),'genbank_context_checks':deposits,'archived_example_records':len(archived),'archived_distinct_sequences':len(set(archived)), 'interpretation':'Two instrument counterexamples, not a correction factor for prior biological counts. Reprocess source FASTQ to quantify impact. This benchmark does not validate unknown-partner calls or intra-exonic discovery.'}
(ROOT/'benchmark-results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'passed':result['passed'],'checks':checks,'legacy_quality_line_false_junctions':result['legacy_quality_line_false_junctions'],'deposits':len(deposits)},indent=2))
if not result['passed']: raise SystemExit(1)
