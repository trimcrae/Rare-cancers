# EMC transcript-discovery pilot — first completed checkpoint

Date: 2026-09-23 America/New_York (execution crossed September 24 UTC).
Owner: Codex thread `01a0d08d-d31f-7ce3-8447-8f3a9962d15e`.

The first real-data pilot is complete. A bounded memory-only stream of SRR33903995 read 1 examined **1,274,822 complete FASTQ records**, recovering **five records with the known EWSR1 exon-12 / NR4A3 exon-3 sequence join** and one record with ordinary genomic adjacency around the known alternative NR4A3 exon. The run transferred 64 MiB compressed in 86.047 seconds; it did not save the multi-gigabyte FASTQ. See [execution result](stream-pilot-result.json), which retains six matching records, qualities, identifiers, counters and a hash of the consumed compressed prefix.

These are read records, not unique molecules, independent patients, abundance estimates or a random sample. No novel fusion, exon, therapeutic effect or biological absence has been established. The ordinary reference adjacency does not determine whether the read originated from a normal allele, precursor transcript or another source.

## What the pilot established

- The previous scanner searches only three predetermined NR4A3 acceptor starts. It discards unidentified upstream sequences and cannot discover arbitrary intra-exonic breaks.
- A synthetic FASTQ containing exactly one known positive near its unchanged 8 MiB chunk boundary produces **two** legacy junction counts. Its overlap is scanned twice. This is a demonstrated instrument defect, not a correction factor for the historical 176-read result.
- A synthetic legal Phred+33 quality line containing ACGT also produces a false legacy hit. This constructed quality range is 32–51; it does not establish that this occurred in the actual Illumina deposit.
- The new [record-aware scout](junction_scout.py) parses four-line FASTQ records, includes a fourth acceptor at the known 72-nt alternative exon, checks available normal reference contexts, retains unidentified contexts, and avoids these two counterexamples. **13 named benchmark checks passed.** See [benchmark](benchmark-results.json).
- A separate verifier checked source hashes, independently parsed source counts, exact sequence identity and retained raw-read motifs: **28 checks passed**. This was coordinator verification, not independent-agent review. See [verification](verification.json).

## Sources and candidates

The exact-disease SRA query returned **43 experiment records** (44 run accessions), including **22 controlled-access experiments**. This is a bounded query, not a complete census of EMC data. The disease phrase misses the Zurich series' misspelled cell-type label; a directed project lookup was required.

| Material | Evidence and disposition |
|---|---|
| [SRR33903995 / GSM9037837](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSM9037837), USZ-23_EMC3, GSE299349 / PRJNA1273954 | Paired RNA-seq; the project has 135 runs but only one sample title matching EMC in this retrieved table. Two compressed mates total 2,963,556,913 bytes. Known fusion positive control; the memory-only pilot ran on the first mate. This is a cell model, not a new patient cohort. |
| [GSM2113301](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSM2113301), V1-34, GSE80126 / SRP073267 | Sample metadata says cell culture, accuracy sample, EMC histology, RIN 10. Two runs are SRR3380704 and SRR3380705; do not count them as two patients. Publisher-processed fusion output is available. Raw reads were not scanned in this checkpoint. |
| SRP640302 / PRJNA1357027 | Twelve experiments labeled RNA-seq are actually TempO-Seq targeted expression assays. Exclude from unrestricted junction discovery. |
| SRP048907 | Eleven RNA-seq experiments recovered by this query are controlled access. Public metadata is not public raw-read access. No restricted access was attempted. |
| DRR062877 and related FANTOM material | Maps through BioSample SAMD00005690 to H-EMC-SS, whose fusion identity is problematic. Exclude as a confirmed EMC fusion-positive control. |
| SRP006575 / GSE28866 | Four EMC-labeled historical 3SEQ libraries are not equivalent to unbiased whole-transcriptome coverage. Retain assay-specific limitations. |

The [V1-34 publisher table analysis](v1-34-positive-control.json) collapses **16 transcript-annotation rows into two distinct 32-nt sequence joins**. One is the known canonical join. The other joins the same EWSR1 flank to a 72-nt exon already described in `research/modalities/nr4a3-intron2-cryptic-exon.json` and present in normal **NM_173200.3**. This is not a novel-exon discovery. The table is processed caller output, not independent raw-read confirmation. Its alternative right-hand sequence ends at 72 nt; downstream continuation is not shown. Multiple annotation rows and support columns must not be summed as independent evidence. [Exact source and sequence checks](verification.json).

The six short GenBank sequences retrieved here are also already represented in earlier repository investigations. Their recovery is a positive-control/source-refresh result, not novelty. The broad NR4A3 nuccore query was capped at 100 of 810 hits; its limits are retained in [retrieval metadata](nuccore-retrieval.json).

## Next executable research step

Reprocess V1-34's two raw runs using record-aware streaming, with both published joins specified before inspection. Preserve fragment identifiers, both mates, anchor qualities, unique start positions and all conflicting mappings. Confirm the alternative join against normal transcript isoforms and genomic sequence using an independent aligner before promoting it. Establish specimen identity and independence before making recurrence claims. Extend beyond four fixed acceptors only after the known-answer checks remain correct. A negative bounded prefix is uninformative about absence.

This prototype is deliberately limited: no genome-wide mapping, arbitrary acceptor discovery, deduplication, HLA inference or statistical recurrence test. Unknown context is a retained screening observation, never a novel-fusion call. Existing normal context references are not exhaustive.

## Execution and ownership

All changes are in this small task packet. Repository main, manuscripts, ownership records and schedulers were not edited. The repository's existing coordinator retains ownership. No checkouts, runtimes, paid APIs, GPU jobs, correspondence or publications were created. Full repository preflight was not run because there is no repository change; packet-specific checks are recorded above.

Three GPT-6 Sol workers were requested but remained `pending_init` and returned no work. Their pending dispatches were interrupted; **no parallel-agent result is claimed and no research job remains running** at this checkpoint. Model usage is unknown. Direct coordinator work produced this packet.

The initial disk reading was 10,078,359,552 bytes free, below the 10 GiB checkout headroom requirement. Only small artifacts were retained. [Original contract](CONTRACT.json) and [dated streaming amendment](STREAMING-AMENDMENT.json) preserve the boundary change allowing memory-only raw-read validation.

Reproduction: use the existing Python runtime with `benchmark_scout.py` and `verify_packet.py`. `stream_pilot.py` repeats the bounded network pilot, so rerun it only for a changed instrument or a justified verification need. Original source bytes, retrieval URLs and hashes are in `sources/` and the retrieval JSON files. The initial failed verifier is retained: it mistakenly expected the published alternative sequence to continue into a downstream exon; the source contains only the 72-nt exon, and the assertion was corrected to that actual evidence.
