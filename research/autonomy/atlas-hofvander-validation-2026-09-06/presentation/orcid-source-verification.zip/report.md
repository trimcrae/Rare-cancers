---
id: CACHE-ATLAS-AUTHOR-ORCID-VERIFICATION
title: Official ORCID identity verification for atlas release
kind: report
status: complete
date: 2026-09-06
last_verified: 2026-09-06
purpose: Resolve the suspected ORCID identity mismatch before release.
scope: Public author identifier only; no funding or conflict-of-interest attestation.
audience: [maintainers]
---

The exact identifier **0000-0002-1823-1451** resolves to **Tristan McRae** in the official public ORCID record. The suspected mismatch is not supported. Retain the identifier; this check establishes the public registry name match, not an independent middle-initial attestation.

The official endpoint https://pub.orcid.org/v3.0/0000-0002-1823-1451/person returned HTTP 200 with `given-names.value = Tristan`, `family-name.value = McRae`, public visibility, and the exact identifier as its path. Its complete response is preserved in `record.response` (929 bytes; SHA256 `b51a75ef69b4b87d391edd54325146243ad3c7222759281399dc0fef1e45aad7`).

The canonical URL https://orcid.org/0000-0002-1823-1451, requested as JSON, redirected to the official public API record at https://pub.orcid.org/v3.0/0000-0002-1823-1451 and returned HTTP 200 with the same identity. Its complete public response is preserved in `registry.response` (23749 bytes; SHA256 `b8e6a711b0e5735b0c3f7ea49f55bada56cff668f8fddcfa36fd8373136e5866`). Exact retrieval URLs, statuses, sizes and hashes are in `retrievals.json`.

The official search result for the demonstration identity Josiah Carberry instead identifies https://orcid.org/0000-0002-1825-0097. These identifiers differ. The positive conclusion here rests on the actual Tristan record bytes, not on the search result or repository reuse.

The existing ASO article author block supplies the same identifier for Tristan D. McRae. No explicit user-issued ORCID attestation was located in the narrow local author-metadata inspection; none is claimed. No alternate identifier was inferred or substituted.

Article-specific funding and conflict-of-interest declarations remain unverified by this check. ORCID identity and an earlier article's declarations do not establish those declarations for the new article. Preserve their actual status for author confirmation before submission; this is an author-metadata completion item, not a scientific-result failure.

No tracked files were changed, no publication was performed, and nothing remains running from this verification.
