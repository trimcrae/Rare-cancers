# Fixed-panel normal context: source recovery, 2026-09-06

An executable source-backed context roster is now available for the fixed11 addresses and separate CHRNA6. It does not modify tumor-analysis membership, rankings or endpoints, and provides no normal-sparing or therapeutic-window verdict.

## What was reusable and what was missing

The existing `research/modalities/emc-surface-normal-window.json` was copied unchanged as `legacy-normal-window.json`. It contains categorical RNA/subcellular summaries for the fixed11, but all11 per-tissue-specific-nTPM fields are null, CHRNA6 is absent, and neither original response bytes nor HPA release/response hashes are recorded. It contains no donor-level normal expression or tissue-IHC evidence. Its RESTRICTED/window labels and `plasma_membrane_confirmed` booleans are legacy algorithm outputs, not established safety or surface-accessibility facts. A missing specific-nTPM field can reflect unavailable/non-applicable summary information; it is not absent expression. Those algorithmic verdicts are preserved only as history and are not reused in the new roster.

The GSE28866 report remains a separate same-source 3SEQ normal-context analysis: adult breast5, colon3, kidney3, lung5, uterus1; fetal organs kept separate; four EMC library/STT records, not verified patient counts. Its square-root-compressed depth-scaled peak values cannot be combined with HPA nTPM, Hofvander TPM, or Affymetrix intensities. Its ALPP mapping absence is not expression absence. Two pooled muscle samples in GSE24369 cannot establish normal-organ selectivity.

## New exact, bounded authoritative recovery

Fetched12 individual gene JSON/XML pairs using the HPA-documented `https://www.proteinatlas.org/<Ensembl>.json` and `.xml` access pattern, plus the official download, tissue-data, subcellular-data and license pages. The11 existing Ensembl IDs were reused; CHRNA6 was resolved by the documented search endpoint and exact returned-symbol assertion (ENSG00000147434). All12 JSON and XML gene/Ensembl identities agree. Full original response bytes and SHA256 hashes are preserved. No images, whole-transcriptome normal matrices or paid data were downloaded.

- Download/version documentation: https://www.proteinatlas.org/about/download
- Tissue data/units: https://www.proteinatlas.org/humanproteome/tissue/data
- Subcellular data: https://www.proteinatlas.org/humanproteome/subcellular/data
- License/citation: https://www.proteinatlas.org/about/licence

Version precision: the current download/method pages identify **HPA25.1 / Ensembl109**. Each retrieved XML entry reports **version25**, with versioned URL `https://v25.proteinatlas.org/<Ensembl>`, Ensembl109, GRCh38.p13, GENCODE43. Record both facts; do not silently relabel XML as25.1 or assign a release to the old cache. The JSON has no explicit release field. Preserve retrieval date/hash as the exact snapshot identity.

HPA copyrightable database material is CC BY4.0; cite the primary relevant publication, HPA website and specific gene/data URL with version. Primary tissue atlas: Uhlen et al.2015, DOI10.1126/science.1260419. Subcellular atlas: Thul et al.2017, DOI10.1126/science.aal3321. The official page warns that external sources can have separate terms. HPA links GTEx terms at https://www.gtexportal.org/home/license ; the web tool returned a JavaScript-only page and this task did not establish a separate GTEx license text or release. Do not infer a new license grant for raw GTEx data.

The HPA consensus normal RNA is explicitly a **maximum of HPA and GTEx gene/tissue nTPM**, and a maximum across sub-tissues for grouped organs. It is not an independently replicated cohort average or a tumor/normal matched reference. XML RNA blocks marked `consensusTissue` must retain that designation even though the top-level source attribute says HPA. The separate `tissue` block is retained separately. No isolated GTEx donor expression records were recovered; none are required for the present descriptive context roster.

## Recovered roster and limitations

`fixed-panel-normal-context-roster.json` has12 records with exact source/version/identity, RNA categories and enriched cell types, normal-tissue IHC summary/reliability, all ICC/IF location tags, antibody IDs/RRIDs, and explicit evidence boundaries. `normal-IHC-cell-records.json` preserves **1,054 normal tissue/cell-type records** across10 genes, including695 `not detected`,112low,173medium,74high calls. These are categorical source observations, not new staining measurements or independent subjects. `normal-RNA-source-records.json` preserves1,092 source tissue/block records with original units/values, without tumor comparisons or ranking. All cells/organ negatives remain; no favorable subset was selected.

| Gene | Source-backed interpretation constraint |
|---|---|
| CD276 | Broad normal IHC signal includes cytoplasmic and membranous staining, while ICC/IF records vesicles. Preserve both assay contexts. |
| SSTR2 | Brain is prominent in the normal summary; tissue-IHC reliability is uncertain and ICC/IF includes intracellular compartments. |
| PRAME | Testis-associated normal evidence; nucleoplasm and plasma-membrane ICC/IF tags both retained. This remains an intracellular peptide-HLA address in the project, not proof of accessible intact surface PRAME or endogenous EMC peptide presentation. |
| FAP | Tissue-IHC reliability uncertain; absent ICC/IF summary is not absent membrane protein. RNA cell-type enrichment is context for stromal origin, not a measurement of EMC tumor versus stroma. |
| CD248 | Normal cell-type and membrane annotations retained with normal IHC; no cell compartment in EMC established. |
| CSPG4 | Normal IHC is broad/cytoplasmic; ICC/IF membrane location does not eliminate normal-organ expression or establish EMC accessibility. |
| MSLN | Normal epithelial staining and membrane/vesicle tags retained. This panel is not a complete survey of mesothelial surfaces. |
| L1CAM | CNS/PNS and renal-tubule normal context is consequential to review; no tolerable-dose threshold follows. |
| GPC3 | No normal tissue-IHC summary or cell rows in this XML. RNA placenta enrichment plus membrane ICC/IF cannot establish adult-organ protein absence. |
| ALPP | Placental/cervical RNA and trophoblast staining retained. ICC/IF explicitly cautions that antibodies target proteins from multiple genes; preserve paralog ambiguity. Pregnancy/placental context cannot be omitted because adult organs are the main focus. |
| CDH17 | Gastrointestinal epithelial protein expression is material normal context; intracellular and cell-junction ICC/IF tags both retained. |
| CHRNA6 | Separate control, retina-enriched RNA summary, no tissue-IHC rows or ICC/IF summary recovered. No normal-neural protein absence inference. |

These short interpretations refer to gene-specific records, not dose-specific clinical toxicity findings. Clinically consequential review categories include neural/retinal, cardiac/vascular, respiratory, renal, gastrointestinal/hepatic, pancreatic/endocrine, hematopoietic and reproductive/placental tissues. The source roster retains all available organs, rather than declaring unmeasured organs safe. RNA enrichment in normal fibroblast/perivascular or other cell populations cannot establish the malignant-versus-stromal source of bulk EMC RNA. HPA ICC/IF is cell-line localization, not normal-organ membrane density, and not an EMC experiment.

## Executable use and stop condition

Use the exact fixed-panel gene join to append these source-record fields to the already frozen atlas output after its tumor analysis. Show normal IHC reliability and explicit missingness alongside RNA context; retain discordant location tags and ALPP antibody cross-reactivity. Do not threshold unmatched nTPM/TPM into a safety margin, assign a surface-positive boolean from a tag, replace normal RNA absence with protein absence, or use normal-context values to select genes post hoc. The retained raw XML also contains antibody-specific data for a later focused review if a source-level discrepancy requires it; no image scores were inferred here.

Stop at descriptive normal context whenever tissue-IHC is missing/uncertain, organ coverage incomplete, assay compartments disagree or surface accessibility is unmeasured. These are explicit limits, not reasons to erase negative evidence. The artifact is useful now for interpreting the fixed tumor contrasts and specifying what protein/cellular validation remains necessary.

Validation:12 exact identity checks, XML/JSON parse checks, source-derived categorical counts and missingness, immutable response hashes. No tumor-expression file opened, no source harmonization, no normal-RNA reanalysis beyond fixed-panel record extraction, no tracked edits, mail, publication or background process. An initial Windows output encoding error occurred during legacy preview; no scientific result was produced by that failed print.
