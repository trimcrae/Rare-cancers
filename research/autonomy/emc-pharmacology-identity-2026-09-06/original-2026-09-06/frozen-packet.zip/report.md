# NCC EMC pharmacology: consistency survives duplicate handling, identity completeness does not

This retrospective analysis preserves 221 CAS-level preparations from one patient-derived EMC model. Four identity-resolved proteasome-directed preparations represent three active moieties and two broad chemical families. All four lie within the lowest 24 ranks for reported viability. The fifth, source-labelled ixazomib citrate/MLN9708, also ranks low but has unresolved exact identity. The frozen complete identity-resolved family claim therefore stops; this does not erase the directly observed consistency in the known subset.

## Results

Rank 1 is lowest reported viability; denominator is always 221 preparations, ties use midranks. Mean+SD ranks use mean+reported SD for every preparation, solely as a deterministic stress test. They are not confidence limits.

| Source preparation (CAS) | Reported viability, % | Reported SD, percentage points | Mean rank | Mean+SD rank | Selected follow-up IC50, nM |
|---|---:|---:|---:|---:|---:|
| Bortezomib (179324-69-7) | 13.6153 | 11.9320 | 15 | 19 | 135 |
| Carfilzomib (868540-17-4) | 23.5755 | 1.4432 | 24 | 17 | Not in table |
| Ixazomib/MLN2238 (1072833-77-2) | 12.8429 | 2.3376 | 14 | 10 | Not in table |
| Ixazomib citrate (1239908-20-3) | 16.7640 | 1.9723 | 17 | 12 | 3511 |
| Source-labelled ixazomib citrate/MLN9708 (1201902-80-8), identity unresolved | 21.9290 | 4.6752 | 22 | 20 | 1982, named “Ixazomib” in follow-up |

The complete source values are retained, including all 51 preparations with reported viability outside 0–100%. All 24 follow-up entries are preserved. The follow-up table does not contain the active ixazomib CAS1072833-77-2: transferring the row labelled “Ixazomib” to that active compound would be an unsupported identity substitution. Follow-up selection, fitting and exposure conditions remain unresolved, so these IC50s are not an independent validation dataset or evidence of clinical potency.

## Chemical identity findings

The [VELCADE label](https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=1521d321-e724-4ffc-adad-34bf4f44fac7) identifies bortezomib as a dipeptidyl boronic acid and reversible proteasome inhibitor. The [KYPROLIS label](https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=ea66eb30-e665-4693-99a1-a9d3b4bbe2d6) identifies carfilzomib as a tetrapeptide epoxyketone proteasome inhibitor. These justify two broad chemical families; they do not establish independent biological replication.

The [NINLARO label](https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=038f2461-834b-4488-9ebd-863c83eef5a7) describes citrate as a prodrug that hydrolyzes to active ixazomib. It must not be treated as a third independent ixazomib-like active compound, or casually called a conventional citrate salt. Conversion in the particular NCC wells was not measured here. Grouping the regulatory citrate preparation with active ixazomib is an explicit active-moiety sensitivity while retaining both measured preparations.

[FDA GSRS](https://precision.fda.gov/ginas/app/ui/substances/46CWK97Z3K) identifies regulatory ixazomib citrate with CAS1239908-20-3 and PubChem CID56844015. The archived PubChem responses associate CID56844015 with InChIKey MBOMYENWWXQSNW-AWEZNQCLSA-N and [MLN9708 CID49867936](https://pubchem.ncbi.nlm.nih.gov/compound/49867936), associated with CAS1201902-80-8, with YTXSYWAKVMZICI-PVCZSOGJSA-N. Their first InChIKey blocks and connectivity SMILES differ. These are different registry connectivity representations, not proof that the authors purchased different material or that either reagent was wrong. The latter row requires source/vendor clarification; neither a new independent active moiety nor equivalence is asserted.

The full source-name roster was read. Five preparations were identified as the primary proteasome-directed candidate family, four with resolved drug/prodrug annotations and one identity-qualified candidate. The remaining 216 entries are explicitly “not identified as primary proteasome-directed in this bounded review,” not experimentally proved negatives. Secondary proteostasis effects and a full off-target taxonomy were outside scope. Related-name groups were separately recorded; authoritative hydrochloride and tosylate relationships were documented for doxorubicin and niraparib. Other apparent salts, stereoisomers, prodrugs and mixtures remain unresolved candidates and are never automatically collapsed. This partial identity curation does not justify a deduplicated whole-panel denominator.

## Exact frozen stop-rule disposition

The retrospective descriptive threshold was rank <=55.25, the lowest quartile of 221 preparations. It is not a biological activity cutoff.

- All confirmed active-moiety groups' worst preparation ranks pass: bortezomib15, carfilzomib24, ixazomib17.
- Two confirmed chemical families are represented: boronic-acid/boronic-ester-prodrug lineage and epoxyketone.
- Removing the boronic-acid lineage leaves carfilzomib at rank24. Removing epoxyketone leaves bortezomib and ixazomib. Only one chemical family remains in either check; this is a descriptive sensitivity, not independent mechanistic replication.
- Identity completeness fails because CAS1201902-80-8 remains unresolved. The exact complete-family stop rule is therefore **unsupported/incomplete**, not passed.

All five candidate preparations remain within the lowest quartile under the mean+SD stress ranking. Assigning the unresolved preparation provisionally to ixazomib or retaining it separately likewise leaves the low-rank pattern unchanged. Those sensitivities do not resolve identity. Thus duplicate handling does not explain away the observed low viability of the three established active compounds, while complete reagent-level interpretation remains limited.

## Scope and next action

This is newly assembled source-grounded evidence, not a new proteasome target discovery. Selected response values were inspected before the protocol; retrospective selection and threshold choice are explicit. Unknown NCC concentration, duration, biological/technical replicate definition, target engagement and dose-response fitting prevent mechanistic attribution and cross-drug potency conclusions. One model cannot establish EMC selectivity, a therapeutic window or clinical efficacy. No numerical NCC–Zurich concordance, Zurich band analysis, hypothesis test or expression reanalysis was performed.

The concrete residual identity question is the vendor catalogue/product identity for CAS1201902-80-8 and why the source follow-up calls it Ixazomib. It should be appended by the coordinator to normal correspondence only if useful and without duplicating the already-sent request. NCC assay Methods and Zurich source measurements remain the prerequisites for a different quantitative cross-study analysis.

## Reproduction and validation

`analyze.py` reads only the frozen roster/protocol and existing source CSVs and emits `ranked-screen.csv`, `result.json`, `checks.json` and short exact regulatory quote checks. No network is used by analysis. `source-screen.csv` and `source-ic50.csv` preserve the original source CSV bytes. Ranks were checked independently using strict-less-than and tie counts; a tied-rank fixture passes. All frozen hashes, all221 entries, all24 follow-up mappings and three short regulatory excerpts were checked. The differing registry connectivity blocks were checked from cached machine-readable responses.

Run with the bundled Python executable, `-B -X utf8`, followed by this directory's `analyze.py`. `acquire_sources.py` documents optional source acquisition; successful bytes and failed requests are retained in provenance. Direct GSRS access failed TLS verification and two Europe PMC requests returned503; the successful authoritative indexed GSRS/PubChem evidence is archived separately. No retry loops, TLS bypass, paid service or inferred successful download occurred.

This is a complete bounded writer checkpoint, not independent scientific review or publication clearance. No commits, pushes, preflight, messages to authors or background processes were launched.
