---
id: DOC-NCC-METHODS-RESCUE-20260906
title: Bounded NCC 2025 Methods rescue
kind: memo
status: live
date: 2026-09-06
last_verified: 2026-09-06
purpose: Record additional legitimate access checks without repeating failed source requests.
scope: DOI 10.1007/s13577-025-01250-7 assay Methods access.
audience: [maintainers, autonomous research agents]
---

No Methods text was recovered. Screen concentration, exposure duration, normalization, replicate definition and IC50 fitting remain unverified for this exact article. The SD column and abstract screening description do not supply these details.

Before searching, read the integrated NCC assay provenance, original NCC/Zurich access memo and source-provenance JSON. They document a subscription preview without Methods, unsuccessful exact MOESM3 access and public MOESM4–6 recovery. No MOESM3 retry, supplement guessing or borrowing conditions from another NCC paper occurred.

Additional routes examined:

- Normal browser entry for the exact publisher URL through `cua.getBrowser` returned **No browser is available**. This is an environment limitation; no publisher-browser page was actually loaded. It does not establish an access denial or global unavailability.
- DOI/title searches for accepted manuscripts and repositories, including a Chiba repository-specific query, surfaced bibliography/abstract records rather than a verified manuscript deposit. Search output is preserved in `web-evidence.json`.
- A newly surfaced institutional repository list at https://reins.tmd.ac.jp/tmdu_hp/S00300701102000600_rep_en.html had an indexed title match. Its live web rendering/find did not reproduce the exact NCC-EMC title, so the search snippet was not treated as a deposit. Direct preservation failed certificate verification; no TLS bypass was used. No source Methods were inferred from the institutional label.
- The DOI-linked OpenAlex work API returned `oa_status: closed`, `best_oa_location: null`, `any_repository_has_fulltext: false`. Its two locations were the publisher DOI and PubMed, both without PDF URLs. This is indexed metadata evidence, not proof that every legitimate deposit is absent. Exact API response bytes and request/hash metadata are preserved.
- The NCC laboratory publication page search result identifies this paper but points to PubMed. The ResearchGate result is a Request PDF/abstract listing. Neither yields the requested Methods text, and no request was sent.

The remaining concrete access route is a normal publisher browser with legitimate subscription access, if available elsewhere, or the already scoped author response. This worker cannot resolve it with the currently available browser surface. No paper-level or assay-compatibility conclusion changes. No correspondence, spending, tracked edits, pharmacology packet changes or running processes.
