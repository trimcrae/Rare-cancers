# B2 episode 1 — the original execution record, and exactly what it contains

The second archive shipped only `agent-a56ed0c3f3f470acc.jsonl`, whose first record is
2026-09-08T14:43:22Z, and `b2-lane/STATE.txt` correctly calls that the POST-RESTART episode.
⛔ That log is episode 2 alone. It must not be described as covering both.

**Episode 1's original transcript SURVIVES and was omitted from that archive by my error, not by
its absence.** It ships here.

| file | bytes | first record | last record |
|---|---:|---|---|
| `agent-a926deb4c243c5d6f.jsonl` | 128,414 | `2026-09-08T14:41:12.587Z` | `2026-09-08T14:42:03.499Z` |
| `agent-a926deb4c243c5d6f.meta.json` | 156 | — | — |

51 records, 15 `tool_use` calls. `grep -o '"model":"[^"]*"'` over it returns `claude-opus-5` and
nothing else. Its meta records `description: "B2 raster image builder candidate"`,
`toolUseId: toolu_01GN4VaYqhm9nTCUKEGCThWL`, `model: opus`, `spawnDepth: 1` — the original dispatch,
whose task the container restart stopped mid-run.

The transcript ends where the restart cut it: its last `tool_use` is the `tar` that was building
`/tmp/claude-0/b2-lane/sandbox/base`. Nothing after that was written, and nothing was reconstructed.

## Episode 1's surviving on-disk artifact, and why it is not here

Episode 1 produced exactly **one** filesystem artifact: `/tmp/claude-0/b2-lane/sandbox/`, directory
mtime `14:41`, 673,696,076 bytes — a non-git copy of the repository working tree. No diffs, no notes,
no probes, no partial patch; episode 2 reused that sandbox rather than re-copying it.

⚠ It is **excluded from every archive on size grounds** and remains in place on the container. It is
a duplicate of files this repository already holds, so shipping it would transport ~674 MB of copies.
`SANDBOX-EXCLUDED.txt` in the second archive records this, and this note records that the excluded
directory is the whole of episode 1's filesystem output.

⛔ No recovery run, no reconstruction, and no relabelling of the episode-2 log.
