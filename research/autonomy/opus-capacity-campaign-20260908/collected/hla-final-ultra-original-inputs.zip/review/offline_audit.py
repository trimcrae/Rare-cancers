"""Independent offline reading/algebra checks; no producer imports or network calls."""
import ast, datetime, hashlib, json, math, pathlib, re, sys
ROOT = pathlib.Path(__file__).resolve().parents[1]
FROZEN = ROOT / 'frozen'
MOD = FROZEN / 'research/modalities'
OUT = ROOT / 'review/offline-audit-results.run2.json'
def read(name):
    return json.loads((MOD / name).read_text(encoding='utf-8'))
def pct(value):
    return 'UNKNOWN' if value is None else f'{100*value:.2f}%'
def ci(value, suffix=True):
    return '\u2014' if value is None else f'{100*value[0]:.2f}\u2013{100*value[1]:.2f}' + ('%' if suffix else '')
def product_cov(afs):
    afs = list(afs)
    return None if not afs else round(1-math.prod((1-p)**2 for p in afs),4)
checks = []
def check(name, observed, expected):
    checks.append({'name':name, 'pass': observed==expected, 'observed':observed, 'expected':expected})
h = read('hla-coverage.json'); g=h['global']; regions=h['regions']
c = read('coverage-curve.json'); m=read('epitope-allele-matrix.json')
bp=read('fusion-breakpoint-neoantigens.json'); cd4=read('patient-cd4-demo.json')
v=read('vaccine-construct.json'); tx=read('emc-construct-inputs.json')
paper=FROZEN/'research/manuscripts/neoantigen/hla-coverage-emc.md'
raw=paper.read_bytes(); lines=raw.decode('utf-8').splitlines()
check('manuscript_bytes', len(raw), 47368)
check('manuscript_sha256', hashlib.sha256(raw).hexdigest(), '768398917208449a088c6d2aa9549d9162b4bbc9aa1c3584d13a55c1ac45af0c')
table_rows={}
for n,line in enumerate(lines,1):
    if line.startswith('|'):
        cells=[s.strip().replace('\\*','*') for s in line.strip('|').split('|')]
        table_rows[cells[0]]=(n,cells)
for name,r in regions.items():
    expected=[name,pct(r['coverage_e7e3_public']),ci(r['coverage_e7e3_public_95ci']),
              pct(r['coverage_any_strong_binder_allele']),ci(r['coverage_any_strong_binder_allele_95ci']),
              pct(r['coverage_cd4_classii']),ci(r['coverage_cd4_classii_95ci']),
              ', '.join(r['coverage_all_alleles_used']) or 'none',
              f"{r['max_total_individuals']:,}",str(r['max_n_populations'])]
    check(f'regional_table:{name}:L{table_rows[name][0]}',table_rows[name][1],expected)
for a,info in g['allele_frequencies'].items():
    expected=[a,'class II (DRB1)' if a.startswith('DRB') else 'class I',
              pct(info['allele_frequency']),ci(info['af_95ci']),pct(info['carrier_frequency']),
              str(info['n_populations']),f"{info['total_individuals']:,}"]
    check(f'global_frequency_table:{a}',table_rows[a][1],expected)
for key,allele_key in [('coverage_e7e3_public','e7e3_public_epitope_alleles'),
                       ('coverage_any_strong_binder_allele','all_strong_binder_alleles'),
                       ('coverage_cd4_classii','class_ii_cd4_helper_alleles')]:
    inf=[g['allele_frequencies'][a] for a in g[allele_key]]
    check(f'global_artifact_formula:{key}',g[key],product_cov(x['allele_frequency'] for x in inf))
    check(f'global_artifact_interval_transform:{key}',g[key+'_95ci'],
          [product_cov(x['af_95ci'][i] for x in inf) for i in range(2)])
for name,r in regions.items():
    for key,allele_key in [('coverage_e7e3_public','coverage_e7e3_alleles_used'),
                           ('coverage_any_strong_binder_allele','coverage_all_alleles_used')]:
        inf=[r['allele_frequencies'][a] for a in r[allele_key]]
        check(f'regional_artifact_formula:{name}:{key}',r[key],product_cov(x['allele_frequency'] for x in inf))
        check(f'regional_artifact_interval_transform:{name}:{key}',r[key+'_95ci'],
              [product_cov(x['af_95ci'][i] for x in inf) for i in range(2)] if inf else None)
check('both_arms_arithmetic',g['coverage_cd8_and_cd4_combined'],round(g['coverage_any_strong_binder_allele']*g['coverage_cd4_classii'],4))
base={'A*01:01','B*07:02','B*15:01'}
complete=[name for name,r in regions.items() if set(r['coverage_all_alleles_used'])==base]
incomplete=[name for name in regions if name not in complete]
check('complete_region_count',len(complete),13)
check('incomplete_region_names',sorted(incomplete),['Melanesia','Micronesia','Polynesia'])
check('expanded_panel_size',c['panel_size'],len(m['panel']))
check('expanded_presenting_set',c['presenting_alleles'],m['presenting_alleles'])
check('expanded_number_presenting',c['n_presenting_alleles'],len(m['presenting_alleles']))
for n,item in enumerate(c['global_curve'],1):
    check(f'global_curve_step_{n}',item['cumulative_coverage'],product_cov(x['af'] for x in c['global_curve'][:n]))
    row=table_rows[str(n)][1]
    check(f'global_curve_table_step_{n}',row,[str(n),item['allele_added'],pct(item['af']),pct(item['cumulative_coverage'])])
check('global_curve_endpoint',c['global_max_coverage'],c['global_curve'][-1]['cumulative_coverage'])
check('global_curve_targets',c['global_alleles_to_reach'],{f'{int(t*100)}pct':next((x['n_alleles'] for x in c['global_curve'] if x['cumulative_coverage']>=t),None) for t in (.5,.8,.9,.95)})
e7=next(j for j in bp['junctions'] if j['EWSR1_exon_end']==7 and j['NR4A3_exon_start']==3)
base_strong=[b for j in bp['junctions'] for b in j['binders'] if b['class']=='strong']
e7_strong=[b for b in e7['binders'] if b['class']=='strong']
cd4strong=[b for b in cd4['all_predictions'] if b['call']=='strong']
check('base_classI_set_from_retained_calls',g['all_strong_binder_alleles'],sorted({x['allele'] for x in base_strong}))
check('e7_classI_set_from_retained_calls',g['e7e3_public_epitope_alleles'],sorted({x['allele'] for x in e7_strong}))
check('classII_set_from_retained_calls',g['class_ii_cd4_helper_alleles'],sorted({x['allele'] for x in cd4strong}))
check('classII_panel_count',len(cd4['patient_class2_hla']),23)
check('classII_strong_count',len(cd4strong),1)
check('classII_reported_screened',cd4['n_alleles_screened'],23)
check('classII_no_reported_missing_model',cd4['alleles_without_a_model'],[])
lead=v['lead_public_construct']
check('construct_window_length',len(lead['assembled_window']),27)
check('construct_minimal_length',len(lead['minimal_SLP']['sequence']),lead['minimal_SLP']['length'])
check('construct_cd8_pairs',lead['cd8_strong_epitopes'],[{k:b[k] for k in ['peptide','allele']} for b in e7_strong])
check('construct_cd4_pairs',lead['cd4_strong_epitopes'],[{k:b[k] for k in ['peptide','allele']} for b in cd4strong])
check('retained_minimal_contains_all_retained_epitopes',all(b['peptide'] in lead['minimal_SLP']['sequence'] for b in lead['cd8_strong_epitopes']+lead['cd4_strong_epitopes']),True)
check('leading_N_is_recorded_seam_codon',e7['seam_codon_residue'],'N')
parent_absence={b['peptide']:{gene:b['peptide'] not in tx['genes'][gene]['protein'] for gene in ('EWSR1','NR4A3')} for b in e7_strong+cd4strong}
check('retained_selected_epitopes_absent_from_two_parents',all(all(x.values()) for x in parent_absence.values()),True)
static_imports={}
for path in [MOD/'hla_coverage.py',MOD/'coverage_scan.py',MOD/'vaccine_construct.py']:
    imports=[]
    for node in ast.walk(ast.parse(path.read_text(encoding='utf-8'))):
        if isinstance(node,ast.Import):
            imports.extend({'module':a.name,'line':node.lineno} for a in node.names)
        elif isinstance(node,ast.ImportFrom):
            imports.append({'module':node.module,'line':node.lineno})
    static_imports[path.name]=sorted(imports,key=lambda x:x['line'])
e7_matrix=[r for r in m['strong_binders'] if r['peptide'] in e7['novel_peptides']]
pA,p7,p15=[g['allele_frequencies'][a]['allele_frequency'] for a in ['HLA-A*01:01','HLA-B*07:02','HLA-B*15:01']]
independent=1-(1-pA)**2*(1-p7)**2*(1-p15)**2
grouped=1-(1-pA)**2*(1-p7-p15)**2
mathematical_diagnostics={
 'same_locus_identity':'With fixed valid frequencies p,q at one diploid HWE locus, absence of both is (1-p-q)^2, not (1-p)^2(1-q)^2. The latter is larger for p,q>0; with other model assumptions fixed it underestimates the union. This does NOT sign total bias versus actual human populations.',
 'conditional_global_rounded_input_diagnostic_only':{'artifact_formula_unrounded':independent,'locus_grouped_unrounded':grouped,'difference_percentage_points':100*(grouped-independent)},
 'pooled_HWE_identity':'For the SAME survey weights and subpopulation HWE, f(mean p)-mean f(p)=Var_w(p), where f(p)=2p-p^2. Pooled HWE is not the mean of within-survey HWE carriage unless frequencies are constant. No empirical correction can be computed without retained per-survey rows.',
 'CI_scope':'All endpoints above only verify the stored transformations; none validates nominal 95% frequentist coverage under heterogeneous surveys, duplicate cohorts or same-/cross-locus dependence.',
}
result={
 'frozen_revision':'6cd29f876b11492e01f4e2ea10752e1bf0dbc4f4',
 'run_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'scope':'Offline JSON/table/source checks and deterministic algebra only; no producer imports, inference regeneration, network, pytest, preflight or biological design.',
 'checks':checks, 'n_checks':len(checks),'n_failed':sum(not c['pass'] for c in checks),
 'static_imports':static_imports,
 'e7e3_expanded_retained_matrix_strong_calls':e7_matrix,
 'base_classI_predictor_metadata':bp['_predictor'],
 'classII_retained_row_count':len(cd4['all_predictions']),
 'classII_possible_declared_pairs':len(cd4['patient_class2_hla'])*cd4['n_candidate_15mers'],
 'classII_retained_strong_calls':cd4strong,
 'two_parent_absence_reading':parent_absence,
 'frequency_artifact_raw_count_fields_retained':False,
 'regional_classII_allele_frequencies_retained':any(any('DRB' in a for a in r['allele_frequencies']) for r in regions.values()),
 'regional_single_allele_sample_counts_retained':False,
 'e7e3_maximum':max(((name,r['coverage_e7e3_public'],r['coverage_e7e3_public_95ci']) for name,r in regions.items() if r['coverage_e7e3_public'] is not None),key=lambda x:x[1]),
 'cd4_minimum':min(((name,r['coverage_cd4_classii'],r['coverage_cd4_classii_95ci']) for name,r in regions.items() if r['coverage_cd4_classii'] is not None),key=lambda x:x[1]),
 'smallest_four_maximum_survey_bases':sorted(((name,r['max_total_individuals'],r['max_n_populations']) for name,r in regions.items()),key=lambda x:x[1])[:4],
 'complete_region_count':len(complete),'incomplete_region_names':incomplete,
 'minimum_among_complete_classI_regions':min(((name,regions[name]['coverage_any_strong_binder_allele']) for name in complete),key=lambda x:x[1]),
 'mathematical_diagnostics':mathematical_diagnostics,
 'figure_visual_inspection':{'path':'research/modalities/coverage-curve.png','method':'Original frozen PNG inspected through view_image; no digitisation or regenerated chart.',
   'observed':'Shows 20 allele positions, global endpoint approximately 85%, Northern Europe endpoint above 90%. These are visual approximate readings, not recovered source measurements.',
   'required_by_frozen_JSON':{'global_points':len(c['global_curve']),'global_endpoint':c['global_max_coverage'],'Northern_Europe_endpoint':c['regions']['Northern Europe']['max_coverage']},
   'verdict':'MATERIAL MISMATCH: stale or otherwise wrong figure for the current coverage-curve.json and manuscript section 3.3; origin not reconstructed.'},
}
OUT.write_text(json.dumps(result,ensure_ascii=True,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:result[k] for k in ['run_utc','scope','n_checks','n_failed','e7e3_maximum','cd4_minimum','smallest_four_maximum_survey_bases','minimum_among_complete_classI_regions','mathematical_diagnostics','figure_visual_inspection']},ensure_ascii=True,indent=2))
print('EXIT='+str(int(result['n_failed']>0)))
sys.exit(int(result['n_failed']>0))
