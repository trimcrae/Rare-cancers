import datetime, hashlib, json, pathlib, subprocess, sys
root=pathlib.Path(__file__).resolve().parent
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
script=root/'offline_audit.py'
proc=subprocess.run([sys.executable,str(script)],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
(root/'offline-audit.run2.stdout.txt').write_bytes(proc.stdout)
(root/'offline-audit.run2.stderr.txt').write_bytes(proc.stderr)
record={'started_utc':start,'ended_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'command':[sys.executable,str(script)],'exit_code':proc.returncode,
        'script_sha256':hashlib.sha256(script.read_bytes()).hexdigest(),
        'stdout_sha256':hashlib.sha256(proc.stdout).hexdigest(),
        'stderr_sha256':hashlib.sha256(proc.stderr).hexdigest(),
        'rerun_reason':'Four run-1 table-format comparisons failed because this review harness omitted the percent suffix in expected Wilson interval strings. Run-1 originals are retained. Only the harness formatting is fixed; frozen source files are unchanged.'}
(root/'offline-audit.run2.execution.json').write_text(json.dumps(record,ensure_ascii=True,indent=2)+'\n',encoding='utf-8')
print(proc.stdout.decode('utf-8',errors='replace'))
print(json.dumps(record,ensure_ascii=True,indent=2))
sys.exit(proc.returncode)
