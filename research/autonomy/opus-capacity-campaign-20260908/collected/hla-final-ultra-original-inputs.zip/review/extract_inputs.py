"""Preserve exact frozen Git blobs, never checkout or modify the repository."""
import hashlib, json, pathlib, subprocess, sys, datetime
ROOT = pathlib.Path(__file__).resolve().parents[1]
REPO = pathlib.Path('C:/Projects/EMC-Research')
REV = '6cd29f876b11492e01f4e2ea10752e1bf0dbc4f4'
DEFAULTS = [
    'AGENTS.md', 'CLAUDE.md', '.claude/skills/paper-hardening/SKILL.md',
    '.claude/skills/repo-gates/SKILL.md', 'research/autonomy/OPERATING_PROTOCOL.md',
    'research/autonomy/publish_bar.py', 'systems/graph/publications.json',
    'research/autonomy/opus-capacity-campaign-20260908/paper-lane/HANDOFF-hla-coverage-frozen-readiness.md',
    'research/manuscripts/neoantigen/hla-coverage-emc.md',
    'research/manuscripts/neoantigen/hla-coverage-emc-history.md',
    'research/modalities/hla_coverage.py', 'research/modalities/hla-coverage.json',
    'research/modalities/coverage_scan.py', 'research/modalities/coverage-curve.json',
    'research/modalities/coverage-curve.png', 'research/modalities/vaccine_construct.py',
    'research/modalities/vaccine-construct.json', 'research/modalities/fusion-breakpoint-neoantigens.json',
    'research/modalities/patient-cd4-demo.json', 'research/modalities/epitope-allele-matrix.json',
]
manifest_path = ROOT / 'review' / 'input-manifest.json'
manifest = json.loads(manifest_path.read_text()) if manifest_path.exists() else {
    'frozen_revision': REV, 'source_repository': str(REPO), 'files': [],
    'requested_model': 'gpt-6-astra', 'requested_reasoning_effort': 'ultra',
    'backend_attestation': 'unavailable', 'token_usage': 'unavailable',
    'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
}
known = {entry['git_path']:entry for entry in manifest['files']}
for path in sys.argv[1:] or DEFAULTS:
    data = subprocess.check_output(['git', '-C', str(REPO), 'show', REV + ':' + path])
    blob = subprocess.check_output(['git', '-C', str(REPO), 'rev-parse', REV + ':' + path], text=True).strip()
    out = ROOT / 'frozen' / path
    out.parent.mkdir(parents=True, exist_ok=True)
    if out.exists():
        assert out.read_bytes() == data, 'Existing evidence copy differs; refusing overwrite: ' + path
    else:
        out.write_bytes(data)
    known[path] = {'git_path':path, 'revision':REV, 'git_blob':blob, 'bytes':len(data),
                   'sha256':hashlib.sha256(data).hexdigest(), 'retained_path':str(out)}
manifest['files'] = list(known.values())
manifest_path.write_text(json.dumps(manifest, ensure_ascii=True, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'input_count':len(known), 'manifest':str(manifest_path)}, ensure_ascii=True))
