"""Retain the supplied intake receipt and finalize a read-only review inventory."""
import datetime, hashlib, json, pathlib, subprocess
ROOT=pathlib.Path(__file__).resolve().parents[1]
REPO=pathlib.Path('C:/Projects/EMC-Research')
REV='6cd29f876b11492e01f4e2ea10752e1bf0dbc4f4'
def digest(b): return hashlib.sha256(b).hexdigest()
def write(path,obj):
    assert not path.exists(), 'Refusing to overwrite final original '+str(path)
    path.write_text(json.dumps(obj,ensure_ascii=True,indent=2)+'\n',encoding='utf-8')
review=ROOT/'review'
source=pathlib.Path('C:/Users/mcrae/.codex/review-workspaces/opus-capacity-sprint-20260907/capacity-campaign-20260908/observations/6cd29f87/delta-intake-receipt.json')
data=source.read_bytes()
external=ROOT/'received/delta-intake-receipt.json'
external.parent.mkdir(parents=True,exist_ok=True)
assert not external.exists()
external.write_bytes(data)
write(review/'external-input-manifest.json',{'files':[{'source_path':str(source),'retained_path':str(external),'bytes':len(data),'sha256':digest(data),'git_bound':False,'role':'root observation receipt; not scientific primary data'}]})
manifest=json.loads((review/'input-manifest.json').read_text())
audit=json.loads((review/'offline-audit-results.run2.json').read_text())
paper='research/manuscripts/neoantigen/hla-coverage-emc.md'
verdict={
 'review_type':'one independent final scientific review batch',
 'publication_id':'PUB-HLA-COVERAGE','reviewed_commit':REV,
 'document':paper,'document_bytes':47368,
 'document_sha256':'768398917208449a088c6d2aa9549d9162b4bbc9aa1c3584d13a55c1ac45af0c',
 'requested_model':'gpt-6-astra','requested_reasoning_effort':'ultra','requested_fork_turns':'none',
 'backend_attestation':'unavailable','token_usage':'unavailable',
 'independent_of_authoring':True,'blind_to_supplied_handoff':False,
 'publication_gate_seat_record':False,
 'central_claim':'The manuscript supplies modelled global and regional population carrier coverage estimates for predicted EWSR1::NR4A3 junction binders, with coverage intervals, to characterize the limited and population-dependent reach of the retained panels.',
 'verdict':'not_supported_in_current_population_coverage_scope',
 'recommendation':'park',
 'experimental_blocker_cleared':False,
 'blocking_experimental_data_required_for_narrow_computational_scope':False,
 'findings':[
   {'id':'HLA-F1','priority':1,'class':'submission blocker','category':'central source provenance','manuscript_lines':[9,11,89,94,232,242,517,521,578,594],
    'finding':'Mutable branch-source URLs, no retained raw frequency/region snapshots or source revisions/retrieval time, no retained included survey rows, despite pinned/re-runnable claims.',
    'evidence':['research/modalities/hla_coverage.py:61','research/modalities/hla_coverage.py:153','research/modalities/hla_coverage.py:198','research/modalities/hla-coverage.json:7'],
    'minimum_action':'Correct reproduction claims; for population inference supply identifiable source snapshots and included survey/count/assignment provenance, or adopt a separately chosen artifact-audit scope.'},
   {'id':'HLA-F2','priority':1,'class':'submission blocker','category':'central population estimand and uncertainty','manuscript_lines':[108,126,232,242,246,316,435],
    'finding':'Allele-specific heterogeneous survey mixtures are not a defined human target population; pooled HWE differs from mean survey carriage; transformed marginal Wilson endpoints do not establish nominal 95% population coverage uncertainty.',
    'evidence':['research/modalities/hla_coverage.py:83','research/modalities/hla_coverage.py:156','research/modalities/hla_coverage.py:219','research/manuscripts/neoantigen/hla-coverage-emc.md:339','systems/POLICY-evidence.md:116'],
    'minimum_action':'Define target population/weights, survey inclusion and overlap/resolution handling and justify uncertainty; otherwise narrow to synthetic plug-in scenarios and recorded, uncalibrated bands.'},
   {'id':'HLA-F3','priority':1,'class':'submission blocker','category':'bounded probability-model defect','manuscript_lines':[111,115,246,258,547,553],
    'finding':'The allele-wise product is not the union probability for mutually exclusive same-locus alleles under the stated diploid model.',
    'evidence':['research/modalities/hla_coverage.py:225','research/modalities/coverage_scan.py:113','review/offline-audit-results.run2.json:mathematical_diagnostics'],
    'minimum_action':'Group same-locus allele frequencies before interpreting a carrier union, preserving a stated residual cross-locus assumption; or retain only as a historical nonprobabilistic score.',
    'conditional_diagnostic_difference_percentage_points':audit['mathematical_diagnostics']['conditional_global_rounded_input_diagnostic_only']['difference_percentage_points'],
    'total_empirical_bias_direction':'unknown'},
   {'id':'HLA-F4','priority':1,'class':'submission blocker','category':'bounded figure defect','manuscript_lines':[442,466],
    'finding':'Frozen PNG shows 20 allele positions and approximately 85% global coverage; current JSON/manuscript contain four qualifying alleles and 30.40% global maximum.',
    'evidence':['research/modalities/coverage-curve.png','research/modalities/coverage-curve.json:3','research/modalities/coverage-curve.json:37','research/modalities/coverage-curve.json:72'],
    'minimum_action':'Withdraw incorrect figure/reference from outgoing package or replace using the adjudicated final data, preserve original and inspect replacement.'},
   {'id':'HLA-F5','priority':1,'class':'submission blocker','category':'bounded biological claim ceiling','manuscript_lines':[100,103,176,177,197,204,508,509],
    'finding':'Normal-proteome absence exceeds a two-parent novelty filter; categorical weaker T-cell target and background causal generalizations lack support from this analysis.',
    'evidence':['research/modalities/fusion_breakpoints.py:291','research/modalities/emc-construct-inputs.json','research/manuscripts/neoantigen/fusion-junction-neoantigen-paper.md:20'],
    'minimum_action':'Limit novelty to absence from named parental proteins and remove or qualify unsupported biological/causal assertions; no new sequences or assay needed for narrowing.'},
   {'id':'HLA-F6','priority':2,'class':'submission blocker','category':'bounded scope and methods description','manuscript_lines':[121,128,145,148,212,228,365,370,420,423,439,450],
    'finding':'Single-allele e7::e3 headline omits retained A*30:02 call and base best-per-peptide selection; regional headline compares incomplete and complete allele sets; operational score definitions are omitted.',
    'evidence':['research/modalities/epitope-allele-matrix.json:48','research/modalities/fusion_breakpoints.py:466','research/modalities/fusion-breakpoint-neoantigens.json:1279','research/modalities/patient-cd4-demo.json:71','research/manuscripts/neoantigen/hla-coverage-emc.md:399'],
    'minimum_action':'Name 10-allele base selection rule and retained score thresholds; acknowledge broader existing e7::e3 call without inventing a new coverage number; compare the 13 complete rows separately.'},
 ],
 'positive_findings':{
    'table_and_algebra_comparisons':122,'comparisons_failed_after_harness_fix':0,
    'e7e3_maximum':audit['e7e3_maximum'],'cd4_minimum':audit['cd4_minimum'],
    'incomplete_regions':audit['incomplete_region_names'],'complete_regions':13,
    'both_arms_product_scope_caveat_correct':True,'classII_23_panel_one_retained_strong_allele_supported':True,
    'construct_description_matches_retained_artifact':True,'ethics_and_declarations_present':True,
    'N_at_e7e3_peptide_start_is_seam_codon_not_evidence_of_parent_fragment':True
 },
 'execution':{'offline_checks_only':True,'producer_runs':0,'prediction_runs':0,'construct_runs':0,'network_fetches':0,'pytest_runs':0,'preflight_runs':0,
              'first_harness_run_exit':1,'first_harness_issue':'Four expected interval strings lacked percent suffix; original script/results retained.',
              'corrected_harness_run_exit':0,'full_report':'review/FINAL-SCIENTIFIC-REVIEW.md'},
 'reopening':{'population_scope':['identifiable original input snapshots or explicitly new versioned study','auditable eligible source rows and target-population definition','locus-correct probability model and defensible uncertainty','correct matched figure and repaired scope/novelty statements'],
              'alternative_scope':'Separately chosen technical audit of frozen artifact and its reproducibility/interpretation limits, without population or eligibility estimates.',
              'no_automatic_new_work_authorized_by_review':True},
 'retention':'No cleanup without sole-owner directory-specific collection receipt; all generated originals retained.'
}
write(review/'scientific-verdict.json',verdict)
checks=[]
for entry in manifest['files']:
    file=pathlib.Path(entry['retained_path'])
    retained=file.read_bytes()
    git=subprocess.check_output(['git','-C',str(REPO),'show',REV+':'+entry['git_path']])
    checks.append({'git_path':entry['git_path'],'bytes':len(retained),'sha256':digest(retained),
                   'manifest_matches':len(retained)==entry['bytes'] and digest(retained)==entry['sha256'],
                   'exact_git_bytes_match':retained==git})
end=datetime.datetime.now(datetime.timezone.utc)
start=datetime.datetime.fromisoformat(manifest['started_utc'])
generated=[]
for file in sorted(ROOT.rglob('*')):
    if file.is_file() and 'frozen' not in file.relative_to(ROOT).parts:
        b=file.read_bytes()
        generated.append({'relative_path':file.relative_to(ROOT).as_posix(),'bytes':len(b),'sha256':digest(b)})
final={'frozen_revision':REV,'started_utc':manifest['started_utc'],'completed_utc':end.isoformat(),
       'elapsed_seconds':(end-start).total_seconds(),
       'requested_model':'gpt-6-astra','requested_reasoning_effort':'ultra','backend_attestation':'unavailable','token_usage':'unavailable',
       'frozen_input_count':len(checks),'input_checks':checks,
       'all_frozen_inputs_match':all(x['manifest_matches'] and x['exact_git_bytes_match'] for x in checks),
       'generated_and_received_originals':generated,
       'inventory_self_exclusion':'completion-integrity.json excludes itself to avoid a recursive hash; its exact file hash is reported to the sole owner at completion.',
       'no_repository_mutations_performed':True,'no_cleanup_performed':True,
       'review_complete':True,'verdict':'park current population-coverage preprint'}
assert final['all_frozen_inputs_match']
write(review/'completion-integrity.json',final)
print(json.dumps({k:final[k] for k in ['completed_utc','elapsed_seconds','frozen_input_count','all_frozen_inputs_match','review_complete','verdict']},ensure_ascii=True,indent=2))
for p in ['FINAL-SCIENTIFIC-REVIEW.md','scientific-verdict.json','completion-integrity.json']:
    b=(review/p).read_bytes()
    print(json.dumps({'path':str(review/p),'bytes':len(b),'sha256':digest(b)},ensure_ascii=True))
