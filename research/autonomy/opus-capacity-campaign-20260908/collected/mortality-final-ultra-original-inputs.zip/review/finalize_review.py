from pathlib import Path
import hashlib,json,datetime,subprocess
R=Path(__file__).resolve().parents[1]
I=R/'inputs'; V=R/'review'
started=json.loads((V/'input-manifest.json').read_text(encoding='utf-8'))['created_utc']
manifests=[json.loads((V/f).read_text(encoding='utf-8')) for f in ['input-manifest.json','dependency-manifest.json']]
checks=[]
OBS=Path(r'C:/Users/mcrae/.codex/review-workspaces/opus-capacity-sprint-20260907/capacity-campaign-20260908/observations/e21841ea')
for manifest in manifests:
    for row in manifest['files']:
        raw=(I/row['path']).read_bytes()
        digest=hashlib.sha256(raw).hexdigest()
        ok=len(raw)==row['bytes'] and digest==row['sha256']
        entry={'path':row['path'],'bytes':len(raw),'sha256':digest,'matches_original_manifest':ok}
        assert ok,entry
        obs=OBS/row['path']
        if row['path'].endswith('HANDOFF-mortality-frozen-readiness.md'):obs=OBS/Path(row['path']).name
        if obs.exists():
            entry['original_observation_still_exact']=obs.read_bytes()==raw
            assert entry['original_observation_still_exact'],entry
        if row.get('source'):
            entry['original_source_still_exact']=Path(row['source']).read_bytes()==raw
            assert entry['original_source_still_exact'],entry
        checks.append(entry)
now=datetime.datetime.now(datetime.timezone.utc)
stamp=now.isoformat()
report=V/'FINAL-SCIENTIFIC-REVIEW.md'
txt=report.read_text(encoding='utf-8')
assert txt.count('{{COMPLETED_UTC}}')==1
report.write_text(txt.replace('{{COMPLETED_UTC}}',stamp),encoding='utf-8')
artifacts=[]
for path in sorted(V.iterdir()):
    if path.is_file() and path.name!='completion-and-integrity.json':
        data=path.read_bytes(); artifacts.append({'path':str(path.relative_to(R)),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
receipt={'completed_utc':stamp,'first_retained_input_verification_utc':started,'elapsed_seconds_since_first_manifest':(now-datetime.datetime.fromisoformat(started)).total_seconds(),'frozen_revision':'e21841ea103560d801f4e21f64ee31a68028e232','requested_review_identity':'/root/mortality_final_ultra; inherited parent configuration; final ultra-review expressly requested','execution_identity_limitation':'Backend model/effort and token-usage receipt not exposed to this subagent; GPT-6-based Codex environment. No invented provider identity.','verdict':'PARK_CURRENT_MANUSCRIPT','all_frozen_inputs_unchanged':True,'input_checks':checks,'review_artifacts':artifacts,'execution_record':{'independent_checks_script':'review/independent_checks.py','independent_checks_observed_exit_code':0,'primary_survival_evidence_observed_exit_code':0,'inspection_scripts_observed_exit_codes':0,'pure_guard_tests':'Both intentionally invalid in-memory specimens were accepted by existing verifier functions; this is a demonstrated check limitation, not a process failure.','scientific_producer_mains_run':False,'whole_producer_chain_run':False,'full_preflight_run':False,'new_sources_retrieved':False,'packages_installed':False,'repo_edits':False,'original_scientific_inputs_modified':False,'warnings':'Initial read-only git status warned about .pytest_cache directory permissions. Large inspection output was truncated in tool display; decisive passages were read in focused calls and complete artifacts remain retained.'},'cleanup_authority':'None. Retain entire directory pending sole collector exact-directory receipt.'}
(V/'completion-and-integrity.json').write_text(json.dumps(receipt,indent=2,ensure_ascii=True)+'\n',encoding='utf-8')
print(json.dumps({'completed_utc':stamp,'verdict':receipt['verdict'],'all_frozen_inputs_unchanged':True,'input_count':len(checks),'report_bytes':report.stat().st_size,'report_sha256':hashlib.sha256(report.read_bytes()).hexdigest(),'receipt':str(V/'completion-and-integrity.json')},indent=2))
