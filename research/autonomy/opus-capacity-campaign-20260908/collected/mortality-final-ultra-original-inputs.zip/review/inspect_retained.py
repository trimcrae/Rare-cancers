from pathlib import Path
import json,re
R=Path(__file__).resolve().parents[1]
def read(name): return json.loads((R/'inputs'/name).read_text(encoding='utf-8'))
p=read('research/literature/emc-mortality-probe.json')
h=read('research/literature/emc-host-factor-probe.json')
reg=read('research/data/emc-clinical-registry.json')
summary={'mortality_keys':list(p),'host_keys':list(h),'registry_keys':list(reg)}
for k,v in p.items():
    if k!='terminal_events': summary['mortality_'+k]=v
for k,v in h.items():
    summary['host_shape_'+k]=list(v) if isinstance(v,dict) else len(v) if isinstance(v,list) else v
(R/'review'/'structure-summary.json').write_text(json.dumps(summary,ensure_ascii=True,indent=2),encoding='utf-8')
rows=[]
for e in p['terminal_events']:
    if re.search(r'myxoid chondrosarcoma|chordoid sarcoma|NR4A3',e.get('title',''),re.I): rows.append(e)
(R/'review'/'title-eligible-retained-sentences.json').write_text(json.dumps(rows,ensure_ascii=True,indent=2),encoding='utf-8')
print(json.dumps({'summary_file':'structure-summary.json','eligible_file':'title-eligible-retained-sentences.json','eligible_papers':len(rows),'sentence_count':sum(len(x['sentences']) for x in rows),'keys':summary['mortality_keys'],'host_keys':summary['host_keys']}))
