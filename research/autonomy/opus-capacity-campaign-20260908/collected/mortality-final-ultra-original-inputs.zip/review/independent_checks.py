"""Finite independent read-only checks; no producer main, network, or scientific edits."""
from pathlib import Path
from collections import Counter
import json, math, statistics, hashlib, datetime, importlib.util, sys
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parents[1]
I=R/'inputs'
def read(n): return json.loads((I/n).read_text(encoding='utf-8'))
def module(n):
    s=importlib.util.spec_from_file_location(n,I/'research/manuscripts'/f'{n}.py')
    m=importlib.util.module_from_spec(s); s.loader.exec_module(m); return m
spec=read('research/manuscripts/emc-terminal-events-classified.json')
p=read('research/literature/emc-mortality-probe.json')
surv=read('research/manuscripts/emc-relative-survival.json')
d=read('research/manuscripts/emc-mortality-decomposition-inputs.json')
host=read('research/literature/emc-host-factor-probe.json')
rt=read('research/literature/rt-lung-mets-probe.json')
reg=read('research/data/emc-clinical-registry.json')
events=spec['individual_events']
kept=[r for r in events if r['death_status']=='documented_death']
labels=Counter(); tiers=Counter(); types=Counter()
for r in kept:
    parts=r.get('split') or {r['label']:r['n_patients']}
    for label,n in parts.items():
        tier=r['split_mechanism_tiers'][label] if r.get('split') else r['mechanism_tier']
        labels[label]+=n; tiers[tier]+=n
        if tier=='stated_terminal_mechanism':
            types[r['split_stated_types'][label] if r.get('split') else r['stated_type']]+=n
idx={r['pmid']:[s['sentence'] for s in r['sentences']] for r in p['terminal_events']}
quote_checks=[{'pmid':r['pmid'],'quote_is_exact_retained_sentence':r['quote'] in idx[r['pmid']]} for r in events]
count_check={'rows':len(events),'reported_instances':sum(r['n_patients'] for r in events),'documented_instances':sum(r['n_patients'] for r in kept),'documented_papers':len({r['pmid'] for r in kept}),'legacy_labels':dict(labels),'tiers':dict(tiers),'stated_types':dict(types),'quote_checks':quote_checks}

# Sole-source correction counterfactual. This does NOT validate the other assignments or independence.
corrected=[r for r in kept if r['pmid']!='22569967']
count_check['remove_confirmed_MEC_deaths_only']={'remaining_documented_instances':sum(r['n_patients'] for r in corrected),'remaining_documented_papers':len({r['pmid'] for r in corrected}),'legacy_label_fraction':14/48,'no_cause_or_mechanism_stated':25,'qualification':'Sole-source exclusion arithmetic, not an accepted final EMC tally.'}

rates=host['background_mortality']['bands_used']
mf=d['background_mortality']['cohort_sex_ratio_male']
def expected(t):
    return sum(w*math.exp(-rates[sex]['AGEGROUP_YEARS55-59']['raw_value']*min(t,5)-rates[sex]['AGEGROUP_YEARS60-64']['raw_value']*max(0,t-5)) for sex,w in [('male',mf),('female',1-mf)])
shares=[]; allshares=[]; recalculated=[]
for s in d['series']:
    for horizon,O in s.get('overall_survival',{}).items():
        t=float(horizon)
        if t>10: continue
        E=expected(t); rs=O/E; g=(rs-O)/(1-O) if O<1 else None
        row={'series':s['key'],'years':t,'observed':O,'expected':E,'relative':rs,'derived_share_pct':100*g if g is not None else None}
        recalculated.append(row)
        if g is not None and rs<=1:
            allshares.append(g*100)
            if rs<0.99: shares.append(g*100)

# This is a mathematical counterexample, not synthetic patient evidence or an EMC estimate.
# Independent exponential latent disease/background event times with hazards 0.1 each.
a=b=0.1; t=5
O=math.exp(-(a+b)*t); E=math.exp(-b*t); rs=O/E
Fc=a/(a+b)*(1-O); Fb=b/(a+b)*(1-O)
proof={'kind':'analytical counterexample only; no patient data','disease_hazard':a,'background_hazard':b,'years':t,'observed_survival':O,'expected_survival':E,'relative_survival':rs,'true_disease_CIF':Fc,'true_background_CIF':Fb,'true_background_fraction_of_deaths':Fb/(1-O),'paper_derived_background_CIF':rs-O,'paper_derived_fraction_of_deaths':(rs-O)/(1-O),'survival_gain_if_disease_hazard_eliminated_and_background_unchanged':E-O,'observed_disease_CIF_upper_bound_on_that_gain':Fc}

# A 0.001 observed-survival perturbation around the excluded 0.88 horizon.
Ej=expected(10)
perturb=[{'O':x,'RS':x/Ej,'derived_share_pct':100*(x/Ej-x)/(1-x)} for x in [.879,.88,.881]]

def wilson(k,n):
    z=1.96; ph=k/n; q=1+z*z/n
    c=(ph+z*z/(2*n))/q; h=z*math.sqrt(ph*(1-ph)/n+z*z/(4*n*n))/q
    return [c-h,c+h]
registry=[{'stratum':s['key'],'disease_events':s['disease_death']['events'],'other_events':s['other_cause_death']['events'],'crude_disease_proportion':s['disease_death']['events']/s['n'],'observed_other_fraction_of_deaths':s['other_cause_death']['events']/(s['disease_death']['events']+s['other_cause_death']['events']),'other_fraction_Wilson95':wilson(s['other_cause_death']['events'],s['disease_death']['events']+s['other_cause_death']['events'])} for s in d['series'] if s.get('other_cause_death')]

# Exercise only pure verification functions with transient in-memory specimens.
term=module('emc_terminal_events'); dec=module('emc_mortality_decomposition')
baseline_term=term.verify_quotes(spec,term.probe_index(p))
forged=json.loads(json.dumps(spec))
forged['individual_events'][0]['quote'] += ' This appended causal assertion is invented for a review guard test.'
forged_result=term.verify_quotes(forged,term.probe_index(p))
changed=json.loads(json.dumps(d)); changed['series'][0]['overall_survival']['5']=.123
base_prov=dec.verify_provenance(d,dec.registry_text_blob(reg))
changed_prov=dec.verify_provenance(changed,dec.registry_text_blob(reg))
guards={'scope':'pure functions only; no producers executed; copies in memory only','baseline_terminal_errors':baseline_term,'invented_quote_suffix_errors':forged_result,'suffix_accepted':len(forged_result)==0,'baseline_decomposition_errors':base_prov,'changed_numeric_survival_to_0_123_errors':changed_prov,'changed_value_accepted':len(changed_prov)==0}

def walk(x,path='$'):
    if isinstance(x,dict):
        yield path,x
        for k,v in x.items(): yield from walk(v,path+'.'+k)
    elif isinstance(x,list):
        for k,v in enumerate(x): yield from walk(v,path+f'[{k}]')
source225=[{'path':path,**x} for path,x in walk(rt) if x.get('pmid')=='22569967' and x.get('abstract')]
growth=[{'path':path,**{k:v for k,v in x.items() if k not in ['top','hits']}} for path,x in walk(rt) if 'query' in x and any(s in str(x['query']).lower() for s in ['doubling','growth rate'])]
sources={'confirmed_MEC_death_evidence':source225,'growth_queries':growth,'palliative_queries':{k:{a:b for a,b in q.items() if a!='hits'} for k,q in p['queries'].items() if 'palliative' in k},'source_PMIDs_present_in_mortality_queries':{pmid:[k for k,q in p['queries'].items() if any(z.get('pmid')==pmid for z in q.get('hits',[]))] for pmid in ['20818875','32953543','37781179','38558247']}}
result={'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'frozen_revision':'e21841ea103560d801f4e21f64ee31a68028e232','counts':count_check,'relative_recalculation':recalculated,'relative_summary':{'included_n':len(shares),'included_distinct_series':len({r['series'] for r in recalculated if r['derived_share_pct'] is not None and r['relative']<.99}),'sorted_included_shares_pct':sorted(shares),'conventional_median_unrounded_pct':statistics.median(shares),'conventional_median_artifact_rounded_values_pct':statistics.median([round(v,1) for v in shares]),'upper_middle_used_by_producer_pct':sorted(round(v,1) for v in shares)[len(shares)//2],'all_finite_nonnegative_excess_n':len(allshares),'median_including_excluded_japan_pct':statistics.median(allshares),'range_including_japan_pct':[min(allshares),max(allshares)],'japan_10y_perturbation':perturb},'competing_risk_counterexample':proof,'registry_counts':registry,'guard_tests':guards,'source_checks':sources}
(R/'review'/'independent-check-results.json').write_text(json.dumps(result,ensure_ascii=True,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k not in ['relative_recalculation','source_checks','counts']},ensure_ascii=True,indent=2))
