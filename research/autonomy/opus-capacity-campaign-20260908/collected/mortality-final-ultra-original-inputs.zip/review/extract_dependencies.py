from pathlib import Path
import subprocess, hashlib, json, datetime, sys
ROOT=Path(__file__).resolve().parents[1]
REPO=Path(r'C:/Projects/EMC-Research')
REV='e21841ea103560d801f4e21f64ee31a68028e232'
out=ROOT/'review'/'dependency-manifest.json'
rows=json.loads(out.read_text(encoding='utf-8'))['files'] if out.exists() else []
for name in sys.argv[1:]:
    raw=subprocess.run(['git','show',REV+':'+name],cwd=REPO,check=True,capture_output=True).stdout
    blob=subprocess.run(['git','rev-parse',REV+':'+name],cwd=REPO,check=True,capture_output=True).stdout.decode().strip()
    target=ROOT/'inputs'/name
    target.parent.mkdir(parents=True,exist_ok=True)
    if target.exists(): assert target.read_bytes()==raw
    else: target.write_bytes(raw)
    row={'path':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'git_blob':blob}
    if row not in rows: rows.append(row)
    print(json.dumps(row))
out.write_text(json.dumps({'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'frozen_revision':REV,'files':rows},indent=2)+'\n',encoding='utf-8')
