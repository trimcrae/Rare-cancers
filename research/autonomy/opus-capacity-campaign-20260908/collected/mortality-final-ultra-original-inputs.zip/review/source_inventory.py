from pathlib import Path
import json
R=Path(__file__).resolve().parents[1]
def read(n): return json.loads((R/'inputs'/n).read_text(encoding='utf-8'))
out={}
for name in ['emc-mortality-probe.json','emc-host-factor-probe.json','rt-lung-mets-probe.json']:
    d=read('research/literature/'+name)
    qs=d.get('queries',{})
    out[name]={'keys':list(d),'queries':[{k:v for k,v in q.items() if k not in ('hits','articles','results')}|{'key':key} for key,q in qs.items()] if isinstance(qs,dict) else qs,'background':d.get('background_mortality')}
reg=read('research/data/emc-clinical-registry.json')
out['registry_overview']=reg['overview']
out['registry_cohorts']=reg['registry']['cohorts']
out['registry_studies']=reg['studies']
(R/'review'/'source-inventory.json').write_text(json.dumps(out,ensure_ascii=True,indent=2),encoding='utf-8')
print(json.dumps(out,ensure_ascii=True,indent=2))
