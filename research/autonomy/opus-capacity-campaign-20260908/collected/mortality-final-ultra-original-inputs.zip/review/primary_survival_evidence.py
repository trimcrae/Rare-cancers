from pathlib import Path
import json
R=Path(__file__).resolve().parents[1]
rt=json.loads((R/'inputs/research/literature/rt-lung-mets-probe.json').read_text(encoding='utf-8'))
reg=json.loads((R/'inputs/research/data/emc-clinical-registry.json').read_text(encoding='utf-8'))
spec=json.loads((R/'inputs/research/manuscripts/emc-mortality-decomposition-inputs.json').read_text(encoding='utf-8'))
def walk(x):
    if isinstance(x,dict):
        yield x
        for v in x.values(): yield from walk(v)
    elif isinstance(x,list):
        for v in x: yield from walk(v)
allrows=list(walk(rt)); out=[]
for s in spec['series']:
    key=s['key'].split('_localized')[0].split('_metastatic')[0]
    ref=reg['registry']['citations'][key]
    found={x['abstract'] for x in allrows if x.get('abstract') and ((ref.get('pmid') and x.get('pmid')==ref['pmid']) or (ref.get('doi') and x.get('doi')==ref['doi']))}
    out.append({'series':s['key'],'pmid':ref.get('pmid'),'doi':ref.get('doi'),'retained_abstracts':sorted(found)})
(R/'review/primary-survival-evidence.json').write_text(json.dumps(out,ensure_ascii=True,indent=2),encoding='utf-8')
print(json.dumps(out,ensure_ascii=True,indent=2))
