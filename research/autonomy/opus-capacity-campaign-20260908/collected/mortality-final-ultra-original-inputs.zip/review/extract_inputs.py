from pathlib import Path
import subprocess, hashlib, json, datetime

ROOT = Path(r'C:/Users/mcrae/Documents/Codex/2026-09-07/emc-research-orchestrator/work/mortality-final-review-20260908')
REPO = Path(r'C:/Projects/EMC-Research')
OBS = Path(r'C:/Users/mcrae/.codex/review-workspaces/opus-capacity-sprint-20260907/capacity-campaign-20260908/observations/e21841ea')
REV = 'e21841ea103560d801f4e21f64ee31a68028e232'
FILES = [
'AGENTS.md', 'CLAUDE.md', '.claude/skills/paper-hardening/SKILL.md', '.claude/skills/repo-gates/SKILL.md',
'research/autonomy/OPERATING_PROTOCOL.md',
'research/autonomy/opus-capacity-campaign-20260908/paper-lane/HANDOFF-mortality-frozen-readiness.md',
'research/manuscripts/emc-mortality-mechanisms-paper.md',
'research/manuscripts/emc-mortality-mechanisms.md',
'research/manuscripts/emc-terminal-events-classified.json',
'research/manuscripts/emc-terminal-events.json',
'research/manuscripts/emc_terminal_events.py',
'research/literature/emc-mortality-probe.json',
'research/manuscripts/emc_mortality_decomposition.py',
'research/manuscripts/emc-mortality-decomposition-inputs.json',
'research/manuscripts/emc-mortality-decomposition.json',
'research/manuscripts/emc_relative_survival.py',
'research/manuscripts/emc-relative-survival.json',
]
rows=[]
for name in FILES:
    raw=subprocess.run(['git','show',REV+':'+name],cwd=REPO,check=True,capture_output=True).stdout
    blob=subprocess.run(['git','rev-parse',REV+':'+name],cwd=REPO,check=True,capture_output=True).stdout.decode().strip()
    target=ROOT/'inputs'/name
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(raw)
    obs=OBS/name
    if name.endswith('HANDOFF-mortality-frozen-readiness.md'): obs=OBS/Path(name).name
    rows.append({'path':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'git_blob':blob,'observation_copy_present':obs.exists(),'observation_exact_match':obs.read_bytes()==raw if obs.exists() else None})
receipt=(OBS/'delta-intake-receipt.json').read_bytes()
(ROOT/'inputs'/'delta-intake-receipt.json').write_bytes(receipt)
rows.append({'path':'delta-intake-receipt.json','bytes':len(receipt),'sha256':hashlib.sha256(receipt).hexdigest(),'source':str(OBS/'delta-intake-receipt.json'),'git_blob':None})
manifest={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'frozen_revision':REV,'mode':'git show read-only; own review copies only','files':rows}
(ROOT/'review'/'input-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print(json.dumps(manifest,indent=2))
