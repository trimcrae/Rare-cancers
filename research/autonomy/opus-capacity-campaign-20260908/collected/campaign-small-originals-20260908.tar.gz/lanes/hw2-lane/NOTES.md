# NOTES — HW2 lane, correction pass over HW1's `hla-coverage-emc.md` candidate

Worker HW2, OPUS-CAPACITY-CAMPAIGN-20260908. WRITER, one bounded coherent correction pass.
Model: **`claude-opus-5` — SELF-REPORT, NOT INDEPENDENTLY VERIFIED.** The environment carries no
model variable; the literal `env` output is reproduced in the final report and in `MODEL-ENV.txt`.

## 0. State, and verification that my inputs did not move under me

| | value |
|---|---|
| start `date -u` | Tue Sep  8 13:44:31 UTC 2026 |
| start `git rev-parse HEAD` | `1a0ce07f66ffefe26ab3bc691db587147ea4169c` |
| start `git status --porcelain` | 4 modified files, all coordinator work on other manuscripts (`degrader/nr4a3-degrader-paper.md`, `endpoint/endpoint-regime-map.json`, `endpoint_regime_map.py`, `fusion-partner/emc-fusion-partner-stratification.md`) |
| end `date -u` | Tue Sep  8 13:52:11 UTC 2026 |
| end `git rev-parse HEAD` | `a06660787101f495cf1b2716aaccb429090896d0` |
| end `git status --porcelain` | *(empty — clean tree)* |

HEAD advanced while I worked. **Verified, not assumed**, per the campaign correction that ends
COMMON-BRIEF §1's blanket guarantee — I named my own inputs and checked those specifically:

* `git diff --stat 1a0ce07f a0666078 -- research/modalities/hla-coverage.json
  research/modalities/coverage-curve.json research/manuscripts/neoantigen/hla-coverage-emc.md
  paper-lane/HW1-executed-artifacts paper-lane/N2-executed-artifacts` → **empty**.
* sha256 of `hla-coverage.json` = `3b40a86392404800f6a0a5d5a701ecff49a168823ab067192ce2c5826d4acf9f`
  and of `coverage-curve.json` = `eb04c77ad5945083ab9ad2b98e654367d9c3a6a0864234e96983701681545acb`,
  identical at start and end.
* HW1's five lane files re-hashed at exit and byte-identical to their start hashes —
  `INPUT-HASHES-start.txt` vs `INPUT-HASHES-end.txt` differ in nothing.

I wrote **nothing** under `/home/user/Rare-cancers` and ran **no git write operation**. All output is
in `/tmp/claude-0/hw2-lane/`, left in place.

## 1. Deliverables in this lane

| file | what it is |
|---|---|
| `hla-coverage-emc.md` | the **corrected candidate** (600 lines) |
| `hla-coverage-emc-history.md` | the **corrected sibling history file**, with source pin, provenance and the exact retention statement |
| `HW2-vs-HW1-AFTER-block.diff` | unified diff of the candidate against HW1's `AFTER-block.md` |
| `SOURCE-KEY-MAP.md` | updated source-key map (new §D, corrected header and §B) |
| `HW2-history-vs-HW1.diff`, `HW2-sourcekeymap-vs-HW1.diff` | diffs of the other two edited files |
| `HW1-AFTER-block.md.readonly-copy` | untouched copy of HW1's candidate, the diff base |
| `INPUT-HASHES-start.txt`, `INPUT-HASHES-end.txt` | input integrity record |
| `apply-corrections.py`, `patch2.py`, `patch3.py` | the **editing mechanism** — exact whole-block string substitutions, each asserted to match exactly once. These are not research code, not a producer, and not proposed for the repository; they are retained only so the edit is auditable. |

## 2. The six corrections, and what each changed in substance

**C1 — the extremes now match the table.**
`regions["Northern Europe"].coverage_e7e3_public` = 0.1611 (CI 0.1383–0.1871) is the maximum
computed e7::e3 coverage; Eastern Asia's 0.1540 is the second. Corrected in the Abstract, in §3.2's
opening paragraph and in the relationship paragraph. The minimum computed CD4 coverage is
`regions["Sub-Saharan Africa"].coverage_cd4_classii` = 0.0227, not Northern Africa's 0.0246;
Northern Africa is still named but no longer as the minimum. The relationship paragraph now states
that the CD8 extreme and the CD4 extreme fall in **different** regions, says explicitly that
**extremes are not a correlation**, and declines an association in *either* direction rather than
implying one by juxtaposition. No correlation statistic was computed. Both leaves were re-read from
the JSON in this pass, not taken from HW1's prose.

**C2 — three incomplete regions, thirteen complete rows.**
`coverage_all_alleles_used` has length < 3 for exactly Micronesia (`[]`), Polynesia (`["B*07:02"]`)
and Melanesia (`["B*07:02","B*15:01"]`); the other thirteen carry all three base alleles. The
"four rows … twelve three-allele rows" sentence is replaced throughout (§3.2 and limitation 5), and
Australia and New Zealand is now explicitly placed in the **small-survey** discussion and explicitly
excluded from the incomplete-allele count, with its class-I data described as complete. The
Micronesia row was **moved to the end** of the regional table so UNKNOWN is last, as the table's own
ordering rule says. **No source cell was altered**: the only `|`-prefixed change in the whole diff is
that row moving from position 1 to position 16.

**C3 — the formula is an implemented approximation, and the panel limits are not clinical floors.**
§2.3 is retitled and rewritten: 1 − ∏(1 − af)² is reported as *what the artifact implements*, with
the specific defect named — the product runs over **B\*07:02 and B\*15:01, two alleles at the same
locus**, which cross-locus independence does not license — and the bias direction and size recorded
as **not established**, i.e. an unresolved model limitation (also limitation 8). The Abstract Methods
bullet carries the same framing. Every clinical "at least" / patient-reach / efficacy / equity
conclusion is now a conditional model estimate: the Conclusions bullet, the §3.1 read-outs,
limitation 4 ("should be read as at least" → "must not be read as clinical at-least statements"),
the §3.3 closing sentence (equity gap → a modelled-carriage difference with no benefit claim), and
the §2.4 "would only raise it" (→ "would change it in a direction this analysis cannot state").
The **1.78%** figure is now flagged in the Abstract, in §2.4, in the §3.1 bullet, in the §3.1 CD4
read-out and in a **new limitation 12** as an artifact-level product of an **all-junction** class-I
factor (27.37%) with an **e7::e3-only** class-II factor (6.49%) — not joint eligibility for one
specified construct, and not a stated requirement for a durable vaccine response. **No numerical
artifact was changed and no producer was run**; the scope mismatch is read from `_class_ii_note`
("MHCnuggets, EWSR1 e7::e3 junction") against §2.1's all-junction base set, and the product
0.2737 × 0.0649 = 0.017763 → 0.0178 was checked arithmetically against the committed leaf.

**C4 — inherited universals removed or qualified.**
(i) The 0.495 cavity score no longer "precludes" small-molecule targeting: §1 now reports it as a
predicted score on predicted structures, retained from `novel-modalities.md` §2, and says explicitly
that a sub-threshold score is a discouraging prediction, not a demonstrated impossibility.
(ii) "clonal, present in every tumour cell and never subclonally lost — so a response against it
cannot be escaped" is replaced by a flagged statement that **no source in this analysis establishes**
clonality, non-loss or non-escape, and that the truncal-driver argument is recorded as a general
hypothesis about fusion antigens.
(iii) "This is the quantitative case that EMC fusion-neoantigen therapy is personalised-first" and
the Conclusions' "This is the quantitative argument for a personalised pipeline" are replaced by
"consistent with … being informative" plus an explicit statement that nothing here establishes
clinical indication.
(iv) Limitation 1's "**no measured result of any kind**" is narrowed to "no measured presentation or
immunogenicity result anywhere in this analysis", with the reason given: the pooled AFND allele
surveys **are** observations and the frequency and sample-size columns inherit them. The standing
evidence-class header carries the same narrowing. No new biology and no experiment was introduced.

**C5 — provenance is now precise; the mandatory rerun is gone.**
The "projected from two committed artifacts and from nothing else" banner is replaced by a
per-section provenance block: Abstract/§2/§3.1/§3.2/§3.3 from the two frozen JSONs; §3.4 from
`vaccine-construct.json`, reported on the **already-read** N2-lane evidence
(`assembled_window` `PSQYSQQSSSYGQQNMPCVQAQYSPSP`, `minimal_SLP` `SYGQQNMPCVQAQYS` 15 aa, two CD8
entries both B\*15:01, **one** CD4 entry DRB1\*14:01); §1's 0.495 from `novel-modalities.md` §2.
§3.4's "NOT re-verified, an owner must re-check" flag is replaced by that sourcing, the construct
text is kept **descriptive with its prediction limits**, and its durability claim ("desirable for a
durable response") is replaced by a statement that nothing here tests it. **No third file was
re-opened and no sequence design was done.** The author block's "regenerate … before circulating",
limitation 3's "Regenerate before circulating" and §5 are all rewritten: a source refresh is an
**optional, distinct future version**, not a gate on reporting the frozen build.

**C6 — title, history placement, retention wording, line count.**
The YAML `title:` (which was also truncated mid-word at `a r`) and the H1 are both set to the
authorized *Modelled HLA coverage of predicted EWSR1::NR4A3 junction binders in extraskeletal myxoid
chondrosarcoma*. The history is the sibling file `hla-coverage-emc-history.md`; its header now states
that its placement is settled and no approval is outstanding, and carries the source pin (text as it
stood at HEAD `d775c80f8e64bc64b67e8c2fb46edeaa2cca2911`, read 2026-09-08) and provenance. Every
blanket "nothing has been deleted" / "preserved in full" assurance is replaced by the exact retention
statement in §4 below, in both the manuscript (§7 and the provenance banner) and the history file.
`SOURCE-KEY-MAP.md`'s header now says **242 lines** in HW1's version, explicitly a line count and not
a count of numeric rows; **no row census was run.**

## 3. What I could not do, with the exact missing input

* **No interval for `coverage_cd8_and_cd4_combined`.** Unchanged from HW1: the artifact has no
  `_95ci` counterpart. Exact missing input: a `global.coverage_cd8_and_cd4_combined_95ci` leaf, or a
  stated propagation rule for the product of two approximate intervals. Condition that would supply
  it: `hla_coverage.py` emitting that key on a regeneration. Branch stopped; nothing invented.
* **No single-construct joint-eligibility figure exists.** Correcting the 1.78% framing exposes the
  gap but cannot fill it. Exact missing input: a class-I coverage leaf computed over the **e7::e3**
  junction's binder set *and* a class-II leaf on the same junction, combined by the producer — i.e.
  `coverage_e7e3_public × coverage_cd4_classii` emitted as its own key with its own provenance. I did
  **not** multiply 0.0851 × 0.0649 myself: that would be a new derived number, and the prohibition on
  new computation applies. Branch stopped and recorded in limitation 12.
* **The direction and magnitude of the same-locus independence bias are not quantified.** Quantifying
  it needs a haplotype-frequency source and a recomputation, both outside this pass. Recorded as an
  unresolved model limitation, not as a caveat that has been discharged.
* **`vaccine-construct.json` was not re-opened by this lane.** Per the correction, I reused the N2
  reading rather than re-checking a third file. The map records that a byte-level re-read at the
  current HEAD has not been performed here.
* **No survey of other documents quoting the superseded 29.7% / 58.0% / 28.4% / 16.5% figures.** Out
  of scope for this pass, as it was for HW1; still open for the owner.

## 4. Retention limitation — carried forward, not softened

HW1's `NOTES.md` §8 records that **six intermediate build fragments** (`_part_head.md`,
`_part_body.md`, `_part_c.md`, `_t1.md`, `_t2.md`, `_maprows.md`) were **deleted** from its own
`/tmp` lane after assembly. Their content is contained in the delivered files, but **embedded content
is not proof that the original bytes survive**. Those originals were not recovered by this pass and
are deliberately **not** recreated. Consequently:

* No sentence in the corrected manuscript, the history file or the key map claims that "nothing was
  deleted" or that anything is "preserved in full".
* The manuscript §7 and the history-file header both state what **is** retained — the *text* of the
  superseded blocks, pinned to the HEAD at which it was read — and state the limitation explicitly.
* I deleted nothing. No campaign evidence directory, no collected set and no file named in any
  receipt was touched, and my own scratch is left in place in full, including the substitution
  scripts.

## 5. What I did NOT do

No producer, figure generator, gate or `scripts/preflight.sh` run. No repository code authored, no
patch proposed to any repository file, no guard touched. No network, no paid API, no GPU, no
publication, no new source, no new prediction, no new query or retrieval, no figure generated, no
patient or crosswalk data, no preregistration change, no peptide or vaccine-design work, no clinical
efficacy/safety/selectivity/readiness claim, no contact with humans. No `reports/W25-*` read or
referenced. No content-policy refusal was encountered in this lane.

## 6. Integration note for the owner (not a decision taken here)

The candidate has passed **no** repository check — no gate was run, as instructed. If it is adopted,
`lint_consistency`, `lint_style` and the pinned-figure rules must be run against it, and note that
the **title change** and the frontmatter `title:` change may interact with pinned figures, view
generation and `systems_check` id/frontmatter rules. That is an integration act, not a writer act.
