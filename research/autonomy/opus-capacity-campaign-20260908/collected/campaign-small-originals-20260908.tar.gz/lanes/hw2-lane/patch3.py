import sys
# ---- SOURCE-KEY-MAP ----
p='/tmp/claude-0/hw2-lane/SOURCE-KEY-MAP.md'; s=open(p).read()
old_head = '''# SOURCE-KEY-MAP — every number in `AFTER-block.md`

Two artifacts only, both read at HEAD `d775c80f8e64bc64b67e8c2fb46edeaa2cca2911`:
`H` = `research/modalities/hla-coverage.json`, `C` = `research/modalities/coverage-curve.json`.
Percentages are the leaf × 100 rendered to two decimals; no other transformation is applied.
Rows marked **RETAINED / NOT RE-VERIFIED** are numbers carried over verbatim from the existing
manuscript whose source lies outside these two artifacts — they were not checked in this pass.
'''
new_head = '''# SOURCE-KEY-MAP — every number in `hla-coverage-emc.md`

Updated in the HW2 correction pass (2026-09-08). Coverage artifacts re-read and hash-verified at
HEAD `1a0ce07f66ffefe26ab3bc691db587147ea4169c`:
`H` = `research/modalities/hla-coverage.json` (sha256
`3b40a86392404800f6a0a5d5a701ecff49a168823ab067192ce2c5826d4acf9f`),
`C` = `research/modalities/coverage-curve.json` (sha256
`eb04c77ad5945083ab9ad2b98e654367d9c3a6a0864234e96983701681545acb`).
These are byte-identical in content to the leaves HW1 read at HEAD
`d775c80f8e64bc64b67e8c2fb46edeaa2cca2911`; every value in section C is unchanged from HW1's map.
Percentages are the leaf × 100 rendered to two decimals; no other transformation is applied.

**Two further sources are named rather than folded into the two artifacts** (see section B):
`vaccine-construct.json` for §3.4, reported on the reading recorded by this project's earlier N2
review pass, and `novel-modalities.md` §2 for §1's 0.495 cavity score.

**Size of this file, stated correctly:** it is **242 lines** in HW1's version — a line count, not a
count of numeric rows, and no row census was run to produce that figure. The HW2 pass appends the
rows below, so the current line count differs.
'''
assert s.count(old_head)==1
s=s.replace(old_head,new_head,1)

old_b = '''| `27 aa`, `15 aa`, `2` CD8 epitopes, `1` CD4 helper, peptide sequences (§3.4) | pre-existing §3.4 text, sourced to `vaccine-construct.json` | RETAINED, explicitly flagged in §3.4 as NOT re-verified; allele identities B*15:01 / DRB1*14:01 *are* consistent with H |'''
new_b = '''| `27 aa`, `15 aa`, `2` CD8 epitopes, `1` CD4 helper, peptide sequences (§3.4) | `vaccine-construct.json` → `assembled_window` = `PSQYSQQSSSYGQQNMPCVQAQYSPSP`, `minimal_SLP` = `SYGQQNMPCVQAQYS` (15 aa), 2 CD8 epitope entries both `B*15:01`, **one** CD4 epitope entry `DRB1*14:01` | SOURCED — on the reading of that artifact recorded by the earlier N2 review pass of this manuscript. Not re-opened in the HW2 pass and not re-run; allele identities are consistent with H. A byte-level re-read of `vaccine-construct.json` at the current HEAD has not been performed by this lane. |'''
assert s.count(old_b)==1
s=s.replace(old_b,new_b,1)

s += '''

## D. Rows added or corrected in the HW2 pass

| Printed value | Artifact | Exact key path / derivation |
|---|---|---|
| `16.11%` / `13.83–18.71%` as the **maximum** computed e7::e3 coverage (Abstract, §3.2, relationship paragraph) | H | `regions["Northern Europe"].coverage_e7e3_public{,_95ci}`; maximum taken over the 14 regions whose `coverage_e7e3_public` is non-`null` |
| `15.40%` as the **second** highest e7::e3 coverage (relationship paragraph) | H | `regions["Eastern Asia"].coverage_e7e3_public` |
| `4.10%` (Northern Europe CD4, relationship paragraph) | H | `regions["Northern Europe"].coverage_cd4_classii` |
| `2.27%` as the **minimum** computed CD4 coverage (relationship paragraph) | H | `regions["Sub-Saharan Africa"].coverage_cd4_classii`; minimum over all 16 regions, every one of which has a non-`null` CD4 leaf |
| `2.01%` (Sub-Saharan Africa e7::e3, relationship paragraph) | H | `regions["Sub-Saharan Africa"].coverage_e7e3_public` |
| `2.46%` (Northern Africa CD4) — **no longer described as the minimum** | H | `regions["Northern Africa"].coverage_cd4_classii` |
| "**three** sub-regions with incomplete class-I allele data" (Micronesia, Polynesia, Melanesia) | H | `regions[*].coverage_all_alleles_used` has length < 3 for exactly these three (`[]`, `["B*07:02"]`, `["B*07:02","B*15:01"]`) |
| "**thirteen** rows carry all three base alleles" | H | the remaining 13 of 16 `regions[*].coverage_all_alleles_used` are `["A*01:01","B*07:02","B*15:01"]` — Australia and New Zealand is one of the thirteen |
| `27.37%` and `6.49%` named as the **two factors** of `1.78%` | H | `global.coverage_any_strong_binder_allele` × `global.coverage_cd4_classii` = `global.coverage_cd8_and_cd4_combined` (0.2737 × 0.0649 = 0.01776, rendered 0.0178) |
| the class-I factor is "all resolved junctions", the class-II factor is "e7::e3 only" | H | `_class_ii_note` states the class-II screen is on the "EWSR1 e7::e3 junction"; `global.all_strong_binder_alleles` is the any-junction strong-binder set (§2.1) |
'''
open(p,'w').write(s)

# ---- HISTORY FILE ----
p2='/tmp/claude-0/hw2-lane/hla-coverage-emc-history.md'; h=open(p2).read()
old_h = '''Companion history record for [`hla-coverage-emc.md`](./hla-coverage-emc.md). **Nothing here has been
deleted or rewritten.** This file exists so that the live manuscript body can carry current
values without a supersession banner sitting over them. Every block below is the *original text*
as it stood in the live document up to this regeneration, reproduced verbatim.'''
new_h = '''Companion history record for [`hla-coverage-emc.md`](./hla-coverage-emc.md), held as a sibling file
alongside it. Its placement is settled; no approval is outstanding for it.

**Source pin and provenance.** Every block below is the text of the corresponding block of
`research/manuscripts/neoantigen/hla-coverage-emc.md` as it stood in the working tree at HEAD
`d775c80f8e64bc64b67e8c2fb46edeaa2cca2911`, read on 2026-09-08 immediately before the regeneration
that produced the current live body. It was moved here, unaltered in wording, so that the live body
can carry current values without a supersession banner sitting over them. The HW2 correction pass of
2026-09-08 changed nothing in the blocks below; it added only this header.

**What is retained, stated exactly.** This file retains the **text** of those blocks. It is **not** a
byte-level archive of the earlier file, and it carries no claim that "nothing was deleted" anywhere.
Two specific limits travel with it:

1. The manuscript's own earlier bytes live in this repository's Git history, not here. This file does
   not reproduce them and should not be cited as if it did.
2. The lane that assembled the regenerated text **deleted six intermediate working fragments**
   (`_part_head.md`, `_part_body.md`, `_part_c.md`, `_t1.md`, `_t2.md`, `_maprows.md`) after
   assembly. Their content is contained in the delivered files, but **content containment is not
   proof that the original bytes survive**. Those originals were not recovered and are deliberately
   **not** recreated.

Nothing below is current. Every figure in it is superseded; the live values are in
`hla-coverage-emc.md`.'''
assert h.count(old_h)==1
open(p2,'w').write(h.replace(old_h,new_h,1))
print('ok')
