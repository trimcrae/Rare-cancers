# Editing mechanism for the HW2 correction pass (not a research artifact, not repository code).
# Applies the coordinator's six corrections as exact whole-block substitutions on HW1's AFTER-block.md.
import sys
src = open('/tmp/claude-0/hw2-lane/HW1-AFTER-block.md.readonly-copy').read()
R = []
def rep(old, new):
    R.append((old, new))

# --- C6: title (YAML) ---
rep('title: "Population coverage of a public EWSR1::NR4A3 fusion-neoantigen immunotherapy in extraskeletal myxoid chondrosarcoma: a r"',
    'title: "Modelled HLA coverage of predicted EWSR1::NR4A3 junction binders in extraskeletal myxoid chondrosarcoma"')

# --- C6: H1 ---
rep('# Population coverage of a public EWSR1::NR4A3 fusion-neoantigen immunotherapy in extraskeletal myxoid chondrosarcoma: a reproducible HLA class-I analysis',
    '# Modelled HLA coverage of predicted EWSR1::NR4A3 junction binders in extraskeletal myxoid chondrosarcoma')

# --- C5: provenance banner ---
rep(r'''> **Provenance of every number in this document.** All coverage and frequency values below are
> projected from two committed artifacts and from nothing else:
> [`hla-coverage.json`](../../modalities/hla-coverage.json) (global and per-region coverage,
> per-allele pooled frequencies, Wilson intervals, class-II arm, both-arms product) and
> [`coverage-curve.json`](../../modalities/coverage-curve.json) (the expanded-panel scan of §3.3).
> Their upstream provenance, as recorded in the artifacts themselves: allele frequencies from the
> **Allele Frequency Net Database (AFND)** via the MIT-licensed `slowkow/allelefrequencies` mirror
> (`_source_urls.allele_frequencies`), region labels from the ISO 3166 / UN M49 table
> (`_source_urls.region_mapping`), source state `AFND frequencies retrieved from MIT-licensed mirror`
> (`_source_status`). The class-II arm is read from `patient-cd4-demo.json` through
> `hla-coverage.json`'s own `⛔_class_ii_provenance`, which records
> `class_ii_junction_context: QYSQQSSSYGQQ|NMPCVQAQYSPS`,
> `corrected_junction_context: SQQSSSYGQQ|NMPCVQAQYSP` and `matches_corrected_seam: true` — i.e. the
> class-II input sits on the corrected transcript-model seam, not on the retracted one.
> **Supersession history is not deleted; it is moved.** The 2026-08-07 supersession record, the
> superseded pre-2026-08-07 values, and the retained "superseded, retained" notes now live in
> [`hla-coverage-emc-history.md`](./hla-coverage-emc-history.md) (this lane:
> `HISTORY-superseded.md`). Nothing below carries a supersession banner, because nothing below is
> the superseded build.''',
    r'''> **Provenance, stated per section rather than in one blanket sentence.**
> *Every coverage, allele-frequency, interval and sample-size value in the Abstract and in
> §2.1–§2.5, §3.1, §3.2 and §3.3* is read from two committed artifacts and from nothing else:
> [`hla-coverage.json`](../../modalities/hla-coverage.json) (global and per-region coverage,
> per-allele pooled frequencies, Wilson intervals, class-II arm, both-arms product) and
> [`coverage-curve.json`](../../modalities/coverage-curve.json) (the expanded-panel scan of §3.3).
> *§3.4's construct values* (assembled window, minimal SLP, epitope counts and their allele
> attributions) come from a **third** artifact, `vaccine-construct.json`, and are reported here on a
> reading of that file recorded in this project's earlier N2 review pass, which read
> `assembled_window`, `minimal_SLP` and the CD8/CD4 epitope entries directly. *§1's 0.495 cavity
> score* comes from [`novel-modalities.md`](../modality-census/novel-modalities.md) §2 and is
> attributed there, not to either coverage artifact.
> Upstream provenance of the two coverage artifacts, as recorded in the artifacts themselves:
> allele frequencies from the **Allele Frequency Net Database (AFND)** via the MIT-licensed
> `slowkow/allelefrequencies` mirror (`_source_urls.allele_frequencies`), region labels from the
> ISO 3166 / UN M49 table (`_source_urls.region_mapping`), source state
> `AFND frequencies retrieved from MIT-licensed mirror` (`_source_status`). The class-II arm is read
> from `patient-cd4-demo.json` through `hla-coverage.json`'s own `⛔_class_ii_provenance`, which
> records `class_ii_junction_context: QYSQQSSSYGQQ|NMPCVQAQYSPS`,
> `corrected_junction_context: SQQSSSYGQQ|NMPCVQAQYSP` and `matches_corrected_seam: true` — i.e. the
> class-II input sits on the corrected transcript-model seam, not on the retracted one.
> **What was retained when the supersession history was moved out of this body, stated exactly.**
> The 2026-08-07 supersession record, the superseded pre-2026-08-07 values and the retained
> "superseded, retained" notes are reproduced in
> [`hla-coverage-emc-history.md`](./hla-coverage-emc-history.md). That file carries the text of
> those blocks; it is **not** a byte-level archive of the files they were assembled from, and this
> document makes no "nothing was deleted" claim on their behalf — see the retention note in §7.
> Nothing below carries a supersession banner, because nothing below is the superseded build.''')

# --- C4: evidence-class header, (iii) ---
rep(r'''frequencies — a projection, not an observation of patients. (iii) An **actual measured
> presentation or immunogenicity result** — mass-spectrometric ligandome evidence, or a T-cell
> assay — **does not exist anywhere in this analysis; there is no wet lab.** A predicted binding
> score is not evidence of presentation, and modelled coverage is not observed coverage in any
> patient series. No sentence below converts one into another.''',
    r'''frequencies — a projection, not an observation of patients. (iii) An **actual measured
> presentation or immunogenicity result** — mass-spectrometric ligandome evidence, or a T-cell
> assay — **is absent from this analysis; there is no wet lab.** That is a statement about
> presentation and immunogenicity specifically, not a claim that the document rests on no
> observations at all: the upstream AFND allele surveys *are* observations, secondary and pooled,
> and the frequency and sample-size columns below inherit whatever they measured. A predicted
> binding score is not evidence of presentation, and modelled coverage is not observed coverage in
> any patient series. No sentence below converts one into another.''')

# --- C5: status / author block, mandatory-rerun prose ---
rep(r'''All numbers are auto-generated by `research/modalities/hla_coverage.py` from public databases;
regenerate (`python research/modalities/hla_coverage.py`) before circulating, as the upstream
allele-frequency mirror updates.''',
    r'''The coverage numbers are auto-generated by `research/modalities/hla_coverage.py` from public
databases and are reported here **as frozen in the committed artifacts**, which is what makes this
text reproducible: any reader can re-derive every figure from the two committed JSONs without a
network. Because the upstream allele-frequency mirror updates, a regenerated build would be a
**distinct, later version of this analysis** — an optional future act, not a gate that must be
cleared before this frozen version may be read or circulated.''')

# --- C1 + C3: Abstract ---
rep(r'''  sequence and therefore a candidate **public neoantigen** for an off-the-shelf vaccine or
  TCR-T product — but only for patients who carry an HLA allele **predicted** to present the
  junction peptide. The clinically decisive question is *what fraction of patients that is.*''',
    r'''  sequence and therefore a candidate **public neoantigen** for an off-the-shelf vaccine or
  TCR-T product — but only for patients who carry an HLA allele **predicted** to present the
  junction peptide. The question this analysis addresses is the modelled size of that carrier
  fraction; whether such a product would work in patients is not addressed here at all.''')

rep(r'''  af = Σcopies / Σ2N, with **Wilson score 95% CIs** (`_method`). Carrier frequency for one allele
  = 1 − (1 − af)²; coverage of an allele set = 1 − ∏(1 − af)² (the IEDB population-coverage
  formula, ≥1 presenting allele under Hardy–Weinberg and cross-locus independence); the coverage
  interval is propagated from the per-allele Wilson bounds and is **approximate** (`_method`).''',
    r'''  af = Σcopies / Σ2N, with **Wilson score 95% CIs** (`_method`). Carrier frequency for one allele
  = 1 − (1 − af)²; coverage of an allele set is computed **as the artifact implements it**,
  1 − ∏(1 − af)², an approximation whose independence assumption this analysis does not establish
  (§2.3 — the product runs over several alleles at the *same* locus, where independence does not
  hold, so this is an unresolved model limitation, not a demonstrated exact formula); the coverage
  interval is propagated from the per-allele Wilson bounds and is **approximate** (`_method`).''')

rep(r'''  **strongly population-dependent**: any-strong-binder coverage runs from **60.43% (Northern
  Europe, 95% CI 55.93–64.95%)** down to **1.37% (Melanesia, 95% CI 0.54–3.49%)**, and is
  **UNKNOWN — not zero — for Micronesia**, where no class-I allele of the set has regional AFND
  data. The e7::e3 junction alone runs from **15.40% (Eastern Asia, 95% CI 14.66–16.17%)** to
  **0.76% (Northern Africa, 95% CI 0.26–2.19%)**, and is **UNKNOWN for Polynesia and Micronesia**.''',
    r'''  **strongly population-dependent**: any-strong-binder coverage runs from **60.43% (Northern
  Europe, 95% CI 55.93–64.95%)** down to **1.37% (Melanesia, 95% CI 0.54–3.49%)**, and is
  **UNKNOWN — not zero — for Micronesia**, where no class-I allele of the set has regional AFND
  data. The e7::e3 junction alone runs from **16.11% (Northern Europe, 95% CI 13.83–18.71%)** to
  **0.76% (Northern Africa, 95% CI 0.26–2.19%)**, and is **UNKNOWN for Polynesia and Micronesia**.
  Three of the sixteen sub-regions — Micronesia, Polynesia and Melanesia — have incomplete class-I
  allele data, leaving **thirteen** regions with all three base alleles present.''')

rep(r'''  gives **1.78% globally** (`coverage_cd8_and_cd4_combined`, the product of the two coverages under
  cross-locus independence; **the artifact publishes no interval for this figure**).''',
    r'''  gives **1.78% globally** (`coverage_cd8_and_cd4_combined`, the product of the two coverages under
  cross-locus independence; **the artifact publishes no interval for this figure**). ⚠ **That
  product mixes two different antigen scopes and is therefore an artifact-level quantity, not a
  joint eligibility estimate for any one construct:** its class-I factor (27.37%) is the base binder
  set pooled **across all resolved junctions**, while its class-II factor (6.49%) is a screen of the
  **e7::e3 junction only**. It is not demonstrated joint eligibility for one specified construct,
  and it is not a stated requirement that a durable vaccine response must meet.''')

rep(r'''- **Conclusions:** On these predictions, a public, off-the-shelf fusion-neoantigen approach to EMC
  is **partial by construction** and **inequitable if framed by a single global number**: the most
  "public" junction is predicted to miss the large majority of patients everywhere, and the
  class-I arm spans 60.43% to 1.37% between its best and worst *computed* sub-regions. Demanding both CD8 *and* CD4 coverage from public epitopes drops the modelled
  addressable fraction to under two per cent. This is the quantitative argument for a
  **personalised** pipeline (sequence the patient's breakpoint → predict junction epitopes → match
  to the patient's own class-I *and* class-II HLA), with public junctions reserved for the specific
  allele groups where modelled coverage is comparatively high. Predicted binding is a screen, not
  proof of presentation and not proof of immunogenicity; the class-II figure is a floor over a
  tested 23-allele panel; all figures are hypothesis-generating and none is a clinical claim.''',
    r'''- **Conclusions:** *Within this model, and conditional on its assumptions*, a single public
  junction's predicted binder is carried by a small minority of the modelled population, and the
  modelled class-I figure spans 60.43% to 1.37% between the best and worst *computed* sub-regions —
  so a single global number is not a usable summary of the modelled spread. Combining the two arms
  as the artifact does yields a modelled figure under two per cent, with the scope mismatch above.
  These are **model estimates about allele carriage, not estimates of how many patients a product
  would reach or benefit**: the panels are limited, the independence assumptions are unverified, and
  a panel-limited coverage number is **not** a guaranteed lower bound on true patient eligibility in
  either direction. The results are consistent with a **patient-specific** matching step (sequence
  the patient's breakpoint → predict junction epitopes → match to the patient's own class-I *and*
  class-II HLA) being informative, but nothing here establishes that such a pipeline is clinically
  indicated, and no equity, efficacy or benefit conclusion follows from this arithmetic. Predicted
  binding is a screen, not proof of presentation and not proof of immunogenicity; all figures are
  hypothesis-generating and none is a clinical claim.''')

# --- C4: §1 druggability + truncal-driver universals ---
rep(r'''**Why immunotherapy at all?** Conventional small-molecule targeting of EWSR1::NR4A3 is
precluded: the fusion is predicted either intrinsically disordered or folded-but-pocket-less
(AlphaFold2 models from the AlphaFold DB + fpocket; best cavity druggability 0.495,
sub-threshold — see the structure assessment in [`novel-modalities.md`](../modality-census/novel-modalities.md) §2). With no druggable pocket, attention turns to the
tumour-specific **fusion junction** as an immunological target.''',
    r'''**Why immunotherapy at all?** A structure assessment recorded in
[`novel-modalities.md`](../modality-census/novel-modalities.md) §2 predicts EWSR1::NR4A3 to be
either intrinsically disordered or folded-but-pocket-less, with a best cavity druggability score of
**0.495**, below the threshold that assessment uses. That is a **predicted score on predicted
models** (AlphaFold2 structures from the AlphaFold DB, scored with fpocket), retained here from that
document and not re-derived in this analysis. It does not establish that small-molecule targeting is
precluded — a sub-threshold cavity score in one modelling pipeline is a discouraging prediction, not
a demonstrated impossibility. It is, however, one reason attention has turned to the tumour-specific
**fusion junction** as an immunological target.''')

rep(r'''product rather than a bespoke per-patient build. A fusion neoantigen also has a structural
advantage over the random somatic-mutation neoantigens that dominate personalised-vaccine
programs: the fusion is the **truncal driver** — clonal, present in every tumour cell and
never subclonally lost — so a response against it cannot be escaped by antigen loss the way a
passenger-mutation response can. Two facts bound the promise, though. First, the''',
    r'''product rather than a bespoke per-patient build. A fusion neoantigen is also often argued to have
an advantage over the random somatic-mutation neoantigens that dominate personalised-vaccine
programs, on the grounds that the fusion is the **truncal driver**. ⚠ **No source in this analysis
establishes that the fusion is present in every tumour cell of every patient, that it is never
subclonally lost, or that a response against it could not be escaped.** Clonality, antigen loss and
immune escape are not measured anywhere in this work, and the argument is recorded here as a
hypothesis about fusion antigens in general, not as a property of EMC established here. Two further
facts bound the promise. First, the''')

# --- C3: §2.3 formula ---
rep(r'''### 2.3 Coverage — a modelled projection
Carrier (phenotype) frequency for one allele = 1 − (1 − af)² (Hardy–Weinberg, ≥1 copy).
Coverage of an allele **set** = 1 − ∏ᵢ(1 − afᵢ)² — the modelled fraction carrying ≥1 predicted
presenting allele, assuming independence across loci; this is the standard **IEDB
population-coverage** formula [3]. A coverage interval is propagated from the per-allele Wilson
bounds and is **approximate** (`_method`).''',
    r'''### 2.3 Coverage — a modelled projection, on an approximation this analysis does not justify
Carrier (phenotype) frequency for one allele = 1 − (1 − af)² (Hardy–Weinberg, ≥1 copy).
Coverage of an allele **set** is computed by the artifact as 1 − ∏ᵢ(1 − afᵢ)², the modelled fraction
carrying ≥1 predicted presenting allele. **This is reported here as the implemented artifact
approximation, not as a demonstrated exact formula.** The artifact's own `_method` names it as
"independence across loci; IEDB population-coverage formula" [3], but that justification does not
cover what the expression actually does in this build: the product runs over **B\*07:02 and
B\*15:01, two alleles at the same locus**, which are not independent draws — a person carrying
B\*07:02 on one chromosome cannot also carry B\*15:01 there — and cross-locus independence says
nothing about that case. Nor is linkage disequilibrium between A and B modelled. **The direction and
size of the resulting bias are not established here**, so this stands as an unresolved model
limitation (§4.8) rather than a caveat that can be signed off. No number in this document was
recomputed under any alternative; every coverage value is the artifact's value as committed.
A coverage interval is propagated from the per-allele Wilson bounds and is **approximate**
(`_method`).''')

# --- C3: §2.4 both-arms scope mismatch ---
rep(r'''alleles that also present the helper would only raise it. The "both-arms" figure
(`coverage_cd8_and_cd4_combined`) is, in the artifact's own words,
`P(>=1 class-I allele) x P(>=1 class-II allele)`, treating HLA-A/B and DRB1 as independent loci.
It is computed and reported here; the artifact publishes **no confidence interval** for it, and
none is invented.''',
    r'''alleles that also present the helper **would change it in a direction this analysis cannot state**,
because the untested alleles' frequencies and binding behaviour are both unknown. The "both-arms"
figure (`coverage_cd8_and_cd4_combined`) is, in the artifact's own words,
`P(>=1 class-I allele) x P(>=1 class-II allele)`, treating HLA-A/B and DRB1 as independent loci.
It is computed and reported here; the artifact publishes **no confidence interval** for it, and
none is invented.
⚠ **Its two factors do not describe the same antigen.** The class-I factor is
`coverage_any_strong_binder_allele` (27.37%), pooled over the alleles presenting a strong predicted
binder of **any** resolved junction; the class-II factor is `coverage_cd4_classii` (6.49%), from a
screen of the **e7::e3 junction only** (`_class_ii_note`). Their product is therefore an
**artifact-level quantity** — the number the producer emits — and **not** the modelled joint
eligibility of any one specified construct, for which both arms would have to be scored on the same
junction. It is also **not** a statement of what a durable vaccine response requires: this analysis
neither establishes nor tests any such requirement.''')

# --- C3: §3.1 both-arms bullet and CD4 read-out ---
rep(r'''- **Both arms** (≥1 class-I *and* ≥1 class-II allele): **1.78%**
  (`coverage_cd8_and_cd4_combined`). **No interval is published for this figure in the artifact.**''',
    r'''- **Both arms** as the artifact computes them (≥1 class-I allele from the **all-junction** base
  set × ≥1 class-II allele from the **e7::e3-only** screen): **1.78%**
  (`coverage_cd8_and_cd4_combined`). **No interval is published for this figure in the artifact**,
  and, per §2.4, this is an artifact-level product across two different antigen scopes rather than
  joint eligibility for a single construct.''')

rep(r'''**CD8 read-out (modelled):** a single public junction is predicted to reach 8.51% of patients;
even the full three-allele base panel leaves the clear majority of patients with no allele
predicted to present any strong binder.

**CD4 read-out (modelled):** the one qualifying strong-helper DRB1 allele covers 6.49% globally,
and requiring **both** a class-I and a class-II allele — what a durable vaccine response needs —
covers 1.78%. The class-II figure is a floor over the tested 23-allele panel (§2.4, §4). This is
the quantitative case that EMC fusion-neoantigen therapy is **personalised-first**, not
off-the-shelf — a design conclusion drawn from predictions, not a clinical finding.''',
    r'''**CD8 read-out (modelled):** in this model a single public junction's binder is carried by 8.51% of
the modelled population, and the full three-allele base panel leaves the clear majority carrying no
allele predicted to present any strong binder. These are modelled carriage fractions over pooled
survey populations; they are not counts of patients reached, and the panel limits below mean they
are not guaranteed floors on true eligibility either.

**CD4 read-out (modelled):** the one qualifying strong-helper DRB1 allele covers 6.49% globally, and
the artifact's product of the two arms is 1.78% — subject to the antigen-scope mismatch in §2.4. The
class-II figure is bounded by the tested 23-allele panel (§2.4, §4). Taken together these modelled
figures are **consistent with** a public, single-junction product addressing only a small modelled
fraction, which is a reason to take a patient-specific matching step seriously as a design option.
They do not establish that such a step is clinically indicated, and none of these numbers is a
statement about outcomes in any patient.''')

# --- C1/C2: §3.2 opening ---
rep(r'''The global average hides a wide spread. Across the 16 UN M49 sub-regions in
`hla-coverage.json.regions`, modelled any-strong-binder coverage runs from **60.43% (Northern
Europe)** down to **1.37% (Melanesia)** among regions where it is computed at all, and is
**UNKNOWN for Micronesia**. The e7::e3 public junction runs from **15.40% (Eastern Asia)** to
**0.76% (Northern Africa)**, and is **UNKNOWN for Polynesia and Micronesia**. **A global coverage
figure therefore overstates benefit for some patients and understates it for others, and must not
be quoted alone.**''',
    r'''The global average hides a wide spread. Across the 16 UN M49 sub-regions in
`hla-coverage.json.regions`, modelled any-strong-binder coverage runs from **60.43% (Northern
Europe)** down to **1.37% (Melanesia)** among regions where it is computed at all, and is
**UNKNOWN for Micronesia**. The e7::e3 public junction runs from **16.11% (Northern Europe,
13.83–18.71%)** down to **0.76% (Northern Africa, 0.26–2.19%)**, and is **UNKNOWN for Polynesia and
Micronesia**. **A single global coverage figure is therefore not a usable summary of the modelled
regional spread and must not be quoted alone.** It is a statement about modelled allele carriage in
pooled survey populations, not about benefit to any patient in any region.''')

# --- C2: move Micronesia row to the end of the regional table ---
mic = '| Micronesia | UNKNOWN | — | UNKNOWN | — | 6.86% | 3.67–12.58% | none | 129 | 2 |\n'
mel = '| Melanesia | 0.86% | 0.36–2.01% | 1.37% | 0.54–3.49% | 7.26% | 5.99–8.82% | B\\*07:02, B\\*15:01 | 1,269 | 19 |\n'
rep(mic, '')
rep(mel, mel + mic)

# --- C2: UNKNOWN-is-not-zero paragraph ---
rep(r'''**UNKNOWN is not zero.** Micronesia has **no** regional AFND data for A\*01:01, B\*07:02 or
B\*15:01 (all three allele entries are `null`), so both its class-I coverage leaves are `null`:
its class-I coverage is **not computed** and is **UNKNOWN**. Polynesia has data for **B\*07:02
only**, so its 1.95% is a one-allele floor and its e7::e3 leaf (which needs B\*15:01) is `null`
and **UNKNOWN**. Melanesia's 1.37% is a two-allele figure. These four rows must not be read
against the twelve three-allele rows as if they measured the same thing.''',
    r'''**UNKNOWN is not zero, and exactly three regions have incomplete class-I allele data.**
Micronesia has **no** regional AFND data for A\*01:01, B\*07:02 or B\*15:01 (all three allele entries
are `null`), so both its class-I coverage leaves are `null`: its class-I coverage is **not computed**
and is **UNKNOWN**. Polynesia has data for **B\*07:02 only**, so its 1.95% rests on one allele and
its e7::e3 leaf (which needs B\*15:01) is `null` and **UNKNOWN**. Melanesia's 1.37% is a two-allele
figure. **Those three rows — Micronesia, Polynesia and Melanesia — must not be read against the
thirteen rows that carry all three base alleles as if they measured the same thing.** Thirteen of the
sixteen sub-regions have the complete three-allele set (`coverage_all_alleles_used` lists A\*01:01,
B\*07:02 and B\*15:01); Australia and New Zealand is one of those thirteen and its class-I data are
complete — it appears below only in the separate discussion of small survey bases, which is a
different concern from missing alleles.''')

# --- C2: sample-size paragraph ---
rep(r'''**Sample size.** The smallest regional bases are Micronesia (129 individuals, 2 populations),
Polynesia (450, 9), Australia and New Zealand (702, 8) and Melanesia (1,269, 19); the largest is
Latin America and the Caribbean (17,277, 113). Intervals in the small regions are correspondingly
wide — Polynesia's any-strong CI spans 0.34–10.41%. Treat those four rows as indicative only.''',
    r'''**Sample size — a separate concern from the missing-allele one above.** The smallest regional
bases are Micronesia (129 individuals, 2 populations), Polynesia (450, 9), Australia and New Zealand
(702, 8) and Melanesia (1,269, 19); the largest is Latin America and the Caribbean (17,277, 113).
Intervals in the small regions are correspondingly wide — Polynesia's any-strong CI spans
0.34–10.41%. Treat those four rows as indicative only. Note that **Australia and New Zealand belongs
to this small-survey group and not to the three incomplete-allele regions**: its three base alleles
all carry regional data, so its coverage is computed over the same allele set as the other twelve
complete rows and is comparable with them; only its precision is limited.''')

# --- C1: relationship paragraph ---
rep(r'''**On the relationship between the two arms.** The superseded build claimed that CD8-best regions
were CD4-worst — an anti-correlation. **That claim is not carried forward, because the current
artifact does not show it.** In the current values the region with the highest e7::e3 coverage
(Eastern Asia, 15.40%) also has the second-highest CD4 coverage (9.84%), and the region with the
lowest computed e7::e3 coverage (Northern Africa, 0.76%) has the lowest CD4 coverage (2.46%). The
highest CD4 coverage sits in Australia and New Zealand (14.33%), whose class-I coverage is
mid-table. No correlation statistic is computed here and none should be inferred; the honest
statement is that the two arms' regional extremes no longer line up in the direction previously
asserted.''',
    r'''**On the relationship between the two arms.** The superseded build claimed that CD8-best regions
were CD4-worst — an anti-correlation. **That claim is not carried forward, and no correlation of any
sign is asserted in its place.** Read from the table: the highest computed e7::e3 coverage is
**Northern Europe at 16.11% (13.83–18.71%)**, whose CD4 coverage is **4.10%**, low but not the
lowest; the next highest is **Eastern Asia at 15.40%**, whose CD4 coverage is **9.84%**, the second
highest in the table. The lowest computed e7::e3 coverage is **Northern Africa at 0.76%** (CD4
2.46%), while the lowest computed CD4 coverage is a **different** region, **Sub-Saharan Africa at
2.27%** (e7::e3 2.01%). The highest CD4 coverage sits in Australia and New Zealand (14.33%), whose
class-I coverage is mid-table. **Extremes are not a correlation.** Four ordered pairs cannot
establish, or rule out, an association between the arms; no correlation statistic is computed here,
computing one would be a new analysis, and no relationship — positive, negative or absent — should be
inferred from these rows in either direction.''')

# --- C3: §3.3 closing equity sentence ---
rep(r'''those thresholds in every region). This quantifies both "how big must a public product be?" and
the equity gap: a fixed allele panel tuned on one population under-serves others.''',
    r'''those thresholds in every region). Within this model, that bears on the design question "how many
alleles would a public product have to present?", and it shows that a fixed allele panel produces
very different modelled carriage figures in different populations. Whether that difference would
translate into differential clinical benefit is outside what these numbers can say, and no equity
conclusion is drawn from them here.''')

# --- C5: §3.4 scope flag ---
rep(r'''> **Scope flag for reviewers.** The numbers in this subsection come from `vaccine-construct.json`,
> which is **outside the two artifacts this regeneration was scoped to read**. They are therefore
> **retained verbatim and NOT re-verified in this pass**; a scientific owner must re-check them
> against `vaccine-construct.json` before circulation. The alleles named below (B\*15:01,
> DRB1\*14:01) *are* consistent with the current `hla-coverage.json`.''',
    r'''> **Provenance of this subsection.** Its values come from a **third** artifact,
> `vaccine-construct.json`, not from the two coverage JSONs. They are not unsourced: this project's
> earlier N2 review pass read that file directly and recorded `assembled_window`
> `PSQYSQQSSSYGQQNMPCVQAQYSPSP`, `minimal_SLP` `SYGQQNMPCVQAQYS` (15 aa), two CD8 epitope entries
> both attributed to B\*15:01, and **one** CD4 epitope entry on DRB1\*14:01 — which is what is
> printed below. The alleles named are consistent with the current `hla-coverage.json`. The
> subsection is descriptive of that committed artifact; it designs nothing new here, and every
> epitope in it is a **model prediction**, not a measured presentation event.''')

# --- C4: §3.4 closing claim ---
rep(r'''Keeping CD8 and CD4 epitopes contiguous in one SLP preserves the processing context and
co-delivers help — desirable, in principle, for a durable response. The script also emits a''',
    r'''Keeping CD8 and CD4 epitopes contiguous in one SLP is a standard design rationale — the intent is to
preserve processing context and co-deliver help. **Nothing in this analysis tests whether it does
either**, and no durability, potency or response claim is made for this construct. The script also emits a''')

# --- C4/C3: Limitations ---
rep(r'''   T-cell target than a fully foreign peptide; tolerance is not modelled. There is **no wet lab**
   and therefore **no measured result of any kind** in this document.''',
    r'''   T-cell target than a fully foreign peptide; tolerance is not modelled. There is **no wet lab**,
   and therefore **no measured presentation or immunogenicity result anywhere in this analysis.**
   That is the precise scope of the absence: the document does rest on observations of a different
   kind — the pooled AFND allele surveys of §2.2 — whose limitations are limitation 3, not
   limitation 1.''')

rep(r'''4. **Class-II coverage is a floor over a 23-allele panel.** The class-I binders come from a
   broad allele scan; the class-II screen tested the 23 alleles enumerated in `_class_ii_note`
   for one junction, and exactly **one** of them, DRB1\*14:01, qualified. Coverage over that
   single allele is therefore a *lower bound*: other untested DR (or DQ/DP) alleles that also
   present the helper would raise it. The both-arms (**1.78%**) and CD4 (**6.49%**) figures
   should be read as "at least", and a full class-II scan is the obvious next step before any of
   these numbers is quoted as final.''',
    r'''4. **Class-II coverage is bounded by a 23-allele panel, and that does not make it a guaranteed
   floor on eligibility.** The class-I binders come from a broad allele scan; the class-II screen
   tested the 23 alleles enumerated in `_class_ii_note` for one junction, and exactly **one** of
   them, DRB1\*14:01, qualified. *Within the model*, adding untested DR/DQ/DP alleles that also
   presented the helper would raise the computed number. But the CD4 (**6.49%**) and both-arms
   (**1.78%**) figures must **not** be read as clinical "at least" statements about patient
   eligibility: the binding calls are predictions that can be false positives as well as false
   negatives, presentation and immunogenicity are unmeasured, the coverage arithmetic rests on the
   unjustified independence approximation of §2.3, and the 1.78% product mixes an all-junction
   class-I factor with an e7::e3-only class-II factor (limitation 12). They are conditional model
   estimates, and a fuller class-II scan would produce a different model estimate, not a correction
   toward a known truth.''')

rep(r'''5. **`null` regions are UNKNOWN, not zero.** Micronesia has no class-I coverage at all, and
   Polynesia none for e7::e3; Polynesia's and Melanesia's any-strong figures rest on one and two
   alleles respectively. Reading any of these as low coverage rather than as absent data would be
   a straightforward error (§3.2).''',
    r'''5. **`null` regions are UNKNOWN, not zero — and there are exactly three of them.** Micronesia,
   Polynesia and Melanesia are the three sub-regions with incomplete class-I allele data: Micronesia
   has no class-I coverage at all, Polynesia none for e7::e3, and Polynesia's and Melanesia's
   any-strong figures rest on one and two alleles respectively. The other **thirteen** sub-regions
   carry all three base alleles. Reading any of the three incomplete rows as low coverage rather than
   as absent data would be a straightforward error (§3.2).''')

rep(r'''8. **Two-field resolution; independence assumption.** AFND data here are 2-field (e.g.
   A\*01:01); we ignore linkage disequilibrium between loci — the independence assumption in
   1 − ∏(1 − af)² (and in the CD8×CD4 product) can mis-estimate coverage where haplotypes are
   correlated, so the true both-arms figure may differ from the independent product.''',
    r'''8. **Two-field resolution; an independence approximation this analysis does not justify.** AFND
   data here are 2-field (e.g. A\*01:01), and linkage disequilibrium between loci is ignored. More
   than that: 1 − ∏(1 − af)² multiplies terms for **B\*07:02 and B\*15:01, two alleles at the same
   locus**, which are not independent, and cross-locus independence does not license that step. The
   same objection applies to the CD8×CD4 product. **This is an unresolved model limitation**, not a
   quantified correction — the direction and magnitude of the bias are not established here, and
   nothing in this document should be read as a claim that the approximation is conservative.''')

rep(r'''   curve answers "how many alleles must be presented", not "is each epitope immunogenic"
   (limitation 1).''',
    r'''   curve answers "how many alleles must be presented", not "is each epitope immunogenic"
   (limitation 1).
12. **The 1.78% both-arms figure combines two different antigen scopes.** Its class-I factor is
   `coverage_any_strong_binder_allele` (27.37%), pooled over binders of **all** resolved junctions;
   its class-II factor is `coverage_cd4_classii` (6.49%), from a screen of the **e7::e3 junction
   only**. The product is what the producer emits — an artifact-level quantity — and is **not**
   demonstrated joint eligibility for any one specified construct, nor a universal requirement that
   a durable vaccine response must satisfy. A single-construct joint estimate would require both
   arms scored on the same junction, which no committed artifact currently provides.''')

# --- C5: §5 reproducibility ---
rep(r'''`coverage_scan.py` builds the §3.3 curve + chart (MHCflurry broad-panel scan → `coverage-curve.json`
+ `coverage-curve.png`), and `vaccine_construct.py` builds the §3.4 construct
(`vaccine-construct.json`, no network — deterministic from the committed epitope JSONs). The
MHCflurry/matplotlib steps run in CI (`.github/workflows/modalities-run.yml`).
If a source is unreachable the script records `source_unavailable` rather than emitting a
fabricated number.''',
    r'''`coverage_scan.py` builds the §3.3 curve + chart (MHCflurry broad-panel scan → `coverage-curve.json`
+ `coverage-curve.png`), and `vaccine_construct.py` builds the §3.4 construct
(`vaccine-construct.json`, no network — deterministic from the committed epitope JSONs). The
MHCflurry/matplotlib steps run in CI (`.github/workflows/modalities-run.yml`).
If a source is unreachable the script records `source_unavailable` rather than emitting a
fabricated number.

**No producer was run to prepare this text.** Every figure above is read from the committed
artifacts as they stand, which is what makes the document reproducible offline: the JSONs are in the
repository and each printed value names its key path. A regeneration against a refreshed upstream
mirror would produce a **different, later version** of this analysis and is an optional future act.
It is **not** a precondition for reading, reviewing or circulating this frozen version, and no
sentence here should be read as requiring one.''')

# --- C6: §7 retention ---
rep(r'''The pre-2026-08-07 build of this document, its superseded values, the supersession banner and the
retained "superseded, retained" notes are preserved in full in
[`hla-coverage-emc-history.md`](./hla-coverage-emc-history.md). Nothing has been deleted; it has
been moved out of the live body so that no supersession banner sits over current numbers.''',
    r'''The pre-2026-08-07 build of this document, its superseded values, the supersession banner and the
retained "superseded, retained" notes are reproduced in
[`hla-coverage-emc-history.md`](./hla-coverage-emc-history.md), so that no supersession banner sits
over current numbers.

**What is retained, stated exactly rather than as a blanket assurance.** The history file carries
the *text* of those blocks as they stood in the live manuscript body immediately before this
regeneration, together with its source pin. It is **not** a byte-level archive: the manuscript's own
Git history in this repository is the record of the file's earlier bytes, and this document does not
claim to reproduce them. Separately, and recorded rather than glossed: the build lane that assembled
this text **deleted six intermediate working fragments** after assembly. Their content is contained
in the delivered files, but **containing the content is not proof that the original bytes survive**,
those originals were not recovered, and they are deliberately **not** recreated here. That
limitation travels with this document.''')

out = src
for old, new in R:
    n = out.count(old)
    if n != 1:
        sys.exit('MATCH FAILURE (%d) for: %r' % (n, old[:90]))
    out = out.replace(old, new, 1)
open('/tmp/claude-0/hw2-lane/hla-coverage-emc.md','w').write(out)
print('OK, replacements applied:', len(R))
