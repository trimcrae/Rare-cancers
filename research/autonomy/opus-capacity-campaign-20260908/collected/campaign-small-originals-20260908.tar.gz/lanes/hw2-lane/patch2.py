import sys
p='/tmp/claude-0/hw2-lane/hla-coverage-emc.md'
s=open(p).read(); R=[]
def rep(a,b): R.append((a,b))
rep(r'''class-II coverage is a **floor over a tested panel**, not a complete class-II scan — untested''',
    r'''class-II coverage is, in the artifact's own words, a **FLOOR over a tested panel** rather than a
complete class-II scan — a statement about what this panel could find, **not** a bound on true
patient eligibility (§4.4) — so untested''')
rep(r'''  coverage **6.49%**, 95% CI **6.30–6.70%** (`coverage_cd4_classii`, `..._95ci`). Floor over the
  tested 23-allele panel (§2.4).''',
    r'''  coverage **6.49%**, 95% CI **6.30–6.70%** (`coverage_cd4_classii`, `..._95ci`). Bounded by the
  tested 23-allele panel (§2.4) — a within-model bound, not a bound on patient eligibility.''')
rep(r'''the coverage in that row is computed over *only* those alleles and is a **floor for a smaller
allele set**, not a like-for-like comparison with a three-allele row.''',
    r'''the coverage in that row is computed over *only* those alleles — it is **the coverage of a smaller
allele set**, not a like-for-like comparison with a three-allele row.''')
rep(r'''The §3.1–§3.2 figures use only the alleles that won best-binder per peptide — a *floor* over the
base set.''',
    r'''The §3.1–§3.2 figures use only the alleles that won best-binder per peptide — the coverage of that
base set alone.''')
rep(r'''   unchecked. Regenerate before circulating.''',
    r'''   unchecked. A refreshed retrieval would give a different model estimate on a later date; it is an
   optional distinct future version of this analysis, not a gate on reporting the frozen build.''')
for a,b in R:
    if s.count(a)!=1: sys.exit('FAIL %r'%a[:70])
    s=s.replace(a,b,1)
open(p,'w').write(s); print('ok',len(R))
