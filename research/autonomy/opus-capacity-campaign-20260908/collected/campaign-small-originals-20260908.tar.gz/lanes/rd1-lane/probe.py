import sys, importlib.util
which = sys.argv[1]
root = f"/tmp/claude-0/rd1-lane/{which}/research/manuscripts"
spec = importlib.util.spec_from_file_location("b", root + "/build_submission_pdf.py")
m = importlib.util.module_from_spec(spec)
try:
    spec.loader.exec_module(m)
except SystemExit as e:
    print("IMPORT SystemExit:", e); sys.exit(9)
body = open(root + "/dependency/emc-atr-collaborator-package.md", encoding="utf-8").read()
body = m.strip_frontmatter(body)
for step, fn in (("declared_running_title", m.declared_running_title),
                 ("parse_front_matter", m.parse_front_matter)):
    try:
        r = fn(body)
        if isinstance(r, dict):
            print(f"OK {step}: keys={sorted(r)}")
            for k in ("author","running","keywords","affiliation"):
                print(f"   {k} = {r.get(k)!r}")
        else:
            print(f"OK {step}: {r!r}")
    except SystemExit as e:
        print(f"FAIL {step}: SystemExit: {e}")
# figure stage
try:
    print("split_figures:", m.split_figures(body, {"Figure 1.": "emc-fusion-frame-fig1.png"}))
except SystemExit as e:
    print("FAIL split_figures: SystemExit:", e)
except Exception as e:
    print("FAIL split_figures:", type(e).__name__, e)
# image rendering
html = m.markdown_to_html("![Figure 1. Three panels.](../figures/emc-fusion-frame-fig1.png)")
print("IMG_TAGS:", html.count("<img"))
print("HTML:", html[:220])
