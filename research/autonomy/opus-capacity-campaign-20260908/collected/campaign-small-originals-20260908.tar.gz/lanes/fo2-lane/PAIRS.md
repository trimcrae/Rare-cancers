# FO2 — coherent correction candidate for `research/manuscripts/fusion-output/nr4a3-fusion-transcriptional-output.md`

Prepared 2026-09-08 against HEAD `de7b3c0ea07265aa92f5207f0e223131c53eb89c`.
**I applied none of these.** Each `old` was verified to occur EXACTLY ONCE in the file at that HEAD,
and all 16 were dry-run applied in order in this lane with no collisions (`DRYRUN-result.md`).

Apply in the listed order. Strings are verbatim, including line breaks.

## P1

**Derivation.** gse28866-tumour-vs-normal.json -> ratio_calibration.n_genes_in_deposit=14120, .n_genes_with_a_normal_ratio=13708, .n_genes_with_a_sarcoma_ratio=13247. Both percentile columns in this table are per-axis, so neither runs on 14,120.

*old* (occurs once):
```
**Table 7. The 3SEQ cohort, calibrated against all 14,120 genes in the same deposit.**
```
*new*:
```
**Table 7. The 3SEQ cohort, calibrated on each axis against the genes in the deposit that have a
computable ratio on that axis: 13,708 genes on the EMC/normal axis and 13,247 on the EMC/sarcoma
axis, out of 14,120 genes present in the deposit.**
```

## P2

**Derivation.** Same fields. ENO3 emc_over_normal_percentile=98.0 is a rank within the normal-axis distribution, whose size is n_genes_with_a_normal_ratio=13708.

*old* (occurs once):
```
and *ENO3* is in the top 2% of 14,120 genes on the
normal axis.
```
*new*:
```
and *ENO3* is in the top 2% of the 13,708 genes with a
computable EMC/normal ratio, which is the denominator of that axis's percentile.
```

## P3

**Derivation.** Same fields; this restates the normal-axis percentile (98.0th), denominator 13,708.

*old* (occurs once):
```
It is in the top
2% of 14,120 genes in an independent cohort on an unrelated technology, the muscle markers are flat
```
*new*:
```
It is in the top
2% of the 13,708 ratio-computable genes on that axis in an independent cohort on an unrelated
technology, the muscle markers are flat
```

## P4

**Derivation.** Same fields; same normal-axis percentile restated in the discussion.

*old* (occurs once):
```
arms, in the top 2% of 14,120 genes in an independent cohort on an unrelated technology, with a
```
*new*:
```
arms, in the top 2% of the 13,708 ratio-computable genes on that axis in an independent cohort on an
unrelated technology, with a
```

## P5

**Derivation.** Same fields. This is the fifth occurrence of the same error, in the artifact/producer table; listed separately because the adjudication named four sites.

*old* (occurs once):
```
`ratio_calibration` — the 3SEQ arm and its percentile calibration against all 14,120 genes in the deposit
```
*new*:
```
`ratio_calibration` — the 3SEQ arm and its percentile calibration, run per axis against the genes with a computable ratio on that axis (13,708 normal, 13,247 sarcoma; 14,120 genes present)
```

## P6

**Derivation.** research/literature/fusion-consensus-probe.json -> queries: filion_2009_pparg__citing_emc.hit_count=22 / __citing_all.hit_count=52; subramanian_2005_cohort__citing_emc=27 / __citing_all=50; kim_2016_eno3__citing_emc=4 / __citing_all=12; brenca_2019_sema3c__citing_all.hit_count=None with returned=0. Max resolved fraction is 54%, so the printed upper bound of 70% has no source and could only come from the null.

*old* (occurs once):
```
are, by contrast, ordinary references of this literature — 42–70% of their citations come from EMC
records, and three of the four are cited by four to six EMC reviews.
```
*new*:
```
are, by contrast, ordinary references of this literature. Of the four primary sources, three returned
a citing-record count: 22 of Filion *et al.*'s 52 citing records (42%), 27 of Subramanian *et al.*'s
50 (54%) and 4 of Kim *et al.*'s 12 (33%) are EMC records. **The Brenca *et al.* citing-record query
returned no count at all, so that fraction is UNKNOWN and no range is stated over the four.** Three of
the four are cited by four to six EMC reviews.
```

## P7

**Derivation.** emc-ret-target-scan.json -> part_1_nbre_scan.focus_genes.{SEMA3C,PPARG,ENO3}.nbre_1mm.n = 39 / 32 / 28; .background_panel.counts (198 entries) has 7 windows with nbre_1mm >= 39, max 43 (HIBCH); .focus_gene_ranks_in_background.ranks.SEMA3C.one_mismatch = {n_background_windows_with_at_least_as_many: 7, n_background: 198, empirical_p_vs_panel: 0.0402, gc_matched.empirical_p: 0.1176}; .focus_genes.SEMA3C.shuffle_null.one_mismatch = {null_mean: 33.7385, empirical_p_one_sided: 0.2029}.

*old* (occurs once):
```
scanned too, and *SEMA3C*'s 39 one-mismatch sites — the most of any gene scanned — are **exactly
what its own composition predicts** (null mean 33.7, p = 0.203; GC-matched p = 0.118), with only the
composition-naive raw rank suggesting enrichment (p = 0.040) in the most AT-rich window of the set.
```
*new*:
```
scanned too, and *SEMA3C*'s 39 one-mismatch sites are **the most of the three class-A genes**
(*PPARG* 32, *ENO3* 28) and not the most of any window scanned: 7 of the 198 background windows carry
as many or more, the highest at 43. **The count is not distinguishable from what its own composition
predicts** (null mean 33.7, p = 0.203; GC-matched p = 0.118) — a non-significant result, which leaves
composition unrefuted as an explanation rather than establishing it — with only the composition-naive
raw rank suggesting enrichment (p = 0.040) in the most AT-rich window of the set.
```

## P8

**Derivation.** nr4a3-fusion-targets.json -> controls.checks.prereg_discordance_SGK1.null_semantics = 'not_outside_up'; .per_platform['GSE24369_series_matrix.txt.gz'] = {band_state: INSIDE_NULL, graded: true, state: AGREES, delta: -0.1807} and .per_platform['GSE4303-GPL3290_series_matrix.txt.gz'] = {band_state: INSIDE_NULL, graded: true, state: AGREES, delta: 0.6156}. The same block's ._threshold field records the earlier fixed raw threshold as 'SUPERSEDED, RETAINED' and calls not_outside_up 'the live rule', so the artifact records a replacement rule, not a predeclared one. No preregistration text is touched by this pair.

*old* (occurs once):
```
whose delta falls *inside* the band is **not a reading at this power** and is not graded either way —
a randomly chosen gene on that platform would land there too. And a control with no computable
```
*new*:
```
whose delta falls *inside* the band is **not a reading at this power** and is not graded either way —
a randomly chosen gene on that platform would land there too. **One control is scored asymmetrically
as implemented, and both of its cells are graded from inside the band.** For *SGK1* the published
prediction is "flat or down", so the implemented rule is `not_outside_up`: the control fails only if
the gene sits outside its band in the UP direction, and an inside-the-band delta therefore satisfies
it and is graded as agreeing. Both *SGK1* cells are graded on that basis (§3.3, Table 4). A cell
graded this way could not have refused the prediction downward at all. This is a description of the
scoring that was run; it is not a claim that the asymmetry was declared in advance. And a control
with no computable
```

## P9

**Derivation.** nr4a3-fusion-targets-occupancy.json -> per_peakset keys carry an explicit @hg19 / @hg38 suffix for every SRX experiment and no suffix for REMAP2022_NR4A1 or the ZENODO1483691 sets. The printed SRX rows are the hg38 leaves: SRX1653204@hg38 n_peaks_total=26660, panel.fraction_with_a_promoter_peak=0.4545, genes.ENO3.empirical_p_vs_panel=0.1206, genes.SEMA3C=0.4573; SRX1653203@hg38 n_peaks_total=22717, panel=0.3131, SEMA3C=0.3166. (The hg19 leaves differ: SRX1653203@hg19 n_peaks_total=22674, panel=0.29, SEMA3C=0.2935.)

*old* (occurs once):
```
Peak counts are promoter-window peaks; *p* is empirical against the panel.
```
*new*:
```
Peak counts are promoter-window peaks; *p* is empirical against the panel. **Every `SRX` row reports
the hg38 processing of that experiment**: the depth, the panel rate and all three *p* values in one
row are that single build's own measurement. The ReMap2022 and Haller (ZENODO) rows exist in one
build only.
```

## P10

**Derivation.** nr4a3-fusion-targets-occupancy.json -> per_peakset['SRX1653203@hg38'].genes.ENO3.empirical_p_vs_panel = 0.0503 (hg19 leaf = 0.0498). Printing 0.050 made an hg38 value read as clearing 0.05; the extra digit keeps the row a single build's own measurement, as adjudicated.

*old* (occurs once):
```
| SRX1653203 | NR4A1 | 22,717 | 31.3% | 2, p 0.050 | 0, p 1.00 | 1, p 0.32 |
```
*new*:
```
| SRX1653203 (hg38) | NR4A1 | 22,717 | 31.3% | 2, p 0.0503 | 0, p 1.00 | 1, p 0.32 |
```

## P11

**Derivation.** nr4a3-fusion-targets-occupancy.json -> per_peakset['SRX1653204@hg38'] = {n_peaks_total: 26660, panel.fraction_with_a_promoter_peak: 0.4545, genes.ENO3.empirical_p_vs_panel: 0.1206, genes.SEMA3C: 0.4573}. Values unchanged; the build label is added so the row is not read as build-agnostic.

*old* (occurs once):
```
| SRX1653204 | NR4A1 | 26,660 | 45.5% | 2, p 0.12 | 0, p 1.00 | 1, p 0.46 |
```
*new*:
```
| SRX1653204 (hg38) | NR4A1 | 26,660 | 45.5% | 2, p 0.12 | 0, p 1.00 | 1, p 0.46 |
```

## P12

**Derivation.** nr4a3-fusion-targets-occupancy.json -> verdict.multiplicity = {n_tests: 36, n_enriched_at_0_05_observed: 2, n_enriched_at_0_05_expected_by_chance: 1.8, p_this_many_or_more_by_chance: 0.5433}. per_gene_summary.ENO3.empirical_p_by_experiment.SRX1653203 = 0.0498 while per_peakset['SRX1653203@hg38'].genes.ENO3.empirical_p_vs_panel = 0.0503 and ['SRX1653203@hg19'] = 0.0498 -> the summary value is the minimum over builds (the same holds for every gene x experiment pair I checked: SRX1653204 ENO3 min(0.1343,0.1206)=0.1206; SEMA3C min(0.2935,0.3166)=0.2935 and min(0.4677,0.4573)=0.4573). ENO3's two hits are SRX1653203 (0.0498) and the parotid set (0.0348); per_gene_summary.{PPARG,SEMA3C}.n_experiments_enriched_at_0_05 = 0. No occupancy run was performed for this pair.

*old* (occurs once):
```
informative experiments, **2 of 36 gene-by-experiment tests reach p < 0.05 against 1.8 expected by
chance — a binomial p of 0.54 for that many or more, which is what chance routinely gives. No class-A
gene carries unusual NR4A occupancy.**
```
*new*:
```
informative experiments, **2 of 36 gene-by-experiment tests reach p < 0.05 against 1.8 expected by
chance — a binomial p of 0.54 for that many or more, which is what chance routinely gives.** Those 36
values are not the table's hg38 cells: each is the **across-build minimum** the artifact records in
`per_gene_summary.<gene>.empirical_p_by_experiment`. The difference is load-bearing for one of the two
hits — *ENO3* in `SRX1653203` is 0.0498 on hg19 and 0.0503 on hg38, so it clears the nominal threshold
on one build and not on the other. **Selecting a per-experiment minimum makes a nominal 0.05 threshold
anti-conservative, so this binomial figure is an indicative calibration and not an exact one; the tail
for a one-hit count was not computed and is not asserted here.** **What the axis supports, stated at
that width: no class-A gene exceeds its background panel in any of these NR4A peak sets.**
```

## P13

**Derivation.** emc-ret-cistrome.json -> part_3_paralogue_overlap.genome_wide_pairwise_sharing.NR4A1_vs_NR4A3 = {peakset_a: 'SRX12698888@hg19', peakset_b: 'SRX12698890@hg19', genome: 'hg19', cell_type_a/b: 'Dendritic Cells', n_peaks_a: 297, n_peaks_b: 102, fraction_of_a_overlapped_by_b: 0.3468, same_cell_type: true}. 0.3468 rounds to 0.347, so the retained derivation exists and is cited rather than omitted. Depth caveat cross-checked against nr4a3-fusion-targets-occupancy.json per_peakset['SRX12698888@hg38'/'SRX12698890@hg38'].panel.fraction_with_a_promoter_peak = 0.0, i.e. both sets are uninformative by that artifact's own rule.

*old* (occurs once):
```
informative experiments — is a paralogue whose peak sharing with NR4A3 is 0.347 in matched dendritic
cells.
```
*new*:
```
informative experiments — is a paralogue whose peak sharing with NR4A3 is 0.347 in one matched pair of
dendritic-cell experiments: 0.3468 of the 297 NR4A1 peaks of `SRX12698888@hg19` overlap the 102 NR4A3
peaks of `SRX12698890@hg19`, both CD1c⁺ dendritic cells on hg19
(`emc-ret-cistrome.json` →
`part_3_paralogue_overlap.genome_wide_pairwise_sharing.NR4A1_vs_NR4A3.fraction_of_a_overlapped_by_b`).
⚠ Both peak sets in that pair are among the shallow dendritic-cell experiments this section calls
uninformative, so this is a single shallow matched-pair reading and not a general paralogue-sharing
constant.
```

## P14

**Derivation.** Same leaf as P13. This is the limitations-list restatement of the same quantity and must carry the same scope.

*old* (occurs once):
```
experiments are NR4A1, a paralogue sharing 0.347 of its peaks with NR4A3 in matched cells; the
```
*new*:
```
experiments are NR4A1, a paralogue sharing 0.347 of its peaks with NR4A3 in one matched pair of
shallow dendritic-cell experiments (297 and 102 peaks; `emc-ret-cistrome.json` →
`part_3_paralogue_overlap.genome_wide_pairwise_sharing.NR4A1_vs_NR4A3`); the
```

## P15

**Derivation.** nr4a3-fusion-targets.json -> controls.checks, 4 controls x 2 platforms = 8 cells. Cells with a computable delta: 7 (the_fusion_itself_NR4A3.per_platform['GSE4303-GPL3290_series_matrix.txt.gz'] has delta=None, state=NOT_MEASURABLE, graded=false). Cells with graded=true: 6 (directional_falsifier_PLAGL1.per_platform['GSE24369_series_matrix.txt.gz'] is graded=false, band_state=INSIDE_NULL). All 6 graded cells have state='AGREES'; controls.checks_failed = []. Manuscript line 441 (§3.3) already states 'Seven of the eight ... six of those are gradeable, and all six agree'. History preserved by appending a dated correction, per the adjudication.

*old* (occurs once):
```
| **corrected 2026-08-08** | Five of six control × platform cells are computable and all five agree; *PLAGL1*/GPL6244 is *inside its null band* and is not a reading at this power. The three-state grading rule is now stated in §2.4. |
```
*new*:
```
| **corrected 2026-08-08; census corrected 2026-09-08** | Five of six control × platform cells are computable and all five agree; *PLAGL1*/GPL6244 is *inside its null band* and is not a reading at this power. The three-state grading rule is now stated in §2.4. **Corrected 2026-09-08:** the cell census in that 2026-08-08 replacement was itself wrong and is superseded, not deleted. **Seven** of the eight control × platform cells carry a computable contrast, **six** of those are gradeable and all six agree; the eighth (*NR4A3* on GPL3290) is not measurable. §3.3 and Table 4 state the 7/6 census; this row had not been brought into line with them. |
```

## P16

**Derivation.** All six appended rows restate derivations already given in P1-P15 above; each names the artifact leaf it rests on. Appended (not rewritten) and dated 2026-09-08, per the adjudication that supersession-table changes preserve the historical record.

*old* (occurs once):
```


## Appendix B · What would change this paper's conclusions
```
*new*:
```

| "top 2% of **14,120** genes" and "Table 7 … calibrated against all 14,120 genes" — the deposit size used as the denominator of a percentile. | **corrected 2026-09-08** | 14,120 is the number of genes in the deposit, not the number ranked. The percentile distributions exclude any gene whose comparator median is zero, so the denominators are **13,708** on the EMC/normal axis and **13,247** on the EMC/sarcoma axis (`gse28866-tumour-vs-normal.json` → `ratio_calibration.n_genes_with_a_{normal,sarcoma}_ratio`). Each site now states the scope its own number was computed on. No percentile changed. |
| "**42–70%** of their citations come from EMC records" (§1.3). | **corrected 2026-09-08** | Only three of the four primary sources returned a citing-record count — 42% (Filion, 22/52), 54% (Subramanian, 27/50) and 33% (Kim, 4/12). The Brenca query returned **no count** (`fusion-consensus-probe.json` → `queries.brenca_2019_sema3c__citing_all.hit_count` = `null`, `returned` = 0), so the upper bound of the printed range rested on a missing measurement rather than on a value. The three resolved fractions are now given individually and the Brenca fraction is stated as UNKNOWN. |
| "*SEMA3C*'s 39 one-mismatch sites — **the most of any gene scanned**" and those sites being "**exactly what its own composition predicts**" (§3.10). | **corrected 2026-09-08** | 39 is the most of the three class-A genes, not of the scan: 7 of the 198 background windows carry as many or more, the highest at 43 (`emc-ret-target-scan.json` → `part_1_nbre_scan.background_panel.counts`). And the composition nulls are **not significant** (p = 0.203; GC-matched p = 0.118), so they leave composition unrefuted rather than demonstrated; "exactly what composition predicts" read a null as proof of the prediction. The counts themselves are unchanged. |
| Table 9 rows and the "2 of 36" headline read as one measurement each, without naming a genome build (§3.11). | **corrected 2026-09-08** | Every `SRX` experiment is processed on both hg19 and hg38 (`nr4a3-fusion-targets-occupancy.json` → `per_peakset` keys). The table's `SRX` rows are the **hg38** leaves and are now labelled so; the "2 of 36" count is computed from a different quantity, the **across-build minimum** in `per_gene_summary.<gene>.empirical_p_by_experiment`, which is now named where it is used. The one consequence: *ENO3* in `SRX1653203` is 0.0498 on hg19 and 0.0503 on hg38. Because a per-experiment minimum is selected, the nominal binomial calibration is indicative rather than exact; no alternative tail was computed and none is claimed. No occupancy analysis was re-run. |
| "a paralogue whose peak sharing with NR4A3 is **0.347**" (§3.11, Limitation 12), stated without its source. | **corrected 2026-09-08** | The derivation is retained and is now cited: `emc-ret-cistrome.json` → `part_3_paralogue_overlap.genome_wide_pairwise_sharing.NR4A1_vs_NR4A3.fraction_of_a_overlapped_by_b` = **0.3468**, the fraction of the 297 NR4A1 peaks of `SRX12698888@hg19` overlapping the 102 NR4A3 peaks of `SRX12698890@hg19` in matched CD1c⁺ dendritic cells. Both peak sets are shallow enough to be uninformative by Table 9's own depth rule, and the sentence now says so. The value is unchanged. |
| §2.4's grading rule stated without exception, while *SGK1* is graded from inside its null band. | **corrected 2026-09-08** | The implemented rule for *SGK1* is asymmetric — `null_semantics` = `not_outside_up` (`nr4a3-fusion-targets.json` → `controls.checks.prereg_discordance_SGK1`) — so both of its `INSIDE_NULL` cells are `graded: true`. §2.4 now discloses the exception as implemented. ⛔ It is described as scoring that was run, not as an advance declaration: the same block records the previous fixed-threshold rule as `SUPERSEDED, RETAINED`. The preregistration text is unchanged and no grade moved. |

## Appendix B · What would change this paper's conclusions
```
