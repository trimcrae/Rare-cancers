import re, sys
sys.path.insert(0,'/home/user/Rare-cancers/research/manuscripts')
import lint_style as L

SRC='before.md'
lines=open(SRC,encoding='utf-8').read().split('\n')

# ---- protected lines: referenced headings (slug must not change) + verbatim superseded quotes
entries=L._body_lines(SRC)
PROTECTED_HEADINGS={184,246,588,685,745,855,909,938,964,987,1003,1145}
VERBATIM={667,1188}
PROTECT=PROTECTED_HEADINGS|VERBATIM

# ---- A. bold-midsentence removal --------------------------------------------------------
emap={n:(line,th,h) for n,line,th,h in entries}
def midsent(prefix):
    return bool(re.search(r"[A-Za-z0-9,)][\s]*$", prefix)) and not re.match(r"^[\s>|*\-+\d.]*$", prefix)

removed_bold=0
for n,(line,th,h) in sorted(emap.items()):
    if n in PROTECT: continue
    cur=lines[n-1]
    # same-line spans
    out=[]; pos=0; changed=False
    for m in re.finditer(r"\*\*(.+?)\*\*", cur):
        pass
    # rebuild iteratively (indices shift), so loop until stable
    while True:
        hit=None
        for m in re.finditer(r"\*\*(.+?)\*\*", cur):
            if th or h: break
            if midsent(cur[:m.start()]):
                hit=m; break
        if not hit: break
        cur=cur[:hit.start()]+hit.group(1)+cur[hit.end():]
        removed_bold+=1; changed=True
    lines[n-1]=cur

# recompute across-line-break cases after same-line pass
def crossline_pass():
    global removed_bold
    ents=[(n,lines[n-1],th,h) for n,(l,th,h) in sorted(emap.items())]
    idx={n:(l,th,h) for n,l,th,h in ents}
    fixed=0
    for n,line,th,h in ents:
        if n in PROTECT or th or h: continue
        if line.count('**')%2!=1: continue
        nxt=idx.get(n+1)
        if nxt is None or '**' not in nxt[0] or n+1 in PROTECT: continue
        prefix=line[:line.rfind('**')]
        if not midsent(prefix): continue
        # strip opening on this line and the first closing on the next
        lines[n-1]=line[:line.rfind('**')]+line[line.rfind('**')+2:]
        nl=nxt[0]; p=nl.find('**')
        lines[n]=nl[:p]+nl[p+2:]
        removed_bold+=1; fixed+=1
    return fixed
while crossline_pass(): pass

# ---- B. decorative glyph removal ---------------------------------------------------------
DEC='⭐⭑★✅⏸✕'
removed_glyph=0
for n,(l,th,h) in sorted(emap.items()):
    if n in PROTECT: continue
    cur=lines[n-1]
    if not any(c in cur for c in DEC): continue
    new=re.sub('['+DEC+']','\x00',cur)
    # collapse: "\x00 " -> "", " \x00" -> "", leftover
    new=re.sub(r'\x00+\s*','',new)
    new=re.sub(r'\s+\x00','',new)
    new=new.replace('\x00','')
    new=re.sub(r'\|\s+','| ',new) if new.strip().startswith('|') else new
    new=re.sub(r'^(\s*(?:>\s*)?)\s+',r'\1',new)
    new=re.sub(r'\s+$','',new) if not cur.endswith('  ') else new
    if new!=cur:
        removed_glyph+=1; lines[n-1]=new

open('after.md','w',encoding='utf-8').write('\n'.join(lines))
print('bold spans unbolded:',removed_bold,'glyph lines cleaned:',removed_glyph)
