# MC2 — old→new pairs for `research/manuscripts/modality-census/cancer-modality-census.md`

Baseline: HEAD `c7a1d468dd6db11e7973a11a62fbfb26a86605f9`, clean tree, `2026-09-08T14:05:08Z`.
Every pair below is derived from a named artifact field. I have applied none of them.

---

## P1 — §2 table, `on_board` row (defect 2)

Derivation: `systems/graph/modalities.json`, count of rows with `verdict == "on_board"` = **42**;
of those, rows with `prior_coverage == "never_searched"` = **1**.

old:
```
| ✓ `on_board` — a route already covers it | 41 | 0 |
```
new:
```
| ✓ `on_board` — a route already covers it | 42 | 1 |
```

---

## P2 — §2 table, `not_applicable` row (defect 3)

Derivation: `systems/graph/modalities.json`, `verdict == "not_applicable"` = **10**, all 10
`never_searched`.

old:
```
| — `not_applicable` | 11 | 11 |
```
new:
```
| — `not_applicable` | 10 | 10 |
```

Cross-check that P1+P2 keep the table coherent: 42+8+33+95+20+9+10 = **217** (matches the stated
217 classes and `len(modalities.json)` = 217); never-searched column 1+0+0+86+6+8+10 = **111**
(matches the stated headline of 111 and the registry count of `never_searched` rows). The four
other rows in the table are already correct against the registry and need no pair.

---

## P3 — §2, the "two wrong readings" paragraph (defect 8)

Derivation: the never-searched total is **111** (`modalities.json`, `prior_coverage ==
"never_searched"`), superseding 127, exactly as §2 and §2.1 already state. For the second number,
see the ambiguity note below.

old:
```
Two readings of that number are wrong and worth heading off. It is **not** a claim that 127 opportunities
were missed — 84 of them are closed by this census on first inspection, which is what a denominator is
```
new:
```
Two readings of that number are wrong and worth heading off. It is **not** a claim that 111 opportunities
were missed — 86 of them are closed by this census on first inspection, which is what a denominator is
```

⚠ **Read the second number before applying.** "them" is anaphoric to the never-searched set, so the
strictly correct figure is `excluded ∩ never_searched` = **86** — which is also the number already
printed in the `excluded` row of the §2 table. If the author instead meant *all* classes this census
closes, the figure is **95** (`verdict == "excluded"`), which is what §4 quotes (see P8). The
superseded text preserved at line 85 reads `excluded 84/83`, i.e. the original sentence used the
**total** excluded count (84) against the never-searched total (127), so the author's original
arithmetic was itself of the second kind and was slightly loose. I have chosen 86 because it makes
the sentence true as written; if you prefer to keep the author's original (loose) construction the
value is 95. Both readings are recorded here rather than silently picked.

---

## P4 — §2.1, audit adjudication attributed to the wrong artifact (defect 9)

Derivation: `research/modalities/census-novelty-audit.json` — `n_rows_with_a_candidate_collision`
= **73** (correct as printed), and **all 73** findings carry
`adjudication: "UNREVIEWED — a term match is not a coverage claim"`; zero findings in that file are
adjudicated. The generator says where the adjudication does live:
`research/modalities/census_novelty_audit.py:20-21` — *"the adjudication is recorded in the census
row itself, never here."* Corroborated in `systems/graph/modalities.json`: 12 of the 20 `candidate`
rows now carry a resolvable `prior_ref`, which is the adjudication the audit asked for.

old:
```
nothing. ⚠ **It flagged 73 rows and only the 20 candidate rows were adjudicated**, because those are
the ones anyone would act on. The remaining flags are recorded as unreviewed rather than silently
cleared, so the count of 111 should be read as *an upper bound that has been tightened once*, not as a
```
new:
```
nothing. ⚠ **It flagged 73 rows and adjudicates none of them** — every finding in the audit file is
recorded `UNREVIEWED`, and the adjudication is recorded in the census row itself, in
[`systems/graph/modalities.json`](../../../systems/graph/modalities.json). **Only the 20 candidate rows
were adjudicated there**, because those are the ones anyone would act on. The remaining flags are left
unreviewed rather than silently
cleared, so the count of 111 should be read as *an upper bound that has been tightened once*, not as a
```

This is a **scope/attribution** fix, not a stale number: 73 and 20 are both correct.

---

## P5 — §3.2a, the MCL-1 / BCL-xL verdict row (defect 1, site 1 of 2)

Derivation, three sources agreeing that the class is **not** excluded:
- `systems/graph/modalities.json` → `MOD-MCL1-BCLXL.verdict` = **`candidate`**, and its
  `zero_dollar_next_step` reads *"⭐ The class stays open because abundance cannot measure which
  protein HOLDS the effectors; that needs BH3 profiling."*
- `research/modalities/census-route-expression-grading.json` → `routes.RT-APOPTOSIS-DEP.verdict` =
  **"AGAINST AT THE ABUNDANCE LEVEL"** (not "excluded"), and
  `routes.RT-APOPTOSIS-DEP.route_action` = *"the MCL-1-dominance form is AGAINST on abundance and FOR
  on the sarcoma dependency prior; the two disagree and dependency is the relevant axis, so the route
  is restored to open rather than down-graded."*
- same file, `routes.RT-APOPTOSIS-DEP.sarcoma_dependency_prior`: MCL1 dependent in **83.5 %**,
  BCL2L1 in **75.8 %**, BCL2 in **2.2 %** of the 91 screened sarcoma lines.

old:
```
| MCL-1 / BCL-xL | excluded at the abundance level — all five druggable guardians are lower on both platforms |
```
new:
```
| MCL-1 / BCL-xL | **against at the abundance level** — all five druggable guardians are lower on both platforms. ⚠ **The class is not excluded and stays a candidate:** across the 91 screened sarcoma lines MCL1 and BCL2L1 are dependencies in 83.5 % and 75.8 % and BCL2 in 2.2 %, so the dependency prior points the opposite way to the abundance read, and the route was restored to open rather than down-graded (`census-route-expression-grading.json` → `RT-APOPTOSIS-DEP.route_action`) |
```

---

## P6 — §3.2a, the count sentence (defect 1, site 2 of 2)

Derivation: the six §3.2 classes, from
`research/modalities/census-route-expression-grading.json` and `systems/graph/modalities.json`:
PRMT5/MAT2A `RT-MTAP-PRMT5` = SUPPORTED (survived); arginine `RT-ARGININE` = AGAINST;
MDM2 `RT-MDM2` = NOT SUPPORTED; EZH2 `RT-EZH2` = NOT SUPPORTED; POLθ `RT-POLQ` = NOT SUPPORTED;
MCL-1/BCL-xL `RT-APOPTOSIS-DEP` = AGAINST ON ABUNDANCE but **restored to open**, registry verdict
`candidate`. So **four excluded, one survived, one still open** — not five and one.

old:
```
All six were graded on 2026-08-09 against the panel and its CI extension. **Five of the six were
excluded and one survived** — which is what the caveat above predicted the theme would produce, and it
```
new:
```
All six were graded on 2026-08-09 against the panel and its CI extension. **Four of the six were
excluded, one survived, and one stays open** — which is close to what the caveat above predicted the theme would produce, and it
```

Note the §3 headline "Twenty classes survive" is **correct** and must not be touched: see
"Defects that did not hold up".

---

## P7 — §3.3, the ALK / ROS1 readability sentence (defect 4)

Derivation: `research/modalities/census-route-expression-grading.json` →
`routes.RT-ALK-HIT.observed`, whose first clause is an explicit retraction of exactly this sentence:
*"⛔ CORRECTED, AND THE OLD SENTENCE WAS CONTRADICTED BY THE TABLE DIRECTLY ABOVE IT IN THIS SAME
FILE: it read 'Both kinases the lead names are NOT READABLE on EITHER platform — ALK and ROS1 have no
probe on GPL6244 or GPL3290'. The panel artifact that OWNS these reads says ALK is readable on
GPL6244 (one probe) and not on GPL3290, and ROS1 is readable on BOTH."* Confirmed in the same file's
`routes.RT-ALK-HIT.genes`: `ALK.GSE24369…readable = true` / `ALK.GSE4303-GPL3290…readable = false`;
`ROS1` readable `true` on both. The artifact's own gloss on what the corrected read means:
*"the route moves from 'we cannot see it' to 'we can see it on one platform and it is unremarkable
there'"*, and `what_this_does_not_settle`: *"ABUNDANCE NEVER ATTRIBUTES A SCREEN HIT EVEN WHERE THE
READ SUCCEEDS."*

This is a **scope** defect, not a number: the paper reproduces a claim the owning artifact retracted
on 2026-08-29. The conclusion (unattributable) survives; the reason given for it does not.

old:
```
belong to a different single class already on the board, and ALK and ROS1 themselves cannot be read on
either expression platform here, so the hit is unattributable to this class in principle. ⚠ The
unreadability is an instrument statement, not a negative reading of either kinase — what closes the row
is that the screen's own weight sits elsewhere
```
new:
```
belong to a different single class already on the board, and abundance cannot attribute a screen hit to
a target in any case, so the hit is unattributable to this class in principle. ⚠ **This document said
until now that neither kinase could be read on either platform, and the owning artifact retracted that
on 2026-08-29:** ALK is readable on one of the two platforms and ROS1 on both, and where they are
readable they sit unremarkably — which rules neither of them out and is a statement about the
instrument rather than a negative reading. What closes the row
is that the screen's own weight sits elsewhere
```

---

## P8 — §4, the count of closed classes (defect 7)

Derivation: `systems/graph/modalities.json`, `verdict == "excluded"` = **95** — the same figure
already printed in the `excluded` row of the §2 table.

old:
```
Eighty-four classes are closed here on first inspection, and that is the census working rather than the
```
new:
```
Ninety-five classes are closed here on first inspection, and that is the census working rather than the
```

---

## P9 — §3.5, the BNCT decline (defect 11)

Derivation: `research/manuscripts/program/emc-unexplored-treatment-lanes.md:602` — the row this
census points at: *"**BNCT** | Dose scales with boron atoms per unit volume, and the field already
measured this failure in the nearest histology: myxofibrosarcoma BNCT attributed low BPA accumulation
to \"the low density of cells per unit volume of mucus produced by the tumor\". EMC is **more**
matrix-dominated."* Corroborated by `systems/graph/modalities.json` → `MOD-BNCT.rationale` ("Ruled
out in the 2026-08-07 sweep on a measurement in the nearest histology") and by the identical clause
carried on `MOD-RADIOIMMUNOCONJUGATE` / `MOD-AUGER`-type rows: *"Dose is delivered per cell but the
tumour is dosed per unit volume, and EMC's matrix-dominated bulk gives it few cells per unit volume."*

⚠ **Partial defect.** The source *does* say "boron atoms per unit volume" — that is the dosimetry
clause. What it does **not** say is that the class was *declined* on it: the measurement it was
declined on is the low density of **cells** per unit volume. The paper's own next sentence already
calls it "that cells-per-volume correction", so the passage is internally inconsistent. The fix
keeps both clauses in their correct roles.

old:
```
neutron capture was declined on boron atoms per unit volume in a matrix-dominated tumour. That
```
new:
```
neutron capture was declined on the low density of cells per unit volume in a matrix-dominated tumour:
dose scales with boron atoms per unit volume, and the boron is delivered per cell. That
```

---

## P10 — §3.8, the count of graded routes (defect 6)

Derivation: `research/modalities/census-route-expression-grading.json` → `routes` has **16** keys
(RT-ARGININE, RT-RET, RT-HYPOXIA-PRODRUG, RT-MATRIX-SYNTHESIS, RT-ALK-HIT, RT-MATRIX-ADDRESS,
RT-IMMUNOCYTOKINE, RT-NR2F1, RT-MTAP-PRMT5, RT-TXN-CDK, RT-CHAPERONE, RT-APOPTOSIS-DEP, RT-MDM2,
RT-EZH2, RT-SGK1, RT-POLQ), and its own `summary` block buckets exactly those 16
(supported 2, against 3, withdrawn 1, split_or_unread 10). Panel size from
`research/modalities/emc-expression-panels.json` → `len(gene_reads)` = **479**,
`generated_utc` = 2026-08-29T12:51:32+00:00.

old:
```
Six of the routes registered above turned out not to need their cheapest observation **run** at all.
The genes were already read and committed in the repository's targeted expression panel, and nobody
had graded them against these routes because the routes did not exist when the panel was built. That
```
new:
```
Sixteen of the routes registered above turned out not to need their cheapest observation **run** at all.
The genes are read and committed in the repository's targeted expression panel — 479 of them as it now
stands, after the extension §3.2a reports — and nobody
had graded them against these routes because the routes did not exist when the panel was built. That
```

⚠ I could **not** verify how the 16 split between "already in the panel when the routes were
registered" and "added by the CI extension": the panel artifact carries only its current
`generated_utc` and the repository history for it is squashed to a single commit
(`git log -- research/modalities/emc-expression-panels.json` → `14a3f172` only). The wording above
therefore asserts only what is checkable — 16 graded routes, 479 genes now.

---

## P11 — §3.8 table, the missing SGK1 and chaperone rows (defect 10)

Derivation: `research/modalities/census-route-expression-grading.json` →
`routes.RT-SGK1.verdict` = *"DISCORDANT ON THE KINASE, CONCORDANT ON ITS SUBSTRATE."*, with
`observed` = *"⚠ SGK1 itself is DISCORDANT — lower on one platform, higher on the other. Its
canonical substrate NDRG1 is higher on both, at the 98th percentile on one."* and
`what_this_does_not_settle` = *"every published mechanism connecting SGK1 to NDRG1 is a
PHOSPHORYLATION of NDRG1 protein — so this substrate elevation is not attributable to SGK1"*;
`routes.RT-CHAPERONE.verdict` = *"PARTLY SUPPORTED — the HSP90 arm only, and the stress-response arm
contradicts it."*, with `observed` = *"The HSP90 machine is HIGHER in EMC on BOTH platforms and the
co-chaperones follow it. ⚠ The HSP70 arm and heat-shock response go the OTHER way on both."* and
`what_this_does_not_settle` = *"An elevated chaperone machine is not evidence that the fusion is its
client, which is the route's actual premise and a co-immunoprecipitation question."*

Both classes are named in the paper (§3.3 SGK1, §3.1 chaperone dependency) with no grading reported.

old:
```
| orphan-receptor dormancy | **unread** — no probe maps to the receptor on either platform |
```
new:
```
| orphan-receptor dormancy | **unread** — no probe maps to the receptor on either platform |
| SGK1 (§3.3) | **discordant on the kinase, concordant on its substrate** — SGK1 itself is lower on one platform and higher on the other; its canonical substrate NDRG1 is higher on both, at the 98th percentile on one. ⚠ Every published SGK1→NDRG1 mechanism is a phosphorylation of NDRG1 protein, so the substrate elevation is not attributable to the kinase; the corroboration the route was registered for did not arrive |
| chaperone dependency (§3.1) | **partly supported** — the HSP90 machine is higher on both platforms and the co-chaperones follow it, while the HSP70 arm and the heat-shock response go the other way on both. ⚠ An elevated chaperone machine is not evidence that the fusion is its client, which is the route's actual premise and a co-immunoprecipitation question |
```

---

## P12 — §3.8, the "243-gene panel" paragraph (defect 5)

Derivation: `research/modalities/emc-expression-panels.json` → `len(gene_reads)` = **479**.
But the number is the smaller half of the problem: `census-route-expression-grading.json` grades
**all six** §3.2 biomarker classes (`RT-MTAP-PRMT5`, `RT-ARGININE`, `RT-MDM2`, `RT-APOPTOSIS-DEP`,
`RT-EZH2`, `RT-POLQ`), and §3.2a of this same paper already reports what all six returned. So the
claim that five of them are *not* in the pass is **false in scope**, not merely stale in its number;
substituting 479 for 243 alone would leave a false sentence that contradicts §3.2a two sections
earlier.

old:
```
⚠ **Five of the six biomarker-selected classes in §3.2 are NOT in this pass**, because their selecting
genes are not among the 243 the panel currently reads. Extending it is a free CI job and is the
immediate next step; until it runs, those five rows are unexamined rather than open.
```
new:
```
⚠ **The panel extension this section named as its next step has since run.** All six biomarker-selected
classes in §3.2 are now in this pass — their selecting genes are among the 479 the panel currently
reads — and [§3.2a](#32a--the-lookups-were-run-the-same-day-and-the-prediction-held) reports what came
back. *Superseded, retained: "Five of the six biomarker-selected classes in §3.2 are NOT in this pass,
because their selecting genes are not among the 243 the panel currently reads. Extending it is a free
CI job and is the immediate next step; until it runs, those five rows are unexamined rather than
open."*
```
