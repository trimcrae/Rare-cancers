import re, sys, importlib.util
spec = importlib.util.spec_from_file_location("ls", "/home/user/Rare-cancers/research/manuscripts/lint_style.py")
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
src, dst = sys.argv[1], sys.argv[2]
raw = open(src, encoding="utf-8").read().split("\n")
entries = m._body_lines(src)
info = {ln: (line, th, h) for ln, line, th, h in entries}
order = [ln for ln,_,_,_ in entries]
paras, cur, prev = [], [], None
for ln in order:
    if prev is not None and (ln != prev+1 or raw[ln-1].strip()==""):
        if cur: paras.append(cur)
        cur=[]
    if raw[ln-1].strip()!="": cur.append(ln)
    prev=ln
if cur: paras.append(cur)

remove=[]; report=[]
for p in paras:
    occ=[]
    for ln in p:
        for mm in re.finditer(r"\*\*", info[ln][0]): occ.append((ln, mm.start()))
    assert len(occ)%2==0, p[0]
    for i in range(0,len(occ),2):
        oln,ocol=occ[i]; cln,ccol=occ[i+1]
        line,is_th,heading=info[oln]
        if is_th or heading or line.lstrip().startswith("|"): continue
        # preceding text within paragraph
        idx=p.index(oln)
        pre=" ".join(info[x][0] for x in p[:idx]) + " " + line[:ocol]
        pre=re.sub(r"\*|`|_","",pre).strip()
        if pre=="" : continue
        if re.match(r"^[-*+]\s*$", line[:ocol].strip() or "x") : pass
        # list item / numbered item start on this line
        if re.match(r"^\s*(?:[-*+]|\d+\.)\s*$", line[:ocol]): continue
        if re.search(r"[.:;!?]$", pre): continue
        remove += [(oln,ocol),(cln,ccol)]
        report.append((oln, line[max(0,ocol-40):ocol+40]))
byline={}
for ln,c in remove: byline.setdefault(ln,[]).append(c)
out=list(raw)
for ln,cols in byline.items():
    s=out[ln-1]
    for c in sorted(cols,reverse=True):
        assert s[c:c+2]=="**",(ln,c)
        s=s[:c]+s[c+2:]
    out[ln-1]=s
open(dst,"w",encoding="utf-8").write("\n".join(out))
print("additional spans removed:", len(remove)//2)
for ln,t in report: print(" ", ln, "…", t.replace("\n"," "))
