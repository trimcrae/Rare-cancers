import re, sys, importlib.util
spec = importlib.util.spec_from_file_location("ls", "/home/user/Rare-cancers/research/manuscripts/lint_style.py")
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
src, dst = sys.argv[1], sys.argv[2]
raw = open(src, encoding="utf-8").read().split("\n")
entries = m._body_lines(src)
info = {ln: (line, th, h) for ln, line, th, h in entries}
lines_in_order = [ln for ln, _, _, _ in entries]
# group body lines into contiguous paragraphs (blank line or gap breaks)
paras, cur = [], []
prev = None
for ln in lines_in_order:
    if prev is not None and (ln != prev + 1 or raw[ln-1].strip() == ""):
        if cur: paras.append(cur)
        cur = []
    if raw[ln-1].strip() != "":
        cur.append(ln)
    prev = ln
if cur: paras.append(cur)

remove = []   # (lineno, col)
kept = 0
for p in paras:
    occ = []
    for ln in p:
        for mm in re.finditer(r"\*\*", info[ln][0]):
            occ.append((ln, mm.start()))
    if len(occ) % 2:
        print("WARN odd paragraph starting line", p[0], file=sys.stderr)
        continue
    for i in range(0, len(occ), 2):
        oln, ocol = occ[i]
        cln, ccol = occ[i+1]
        line, is_th, heading = info[oln]
        if is_th or heading:
            kept += 1; continue
        prefix = line[:ocol]
        if re.search(r"[A-Za-z0-9,)][\s]*$", prefix) and not re.match(r"^[\s>|*\-+\d.]*$", prefix):
            remove += [(oln, ocol), (cln, ccol)]
        else:
            kept += 1
byline = {}
for ln, c in remove: byline.setdefault(ln, []).append(c)
out = list(raw)
for ln, cols in byline.items():
    s = out[ln-1]
    for c in sorted(cols, reverse=True):
        assert s[c:c+2] == "**", (ln, c)
        s = s[:c] + s[c+2:]
    out[ln-1] = s
open(dst, "w", encoding="utf-8").write("\n".join(out))
print("spans removed:", len(remove)//2, "spans kept:", kept)
