import sys, importlib.util
spec = importlib.util.spec_from_file_location("ls", "/home/user/Rare-cancers/research/manuscripts/lint_style.py")
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
r = m.lint_file(sys.argv[1])
from collections import Counter
c = Counter(k for _,_,k,_ in r["findings"])
print(r["words"], r["bold_per_1000"], r["emdash_per_1000"], dict(c), len(r["findings"]))
for lineno, sev, kind, msg in r["findings"]:
    print(f"{lineno}\t{kind}\t{msg}")
