import re, sys, importlib.util
spec = importlib.util.spec_from_file_location("ls", "/home/user/Rare-cancers/research/manuscripts/lint_style.py")
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
src = sys.argv[1]; dst = sys.argv[2]
raw = open(src, encoding="utf-8").read().split("\n")
entries = m._body_lines(src)
body = {ln: (line, th, h) for ln, line, th, h in entries}
# collect edits: (lineno, col) positions of '**' markers to delete
dele = {}
def mark(ln, col):
    dele.setdefault(ln, set()).add(col)
for ln, line, is_th, heading in entries:
    if is_th or heading:
        continue
    for mm in re.finditer(r"\*\*(.+?)\*\*", line):
        prefix = line[:mm.start()]
        if re.search(r"[A-Za-z0-9,)][\s]*$", prefix) and not re.match(r"^[\s>|*\-+\d.]*$", prefix):
            mark(ln, mm.start()); mark(ln, mm.end()-2)
    if line.count("**") % 2 == 1:
        nxt = body.get(ln+1)
        if nxt is not None and "**" in nxt[0]:
            pos = line.rfind("**")
            prefix = line[:pos]
            if re.search(r"[A-Za-z0-9,)][\s]*$", prefix) and not re.match(r"^[\s>|*\-+\d.]*$", prefix):
                mark(ln, pos); mark(ln+1, nxt[0].find("**"))
out = list(raw)
for ln, cols in dele.items():
    s = out[ln-1]
    for c in sorted(cols, reverse=True):
        assert s[c:c+2] == "**", (ln, c, s[c-5:c+10])
        s = s[:c] + s[c+2:]
    out[ln-1] = s
open(dst, "w", encoding="utf-8").write("\n".join(out))
print("lines touched:", len(dele), "markers removed:", sum(len(v) for v in dele.values()))
