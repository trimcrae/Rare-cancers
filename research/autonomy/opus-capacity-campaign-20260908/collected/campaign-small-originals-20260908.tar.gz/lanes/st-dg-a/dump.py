import sys, collections
sys.path.insert(0, '/home/user/Rare-cancers/research/manuscripts')
import lint_style
r = lint_style.lint_file(sys.argv[1])
cut = 2853
tot = collections.Counter(); a = collections.Counter(); b = collections.Counter()
for ln, sev, kind, msg in r["findings"]:
    tot[kind]+=1
    (a if (ln<=cut and ln!=0) else b)[kind]+=1
print("words", r["words"], "bold", r["bold_per_1000"], "emdash", r["emdash_per_1000"])
print("TOTAL", sum(tot.values()), dict(sorted(tot.items())))
print("IN-SUBSET (lines 1-%d)"%cut, sum(a.values()), dict(sorted(a.items())))
print("OUT-OF-SUBSET (line>%d or density=line0)"%cut, sum(b.values()), dict(sorted(b.items())))
if len(sys.argv)>2:
    for ln, sev, kind, msg in r["findings"]:
        print(f"{ln}\t{kind}\t{msg}")
