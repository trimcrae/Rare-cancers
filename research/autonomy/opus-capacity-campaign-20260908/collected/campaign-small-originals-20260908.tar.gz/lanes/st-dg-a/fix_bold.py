import re, sys
sys.path.insert(0, '/home/user/Rare-cancers/research/manuscripts')
import lint_style

SRC = '/tmp/claude-0/st-dg-a/before.md'
DST = '/tmp/claude-0/st-dg-a/after.md'
CUT = 2853

raw = open(SRC, encoding='utf-8').read().split('\n')
elig = {ln: (th, hd) for ln, line, th, hd in lint_style._body_lines(SRC)}

def flagged(prefix):
    return bool(re.search(r"[A-Za-z0-9,)][\s]*$", prefix)) and not re.match(r"^[\s>|*\-+\d.]*$", prefix)

def editable(ln):
    if ln not in elig or ln > CUT:
        return False
    th, hd = elig[ln]
    return not (th or hd)

work = list(raw)
n_pair = n_cross = 0
for _ in range(10):
    snapshot = list(work)
    for ln in range(1, min(CUT, len(work)) + 1):
        if not editable(ln):
            continue
        changed = True
        while changed:
            changed = False
            line = work[ln-1]
            for m in re.finditer(r"\*\*(.+?)\*\*", line):
                if flagged(line[:m.start()]):
                    work[ln-1] = line[:m.start()] + m.group(1) + line[m.end():]
                    n_pair += 1
                    changed = True
                    break
    for ln in range(1, min(CUT, len(work)) + 1):
        if not editable(ln):
            continue
        line = work[ln-1]
        if line.count('**') % 2 != 1:
            continue
        if ln + 1 not in elig:
            continue
        nxt = work[ln]
        if '**' not in nxt:
            continue
        pos = line.rfind('**')
        if not flagged(line[:pos]):
            continue
        work[ln-1] = line[:pos] + line[pos+2:]
        j = nxt.find('**')
        work[ln] = nxt[:j] + nxt[j+2:]
        n_cross += 1
    if work == snapshot:
        break

open(DST, 'w', encoding='utf-8').write('\n'.join(work))
print('pairs unbolded:', n_pair, 'cross-line spans unbolded:', n_cross)
