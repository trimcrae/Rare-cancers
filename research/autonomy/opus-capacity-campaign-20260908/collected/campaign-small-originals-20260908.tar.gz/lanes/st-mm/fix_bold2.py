import re, sys, importlib.util
spec = importlib.util.spec_from_file_location(
    "lint_style", "/home/user/Rare-cancers/research/manuscripts/lint_style.py")
ls = importlib.util.module_from_spec(spec); spec.loader.exec_module(ls)

path = sys.argv[1]
raw = open(path, encoding="utf-8").read().split("\n")
entries = ls._body_lines(path)
for n, line, _t, _h in entries:
    assert line == raw[n-1]
meta = {n: (th, hd) for (n, _l, th, hd) in entries}

# Pair ** markers sequentially across body lines (document order).
marks = []
for n, line, _t, _h in entries:
    for m in re.finditer(r"\*\*", line):
        marks.append((n, m.start()))
pairs = [(marks[i], marks[i+1]) for i in range(0, len(marks) - len(marks) % 2, 2)]
odd = marks[-1] if len(marks) % 2 else None

dele = {}
report = []
for (n1, i1), (n2, i2) in pairs:
    th, hd = meta[n1]
    if th or hd:
        continue
    prefix = raw[n1-1][:i1]
    if re.search(r"[A-Za-z0-9,)][\s]*$", prefix) and not re.match(r"^[\s>|*\-+\d.]*$", prefix):
        dele.setdefault(n1, set()).add(i1)
        dele.setdefault(n2, set()).add(i2)
        report.append((n1, n2))

for n, idxs in dele.items():
    l = raw[n-1]
    for i in sorted(idxs, reverse=True):
        assert l[i:i+2] == "**", (n, i, repr(l))
        l = l[:i] + l[i+2:]
    raw[n-1] = l
open(path, "w", encoding="utf-8").write("\n".join(raw))
print(f"marks={len(marks)} pairs={len(pairs)} odd={odd} unbolded_spans={len(report)} lines_touched={len(dele)}")
print("cross-line spans unbolded:", [p for p in report if p[0] != p[1]])
