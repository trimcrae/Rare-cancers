import re, sys, importlib.util, os
spec = importlib.util.spec_from_file_location(
    "lint_style", "/home/user/Rare-cancers/research/manuscripts/lint_style.py")
ls = importlib.util.module_from_spec(spec); spec.loader.exec_module(ls)

path = sys.argv[1]
MARK = "\x00\x00"  # placeholder for a removed ** marker

for it in range(60):
    raw = open(path, encoding="utf-8").read().split("\n")
    entries = ls._body_lines(path)
    meta = {n: (th, hd) for (n, _l, th, hd) in entries}
    lines = {n: l for (n, l, _t, _h) in entries}
    changed = 0
    # positions to delete: dict lineno -> set of start indices of "**" in the RAW line
    dele = {}
    def flag(n, i):
        dele.setdefault(n, set()).add(i)
    for n, line, is_th, heading in entries:
        assert line == raw[n-1], (n, repr(line), repr(raw[n-1]))
        for m in re.finditer(r"\*\*(.+?)\*\*", line):
            if is_th or heading:
                continue
            prefix = line[:m.start()]
            if re.search(r"[A-Za-z0-9,)][\s]*$", prefix) and not re.match(r"^[\s>|*\-+\d.]*$", prefix):
                flag(n, m.start()); flag(n, m.end()-2)
        if line.count("**") % 2 == 1:
            nxt_n = n + 1
            nxt = lines.get(nxt_n)
            if nxt is not None and "**" in nxt and not (is_th or heading):
                j = line.rfind("**")
                prefix = line[:j]
                if re.search(r"[A-Za-z0-9,)][\s]*$", prefix) and not re.match(r"^[\s>|*\-+\d.]*$", prefix):
                    flag(n, j); flag(nxt_n, nxt.find("**"))
    if not dele:
        break
    for n, idxs in dele.items():
        l = raw[n-1]
        for i in sorted(idxs, reverse=True):
            assert l[i:i+2] == "**", (n, i, repr(l))
            l = l[:i] + l[i+2:]
            changed += 1
        raw[n-1] = l
    open(path, "w", encoding="utf-8").write("\n".join(raw))
    print(f"iter {it}: removed {changed} markers on {len(dele)} lines")
else:
    print("WARNING: did not converge")
