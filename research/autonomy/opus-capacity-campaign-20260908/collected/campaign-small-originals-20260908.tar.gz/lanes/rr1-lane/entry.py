ENTRY = '''    # ⭐ THE ATR PANEL ASK, REGISTERED <DATE>. Endpoint `PUB-ATR-PANEL-ASK` in
    # systems/graph/publications.json names this file as its `document.file` and NOTHING BUILT IT,
    # so `publish_bar` clause 8 (`deliverable_is_buildable`) reads FAIL for it: the manuscript
    # exists and no artifact a submit act needs could ever be produced. Registering it here is the
    # renderer decision only — it does not post, submit or authorise anything, and BLK-NO-WET-LAB
    # still blocks the endpoint.
    # ⚠ NO TABLES AND NO REFERENCES COMPANION: this paper carries its numbered reference list
    # inline under `## 8. References` and sets its five tables in the running text, exactly like
    # `vaccine-path`. `references: None` means "this paper has none", and
    # `test_every_reference_entry_survives` reads the list out of the manuscript instead.
    # ⚠ `figures` IS EMPTY AND THAT IS NOT AN OVERSIGHT. `split_figures` inlines an SVG from
    # `figures/` against a legend in a `## Figure legends` section; this manuscript has no such
    # section and embeds its one figure inline as a raster image beside its legend in §3.4.
    # Declaring it here would raise `anchor not found: '## Figure legends'`.
    "atr-panel-ask": {
        "manuscript": "dependency/emc-atr-collaborator-package.md",
        "references": None,
        "tables": None,
        "stamp_sources": (
            "dependency/emc-atr-collaborator-package.md",
            "figures/emc-atr-figure-provenance.json",
        ),
        "figures": {},
        "journal": {
            "article_type": "Original Research Article",
            "section": "",
            # ⛔ EVIDENCE-ACCURATE, AND IT IS NOT THE GRAPH'S SENTENCE. The frozen endpoint
            # record still describes an experimental proposal whose remaining cost is "the bench
            # time and nothing else". What this file IS is a sequence-analysis report with a
            # pre-specified prediction set: no experiment was performed, no reagent was made, and
            # the manuscript states its own missing sources and unverified constructs. The banner
            # prints on page one of every build, so it says only what the repository can stand
            # behind — where the paper is (nowhere), and what it did not do.
            "preprint_note": "Not posted as a preprint and not submitted to or accepted by a "
                             "journal. A sequence-analysis report with a pre-specified prediction "
                             "set: no experiment was performed and no reagent was made.",
        },
        "out": "dependency/emc-atr-collaborator-package.pdf",
    },
'''
