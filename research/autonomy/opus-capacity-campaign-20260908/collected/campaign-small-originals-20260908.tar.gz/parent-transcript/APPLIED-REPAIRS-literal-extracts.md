# Literal parent transcript extracts — applied repairs (ATR, MF1, PR2)
Exported verbatim from the parent session JSONL: tool_use input and tool_result content as recorded,
with original tool_use ids, record uuids and timestamps. ⛔ Not a re-run, paraphrase or reconstruction.
Source: `/root/.claude/projects/-home-user-Rare-cancers/8ecd0f49-96ba-5dcf-b11a-af5e48bdec71.jsonl`

## ATR-01-U1-sequence-derivation

- tool_use id: `toolu_01UPU5KYsrrfjWtfdA5GGUZE`
- tool_use timestamp: `2026-09-08T14:11:26.231Z`
- record uuid: `bca64874-fda8-4334-92d9-5cd42917105b`
- tool_result timestamp: `2026-09-08T14:11:28.962Z`
- tool_result uuid: `c3f5a6c2-1ef2-427c-8b19-8fe9ce88bc05`
- is_error: `False`

### command, verbatim

```
python3 - <<'PY'
import json
s=json.load(open('research/modalities/fet-sequences-cache.json'))['TAF15']
first=[i for i in range(len(s)-1) if s[i]=='R' and s[i+1]=='G']
print("first complete RG at 1-based residues:", [(i+1,i+2) for i in first[:3]])
for L in (161,174,175,176):
    n=sum(1 for i in range(L-1) if s[i]=='R' and s[i+1]=='G')
    print(f"prefix 1-{L}: complete RG count = {n}")
print("residues 173-178:", s[172:178])
PY
```

### result, verbatim

```
first complete RG at 1-based residues: [(175, 176), (185, 186), (187, 188)]
prefix 1-161: complete RG count = 0
prefix 1-174: complete RG count = 0
prefix 1-175: complete RG count = 0
prefix 1-176: complete RG count = 1
residues 173-178: DNRGYG
```

## ATR-02-apply-U1-U4-E1-E2

- tool_use id: `toolu_01NNPkceutvZRZuS8c8dPjZp`
- tool_use timestamp: `2026-09-08T14:13:47.421Z`
- record uuid: `c74b2246-b078-46b5-b7ff-b97e66f61242`
- tool_result timestamp: `2026-09-08T14:13:49.971Z`
- tool_result uuid: `de5c5006-94e6-4ef5-8f77-172c62246836`
- is_error: `False`

### command, verbatim

```
python3 - <<'PY'
p='research/manuscripts/dependency/emc-atr-collaborator-package.md'
s=open(p,encoding='utf-8').read()
def rep(old,new):
    global s
    assert s.count(old)==1,(s.count(old),old[:70])
    s=s.replace(old,new)

rep("""TAF15's sourced exon 6 junction retains 161 residues
and TAF15's first RG dipeptide falls at residue 175, so the junction lies inside the strict zero-RG
window with 13 residues of margin, where the earlier sweep could report only a range of 100 to 170.
Margin is the RG-free ceiling (174, the largest retained length carrying no RG
dipeptide) minus the retained length (161), the convention the census uses; the distance to the
first RG position is one greater.""",
"""TAF15's sourced exon 6 junction retains 161 residues
and TAF15's first complete RG dipeptide occupies residues 175 and 176, so the junction lies inside
the strict zero-RG window with **14 residues of headroom**, where the earlier sweep could report only
a range of 100 to 170. The largest prefix of TAF15 carrying no complete RG dipeptide is **175**
residues -- a prefix of 175 contains none, a prefix of 176 contains one -- so the headroom is 175
minus 161.

A stored field disagrees, and the disagreement is a label rather than a measurement. The artifact
carries 174 and 13. 174 is a conservative boundary: it ends one residue before the arginine that
starts the first RG, so a prefix of that length cannot contain even the beginning of one. It is not
the largest zero-complete-RG prefix, and 13 is not the complete-dipeptide headroom, although the
field is labelled as though both were. The stored values and their history are left exactly as they
are, and this paragraph is the current reading; a reader can reproduce the discrepancy by counting
RG dipeptides in prefixes of 174, 175 and 176 residues of the cached TAF15 sequence.""")

rep("""*The margin convention in P3.* P3's registered basis states 14 residues of margin to TAF15's first RG
at residue 175. Two conventions are in use and they differ by one. The census convention, used in
section 3.4, is the RG-free ceiling (174, the largest retained length carrying no RG dipeptide) minus
the retained length (161), which gives 13. The distance from the retained length to the first RG
position (175 minus 161) is 14. Both describe the same junction and the same sequence; section 3.4
states the census convention explicitly and P3 is left as registered.""",
"""*The margin figure in P3.* P3's registered basis states 14 residues of margin to TAF15's first RG at
residue 175, and that is the correct complete-dipeptide headroom: the largest prefix with no complete
RG is 175 residues, the retained length is 161, and 175 minus 161 is 14. This was previously described
here as one of two conventions differing by one, the other giving 13. That description was wrong. 13
is not a second convention; it is the artifact's conservative 174-residue boundary, which stops before
the arginine that opens the first RG and is labelled as though it were the largest RG-free prefix.
Section 3.4 records the discrepancy and how to reproduce it. P3's registered wording is unchanged, as
is every stored artifact byte.""")

rep("""| EWSR1::NR4A3 type 2 | EWSR1 e7 to NR4A3 e2 | counted once in the two series that typed EWSR1 subtypes: 1 of the 15 fusion-positive cases [9], and absent from the counted types of [7] | [4,6] |""",
"""| EWSR1::NR4A3 type 2 | EWSR1 e7 to NR4A3 e2 | 1 of 15 fusion-positive cases in Okamoto [9]; the retrieved Panagopoulos abstract [7] does not state a type-2 count | [4,6] |""")

rep("""P5 is the arm capable of falsifying the class argument. Four outcomes are distinguishable. TCF12::NR4A3
not recruited while EWSR1::NR4A3 is recruited leaves the prediction standing and demonstrates FET
specificity within one disease, which no experiment in reference 1 performs. Both recruited places
the driver in something the two chimeras share that is not the FET low-complexity region, the
obvious candidate being the NR4A3 moiety, which is why GFP-NR4A3 alone is a required control in the
same run; that outcome refutes the class argument for EMC and the structural mechanism as stated.
TCF12::NR4A3 recruited while EWSR1::NR4A3 is not inverts the structural argument. Neither recruited
indicates that EMC does not inherit the lesion by this readout, a negative result that would spare
other groups the experiment.""",
"""P5 is the arm capable of falsifying the class argument, and what these patterns can carry is narrower
than an earlier version of this section claimed. The predictions specify an ordering and a
non-recruitment, and an ordering alone cannot assign a unique cause. Type 1 and type 2 differ in
retained residues and junction segments other than RG content, so a kinetic difference between them is
not attributable to RG dose by this design; and a partner-alone control shows what the partner does on
its own, not that the other moiety is necessary. Four outcomes are distinguishable, and each is stated
as what it is consistent with rather than what it demonstrates.

TCF12::NR4A3 not recruited while EWSR1::NR4A3 is recruited leaves P5 standing. It is consistent with a
FET-specific requirement and does not establish one, because the two chimeras differ in more than the
presence of a FET N-terminus. Both recruited contradicts P5's exclusive prediction; it does not show
that FET-mediated recruitment is absent in the EWSR1 chimera, since a shared phenotype is not evidence
of a shared cause, and it does not by itself locate the driver in the NR4A3 moiety. GFP-NR4A3 alone is
run in the same experiment because NR4A3's own behaviour is a fact worth having, not because
recruitment of NR4A3 alone would remove the FET attribution. TCF12::NR4A3 recruited while EWSR1::NR4A3
is not is inconsistent with the ordering the structural argument predicts. Neither recruited indicates
that EMC does not inherit the lesion by this readout, a negative result that would spare other groups
the experiment.

P5 is untested until a TCF12::NR4A3 construct exists. No such construct is emitted, for the reason in
section 3.1, and full-length GFP-TCF12 does not substitute for one: it is a partner-alone control and
it cannot test a prediction about a fusion.""")

rep("""No TCF12::NR4A3 construct is emitted, for the reason in section 3.1. A laboratory holding a
TCF12::NR4A3 case should sequence the junction; failing that, the arm runs with full-length
GFP-TCF12, which tests the same question the control exists for, whether a non-FET N-terminus
reaches a double-strand break at all.""",
"""No TCF12::NR4A3 construct is emitted, for the reason in section 3.1. A laboratory holding a
TCF12::NR4A3 case should sequence the junction. Without one, P5 cannot be run. Full-length GFP-TCF12
answers a different and narrower question, whether a non-FET N-terminus reaches a double-strand break
at all, and it is a partner-alone control rather than a stand-in for the fusion. A result from
GFP-TCF12 leaves P5 untested.""")

rep("""| GFP-NR4A3, full length | partner-alone control, the EMC analogue of reference 1's GFP-FLI1 control | no accumulation. Recruitment of NR4A3 alone would remove the attribution of the fusion's recruitment to the FET moiety |
| GFP-TCF12, full length | partner-alone anchor for the P5 arm | no accumulation, TCF12 being non-FET by section 3.5 |""",
"""| GFP-NR4A3, full length | partner-alone control, the EMC analogue of reference 1's GFP-FLI1 control | no accumulation. Recruitment of NR4A3 alone would show that the partner reaches breaks on its own; it would not by itself remove a FET contribution in the fusion, which a partner-alone control cannot isolate |
| GFP-TCF12, full length | partner-alone control for a non-FET N-terminus | no accumulation, TCF12 being non-FET by section 3.5. It is not a TCF12::NR4A3 construct and does not test P5, which stays untested without one |""")

rep("""The reported EMC junctions are compiled from primary sources, translated at transcript rather than""",
"""The reported EMC junctions are compiled from published sources, including primary reports and reviews
(reference 4 is a review), translated at transcript rather than""")
rep("""This report supplies those three things. It compiles the reported EMC junctions from primary
sources,""","""This report supplies those three things. It compiles the reported EMC junctions from published
sources, primary reports and reviews alike,""")
rep("""  Compile the reported NR4A3-fusion junctions of extraskeletal myxoid chondrosarcoma from primary
  sources,""","""  Compile the reported NR4A3-fusion junctions of extraskeletal myxoid chondrosarcoma from published
  sources,""")

rep("""**Supplementary Table S1.** Reference gene models, from the UniProt and Ensembl records retrieved into the input cache [8].

| gene | transcript | protein | transcript / coding exons | Ensembl matches UniProt |
|---|---|---|---|---|
| EWSR1 | ENST00000397938 | 656 aa | 17 / 17 | yes |
| TAF15 | canonical | 592 aa | 16 / 16 | yes |
| FUS | canonical | 526 aa | 15 / 15 | yes |
| NR4A3 | ENST00000395097 | 626 aa | 8 / 6, exons 1-2 non-coding | yes |
| TCF12 | canonical | 706 aa | 21 / 19 | no; UniProt Q99081 is 682 aa |""",
"""**Supplementary Table S1.** Reference gene models, from the UniProt and Ensembl records retrieved into
the input cache [8]. Transcript accessions are the ones the cache holds; the cache records its
retrieval as 2026-08-12. No assembly, release or version suffix is given, because none is recorded.

| gene | transcript | protein | transcript / coding exons | Ensembl matches UniProt |
|---|---|---|---|---|
| EWSR1 | ENST00000397938 | 656 aa | 17 / 17 | yes |
| TAF15 | ENST00000605844 | 592 aa | 16 / 16 | yes |
| FUS | ENST00000254108 | 526 aa | 15 / 15 | yes |
| NR4A3 | ENST00000395097 | 626 aa | 8 / 6, exons 1-2 non-coding | yes |
| TCF12 | ENST00000333725 | 706 aa | 21 / 19 | no; UniProt Q99081 is 682 aa |""")
open(p,'w',encoding='utf-8').write(s)
print('manuscript ok')

c='research/manuscripts/dependency/emc-atr-collaborator-package-cover-letter.md'
t=open(c,encoding='utf-8').read()
old="""Type 1 is
the commonest EWSR1::NR4A3 type in both series that typed EWSR1 subtypes, and type 2 is counted once
in those series."""
assert t.count(old)==1
t=t.replace(old,"""Type 1 is
the commonest EWSR1::NR4A3 type in both series that typed EWSR1 subtypes. Type 2 is 1 of 15
fusion-positive cases in Okamoto [9]; the retrieved Panagopoulos abstract [7] does not state a type-2
count, so no count across the two series is available.""")
open(c,'w',encoding='utf-8').write(t)
print('cover ok')
PY
```

### result, verbatim

```
manuscript ok
cover ok
```

## MF-01-apply-first-batch

- tool_use id: `toolu_011NedS4epwzXMjxKbiZ8bXZ`
- tool_use timestamp: `2026-09-08T14:02:29.291Z`
- record uuid: `cebdce15-2bc0-4a0f-9d32-bc73245233fb`
- tool_result timestamp: `2026-09-08T14:02:31.241Z`
- tool_result uuid: `e6c555a4-054a-4444-bc56-215ae8804b81`
- is_error: `False`

### command, verbatim

```
python3 - <<'PY'
p='research/manuscripts/methods-record/degrader-methods-failure-record.md'
s=open(p,encoding='utf-8').read()
def rep(old,new):
    global s
    assert s.count(old)==1,(s.count(old),old[:60])
    s=s.replace(old,new)

# E5 · B5 line: historical, and say only what the registry actually says
rep("""| what blocks it | **nothing scientific.** `systems_check.py --check` emits `[B5] RT-METHODS-PAPER is ready and its endpoint PUB-METHODS is unwritten — nothing blocks this paper except writing it` |""",
"""| what blocks it | **the route's registered inherited-blockers list is empty.** ⚠ That is all the registry says, and it is not a finding that the science is ready: `RT-METHODS-PAPER.readiness.missing` still names one item (§10.3 item 1). The `[B5] RT-METHODS-PAPER …` line this row used to quote is **historical** — `systems_check.py --check` no longer emits a B5 for this route, and the six it does emit name other routes |""")

# E1 · §1: align the fourth-candidate statement with the register's own V4 row
rep("""None of the three succeeded, no fourth is staged, and
the direct consequence""",
"""None of the three succeeded. ⚠ A fourth known-answer test
for this axis, `V4`, **is** built and staged — but it carries no result key, was never completed and is not
authorised, so it grades nothing and leaves the claim ceiling exactly where the three failures put it. The
direct consequence""")

# E2 · §4.2: same alignment
rep("""detection**, and **no fourth candidate is staged**. That, and not the preregistered null, is why every""",
"""detection**. The fourth candidate, `V4`, is **built and staged with no result** — never completed, not
authorised (§5.1) — which is a different state from "not staged" and changes the claim ceiling by nothing.
That, and not the preregistered null, is why every""")

# E3a · §1 four/sixteen scoped to this paper's cited instruments
rep("""Of the instruments this program used, four recovered their known answer within a stated scope and sixteen are
carried as **disclosed failing**""",
"""Of the **twenty instruments this paper cites** — the `support` and `disclosed_failing` lists of
`RT-METHODS-PAPER.instruments`, which is not the whole of the program's instrument register — four recovered
their known answer within a stated scope and sixteen are carried as **disclosed failing**""")

# E3b · §5.1 the same scope
rep("""partitions the instruments this paper cites into two lists, and **the partition is the paper's headline
table**: **four** are cited as `support`""",
"""partitions the instruments this paper cites into two lists, and **the partition is the paper's headline
table**. ⚠ Its denominator is **the twenty instruments this route cites**, not every instrument the program
has ever held: **four** are cited as `support`""")

# E4a · §3(c): drop the unsupported field-wide premise from current prose
rep("""**(c) The field's negative-methods record is thin.** ⚠ **This is the one premise in the paper that this
repository cannot currently support with a measurement or a citation, and it is stated as a position rather
than a finding.** It is the program's standing view (CLAUDE.md §5: *"a definitional closure is a publishable
negative, and the field publishes almost none of them"*) and it is the stated rationale in
[`systems/graph/routes.json`](../../../systems/graph/routes.json) → `RT-METHODS-PAPER.rationale`. **Before
submission it needs either a cited bibliometric source or removal**; carried in
[§10.2](#102--the-one-premise-this-repository-cannot-support-today) so it cannot be forgotten. The argument
does not fall over without it — the audit stands on (a) and (b) — but the sentence must not be asserted as if
it had been measured.""",
"""**(c) The failures themselves are the transferable content.** Each of the four outcome classes in §4 carries
a mechanism another group can act on without repeating the run: a wrong-sign cooperativity calibrator, an
adequately-powered endpoint-MD null, a covalency-confounded retrospective, a scoring margin refuted by its own
within-repo false-positive rate, and a benchmark whose *unbound* protocol supplied information its label
implied it withheld. That is the contribution, and it stands on what this program measured.

⚠ **What this paper does NOT assert is any claim about how often the field publishes negatives.** The earlier
framing rested on the clause *"the field publishes almost none of them"*, which this repository cannot support
with a measurement or a citation. It is **historical**: it survives in
[`CLAUDE-history.md`](../../../CLAUDE-history.md) as a superseded standing view, and is quoted there rather
than asserted here. No bibliometric survey was run, and none is proposed; nothing in the argument depends on
one.""")

# E4b · §10.2 becomes a dated correction record rather than an open to-do
rep("""### 10.2 · The one premise this repository cannot support today

The sentence *"the field publishes almost none of them"* ([§3](#3--why-this-is-a-paper-and-not-a-lab-notebook)(c))
is a position, not a measurement. **Before submission it needs a cited bibliometric source or it comes out.**
Nothing else in the paper depends on it.""",
"""### 10.2 · The unsupported premise, removed 2026-09-08

The sentence *"the field publishes almost none of them"* was carried in §3(c) as a position rather than a
measurement, pending a cited bibliometric source. ⭐ **2026-09-08: it came out** — of this paper's prose and of
its endpoint's `what_it_would_claim` field — rather than being kept open indefinitely against a survey nobody
was going to run. The clause is preserved as a superseded standing view in
[`CLAUDE-history.md`](../../../CLAUDE-history.md), labelled historical there; it is not asserted anywhere in
the current text. Nothing else in the paper depended on it, and §3(c) now rests the contribution on the
documented method failures themselves.""")
open(p,'w',encoding='utf-8').write(s)
print('md ok')
PY
```

### result, verbatim

```
md ok
```

## MF-02-complete-batch-and-quote-check

- tool_use id: `toolu_01EAgNatKGQhmUcGV92JZ8Hw`
- tool_use timestamp: `2026-09-08T14:24:21.179Z`
- record uuid: `c47ebbf3-0ca2-49a4-bb5f-c9500b1f1769`
- tool_result timestamp: `2026-09-08T14:24:28.885Z`
- tool_result uuid: `3b9317a2-20bf-4c0d-92da-c4ead0157183`
- is_error: `False`

### command, verbatim

```
python3 - <<'PY'
p='research/manuscripts/methods-record/degrader-methods-failure-record.md'
s=open(p,encoding='utf-8').read()
def rep(old,new):
    global s
    assert s.count(old)==1,(s.count(old),old[:70])
    s=s.replace(old,new)

rep("""the register's own word, which covers three materially different outcomes
that the paper's central methodological argument is written to separate.""",
"""the register's own word, which covers four materially different outcomes
that the paper's central methodological argument is written to separate (§5.1).""")

rep("""One home: [`pose-second-method.json`](../../modalities/pose-second-method.json).""",
"""⚠ **And the known-answer half of that comparator did not produce a grade, which is a different fact from
not having been attempted.** The census records `n_pairs_attempted: 12` with `n_gradeable: 0`, and its own
summary sentence reads "NOTHING — the arm did not run." The fields beneath that sentence are more specific
than it is: 2 pairs were excluded by a pre-registered rule and 6 carry an unrun status, which leaves the
remainder attempted without reaching a grade, for the named cause — a protocol file the run could not read.
⛔ **A zero gradeable out of twelve attempted is therefore not by itself evidence that the arm was never
attempted**, and this paper does not report it as one. Nothing was re-run to establish that; the attempt and
execution status above are read from the retained record as it stands.

Two homes: [`pose-second-method.json`](../../modalities/pose-second-method.json) and
[`pose-conditionality-census.json`](../../modalities/pose-conditionality-census.json).""")

rep("""| **no control EXISTS** | `V9` (a self-check, not a known answer), `V14`, `V16`, `V22` | nothing has ever graded it, which is a hole and not a failure |""",
"""| **no control EXISTS** | `V9` (a self-check, not a known answer), `V14`, `V16`, `V22` | nothing has ever graded it, which is a hole and not a failure. ⛔ These carry `known_answer_control.state: "none"` — the artifact's NULL tier — which is not the same record as `state: "fails"`. A null says no verdict exists; a failure says a verdict exists and is negative. Summing the two would inflate the failure count, and separating them is what this taxonomy is for |""")

rep("""> its selectivity claims its methods were able to support and which they were not — and the disclosed failures
> are the transferable result.""",
"""> its selectivity claims its methods were able to support and which they were not — and the disclosed failures,
> each with its diagnosed mechanism, are the transferable result.""")

rep("""The `[B5] RT-METHODS-PAPER …` line this row used to quote is **historical** — `systems_check.py --check` no longer emits a B5 for this route, and the six it does emit name other routes |""",
"""This row used to quote a `[B5]` line from `systems_check.py --check`; that line is **historical**. B5 fires for a route whose endpoint is unwritten, so it reports a document's existence rather than a scientific blocker, and it stops firing once the endpoint is written — which is what happened here |""")
open(p,'w',encoding='utf-8').write(s)
print('ok')
PY
python3 research/manuscripts/lint_style.py 2>&1|tail -1; python3 research/manuscripts/lint_consistency.py 2>&1|tail -1; diff <(python3 -c "
import json;d=json.load(open('systems/graph/publications.json'))
def w(o):
  if isinstance(o,dict):
    if o.get('id')=='PUB-METHODS': print(o['what_it_would_claim'])
    for v in o.values(): w(v)
  elif isinstance(o,list):
    [w(v) for v in o]
w(d)") /dev/stdin <<'EOF'
A computation-only program can state, with its instruments' known-answer controls attached, exactly which of its selectivity claims its methods were able to support and which they were not — and the disclosed failures, each with its diagnosed mechanism, are the transferable result.
EOF
echo "QUOTE MATCH EXIT=$?"
```

### result, verbatim

```
ok
lint_style: 0 ERROR across 15 file(s)
lint_consistency: 0 ERROR across 29 target file(s)
QUOTE MATCH EXIT=0
```

## MF-03-repair-two-misapplications

- tool_use id: `toolu_01YQv8VqqJRNDABuhjidQP7d`
- tool_use timestamp: `2026-09-08T14:50:39.346Z`
- record uuid: `43d01deb-04b9-42c9-b764-059e1e8cc72a`
- tool_result timestamp: `2026-09-08T14:50:42.167Z`
- tool_result uuid: `3222589b-9233-463a-b8dd-a8c581de60b5`
- is_error: `False`

### command, verbatim

```
python3 - <<'PY'
p='research/manuscripts/methods-record/degrader-methods-failure-record.md'
s=open(p,encoding='utf-8').read()
def rep(old,new):
    global s
    assert s.count(old)==1,(s.count(old),old[:70])
    s=s.replace(old,new)

# 1 · remove the false NULL-tier equivalence from the taxonomy row
rep("""| **no control EXISTS** | `V9` (a self-check, not a known answer), `V14`, `V16`, `V22` | nothing has ever graded it, which is a hole and not a failure. ⛔ These carry `known_answer_control.state: "none"` — the artifact's NULL tier — which is not the same record as `state: "fails"`. A null says no verdict exists; a failure says a verdict exists and is negative. Summing the two would inflate the failure count, and separating them is what this taxonomy is for |""",
"""| **no control EXISTS** | `V9` (a self-check, not a known answer), `V14`, `V16`, `V22` | nothing has ever graded it, which is a hole and not a failure |""")

# 1b · put the real NULL-vs-failed-calibration distinction where it belongs, at §4.3
rep("""### 4.3 · What the SMARCA2/4 null does not license

Three bindings, all preregistered, all reproduced here because a methods paper that reports a null without
its limits is doing the thing this paper criticises:""",
"""### 4.3 · What the SMARCA2/4 null does not license

⛔ **First, what the word NULL is doing here, because it invites exactly the wrong reading.**
[`selcal-verdict.json`](../../modalities/selcal-verdict.json) records `tier: "NULL"` with
*p* = 0.746753 and `technical_failures` of **0** in both arms. That label describes the **statistical
result**: the instrument ran, nothing broke, and it did not separate the two paralogues. ⛔ **That is a
FAILED CALIBRATION, not an absent one** — the known-answer control did not recover a known difference,
and `V11`'s control state in the register is `fails`, not `none`. A NULL tier is not an absent control
and not an absent verdict; it is a verdict, and the verdict is negative. Reading it as "no result" would
quietly move this instrument into the no-control-exists row of §5.1, where it does not belong.

Three bindings, all preregistered, all reproduced here because a methods paper that reports a null without
its limits is doing the thing this paper criticises:""")

# 2 · replace the remainder arithmetic with the recorded dispositions
rep("""⚠ **And the known-answer half of that comparator did not produce a grade, which is a different fact from
not having been attempted.** The census records `n_pairs_attempted: 12` with `n_gradeable: 0`, and its own
summary sentence reads "NOTHING — the arm did not run." The fields beneath that sentence are more specific
than it is: 2 pairs were excluded by a pre-registered rule and 6 carry an unrun status, which leaves the
remainder attempted without reaching a grade, for the named cause — a protocol file the run could not read.
⛔ **A zero gradeable out of twelve attempted is therefore not by itself evidence that the arm was never
attempted**, and this paper does not report it as one. Nothing was re-run to establish that; the attempt and
execution status above are read from the retained record as it stands.""",
"""⚠ **And the known-answer half of that comparator produced ZERO GRADEABLE PAIRS.** The panel lists twelve
apo/holo pairs, and ⛔ **twelve listed pairs are not twelve completed docking runs** — every one of them
carries a recorded disposition short of a grade, and they are four different dispositions, not one:

| n | disposition, as recorded |
|---:|---|
| 2 | excluded by the pre-registered rule **R2b** — the holo ligand is covalently linked (5Y41, 5YD6), and a non-covalent dock cannot reproduce a covalent pose |
| 6 | `second_method._status: "UNRUN — rDock's dock.prm is not readable"` |
| 1 | **fetch** refusal, 1RXR→9QX6 — HTTP 404, no legacy PDB-format file is served for that entry, which the record itself flags as a file-format bias toward older entries rather than a scientific result |
| 3 | **alignment** refusals — 1RXR→6LB4, 1DSZ→9GFE, 1DSZ→3KMR |

⛔ **The unreadable-`dock.prm` cause belongs to the six UNRUN entries and to no others.** The remaining four
did not fail for that reason, and an earlier version of this paragraph said they did. A zero gradeable is
therefore not evidence that the arm was never attempted, and it is equally not evidence that twelve docking
runs were performed and came back empty. Nothing was re-run to establish any of this; the dispositions above
are read from the retained record as it stands.""")

# 3 · section 6 title and both anchors: assessed, not graded
rep("""## 6 · The 2026-08-03 sweep — three instruments assembled and graded in one day""",
"""## 6 · The 2026-08-03 sweep — three instruments assembled and assessed in one day""")
s=s.replace("#6--the-2026-08-03-sweep--three-instruments-assembled-and-graded-in-one-day",
            "#6--the-2026-08-03-sweep--three-instruments-assembled-and-assessed-in-one-day")
open(p,'w',encoding='utf-8').write(s)
print('ok')
PY
grep -c "assembled-and-assessed-in-one-day" research/manuscripts/methods-record/degrader-methods-failure-record.md; grep -c "assembled-and-graded-in-one-day" research/manuscripts/methods-record/degrader-methods-failure-record.md
```

### result, verbatim

```
ok
2
0
```

## PR2-01-apply-patch-and-producer-run

- tool_use id: `toolu_01HM1H9qqBbuiYjR86yFbo63`
- tool_use timestamp: `2026-09-08T13:55:43.255Z`
- record uuid: `db9a7c65-2997-49be-bda2-bb82f8fda166`
- tool_result timestamp: `2026-09-08T13:55:45.014Z`
- tool_result uuid: `28dfb77f-3493-470f-962e-c092766b9b20`
- is_error: `False`

### command, verbatim

```
cp /tmp/claude-0/pr2-lane/repo/research/manuscripts/emc_fusion_partner_pooling.py research/manuscripts/emc_fusion_partner_pooling.py && cp /tmp/claude-0/pr2-lane/repo/research/manuscripts/tests/test_fusion_partner_prose_matches_its_artifact.py research/manuscripts/tests/test_fusion_partner_prose_matches_its_artifact.py && python3 research/manuscripts/emc_fusion_partner_pooling.py; echo "PRODUCER EXIT=$?"
```

### result, verbatim

```
wrote /home/user/Rare-cancers/research/manuscripts/fusion-partner/emc-fusion-partner-pooling.json

== A_tki_objective_response
{
 "question": "Does the NR4A3 5' fusion partner predict objective response to an antiangiogenic TKI in advanced EMC?",
 "endpoint": "RECIST objective response (partial or complete) on sunitinib or pazopanib",
 "cohorts_identified": 3,
 "cohorts_pooled_primary": 1,
 "cohorts_excluded": {
  "sunitinib-2014": "population-overlap (POLICY-evidence.md s2.3) -- cannot be shown distinct from the pazopanib trial",
  "sunitinib-2012-two-cases": "population-overlap (POLICY-evidence.md s2.3) -- contained in the 2014 series"
 },
 "primary_non_overlapping": {
  "definition": "POLICY-conformant headline: only cohorts that can be shown non-overlapping. Overlap with the sunitinib series cannot be excluded, so the smaller series is held out and the pazopanib trial stands alone.",
  "contrast": {
   "id": "tki_response_pazopanib_only",
   "taf15_arm": {
    "events": 0,
    "denom": 3,
    "proportion": 0.0,
    "percent": 0.0,
    "ci95_lo_percent": 0.0,
    "ci95_hi_percent": 56.1,
    "interval": "Wilson score, 95%"
   },
   "comparator_arm": {
    "events": 4,
    "denom": 19,
    "proportion": 0.2105,
    "percent": 21.1,
    "ci95_lo_percent": 8.5,
    "ci95_hi_percent": 43.3,
    "interval": "Wilson score, 95%"
   },
   "comparator_minus_taf15_percentage_points": 21.1,
   "fisher_exact_two_sided_p": 1.0,
   "fisher_note": "POST-HOC DESCRIPTIVE ONLY. Not prespecified, not performed in any source report, not corrected for the multiple endpoints on this page, and not used to license any claim.",
   "note": "Single-cohort intervals; no between-study weighting is involved."
  }
 },
 "secondary_assume_independent": {
  "definition": "Maximal-information analysis, valid ONLY if no patient appears in both reports. Crude denominator-weighted pool of both cohorts (POLICY-evidence.md s2.2).",
  "contrast": {
   "id": "tki_response_both_cohorts",
   "taf15_arm": {
    "events": 0,
    "denom": 5,
    "proportion": 0.0,
    "percent": 0.0,
    "ci95_lo_percent": 0.0,
    "ci95_hi_percent": 43.4,
    "interval": "Wilson score, 95%"
   },
   "comparator_arm": {
    "events": 10,
    "denom": 27,
    "proportion": 0.3704,
    "percent": 37.0,
    "ci95_lo_percent": 21.5,
    "ci95_hi_percent": 55.8,
    "interval": "Wilson score, 95%"
   },
   "comparator_minus_taf15_percentage_points": 37.0,
   "fisher_exact_two_sided_p": 0.155,
   "fisher_note": "POST-HOC DESCRIPTIVE ONLY. Not presp

== B_outcome_by_partner
{
 "question": "Does the NR4A3 5' fusion partner predict disease-specific death, recurrence or metastasis?",
 "what_changed_2026_08_08": "\u2b50 A MAGNITUDE IS COMPUTABLE FOR THE FIRST TIME. Until 2026-08-08 exactly one cohort (Agaram 2014, 23 of its 24 partner-assigned patients carried an EWSR1 or TAF15 partner, and the source records no follow-up count for them) published EMC outcome event counts by NR4A3 partner, so the 'pool' was a single-cohort Wilson interval and the file said so. A human read Huang 2023's published PDF and extracted its Table 1, adding 50 EWSR1- or TAF15-assigned patients with follow-up -- 50 of the 53 followed, which are themselves 53 of the 58 in the series, the other 3 followed cases being 2 TCF12 and 1 unidentified partner -- from an independent country and institution set. The outcome pool is now 73 patients across two non-overlapping cohorts. \u26a0 THIS IS THE PROGNOSIS QUESTION AND ONLY THE PROGNOSIS QUESTION -- see `does_not_touch_the_response_question` below.",
 "does_not_touch_the_response_question": "\u26d4 HUANG 2023 CONTAINS NO ANTIANGIOGENIC-TKI RESPONSE DATA AND MOVES ANALYSIS A BY ZERO. It is a pathology series with a survival analysis; the only systemic therapy it reports is chemotherapy, as a prognostic covariate, not as a response endpoint and not by partner. The TREATMENT-RESPONSE half of this page is still what it was: the entire published TAF15::NR4A3 antiangiogenic experience is 3 to 5 patients with ZERO responses, and a zero-event arm yields no magnitude at any denominator. A_tki_objective_response is unchanged, word for word, by this integration. Anyone reading the new prognostic magnitude as if it settled the response question has conflated two different endpoints in two different populations.",
 "cohorts_identified": 4,
 "cohorts_pooled": 2,
 "pooled_cohorts": [
  "agaram-2014-outcome",
  "huang-2023-outcome"
 ],
 "cohorts_excluded": {
  "suemitsu-2025-outcome": "population-overlap-unresolved (POLICY-evidence.md s2.1/s2.3) -- see cohorts[suemitsu-2025-outcome].context_note",
  "paioli-2021-outcome": "counts-not-reported (POLICY-evidence.md s2.1/s2.3) -- see cohorts[paioli-2021-outcome].context_note"
 },
 "non_overlap_argument": "MSKCC (New York, 26 consecutive cases) versus 15 Taiwanese institutions led from Chang Gung Memorial Hospital (58 FISH-confirmed cases). No shared authors, no shared referral networ

== C_partner_prevalence
{
 "question": "How many EMC patients would a TAF15-vs-EWSR1 stratification actually touch?",
 "denominator_convention": "Partner-assigned cases only. Each cohort's NR4A3-rearranged-but-partner-unassigned residue is recorded in its `not_partner_assigned` field and excluded from both numerator and denominator, because the series do not report that residue comparably.",
 "cohorts_pooled": [
  "agaram-2014-prevalence",
  "huang-2023-prevalence",
  "lenz-2023-prevalence",
  "paioli-2021-prevalence"
 ],
 "partner_assigned_per_cohort": {
  "agaram-2014-prevalence": 24,
  "huang-2023-prevalence": 57,
  "lenz-2023-prevalence": 11,
  "paioli-2021-prevalence": 62
 },
 "cohorts_excluded": {
  "llombart-bosch-2022-prevalence": "abstract-only",
  "klubickova-2022-prevalence": "population-overlap with lenz-2023-prevalence",
  "sjogren-2003-prevalence": "outcome-is-the-inclusion-criterion (s2.1(3)): four of its nine patients are in the series because the same group had already published their fusion transcript, so their partner assignment is the entry ticket and its partner-unassigned residue of zero is structural on that half of the cohort"
 },
 "non_overlap_argument": "Four geographically and institutionally distinct series -- MSKCC (USA), Taiwanese institutions, Czech Republic, Italian Sarcoma Group -- with no shared authors between them and no shared referral network.",
 "\u26a0_a_fifth_series_EXISTS_and_is_refused_on_a_DIFFERENT_ground": "sjogren-2003-prevalence is not held out for overlap or for being an abstract -- it is a peer-reviewed, fully-accounted, karyotyped series and it would have PASSED s2.1(1), (2) at patient level and (4). It fails s2.1(3) alone. That distinction is recorded because the three exclusions are otherwise easy to read as one kind of objection, and this one is the kind that a wider denominator makes tempting: it would have RAISED the coverage ceiling computed in research/manuscripts/aso_coverage_ladder.py, not lowered it.",
 "pooled": {
  "EWSR1::NR4A3": {
   "events": 120,
   "denom": 154,
   "proportion": 0.7792,
   "percent": 77.9,
   "ci95_lo_percent": 70.7,
   "ci95_hi_percent": 83.7,
   "interval": "Wilson score, 95%"
  },
  "TAF15::NR4A3": {
   "events": 28,
   "denom": 154,
   "proportion": 0.1818,
   "percent": 18.2,
   "ci95_lo_percent": 12.9,
   "ci95_hi_percent": 25.0,
   "interval": "Wilson score, 95%"
  },
  "TCF12::NR4A3": {
   
PRODUCER EXIT=0
```

## PR2-02-leaf-equality-check-and-tests

- tool_use id: `toolu_0114RQ1RuHCEGNF9pnjbrhaq`
- tool_use timestamp: `2026-09-08T13:55:52.326Z`
- record uuid: `32d5eb52-907a-4f1a-8e75-b9a0e4e25d9c`
- tool_result timestamp: `2026-09-08T13:55:54.831Z`
- tool_result uuid: `0f07f2fc-44d6-42dc-9060-3ebb260d4a25`
- is_error: `False`

### command, verbatim

```
python3 - <<'PY'
import json
def leaves(o,p="$",out=None):
    if out is None: out={}
    if isinstance(o,dict):
        for k,v in o.items(): leaves(v,f"{p}.{k}",out)
    elif isinstance(o,list):
        for i,v in enumerate(o): leaves(v,f"{p}[{i}]",out)
    else: out[p]=o
    return out
b=leaves(json.load(open('/tmp/claude-0/fp-before.json')))
a=leaves(json.load(open('research/manuscripts/fusion-partner/emc-fusion-partner-pooling.json')))
print("leaves",len(b),len(a))
print("only-before",[k for k in b if k not in a])
print("only-after",[k for k in a if k not in b])
diff=[k for k in b if k in a and b[k]!=a[k]]
nonstr=[k for k in diff if not (isinstance(b[k],str) and isinstance(a[k],str))]
print("changed",len(diff),"non-string changed",nonstr)
for k in diff: print("  CHANGED:",k)
PY
echo "=== check ==="; python3 research/manuscripts/emc_fusion_partner_pooling.py --check; echo "CHECK EXIT=$?"
echo "=== tests ==="; /root/.local/bin/pytest research/manuscripts/tests/test_fusion_partner_prose_matches_its_artifact.py research/manuscripts/tests/test_emc_fusion_partner_pooling_check.py -q 2>&1 | tail -5; echo "PYTEST EXIT=${PIPESTATUS[0]}"
```

### result, verbatim

```
leaves 1142 1142
only-before []
only-after []
changed 4 non-string changed []
  CHANGED: $._generated_utc
  CHANGED: $.cohorts[4].counts_read_from
  CHANGED: $.analyses.B_outcome_by_partner.what_changed_2026_08_08
  CHANGED: $.analyses.B_outcome_by_partner.verdict
=== check ===
emc_fusion_partner_pooling --check: OK (committed artifact reproduces from the generator's counts)
CHECK EXIT=0
=== tests ===
  /home/user/Rare-cancers/research/manuscripts/tests/test_fusion_partner_prose_matches_its_artifact.py:2: DeprecationWarning: invalid escape sequence '\d'
    """Every number the FUSION-PARTNER manuscript prints, tied to the artifact field that computes it.

-- Docs: https://docs.pytest.org/en/stable/how-to/capture-warnings.html
146 passed, 1 warning in 0.61s
PYTEST EXIT=0
```

## PR2-03-label-fix-and-regeneration

- tool_use id: `toolu_01Pj5ax9BJfQrGc9ch2JFBke`
- tool_use timestamp: `2026-09-08T14:05:14.461Z`
- record uuid: `f8550fcf-5be8-4712-8346-2e1961231dcc`
- tool_result timestamp: `2026-09-08T14:05:16.882Z`
- tool_result uuid: `ddb4176d-db65-453e-aaf0-ac515d0e88df`
- is_error: `False`

### command, verbatim

```
python3 - <<'PY'
p='research/manuscripts/emc_fusion_partner_pooling.py'
s=open(p,encoding='utf-8').read()
def rep(old,new):
    global s
    assert s.count(old)==1,(s.count(old),old[:70])
    s=s.replace(old,new)
rep("""            "series; the remaining 3 followed cases are the miscellaneous group -- 2 TCF12, 1 "
            "partner unidentified -- which is partner-assigned but which the paper does not carry "
            "as an outcome arm and which is therefore in neither numerator nor denominator here)."
""",
"""            "series; the remaining 3 followed cases are two TCF12-ASSIGNED cases and one case "
            "whose partner is UNIDENTIFIED -- note the unidentified case is not partner-assigned "
            "at all -- and all three are excluded from the EWSR1 and TAF15 outcome arms, so they "
            "are in neither numerator nor denominator here)."
""")
rep("""        "PMID 36948401: 50 EWSR1- or TAF15-assigned patients with follow-up (42 EWSR1 + 8 "
        "TAF15); the remaining 3 of the 53 followed are the miscellaneous group (2 TCF12, 1 "
        "partner unidentified), which is partner-assigned but carried by no outcome arm"
""",
"""        "PMID 36948401: 50 EWSR1- or TAF15-assigned patients with follow-up (42 EWSR1 + 8 "
        "TAF15); the remaining 3 of the 53 followed are two TCF12-assigned cases and one case "
        "with an unidentified partner -- the unidentified case is not partner-assigned -- and "
        "all three are carried by no outcome arm"
""")
open(p,'w',encoding='utf-8').write(s)
print('ok')
PY
cp research/manuscripts/fusion-partner/emc-fusion-partner-pooling.json /tmp/claude-0/fp-before2.json
python3 research/manuscripts/emc_fusion_partner_pooling.py >/tmp/claude-0/fp-run2.log 2>&1; echo "PRODUCER EXIT=$?"; head -1 /tmp/claude-0/fp-run2.log
```

### result, verbatim

```
ok
PRODUCER EXIT=0
wrote /home/user/Rare-cancers/research/manuscripts/fusion-partner/emc-fusion-partner-pooling.json
```

## PR2-04-scope-clarifications

- tool_use id: `toolu_01TWwq9jHB3nSSjC77xbBsQZ`
- tool_use timestamp: `2026-09-08T14:15:22.051Z`
- record uuid: `33b2d1dc-43d1-454d-af33-896fb5a99dd2`
- tool_result timestamp: `2026-09-08T14:15:24.758Z`
- tool_result uuid: `8ed37e6d-1d95-4efe-9581-d00352862966`
- is_error: `False`

### command, verbatim

```
python3 - <<'PY'
p='research/manuscripts/emc_fusion_partner_pooling.py'
s=open(p,encoding='utf-8').read()
def rep(old,new):
    global s
    assert s.count(old)==1,(s.count(old),old[:70])
    s=s.replace(old,new)
# non-overlap is argued, not patient-verified
rep("""            "country and institution set. The outcome pool is now {tot} patients across two "
            "non-overlapping cohorts. ⚠ THIS IS THE PROGNOSIS QUESTION AND ONLY THE PROGNOSIS " """.rstrip()+"\n",
"""            "country and institution set. The outcome pool is now {tot} patients across two "
            "cohorts whose non-overlap is ARGUED from the reported authors, institutions and "
            "geography and is NOT patient-verified. ⚠ THIS IS THE PROGNOSIS QUESTION AND ONLY THE PROGNOSIS "\n""")
# Agaram follow-up absence scoped to the retained extraction
rep("""            "(Agaram 2014, {ag} of its {agp} partner-assigned patients carried an EWSR1 or TAF15 "
            "partner, and the source records no follow-up count for them) published EMC outcome " """.rstrip()+"\n",
"""            "(Agaram 2014, {ag} of its {agp} partner-assigned patients carried an EWSR1 or TAF15 "
            "partner; the retained extraction for that cohort carries no separate follow-up-count "
            "field, which is a gap in what was extracted here and not a finding about what the "
            "primary publication reports) published EMC outcome "\n""")
rep("""            "TWO cohorts, {n} patients assigned to EWSR1::NR4A3 or TAF15::NR4A3 -- Agaram "
            "2014's {agn} of {agp} partner-assigned, for which the source records no follow-up "
            "count, plus Huang 2023's {hun} of the {huf} followed -- from two continents with no "
            "shared authors. Pooled disease-specific death is " """.rstrip()+"\n",
"""            "TWO cohorts, {n} patients assigned to EWSR1::NR4A3 or TAF15::NR4A3 -- Agaram "
            "2014's {agn} of {agp} partner-assigned, for which the retained extraction carries no "
            "separate follow-up-count field, plus Huang 2023's {hun} of the {huf} followed -- from "
            "two continents with no shared authors, a non-overlap ARGUED from those reported "
            "author, institution and geography records rather than verified patient by patient. "
            "Pooled disease-specific death is "\n""")
# and the helper docstring that asserts the same
rep("""        Agaram 2014 it is NOT "with follow-up" either: that cohort records no follow-up count,
        and `cohorts[agaram-2014-outcome]` carries no `n_with_followup` field to state one.""",
"""        Agaram 2014 it is NOT "with follow-up" either: `cohorts[agaram-2014-outcome]` carries no
        `n_with_followup` field, so this extraction holds no follow-up count for that cohort. That
        is a gap in the retained extraction, not a claim about what the primary publication reports.""")
open(p,'w',encoding='utf-8').write(s)
print('ok')
PY
```

### result, verbatim

```
ok
```

## PR2-05-regenerate-and-verify-equality

- tool_use id: `toolu_014j1H3b3wGaxLo7JRjKcMjk`
- tool_use timestamp: `2026-09-08T14:15:32.167Z`
- record uuid: `b1c0c53a-4f86-4287-8e46-35498f83fc3b`
- tool_result timestamp: `2026-09-08T14:15:36.467Z`
- tool_result uuid: `cfad0358-2e0c-4329-9a4a-f63d1130d77c`
- is_error: `False`

### command, verbatim

```
cp research/manuscripts/fusion-partner/emc-fusion-partner-pooling.json /tmp/claude-0/fp-before3.json
python3 research/manuscripts/emc_fusion_partner_pooling.py >/tmp/claude-0/fp-run3.log 2>&1; echo "PRODUCER EXIT=$?"
python3 - <<'PY'
import json
def leaves(o,p="$",out=None):
    if out is None: out={}
    if isinstance(o,dict):
        for k,v in o.items(): leaves(v,f"{p}.{k}",out)
    elif isinstance(o,list):
        for i,v in enumerate(o): leaves(v,f"{p}[{i}]",out)
    else: out[p]=o
    return out
b=leaves(json.load(open('/tmp/claude-0/fp-before3.json')))
a=leaves(json.load(open('research/manuscripts/fusion-partner/emc-fusion-partner-pooling.json')))
print("leaves",len(b),len(a))
nums=[k for k in b if isinstance(b[k],(int,float)) and not isinstance(b[k],bool)]
bools=[k for k in b if isinstance(b[k],bool)]
print("numeric leaves",len(nums),"all equal:",all(b[k]==a[k] for k in nums))
print("boolean leaves",len(bools),"all equal:",all(b[k]==a[k] for k in bools))
d=[k for k in b if b[k]!=a[k]]; print("changed:",d)
PY
python3 research/manuscripts/emc_fusion_partner_pooling.py --check; echo "CHECK=$?"
/root/.local/bin/pytest research/manuscripts/tests/test_fusion_partner_prose_matches_its_artifact.py research/manuscripts/tests/test_emc_fusion_partner_pooling_check.py -q 2>&1|tail -1
```

### result, verbatim

```
PRODUCER EXIT=0
leaves 1142 1142
numeric leaves 521 all equal: True
boolean leaves 52 all equal: True
changed: ['$._generated_utc', '$.analyses.B_outcome_by_partner.what_changed_2026_08_08', '$.analyses.B_outcome_by_partner.verdict']
emc_fusion_partner_pooling --check: OK (committed artifact reproduces from the generator's counts)
CHECK=0
146 passed in 0.60s
```
