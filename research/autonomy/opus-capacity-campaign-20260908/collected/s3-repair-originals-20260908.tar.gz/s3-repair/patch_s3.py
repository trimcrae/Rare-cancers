import io
p = "/tmp/claude-0/b2-lane/sandbox/base/research/manuscripts/build_submission_pdf.py"
s = io.open(p, encoding="utf-8").read()
orig = s

# --- 1. module global, beside _TABLES_IN_COLUMN -------------------------------------------
a1 = "_TABLES_IN_COLUMN = False\n"
assert s.count(a1) == 1
s = s.replace(a1, a1 + '''#: ⛔ OPT-IN PER PAPER, AND THE DEFAULT IS THE OLD BEHAVIOUR. Caption prefixes whose spliced table
#: must span both journal columns instead of sitting in one. A paper names them in
#: `layout: {"full_width_tables": (...)}`; an empty tuple is every other paper and changes nothing.
#: ⚠ SET UNCONDITIONALLY AT THE TOP OF `assemble`, never only on the branch that needs it: a module
#: global that one style leaves behind is read by the NEXT paper built in the same process, and the
#: gate builds every paper in one run.
_FULL_WIDTH_TABLE_CAPTIONS = ()
''', 1)

# --- 2. reset + set in assemble, before the style branch ------------------------------------
a2 = '''def assemble(paper, style="journal"):
    """Return (markdown, prerendered_floats). In manuscript style the float map is empty."""
    body = strip_frontmatter(read(paper["manuscript"]))'''
assert s.count(a2) == 1
s = s.replace(a2, '''def assemble(paper, style="journal"):
    """Return (markdown, prerendered_floats). In manuscript style the float map is empty."""
    global _FULL_WIDTH_TABLE_CAPTIONS
    _FULL_WIDTH_TABLE_CAPTIONS = tuple((paper.get("layout") or {}).get("full_width_tables") or ())
    body = strip_frontmatter(read(paper["manuscript"]))''', 1)

# --- 3. the caption lookup helper, beside _label_for_spliced_table ---------------------------
a3 = '''def markdown_to_html(text, floats=None):'''
assert s.count(a3) == 1
s = s.replace(a3, '''def _table_spans_both_columns(lines, table_start):
    """True when the caption directly above this spliced table is one the paper declared wide.

    ⛔ WHY THIS EXISTS. Supplementary Table S3 is five columns of long verbatim cells, and five is
    under `LANDSCAPE_MIN_COLS`, so `render_table`'s `wide_body` rule never fired for it. It set at
    full body width inside an 88 mm journal column and its fourth data column, TAF15_NR4A3, ran off
    the right edge of the page: `TAF15:`, `ENST0`, `UNRES` printed truncated at the paper's edge
    (blind screen of the built PDF, page 6, 2026-09-08). Column COUNT is the wrong predicate for it
    — the table is wide because of what its cells CONTAIN, which no count can see — so the paper
    names the caption instead.
    ⚠ MATCHED ON THE CAPTION, NOT ON A COUNT OR AN INDEX, so "Supplementary Table S3." and
    "Supplementary Table S3, continued." are both caught by the one declared prefix and stay
    together at the same width. A renumbering that renames the caption stops matching and the table
    goes back to the column — visibly, in the next build, rather than silently.
    """
    if not _FULL_WIDTH_TABLE_CAPTIONS:
        return False
    for k in range(table_start - 1, max(-1, table_start - 40), -1):
        line = lines[k].strip()
        if not line:
            continue
        if line.startswith("**"):
            caption = line[2:]
            return any(caption.startswith(prefix) for prefix in _FULL_WIDTH_TABLE_CAPTIONS)
        if line.startswith(("#", "|", "<figure", "<svg")):
            return False
    return False


def markdown_to_html(text, floats=None):''', 1)

# --- 4. the emitter --------------------------------------------------------------------------
a4 = '''        if stripped.startswith("|") and i + 1 < len(lines) and re.match(
                r"^\\|[\\s:|-]+\\|?\\s*$", lines[i + 1].strip()):
            rows = []'''
assert s.count(a4) == 1
s = s.replace(a4, '''        if stripped.startswith("|") and i + 1 < len(lines) and re.match(
                r"^\\|[\\s:|-]+\\|?\\s*$", lines[i + 1].strip()):
            table_start = i
            rows = []''', 1)

a5 = '''            label = _CURRENT_TABLE_LABEL or _label_for_spliced_table(lines, i, rows)
            out.append('<div class="tablewrap">'
                       + render_table(rows, label) + "</div>")
            continue'''
assert s.count(a5) == 1
s = s.replace(a5, '''            label = _CURRENT_TABLE_LABEL or _label_for_spliced_table(lines, i, rows)
            #: ⚠ THE CLASS RIDES ON THE WRAPPER, NOT ON THE <table>, and the type size is NOT
            #: touched. `.wide-body-table` spans AND shrinks to 6.4 pt; this table is already the
            #: smallest type in the paper and the whole point of the repair is that a reader can
            #: read it. Width is the only thing that changes.
            klass = ("tablewrap fullwidth" if _table_spans_both_columns(lines, table_start)
                     else "tablewrap")
            out.append(f'<div class="{klass}">'
                       + render_table(rows, label) + "</div>")
            continue''', 1)

# --- 5. the per-paper stylesheet -------------------------------------------------------------
a6 = '''#: ⭐ NUCLEIC ACID THERAPEUTICS SUBMISSION FORMAT, AS AN OPT-IN OVERLAY (2026-08-25).\n'''
assert s.count(a6) == 1
s = s.replace(a6, '''#: ⭐ THE SAME MECHANISM THE RASTER FIGURE AND `.wide-body-table` ALREADY USE, and deliberately
#: not a new one: `column-span: all` on the wrapper, which this stylesheet is known to survive.
#: ⛔ NO FONT-SIZE RULE HERE, AND THAT IS THE POINT. `.wide-body-table` spans and drops to 6.4 pt;
#: applying it to Supplementary Table S3 would have traded a clipped column for an unreadable one,
#: in the same build where a figure was just widened BECAUSE its type was too small. The table
#: keeps the 6.6 pt `.col-float table`/body size it already had and is given room instead.
#: ⛔ AND `.backmatter` IS IN THE SELECTOR BECAUSE `.cols` ALONE DID NOTHING — measured, not
#: predicted. The first version of this rule matched `.cols .tablewrap.fullwidth`; the class was
#: emitted on exactly the two intended tables, the stylesheet shipped, the PDF bytes changed, and
#: page 6 rendered PIXEL-IDENTICAL to the clipped build (sha256 of the 400 dpi page raster equal
#: before and after). Section 9 sits in `<div class="backmatter">`, which is a SECOND multicol
#: container, so the spanner has to name that container to have anything to span.
#: ⚠ Appended only for a paper that declared `layout: {"full_width_tables": (...)}`, so no other
#: registered paper's bytes move — asserted by
#: `test_a_paper_without_inline_images_renders_byte_identically` over the whole registry.
FULL_WIDTH_TABLE_CSS = """
.cols .tablewrap.fullwidth, .backmatter .tablewrap.fullwidth {
    column-span: all; break-inside: avoid; margin: 2mm 0 3mm 0; }
.cols .tablewrap.fullwidth table, .backmatter .tablewrap.fullwidth table { width: 100%; }
"""


#: ⭐ NUCLEIC ACID THERAPEUTICS SUBMISSION FORMAT, AS AN OPT-IN OVERLAY (2026-08-25).\n''', 1)

# --- 6. journal_css hook ---------------------------------------------------------------------
a7 = '''    raster = ""
    if (paper or {}).get("inline_images"):'''
assert s.count(a7) == 1
s = s.replace(a7, '''    raster = ""
    if ((paper or {}).get("layout") or {}).get("full_width_tables"):
        raster += FULL_WIDTH_TABLE_CSS
    if (paper or {}).get("inline_images"):''', 1)
a8 = '''        raster = RASTER_IMAGE_CSS + ('''
assert s.count(a8) == 1
s = s.replace(a8, '''        raster += RASTER_IMAGE_CSS + (''', 1)

# --- 7. the PAPERS entry ----------------------------------------------------------------------
a9 = '''        "layout": {"raster_full_width": True},'''
assert s.count(a9) == 1
s = s.replace(a9, '''        # ⛔ AND SUPPLEMENTARY TABLE S3 SPANS BOTH COLUMNS FOR THE SAME REASON, MEASURED IN THE
        # BUILT PDF (page 6, 2026-09-08): five columns is under LANDSCAPE_MIN_COLS so nothing
        # widened it, and its TAF15_NR4A3 column printed off the right edge of the page —
        # `TAF15:`, `ENST0`, `UNRES` truncated at the paper's edge. The prefix catches the
        # "continued" half too, so the two parts stay at one width. No cell, caption or type size
        # changes; only the measure the table is given.
        "layout": {"raster_full_width": True,
                   "full_width_tables": ("Supplementary Table S3",)},''', 1)

assert s != orig
io.open(p, "w", encoding="utf-8").write(s)
print("patched, delta bytes:", len(s) - len(orig))
