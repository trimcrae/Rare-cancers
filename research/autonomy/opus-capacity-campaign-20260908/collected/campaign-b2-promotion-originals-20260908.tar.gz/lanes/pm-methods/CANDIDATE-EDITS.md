# PM-METHODS candidate — degrader-methods-failure-record.md
Base blob 3816edfaeabbc6a7ae406836ad0828b6ecd10a8c (identical at 143d7f3f and 41fc23b9).
BEFORE.md sha256 88816ae06c0c8aaf4e9799dfc2f867a280e7d05a65f157fedff25ffdb9fa31f5 (51060 B)
AFTER.md  sha256 5678f6cd5fee39fa942b041a0fb31f6a946352f4dd473c854604ff2b55c1d1de (51143 B)
Two cross-reference repairs. No scientific content, no quantity, no hedge, no marker changed.

## E1 — §3(c): the pointer misdirects the reader (defect introduced today in c7a1d468)
old:
**(c) The failures themselves are the transferable content.** Each of the four outcome classes in §4 carries
a mechanism another group can act on without repeating the run: a wrong-sign cooperativity calibrator, an
adequately-powered endpoint-MD null, a covalency-confounded retrospective, a scoring margin refuted by its own
within-repo false-positive rate, and a benchmark whose *unbound* protocol supplied information its label
implied it withheld. That is the contribution, and it stands on what this program measured.
new:
**(c) The failures themselves are the transferable content.** Each carries a mechanism another group can act
on without repeating the run: a wrong-sign cooperativity calibrator, an adequately-powered endpoint-MD null
and a covalency-confounded retrospective ([§4](#4---the-spine--four-outcomes-that-are-routinely-summed-into-one)),
a scoring margin refuted by its own within-repo false-positive rate, and a benchmark whose *unbound* protocol
supplied information its label implied it withheld ([§7.1](#71--what-it-can-do)). That is the
contribution, and it stands on what this program measured.

WHY: the sentence lists FIVE mechanisms and attributes all five to "the four outcome classes in §4".
Only the first three are §4 rows 1-3. The fourth is §7.1 item 2 (decoy false-positive rate) and the
fifth is §7.1 item 5 (the unbound-protocol benchmark). A reader who follows the pointer does not find
them. The five items and their wording are untouched; only the pointer changes.
NOTE the word "four" here was a MISCOUNT of a cross-reference, not a settled quantity. Every settled
"four" is untouched and verified present: abstract L62 (disclosed_failing covers four outcomes),
§4 heading L139 + L143, §5.1 L253/L256, §6 L293/L323.
ALTERNATIVE if the parent prefers to keep the count word: "Each of §4's outcome classes carries a
mechanism ..., as do two of §7.1's items: ...". E1 as written is the shorter repair.

## E2 — §9 figure bill: §8 has numbered items, not subsections
old: | §4 row 1, §7.2, §8.2 |
new: | §4 row 1, §7.2, §8 item 2 |

old: | §4.3 item 2, §8.5 |
new: | §4.3 item 2, §8 item 5 |

WHY: §8 is a flat numbered list; there is no §8.2 or §8.5 to turn to. The same table already writes
"§8 item 4", "§8 item 1" and "§8 item 6" correctly, so these two are the outliers. Targets unchanged.

## FLAGGED, NOT CHANGED (parent's call; I did not touch either)
F1. Front matter reads `date: 2026-08-06` / `last_verified: 2026-08-06`, but §10.2 carries a dated
    2026-09-08 correction and §9 says "Every path was verified to exist on this branch on 2026-08-06".
    Bumping `last_verified` would assert a verification I did not perform, so I left it. (I did verify
    all 38 relative link targets still exist today — see report — but that is not the whole of what
    `last_verified` claims.)
F2. §7.1 item 4 ends "Pushing unrelated close paralogue pairs through the identical pipeline makes a
    zero gradeable." It is terse and it collides with the term of art in
    categorical-decoy-null.json, where "graded"/"gradeability" is a property of a DECOY ROW, not of a
    zero. The artifact's own reading is "converts 'the categorical gate fired' into 'the categorical
    gate fired, against a measured background'". Defensible as written, so I did not rewrite it
    rather than risk restating the science.
