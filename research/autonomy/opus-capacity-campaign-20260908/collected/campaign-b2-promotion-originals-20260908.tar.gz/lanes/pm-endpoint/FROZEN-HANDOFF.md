# PM-ENDPOINT — FROZEN HANDOFF
Worker: PM-ENDPOINT. Verdict: ALREADY COHERENT. Zero edits proposed.
Start 2026-09-08T15:24:06Z / End 2026-09-08T15:26:11Z. HEAD 143d7f3f6195c959e67f12a60cb5d8f1a6d46e03 at both ends.
Target sha256 bae48dbd23966cc247d428448ea81116fef7aeabf718e5f2da74103014f30408 (53719 bytes), unchanged start to end.
Manifest: frozen-manifest.txt. Lint output: lint_consistency.txt.

## What the package claims
- 552 arms / 138 trials with a complete four-cell table; median DCR-ORR gap 39.4 pp (IQR 20.0-54.3).
- 251 of 552 arms (45.5%) return zero objective responses, tracking the binomial at 7.7%.
- 44 conditions placed on two measured axes; 16 at or below the 5% null; design-boundary share bounded 31.8%-73.9%.
- Reporting census: 2,715 of 2,851 (95.2%) trials naming best overall response omit the four categories.
- EMC worked extreme (§8, three cohorts): 12.8 / 89.4 / 76.6 on the REPORTED nominal 47; 46-denominator
  fixed-event sensitivity 13.0 / 91.3 / 78.3, a 1.7-point shift, printed and distinguished.

## What it does not claim
- No efficacy, safety, selectivity, potency, dose or clinical readiness for any agent; no treatment recommendation.
- No causal reading of any endpoint difference; no natural-history reading from any corpus arm.
- §8 conservatism holds ONLY under the specified fixed-event denominator sensitivity, "not a general bound".
- The missing EMC classification is not imputed and not identified with any patient.
- IMMUNOSARC II is conference-abstract evidence in the retained record; no claim that no full paper exists.
- Zero-event-boundary finding is WITHDRAWN (interval 0.0%-47.8% spans zero); named common-cancer list withdrawn.

## Checks RUN (this session, read-only)
- lint_style.py on target: clean, "0 ERROR across 1 file(s)", exit 0.
- lint_consistency.py (repo-wide, 29 target files): "0 ERROR", exit 0; no line names this manuscript.
- lint_claims.py on target: "0 ERROR, 2 WARN", exit 0. Both WARNs are R4-confirms on (a) the editorial
  authorship comment line 39 and (b) "central molecular confirmation" in settled §8. Neither is an error;
  both sit in text I am forbidden to touch.
- pytest test_endpoint_manuscript_figures.py: 7 passed, exit 0.
- pytest test_endpoint_logic.py + test_the_census_reads_every_publication_endpoint.py
  + test_the_endpoint_reference_list_binds_to_what_was_fetched.py: 85 passed, exit 0.
- Link resolution: all 19 relative links in the manuscript resolve on disk (0 missing).
- Package coherence: all 7 producers named in §2.4 exist; their order matches the dependency order in
  scripts/regenerate_endpoint_chain.sh exactly; all 7 appear in .github/workflows/tests.yml lines 204-210,
  so "All seven run in continuous integration" is accurate.
- §8 values checked against emc-endpoint-discordance.json D1: 47/12.8/89.4/76.6 and
  sensitivity_immunosarc2_denominator_22 = 46/13.0/91.3/78.3/1.7. Prose matches storage exactly.

## Checks NOT run (deliberately)
- No producer run, no --check, no regenerate_endpoint_chain.sh, no scripts/preflight.sh (forbidden by brief).
- test_endpoint_producers_check.py NOT run (it exercises producer --check paths).
- No network, no rebuild of figures or artifacts, no git write.

## Reopening condition
Reopen ONLY if (a) a producer re-run changes any stored value this manuscript quotes, (b) a source is
retracted or a citation identifier fails lint_citations.py, or (c) the parent decides the editorial
HTML comment block (lines 44-56, "EDITORIAL, NOT FOR SUBMISSION") must be stripped before deposit —
that is a submission-packaging act, not a coherence defect, and is the parent's call.
