import io
p = "/tmp/claude-0/b2-lane/sandbox/base/research/manuscripts/build_submission_pdf.py"
s = io.open(p, encoding="utf-8").read()
anchor = '''        "out": "neoantigen/emc-vaccine-development-path.pdf",
    },
'''
assert s.count(anchor) == 1
ENTRY = '''    # ⭐ THE ATR PANEL ASK, REGISTERED 2026-09-08. Endpoint `PUB-ATR-PANEL-ASK` in
    # systems/graph/publications.json names this file as its `document.file` and NOTHING BUILT IT,
    # so `publish_bar` clause 8 (`deliverable_is_buildable`) reads FAIL for it: the manuscript
    # exists and no artifact a submit act needs could ever be produced. Registering it here is the
    # renderer decision only — it does not post, submit or authorise anything, and BLK-NO-WET-LAB
    # still blocks the endpoint.
    # ⚠ NO TABLES AND NO REFERENCES COMPANION: this paper carries its numbered reference list
    # inline under `## 8. References` and sets its five tables in the running text, exactly like
    # `vaccine-path`. `references: None` means "this paper has none", and
    # `test_every_reference_entry_survives` reads the list out of the manuscript instead.
    # ⚠ `figures` IS EMPTY AND THAT IS NOT AN OVERSIGHT. `split_figures` inlines an SVG from
    # `figures/` against a legend in a `## Figure legends` section; this manuscript has no such
    # section and embeds its one figure inline as a raster image beside its legend in §3.4.
    # Declaring it here would raise `anchor not found: '## Figure legends'`. The raster is handled
    # by `inline_images` below instead, which is a different mechanism with a different guarantee:
    # `figures` gives live vector text, `inline_images` gives an embedded picture.
    "atr-panel-ask": {
        "manuscript": "dependency/emc-atr-collaborator-package.md",
        "references": None,
        "tables": None,
        # ⛔ THE FIGURE IS STAMPED THROUGH `stamp_sources`, NOT THROUGH `figures`. `_write_build_stamp`
        # hashes `paper["figures"]` values and this entry's is empty, so without the PNG named here
        # the PDF would be stamped current against a list that omits the one artifact it renders —
        # the exact hole the round-15 figure-staleness finding closed for the ASO paper.
        "stamp_sources": (
            "dependency/emc-atr-collaborator-package.md",
            "figures/emc-atr-figure-provenance.json",
            "figures/emc-fusion-frame-fig1.png",
        ),
        "figures": {},
        # ⭐ OPT-IN. Without this key the manuscript's `![Figure 1. …](../figures/…png)` renders as
        # a stray `!` and a hyperlink to a file that does not travel with the deposit (measured
        # 2026-09-08, `IMG_TAGS: 0`). No other paper sets it and no other paper changes by one byte.
        "inline_images": True,
        "journal": {
            # ⭐ THE TYPE THE MANUSCRIPT ITSELF DECLARES, not a house default: its editorial VENUE
            # block reads "Genes, Chromosomes and Cancer (Wiley), Research Article, with the
            # preprint on bioRxiv". ⚠ That block also records that the journal's own author
            # guidelines returned HTTP 403 from CI, so the type name is the manuscript's declared
            # target and NOT a verified reading of the venue's article-type list.
            "article_type": "Research Article",
            "section": "",
            # ⛔ EVIDENCE-ACCURATE, AND IT IS NOT THE GRAPH'S SENTENCE. The frozen endpoint
            # record still describes an experimental proposal whose remaining cost is "the bench
            # time and nothing else". What this file IS is a sequence-analysis report with a
            # pre-specified prediction set: no experiment was performed, no reagent was made, and
            # the manuscript states its own missing sources and unverified constructs. The banner
            # prints on page one of every build, so it says only what the repository can stand
            # behind — where the paper is (nowhere), and what it did not do.
            "preprint_note": "Not posted as a preprint and not submitted to or accepted by a "
                             "journal. A sequence-analysis report with a pre-specified prediction "
                             "set: no experiment was performed and no reagent was made.",
        },
        "out": "dependency/emc-atr-collaborator-package.pdf",
    },
'''
s = s.replace(anchor, anchor + ENTRY, 1)
io.open(p, "w", encoding="utf-8").write(s)
print("PAPERS entry added")
