import sys, zlib, struct
def readpng(p):
    d=open(p,"rb").read(); i=8; idat=b""
    while i<len(d):
        ln=struct.unpack(">I",d[i:i+4])[0]; t=d[i+4:i+8]; da=d[i+8:i+8+ln]
        if t==b"IHDR": W,H,bd,ct=struct.unpack(">IIBB",da[:10])
        if t==b"IDAT": idat+=da
        i+=12+ln
    raw=zlib.decompress(idat); bpp=3; stride=W*bpp
    out=[]; prev=bytearray(stride); pos=0
    for y in range(H):
        ft=raw[pos]; pos+=1; line=bytearray(raw[pos:pos+stride]); pos+=stride
        if ft==1:
            for x in range(bpp,stride): line[x]=(line[x]+line[x-bpp])&255
        elif ft==2:
            for x in range(stride): line[x]=(line[x]+prev[x])&255
        elif ft==3:
            for x in range(stride):
                a=line[x-bpp] if x>=bpp else 0; line[x]=(line[x]+((a+prev[x])>>1))&255
        elif ft==4:
            for x in range(stride):
                a=line[x-bpp] if x>=bpp else 0; b=prev[x]; c=prev[x-bpp] if x>=bpp else 0
                pp=a+b-c; pa=abs(pp-a); pb=abs(pp-b); pc=abs(pp-c)
                pr=a if (pa<=pb and pa<=pc) else (b if pb<=pc else c)
                line[x]=(line[x]+pr)&255
        out.append(bytes(line)); prev=line
    return W,H,out
def box(rows,W,x0,y0,x1,y1,thr=128):
    mnx,mxx,mny,mxy=10**9,-1,10**9,-1
    for y in range(y0,y1):
        r=rows[y]
        for x in range(x0,x1):
            if r[x*3]<thr:
                mnx=min(mnx,x);mxx=max(mxx,x);mny=min(mny,y);mxy=max(mxy,y)
    return (mnx,mny,mxx,mxy) if mxx>=0 else None
if __name__=="__main__":
    png=sys.argv[1]; dpi=float(sys.argv[2])
    W,H,rows=readpng(png); print(f"{png}: {W}x{H} px at {dpi} dpi")
    for spec in sys.argv[3:]:
        name,x0,y0,x1,y1=spec.split(",")
        b=box(rows,W,int(x0),int(y0),int(x1),int(y1))
        if not b: print(f"  {name}: NO INK in window"); continue
        hpx=b[3]-b[1]+1; hmm=hpx*25.4/dpi; hpt=hmm/25.4*72
        print(f"  {name}: ink bbox {b} -> height {hpx}px = {hmm:.3f} mm = {hpt:.2f} pt "
              f"(cap-height model: font ~ {hpt/0.729:.2f} pt)")
