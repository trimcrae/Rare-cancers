import sys, zlib, struct
def readppm(p):
    f=open(p,"rb"); assert f.readline().strip()==b"P6"
    l=f.readline()
    while l.startswith(b"#"): l=f.readline()
    w,h=[int(x) for x in l.split()]; f.readline()
    return w,h,f.read()
def writepng(path,w,h,rows):
    raw=b"".join(b"\x00"+r for r in rows)
    def chunk(t,d): 
        c=struct.pack(">I",len(d))+t+d; return c+struct.pack(">I",zlib.crc32(t+d)&0xffffffff)
    png=b"\x89PNG\r\n\x1a\n"+chunk(b"IHDR",struct.pack(">IIBBBBB",w,h,8,2,0,0,0))+chunk(b"IDAT",zlib.compress(raw,6))+chunk(b"IEND",b"")
    open(path,"wb").write(png)
def crop(src,dst,dpi,x0pt,y0pt,wpt,hpt,pageh_pt):
    W,H,d=readppm(src); s=dpi/72.0
    x=int(x0pt*s); y=int((pageh_pt-y0pt-hpt)*s); cw=int(wpt*s); ch=int(hpt*s)
    x=max(0,x); y=max(0,y); cw=min(cw,W-x); ch=min(ch,H-y)
    rows=[d[((y+j)*W+x)*3:((y+j)*W+x+cw)*3] for j in range(ch)]
    writepng(dst,cw,ch,rows); print(f"{dst}: {cw}x{ch}px from {src} ({W}x{H}) at {dpi}dpi")
if __name__=="__main__":
    a=sys.argv
    crop(a[1],a[2],float(a[3]),float(a[4]),float(a[5]),float(a[6]),float(a[7]),float(a[8]))
