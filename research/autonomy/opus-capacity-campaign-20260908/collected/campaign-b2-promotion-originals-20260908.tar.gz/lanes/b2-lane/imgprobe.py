import sys, os, hashlib, importlib.util, io, contextlib
root = sys.argv[1]  # .../research/manuscripts
sys.path.insert(0, root)
spec = importlib.util.spec_from_file_location("bspx", os.path.join(root, "build_submission_pdf.py"))
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
for key in sorted(m.PAPERS):
    paper = m.PAPERS[key]
    for style in ("journal", "manuscript"):
        buf = io.StringIO()
        try:
            with contextlib.redirect_stderr(buf), contextlib.redirect_stdout(buf):
                body, floats = m.assemble(paper, style)
                if style == "journal":
                    front = m.parse_front_matter(body)
                    page = m.wrap_journal(paper, front, m.markdown_to_html(front["body"], floats))
                else:
                    front = m.parse_front_matter(body)
                    page = m.wrap_manuscript(front["title"], m.markdown_to_html(body), "", paper)
            h = hashlib.sha256(page.encode("utf-8")).hexdigest()
            print(f"{key:22s} {style:11s} {h}  len={len(page)} img={page.count('<img')}")
        except BaseException as e:
            print(f"{key:22s} {style:11s} ERROR {type(e).__name__}: {e}")
