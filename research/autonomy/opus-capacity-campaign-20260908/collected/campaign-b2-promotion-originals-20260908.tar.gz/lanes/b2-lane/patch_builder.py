import io, re, sys
p = "/tmp/claude-0/b2-lane/sandbox/base/research/manuscripts/build_submission_pdf.py"
s = io.open(p, encoding="utf-8").read()
orig = s

HELPER = '''
#: --------------------------------------------------------------- opt-in raster images
#: ⭐ OPT-IN PER PAPER, AND THE DEFAULT IS THE OLD BEHAVIOUR. A paper sets `"inline_images": True`
#: in its PAPERS entry; every entry without the key assembles through exactly the code path it
#: assembled through before this function existed, which is asserted by
#: `test_a_paper_without_inline_images_renders_byte_identically`.
#:
#: ⛔ WHY THIS EXISTS AT ALL. `markdown_to_html`/`inline()` have NO image rule, measured 2026-09-08:
#: `![alt](file.png)` reaches the page as a stray `!` followed by a hyperlink to a file that does
#: not travel with the deposit, and `IMG_TAGS` is 0. `split_figures` cannot help — it keys off a
#: `## Figure legends` section and splices an SVG raw, and the only artifacts for the ATR figure are
#: a PNG and a PDF. So the raster is embedded here, at assembly, as a data URI: an external `src`
#: does not survive the print path (Chromium loads the HTML from a temp file elsewhere) and would
#: print as a blank box.
#:
#: ⚠ ONE LINE, AND THE `<figure>` OPENS IT. `markdown_to_html` appends a line beginning `<figure`
#: verbatim and its paragraph collector treats `<figure` as a terminator, so a self-contained
#: single-line `<figure>…</figure>` needs no new branch in the renderer and cannot be re-parsed as
#: markdown. Nothing is added to `inline()`: the stash ordering there carries two documented
#: deposit-corrupting bugs, and an image rule placed anywhere but ahead of the link rule reproduces
#: the stray-`!` reading. An image that is NOT alone on its line is therefore a hard failure below
#: rather than silent damage.
_IMAGE_LINE_RE = re.compile(r"^!\\[([^\\]]*)\\]\\(([^)\\s]+)\\)\\s*$")
_IMAGE_ANYWHERE_RE = re.compile(r"!\\[[^\\]]*\\]\\([^)\\s]+\\)")
#: Raster formats a browser prints from a data URI. SVG is deliberately absent: an SVG figure goes
#: through `split_figures`/`assemble`'s own splice, which keeps it live text.
_RASTER_MIME = {".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg"}


def inline_raster_images(body, paper):
    """Replace each standalone `![alt](path)` line with a `<figure>` carrying the file inline.

    The alt text rides into the `<img alt>`, so the figure is never a bare image: a reader whose
    viewer cannot draw it, and every text-extraction path over the PDF, still gets the caption
    sentence. The printed legend is the `**Figure N.**` paragraph the manuscript already sets
    directly under the image, and it is left exactly where it is.
    """
    if not paper.get("inline_images"):
        return body
    base = os.path.dirname(os.path.join(HERE, paper["manuscript"]))
    out, seen = [], 0
    for line in body.split("\\n"):
        match = _IMAGE_LINE_RE.match(line.strip())
        if not match:
            if _IMAGE_ANYWHERE_RE.search(line):
                raise SystemExit(
                    "inline_images: an image is embedded inside a line of prose:\\n  "
                    + line.strip()[:160]
                    + "\\nOnly an image alone on its own line is handled. `inline()` has no image "
                      "rule and adding one would have to be stashed ahead of the link rule; until "
                      "that is done deliberately this is a build failure rather than a stray '!' "
                      "and a dead link in the deposit.")
            out.append(line)
            continue
        alt, src = match.group(1), match.group(2)
        path = os.path.normpath(os.path.join(base, src))
        ext = os.path.splitext(path)[1].lower()
        if ext not in _RASTER_MIME:
            raise SystemExit(f"inline_images: {src!r} is not a raster this builder embeds "
                             f"({', '.join(sorted(_RASTER_MIME))})")
        if not os.path.exists(path):
            raise SystemExit(f"inline_images: {src!r} does not exist at {path}")
        if not alt.strip():
            raise SystemExit(f"inline_images: {src!r} has empty alt text. The alt text is the "
                             "caption the image carries into the PDF's text layer; an image "
                             "without one is a bare picture.")
        data = base64.b64encode(open(path, "rb").read()).decode("ascii")
        #: ⚠ THE FIRST IMAGE IS `lead` FOR THE SAME REASON THE FIRST SPLICED FIGURE IS: manuscript
        #: style sets `figure.figure { break-before: page }`, which would put this figure on a page
        #: of its own and strand the legend paragraph that follows it.
        klass = "figure lead" if seen == 0 else "figure"
        seen += 1
        out.append(f'<figure class="{klass}"><img class="raster" '
                   f'src="data:{_RASTER_MIME[ext]};base64,{data}" '
                   f'alt="{_html.escape(alt, quote=True)}"/></figure>')
    return "\\n".join(out)


'''

anchor = 'def assemble(paper, style="journal"):'
assert s.count(anchor) == 1
s = s.replace(anchor, HELPER.lstrip("\n") + anchor, 1)

# call site: both styles, before the style branch
call_anchor = '''    if paper.get("bracketed_citations"):
        body = _bracket_citations(body)

    if style == "manuscript":'''
assert s.count(call_anchor) == 1
s = s.replace(call_anchor, '''    if paper.get("bracketed_citations"):
        body = _bracket_citations(body)

    #: BOTH styles, and before either branch: the journal branch runs `split_figures`, which scans
    #: for a `## Figure legends` section, and the manuscript branch splices SVGs against `**Figure`
    #: anchors. Neither sees a markdown image, so this has to happen ahead of both.
    body = inline_raster_images(body, paper)

    if style == "manuscript":''', 1)

# ---- opt-in stylesheet, appended ONLY for a paper that set the flag ----
CSSCONST = '''
#: ⛔ NOT WRITTEN INTO `COMMON` OR `MANUSCRIPT_CSS`, FOR THE REASON `NAT_SUBMISSION_CSS` RECORDS
#: DIRECTLY BELOW: those sheets are shared by every paper's build, and a rule added to them changes
#: the bytes of documents nobody asked to change — including a deposited one. These rules are inert
#: for a paper with no `<img class="raster">`, and "inert" is not the same as "absent": the opt-in
#: check in `journal_css` and `wrap_manuscript` is what makes every unflagged paper render byte for
#: byte as it did before, which `test_a_paper_without_inline_images_renders_byte_identically`
#: asserts over the whole registry rather than over one pinned paper.
RASTER_IMAGE_CSS = """
/* An embedded raster never exceeds its box and never distorts; the per-style width chooses the
   printed measure, and `height: auto` keeps the aspect ratio the file was drawn at. */
figure.figure img.raster { display: block; margin: 0 auto; max-width: 100%; height: auto; }
"""

#: ⭐ 86% OF THE TEXT MEASURE, AND A PERCENTAGE RATHER THAN A LENGTH BECAUSE THE LENGTH WAS
#: MEASURED AND IT LIES. A4 at this sheet's 18 mm side margins leaves 174 mm of measure and 259 mm
#: of height; the one raster this applies to is 2220 x 2670 px. Read out of the built PDF's own
#: image CTM (2026-09-08): `width: 150mm` printed the image 106.2 mm wide and `width: 200mm`
#: printed it 141.9 mm wide — Chromium does not put a `mm` width on this replaced element at face
#: value — while `width: 100%` printed 174.15 mm starting at x = 51 pt, which is the 18 mm margin
#: exactly. So the measure is expressed as a fraction of itself, which is verifiable, and every
#: number below was READ BACK from the artifact rather than assumed.
#: 86% = 149.8 mm wide and 180.1 mm tall, so 2220 px / 5.898 in = 376 effective dpi, and the figure
#: leaves ~79 mm of the 259 mm column for the legend paragraph that must stay with it. Full measure
#: was rejected: it buys only 324 dpi and stands 209 mm tall, which leaves the legend nowhere to go.
#: ⚠ 376 dpi IS A RESOLUTION, NOT A LEGIBILITY RESULT. Whether this figure's smallest type is
#: readable at 150 mm is UNVERIFIED: it needs a rendered proof read at 100%, or the drawing
#: script's font sizes converted through this scale and checked against a minimum print type size.
#: Nothing in this stylesheet establishes it, and no number here should be quoted as if it did.
RASTER_IMAGE_CSS_MANUSCRIPT = """
figure.figure img.raster { width: 86%; }
"""

#: In two columns the measure IS the column. Read back from the built journal PDF (2026-09-08):
#: the image lands in column two of page 2 at 74.97 x 90.13 mm, which is 752 effective dpi across
#: and down — narrower than the 88 mm column because the figure box is centred inside it, and
#: that is accepted rather than forced wider: the legend paragraph sits with it on the same page.
#: ⚠ 752 dpi IS STILL NOT LEGIBILITY. 75 mm is the more demanding of the two styles to read and
#: nothing here has been read at 100%; the manuscript-style caveat above applies with more force.
RASTER_IMAGE_CSS_JOURNAL = """
.cols figure.figure img.raster { width: 100%; }
"""


'''
anchor = "#: \u2b50 NUCLEIC ACID THERAPEUTICS SUBMISSION FORMAT, AS AN OPT-IN OVERLAY (2026-08-25).\n"
assert s.count(anchor) == 1
s = s.replace(anchor, CSSCONST.lstrip("\n") + anchor, 1)

# journal_css hook
jc = '''    g = dict(DEFAULT_GEOMETRY)
    g.update((paper or {}).get("geometry") or {})
    return COMMON + f"""'''
assert s.count(jc) == 1
s = s.replace(jc, '''    g = dict(DEFAULT_GEOMETRY)
    g.update((paper or {}).get("geometry") or {})
    raster = (RASTER_IMAGE_CSS + RASTER_IMAGE_CSS_JOURNAL
              if (paper or {}).get("inline_images") else "")
    return COMMON + raster + f"""''', 1)

# wrap_manuscript hook
wm = '''    css = MANUSCRIPT_CSS
    if house_style and ((paper or {}).get("layout") or {}).get("nat_submission"):
        css = css + NAT_SUBMISSION_CSS'''
assert s.count(wm) == 1
s = s.replace(wm, '''    css = MANUSCRIPT_CSS
    if (paper or {}).get("inline_images"):
        css = css + RASTER_IMAGE_CSS + RASTER_IMAGE_CSS_MANUSCRIPT
    if house_style and ((paper or {}).get("layout") or {}).get("nat_submission"):
        css = css + NAT_SUBMISSION_CSS''', 1)

assert s != orig
io.open(p, "w", encoding="utf-8").write(s)
print("builder patched, delta bytes:", len(s) - len(orig))
