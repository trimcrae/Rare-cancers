# PM-DEG candidate — apply instructions (parent is sole integration owner)

Target: research/manuscripts/degrader/nr4a3-degrader-paper.md
Baseline sha256 (file as measured): ab9ab4481df57eeaf9e8e2840da911a7c8273181b000dee29471a89115f60607
Candidate:  /tmp/claude-0/pm-deg/paper-after.md
Candidate sha256: 148a5ea67ce8bc5061139ba51deb08a4849fb68bc29195577c588e05d0ac74cc

Apply (only if the baseline sha still matches):
  cp /tmp/claude-0/pm-deg/paper-after.md research/manuscripts/degrader/nr4a3-degrader-paper.md
or:
  patch -p0 < /tmp/claude-0/pm-deg/paper.diff

Change is WHITESPACE ONLY, confined to the Abstract (old lines 42-104).
Non-whitespace character stream of the whole file is byte-identical before/after (verified).
Seven paragraph breaks inserted immediately before these verbatim sentence starts:
  1. "A three-independent-seed metadynamics workflow"
  2. "A falsification-heavy, pocket-conditioned generative campaign"
  3. "Separately, because a useful degradation window"
  4. "**A preregistered known-answer test of the ternary machinery itself"
  5. "**A second preregistered known-answer test asks whether the endpoint readout"
  6. "The **causal test of whether any designed element creates discrimination"
  7. "This is a **computation-only** design"
Abstract rewrapped at width 108 (matches surrounding prose width).
