import re, textwrap
src = open('abstract-before.txt').read()
flat = re.sub(r'\s+', ' ', src).strip()

# Paragraph boundaries: text that must START a new paragraph. Verbatim prefixes.
starts = [
 "A three-independent-seed metadynamics workflow",
 "A falsification-heavy, pocket-conditioned generative campaign",
 "Separately, because a useful degradation window",
 "**A preregistered known-answer test of the ternary machinery itself",
 "**A second preregistered known-answer test asks whether the endpoint readout",
 "The **causal test of whether any designed element creates discrimination",
 "This is a **computation-only** design",
]
idxs = [0]
for s in starts:
    i = flat.index(s)
    assert flat.count(s) == 1, s
    idxs.append(i)
idxs.append(len(flat))
paras = [flat[idxs[k]:idxs[k+1]].strip() for k in range(len(idxs)-1)]
out = "\n\n".join(textwrap.fill(p, width=108, break_long_words=False, break_on_hyphens=False) for p in paras)
open('abstract-after.txt','w').write(out + "\n")

# verification: word streams identical
a = re.sub(r'\s+',' ',src).strip()
b = re.sub(r'\s+',' ',out).strip()
print("WORD-STREAM IDENTICAL:", a == b)
print("paragraphs:", len(paras), "words:", len(b.split()))
