"""Review computations only: never imports or executes scientific producers."""
from pathlib import Path
import json, hashlib, subprocess, statistics, math, collections, re, xml.etree.ElementTree as ET
OUT=Path(__file__).resolve().parent
PKG=Path(r'C:/Users/mcrae/.codex/review-workspaces/opus-capacity-sprint-20260907/capacity-campaign-20260908/observations/endpoint-final-review-package-20260908/package')
REPO=Path(r'C:/Projects/EMC-Research')
REV='9c6f4a80fc2fd69ee71ad6124c8de03e6e1af395'
def read(name): return json.loads((PKG/name).read_text(encoding='utf-8'))
def dump(name,obj): (OUT/name).write_text(json.dumps(obj,indent=2,ensure_ascii=True)+'\n',encoding='utf-8')
deps=['research/manuscripts/endpoint/endpoint-prior-art-inputs.json', 'research/manuscripts/endpoint/placebo-arm-detail-inputs.json','research/manuscripts/endpoint/natural-history-inputs.json']
dh=[]
for path in deps:
    b=subprocess.check_output(['git','show',REV+':'+path],cwd=REPO)
    target=OUT/'frozen-dependencies'/path; target.parent.mkdir(parents=True,exist_ok=True); target.write_bytes(b)
    dh.append(dict(repo_path=path,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
dump('additional-source-input-hashes.json',dict(revision=REV,files=dh))
c=read('endpoint-corpus.json'); arms=c['C2_arms']; r=read('orr-dcr-reread.json'); g=read('endpoint-regime-map.json')
groups=collections.defaultdict(list)
for i,a in enumerate(arms): groups[(a['nct_id'],a['arm_title'])].append((i,a))
repeats=[]
for key,vals in groups.items():
    if len(vals)>1:
        repeats.append(dict(nct=key[0],arm=key[1],rows=[dict(index=i,title=a['outcome_measure_title'],n=a['evaluable_n'],cells=a['cells']) for i,a in vals]))
dump('repeated-trial-arm-records.json',dict(total_records=len(arms),distinct_trial_arm_strings=len(groups),repeated_groups=len(repeats),excess_records=len(arms)-len(groups),groups=repeats))
ns=[a['evaluable_n'] for a in arms]
gaps=[100*a['cells']['SD']/a['evaluable_n'] for a in arms]
orr=[(a['cells']['CR']+a['cells']['PR'])/a['evaluable_n'] for a in arms]
bins=[]
for lo,hi in [(1,4),(5,9),(10,19),(20,39),(40,10**9)]:
    ix=[i for i,n in enumerate(ns) if lo<=n<=hi]
    bins.append(dict(lo=lo,hi=hi,records=len(ix),zero=sum(orr[i]==0 for i in ix),observed=100*sum(orr[i]==0 for i in ix)/len(ix),expected=100*statistics.mean((1-statistics.median(orr))**ns[i] for i in ix),median_n=statistics.median(ns[i] for i in ix)))
checks=dict(records=len(arms),trials=len(set(a['nct_id'] for a in arms)),units=dict(collections.Counter(a['unit_of_measure'] for a in arms)),four_cells_sum_stored_n=all(sum(a['cells'].values())==a['evaluable_n'] for a in arms),independent_denominator_field_present=any('reported_denominator' in a or 'denoms' in a for a in arms),
    median_gap=statistics.median(gaps),iqr_exclusive=[statistics.quantiles(gaps,n=4)[i] for i in (0,2)],
    at_least_50=sum(x>=50 for x in gaps),zero=sum(x==0 for x in orr),median_orr=statistics.median(orr),bins=bins,
    illustrative_zero_response_exact_upper_one_sided_95={str(n):1-0.05**(1/n) for n in (3,20,60)},
    known_census=dict(c['C3b_census_denominator_decomposed']),emc=read('emc-endpoint-discordance.json')['D1_same_patients_two_endpoints'])
dump('independent-arithmetic-results.json',checks)
figs=[]
for path in sorted(PKG.glob('*.svg')):
    root=ET.fromstring(path.read_bytes()); texts=[''.join(n.itertext()) for n in root.iter() if n.tag.rsplit('}',1)[-1]=='text']
    figs.append(dict(name=path.name,width=root.attrib['width'],height=root.attrib['height'],texts=texts,circle_count=sum(n.tag.endswith('circle') for n in root.iter()),path_count=sum(n.tag.endswith('path') for n in root.iter())))
dump('figure-structure-and-labels.json',figs)
print(json.dumps(dict(records=checks['records'],trials=checks['trials'],median_gap=checks['median_gap'],zero=checks['zero'],distinct_trial_arm_strings=len(groups),repeated_groups=len(repeats),excess_records=len(arms)-len(groups),additional_sources=len(dh)),ensure_ascii=True))
