"""Rasterize existing SVGs with installed Edge; no scientific regeneration."""
from pathlib import Path
import subprocess,json,hashlib
OUT=Path(__file__).resolve().parent
PKG=Path(r'C:/Users/mcrae/.codex/review-workspaces/opus-capacity-sprint-20260907/capacity-campaign-20260908/observations/endpoint-final-review-package-20260908/package')
edge=r'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe'
receipts=[]
for i,p in enumerate(sorted(PKG.glob('*.svg'))):
    target=OUT/(p.stem+'.png')
    cmd=[edge,'--headless','--disable-gpu','--no-first-run','--no-default-browser-check','--hide-scrollbars','--window-size=1000,640','--force-device-scale-factor=1','--user-data-dir='+str(OUT/'edge-render-profile'),'--screenshot='+str(target),p.as_uri()]
    r=subprocess.run(cmd,capture_output=True,timeout=30,creationflags=subprocess.CREATE_NO_WINDOW)
    (OUT/(p.stem+'-render-original.log')).write_bytes(r.stdout+b'\n'+r.stderr)
    receipts.append(dict(input=p.name,command=cmd,returncode=r.returncode,output=str(target),output_exists=target.exists(),sha256=hashlib.sha256(target.read_bytes()).hexdigest() if target.exists() else None))
(OUT/'render-receipt.json').write_text(json.dumps(receipts,indent=2)+'\n',encoding='utf-8')
print(json.dumps(receipts))
