"""Independent arithmetic/plot checks; does not run or import any project producer."""
from pathlib import Path
import json, math, statistics, collections, hashlib, subprocess, xml.etree.ElementTree as ET
OUT=Path(__file__).resolve().parent
PKG=Path(r'C:/Users/mcrae/.codex/review-workspaces/opus-capacity-sprint-20260907/capacity-campaign-20260908/observations/endpoint-final-review-package-20260908/package')
REV='9c6f4a80fc2fd69ee71ad6124c8de03e6e1af395'
def read(name):return json.loads((PKG/name).read_text(encoding='utf-8'))
def dump(name,obj):(OUT/name).write_text(json.dumps(obj,indent=2,ensure_ascii=True)+'\n',encoding='utf-8')
c=read('endpoint-corpus.json'); a=c['C2_arms']; rr=read('orr-dcr-reread.json'); g=read('endpoint-regime-map.json'); coords=g['G3_disease_coordinates']['coordinates']
f2=ET.fromstring((PKG/'endpoint-gap-distribution.svg').read_bytes())
pts=[tuple(map(float,s.split(','))) for s in f2.find('{*}polyline').attrib['points'].split()]
gaps=sorted(x['gap_pp'] for x in rr['R2_per_arm_rows'])
f2max=max(abs(pts[2*i+j][k]-((78+gap*7.68,404-(i+j)/len(gaps)*360)[k])) for i,gap in enumerate(gaps) for j in (0,1) for k in (0,1))
f3=ET.fromstring((PKG/'endpoint-zero-response.svg').read_bytes())
obs=[e for e in f3.findall('{*}rect') if e.attrib.get('fill-opacity')=='0.78']
exp=[e for e in f3.findall('{*}rect') if e.attrib.get('fill-opacity')=='0.42']
bandchecks=[]
for i,(lo,hi) in enumerate([(1,4),(5,9),(10,19),(20,39),(40,10**9)]):
    sub=[x for x in a if lo<=x['evaluable_n']<=hi]
    o=sum(x['cells']['CR']+x['cells']['PR']==0 for x in sub)/len(sub)
    e=statistics.mean(0.923**x['evaluable_n'] for x in sub)
    bandchecks.append(dict(band=[lo,hi],n=len(sub),observed_pct=100*o,expected_pct=100*e,observed_drawn_pct=float(obs[i].attrib['height'])/360*100,expected_drawn_pct=float(exp[i].attrib['height'])/360*100))
f1=ET.fromstring((PKG/'endpoint-regime-map.svg').read_bytes())
circles=[e for e in f1.findall('{*}circle') if e.find('{*}title') is not None]
bycond={e.find('{*}title').text.split(' — ')[0]:e for e in circles}
clipped=[];undefined=[];deltas=[]
for co in coords:
    e=bycond[co['condition']];p=co['median_objective_response_pct'];n=co['median_actual_enrolment']
    actual_p=(496-float(e.attrib['cy']))/7.5
    if abs(actual_p-p)>0.01:clipped.append(dict(condition=co['condition'],source_pct=p,drawn_pct=actual_p))
    if co['median_trial_is_below_the_design_contour'] is None:undefined.append(dict(condition=co['condition'],fill=e.attrib['fill'],source_class=None))
def tail(n,k,p):return sum(math.comb(n,j)*p**j*(1-p)**(n-j) for j in range(k,n+1))
def design(p):
    for n in range(1,201):
        for k in range(1,n+1):
            alpha=tail(n,k,.05)
            if alpha<=.05+1e-14:
                power=tail(n,k,p)
                if power>=.8-1e-14:return dict(n=n,reject_at_least=k,alpha=alpha,power=power)
                break
def wilson(k,n):
    z=1.96;p=k/n;den=1+z*z/n;cen=(p+z*z/(2*n))/den;hw=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/den
    return [100*(cen-hw),100*(cen+hw)]
cer=[x for x in a if 'Cervical Cancer' in x['conditions']]
condition_labels=[dict(nct_id=x['nct_id'],arm_title=x['arm_title'],conditions=x['conditions'],phases=x['phases'],source_title=x['outcome_measure_title']) for x in a if x['nct_id']=='NCT02475213' and x['arm_title']=='Melanoma Cohort']
report=dict(figure2=dict(polyline_points=len(pts),expected_points=len(gaps)*2,max_pixel_discrepancy_due_to_rounding=f2max),
figure3=bandchecks,figure1=dict(condition_circles=len(circles),clipped=clipped,undefined_colored_as_at_or_above=undefined,nominal_emc_plotted_n=22),
cervical_sensitivity=dict(records=len(cer),trials=sorted(set(x['nct_id'] for x in cer)),all_records_have_both_phase1_and_phase2=all(set(['PHASE1','PHASE2'])<=set(x['phases']) for x in cer)),cross_condition_example=condition_labels,
emc=dict(n47=dict(orr=600/47,dcr=4200/47,gap=3600/47,orr_wilson=wilson(6,47),dcr_wilson=wilson(42,47)),n46_fixed_events=dict(orr=600/46,dcr=4200/46,gap=3600/46,orr_wilson=wilson(6,46),dcr_wilson=wilson(42,46)),nominal_rounded_12_8_design=design(.128),nominal_exact_6_over_47_design=design(6/47),zero_event_n_at_12_8=math.ceil(math.log(.1)/math.log(1-.128)),percentile_at_nominal_gap=100*sum(x['gap_pp']<=76.6 for x in rr['R2_per_arm_rows'])/len(gaps)),
raw_cache_refs=subprocess.run(['git','show-ref'],cwd=r'C:/Projects/EMC-Research',capture_output=True,text=True).stdout.splitlines())
report['raw_cache_refs']=[s for s in report['raw_cache_refs'] if 'literature-cache' in s]
path='research/manuscripts/endpoint/lit-targets-xdisease-ctg-results.json'
b=subprocess.check_output(['git','show',REV+':'+path],cwd=r'C:/Projects/EMC-Research')
(OUT/'frozen-dependencies'/path).write_bytes(b)
report['additional_protocol_input']=dict(repo_path=path,sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
dump('figure-and-methods-results.json',report)
print(json.dumps({k:report[k] for k in ('cervical_sensitivity','emc','raw_cache_refs')},ensure_ascii=True))
