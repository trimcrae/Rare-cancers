"""Independent read-only checks of frozen endpoint inputs. Does not import producers."""
from pathlib import Path
import hashlib, json, subprocess, statistics, math, re, collections, xml.etree.ElementTree as ET

OUT=Path(__file__).resolve().parent
PKG=Path(r'C:/Users/mcrae/.codex/review-workspaces/opus-capacity-sprint-20260907/capacity-campaign-20260908/observations/endpoint-final-review-package-20260908/package')
REPO=Path(r'C:/Projects/EMC-Research')
REV='9c6f4a80fc2fd69ee71ad6124c8de03e6e1af395'
def dump(name,obj):
    (OUT/name).write_text(json.dumps(obj,indent=2,ensure_ascii=True)+'\n',encoding='utf-8')
def read(name): return json.loads((PKG/name).read_text(encoding='utf-8'))

receipt=json.loads((PKG.parent.parent/'endpoint-final-review-package-20260908-final-local-receipt.json').read_text())
bindings={v['member']:v['exact_byte_matches_at_frozen_revision'][0] for v in receipt['git_file_bindings']}
hashes=[]
for p in sorted(PKG.iterdir()):
    b=p.read_bytes(); binding=bindings['package/'+p.name]
    git_bytes=subprocess.check_output(['git','show',REV+':'+binding['repo_path']],cwd=REPO)
    hashes.append(dict(name=p.name,bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),repo_path=binding['repo_path'],git_blob=binding['git_blob'],exact_git_bytes=b==git_bytes))
dump('independent-input-hashes.json',dict(revision=REV,files=hashes))

deps=['AGENTS.md','CLAUDE.md','research/autonomy/OPERATING_PROTOCOL.md','.claude/skills/paper-hardening/SKILL.md',
'systems/POLICY-evidence.md','.github/workflows/tests.yml','research/manuscripts/endpoint_corpus.py',
'research/manuscripts/orr_dcr_reread.py','research/manuscripts/placebo_arm_calibration.py',
'research/manuscripts/endpoint_prior_art_audit.py']
dh=[]
for path in deps:
    b=subprocess.check_output(['git','show',REV+':'+path],cwd=REPO)
    target=OUT/'frozen-dependencies'/path
    target.parent.mkdir(parents=True,exist_ok=True); target.write_bytes(b)
    dh.append(dict(repo_path=path,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
dump('additional-dependency-hashes.json',dict(revision=REV,files=dh))

schemas={}
for p in sorted(PKG.glob('*.json')):
    obj=read(p.name)
    schemas[p.name]={k:dict(type=type(v).__name__,size=len(v) if isinstance(v,(dict,list)) else None,keys=list(v)[:30] if isinstance(v,dict) else None) for k,v in obj.items()}
dump('input-schemas.json',schemas)
print(json.dumps(dict(input_files=len(hashes),all_exact_git_bytes=all(x['exact_git_bytes'] for x in hashes),additional_frozen_dependencies=len(dh),schemas='input-schemas.json'),ensure_ascii=True))
