"""Retain final integrity/quantile checks and an artifact manifest; no project writes."""
from pathlib import Path
import hashlib,json,math,datetime
OUT=Path(__file__).resolve().parent
PKG=Path(r'C:/Users/mcrae/.codex/review-workspaces/opus-capacity-sprint-20260907/capacity-campaign-20260908/observations/endpoint-final-review-package-20260908/package')
initial=json.loads((OUT/'independent-input-hashes.json').read_text())
current=[dict(name=x['name'],sha256=hashlib.sha256((PKG/x['name']).read_bytes()).hexdigest(),unchanged=hashlib.sha256((PKG/x['name']).read_bytes()).hexdigest()==x['sha256']) for x in initial['files']]
rr=json.loads((PKG/'orr-dcr-reread.json').read_text(encoding='utf-8'))
gaps=sorted(x['gap_pp'] for x in rr['R2_per_arm_rows'])
def type7(q):
    at=q*(len(gaps)-1);lo=math.floor(at);hi=math.ceil(at)
    return gaps[lo]+(at-lo)*(gaps[hi]-gaps[lo])
result=dict(verified_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),input_files_unchanged=all(x['unchanged'] for x in current),files=current,iqr_type7_on_stored_gap_values=[type7(.25),type7(.75)],verdict='MAJOR_SCIENTIFIC_REVISION_REQUIRED',publication_authorized_by_this_review=False)
(OUT/'final-review-integrity.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
manifest=[]
for p in sorted(OUT.rglob('*')):
    if p.is_file() and 'edge-render-profile' not in p.parts and p.name!='review-artifact-manifest.json':
        b=p.read_bytes();manifest.append(dict(path=p.relative_to(OUT).as_posix(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
(OUT/'review-artifact-manifest.json').write_text(json.dumps(dict(note='Review evidence inventory; Edge temporary profile excluded. Not a publication gate receipt.',files=manifest),indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(input_files_unchanged=result['input_files_unchanged'],iqr=result['iqr_type7_on_stored_gap_values'],review_files=len(manifest),report_sha256=next(x['sha256'] for x in manifest if x['path']=='FINAL-SCIENTIFIC-REVIEW.md'))))
