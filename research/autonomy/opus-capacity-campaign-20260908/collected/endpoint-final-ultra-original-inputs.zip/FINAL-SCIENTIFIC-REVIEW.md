# Independent final scientific review — endpoint/response manuscript

Frozen revision: `9c6f4a80fc2fd69ee71ad6124c8de03e6e1af395`.

Manuscript: `research/manuscripts/endpoint/response-endpoint-indolent-tumours.md`, all 763 lines read. SHA256: `bae48dbd23966cc247d428448ea81116fef7aeabf718e5f2da74103014f30408`; 53,719 bytes. Review completed 2026-09-08. This is the one commissioned independent final scientific review, not a producer run, publication approval, or additional campaign lane.

**Verdict: major scientific revision required; do not submit this frozen version.** The same-denominator identity is sound, several numerical summaries reproduce from the retained rows, and the reporting question could support a useful descriptive paper. However, the data unit and denominator validation do not match the manuscript's central methods. The disease map adds unsupported arm-to-disease/phase assignments and invalid bounding claims. These are substantive issues that passing consistency tests cannot resolve.

All line references below refer to the exact frozen files, never the stale local working tree. Basenames without a directory are under `research/manuscripts/endpoint/`; Python basenames are under `research/manuscripts/`. The receipt maps these files to their Git blobs. I independently compared the actual bytes of all 21 package files with `git show` at this revision: all matched. Additional dependencies were read only from that revision and retained with hashes under this review directory.

## Material scientific findings

### F1 — The claimed independent response denominator is constructed from the outcome cells

**Outgoing claim:** manuscript lines 69–74, 140–143, and especially 158–162 require a reported evaluable denominator and assert that checking the four categories against it prevents mixed-denominator records from entering the build.

**Evidence:** frozen `endpoint_corpus.py` lines 130–150 extracts categorical measurements into a dictionary; lines 203–231 set `n = sum(cells.values())` and save it as `evaluable_n`. No separately reported outcome denominator is read or compared. All 552 rows sum to their stored denominator, but that equality is guaranteed by construction. The cache contains no independent reported-denominator field. The extraction function also overwrites the same category label across classes for a group rather than preserving the source class identity (lines 132–150). These are direct code observations, not an inference that a particular patient was missing.

**Consequence:** the principal inclusion rule and validation guarantee are untrue as implemented. The stored ORR/DCR quantities are conditional on the four extracted cells; the review cannot establish that they use the source's response-evaluable population, that other categories were absent, or that the four counts shared an independently reported denominator. The attractive algebra does not validate the extraction it is applied to. This is particularly consequential in a manuscript whose main recommendation is denominator integrity.

**Minimum repair:** either retain and verify the source-reported outcome denominator, group/class identity, units, and non-evaluable categories before calling records complete, or explicitly redefine the analysis as proportions among four extracted classifications and withdraw the reported-denominator/build-guard claims. Do not describe the tautological sum check as external validation. A source audit and regenerated downstream results are needed if the original complete-arm estimand is retained. I did not regenerate or reconstruct patient data.

### F2 — “552 arms” is a count of response-table records, including repeated readings of the same arm

**Outgoing claim:** title at line 27; Methods lines 70, 140 and 171–173; Results lines 76–80, 333–408; Figures 2 and 3.

**Evidence:** the independent grouping of retained rows finds 552 records but only 465 distinct `(nct_id, arm_title)` strings; 65 such groups contain more than one record, producing 87 excess records relative to that string-based grouping. This diagnostic is not a proposed count of independent arms. Concrete examples do establish repeated measurements:

- `endpoint-corpus.json` lines 90–137: NCT00858117's “Alemtuzumab and Rituximab” arm appears twice with n=30, once using physical examination and once CT. Its SD counts are 0 and 9.
- `endpoint-corpus.json` lines 1045–1236: the two NCT00600340 treatment arms each appear four times: ITT/PP populations crossed with confirmed/unconfirmed best overall response. These are not four independent trial arms.
- The extractor's deduplication key includes the outcome-measure title and denominator (`endpoint_corpus.py` lines 213–218), so different measures/subsets of the same arm are intentionally retained.

**Consequence:** the median, zero-response frequency, arm-size stratification, control-candidate counts and disease coordinates are weighted by the number of reported response measures as well as by arms. Repeated/subset records can count the same patients multiple times. Calling the denominator-weighted sum 18,318 “patients” would also imply an unverified unique-patient total. Absence of a pooled causal estimate does not fix this descriptive-unit error.

**Minimum repair:** choose and document one eligible response assessment per actual arm before recomputing arm-level results, with a record of alternatives, or change the estimand throughout to response-table records, explicitly acknowledge overlap and reporting-multiplicity weighting, and remove arm-level generalizations. Do not silently replace 552 with 465: title strings alone are not a validated arm-identity adjudication. Preserve the full table inventory so the choice is reviewable.

### F3 — Disease/phase coordinates are assigned from trial metadata, not measured for the contributing arms

**Outgoing claim:** lines 73–74, 110–113, 230–250 and 276–285; limitations at 645–661. In particular, “phase 2 and phase 3 arms only” is said to show that the low corner is not an artefact of dose escalation.

**Evidence:** `endpoint_corpus.py` lines 185–191 and 226–229 copy the whole trial's condition list and phase list onto every extracted record. `endpoint_regime_map.py` lines 278–287 then assigns every record to every listed condition and retains it in the phase-2/3 sensitivity whenever the trial phase list contains either label.

This is observable in the retained data, not just a possible limitation:

- All 23 records contributing to “Cervical Cancer” come from a single mixed PHASE1/PHASE2 trial, NCT03829501. Its dose-labelled records retain the full list of 12 conditions, and all 23 survive the nominal phase-2/3 filter. See `endpoint-corpus.json` from line 10941 and `endpoint-regime-map.json` lines 253–272.
- NCT02475213's explicitly named “Melanoma Cohort” is also assigned “Head and Neck Cancer,” “Non Small Cell Lung Cancer,” and “Urothelial Carcinoma” through the trial-wide list (`endpoint-corpus.json` from line 9412). A melanoma-specific cohort's response table is therefore used to place other disease labels.

The claimed absence of response-criterion information is also too broad: the retained outcome titles themselves identify RECIST versions, modified criteria, and physical/CT readings. Such information is not consistently structured or fully extracted; that is different from being absent from posted results.

**Consequence:** the map cannot be interpreted as diseases placed by “their own measured numbers,” and the phase sensitivity does not exclude phase-1 portions of mixed-phase trials. The disclosed synonym/broad-label limitation does not disclose this cross-assignment mechanism. At least one supposedly disease-specific low coordinate is effectively one mixed-phase multi-disease trial replicated across labels.

**Minimum repair:** validate arm-level disease and phase mapping, excluding unresolved assignments from disease-specific inferences, or label the map strictly as trial-registration-label aggregates and withdraw the disease-specific/phase-exclusion conclusions. Say that review/criterion metadata were not consistently extracted, rather than unavailable. Total trial enrolment also needs to remain distinguished from enrolment in a disease-specific response-evaluable arm.

### F4 — The accrual scenarios do not identify lower/upper bounds or future trial capacity

**Outgoing claim:** lines 81–83, 254–256, 270–272, 289–322 and 620–624, especially the “lower bound” and “upper” assertions at 312–316.

**Evidence:** `endpoint-regime-map.json` G4b (lines 1106–1180) contains 7/22=31.8% under completed-trial accrual and 17/23=73.9% under terminated-for-accrual accrual. The conditions differ: 35 placed versus 36 placed, with 22 versus 23 defined design comparisons. Both query result sets are capped. There is no specified common target population or demonstrated monotonic relationship proving these samples bracket its prevalence. Opposite qualitative selection stories do not establish statistical bounds.

Separately, the solver stops at n=200 (`endpoint_regime_map.py` lines 63–67 and 97–108), while the manuscript calls an unresolved result “no design of realistic size” at lines 225–226 without stating this operational cap. The 5% null is an illustrative borrowed assumption, not an established null for every condition. A historical median response across heterogeneous regimens is not the true response probability of a future agent. Two completed EMC cohorts of 22 and 23 evaluable patients show achieved cohort sizes, not inability ever to accrue 79; lines 655–656 already acknowledge this distinction, contradicting the stronger claim at 623.

**Consequence:** the claimed bound and disease-capacity conclusions are not identified by these data even if all numerical calculations are correct. The reported limitations do not make the stronger conclusion valid.

**Minimum repair:** report 7/22 and 17/23 as descriptive sensitivity results over different condition sets; call 31.8–73.9% their observed scenario range, not a population bound. State the n≤200 solver cap and the assumed 5% null. Describe the two EMC cohort sizes as smaller than an illustrative requirement at the nominal rate, and withdraw “cannot accrue” and “cannot support a response-rate summary.” Retain the withdrawal of the zero-event prevalence claim; this review does not reinstate it.

### F5 — Zero responses carry information; the size pattern does not identify agent-independent causation

**Outgoing claim:** lines 65–88, 216–219, 247–250, 382–408 and 412–413 say a zero readout returns nothing, cannot be interpreted, or is largely an arm-size property rather than an agent property.

**Evidence:** for zero responses in n binomial observations the likelihood is `(1-p)^n`; it varies with p, so the outcome is informative about response probability. A one-sided exact 95% upper limit is `1 - 0.05^(1/n)`: approximately 63.2% for n=3, 13.9% for n=20, and 4.9% for n=60. A small zero-result arm may fail to exclude a relevant response probability; it does not contain no information. An observed median of zero similarly does not establish a true probability of zero or invalidate a response endpoint.

Figure 3's fixed-p expectation is computed correctly at p=7.7%, but this value is derived from the same selected corpus, whose phase, treatment, disease and response-record multiplicity vary with arm size. Five descriptive size bands and one fixed-rate curve do not separate those contributions. The stored data do not test how often authors actually label the agent inactive, either.

**Consequence:** the abstract's “returns nothing” and the substantive interpretation of Figure 3 confuse imprecision with absence of information, and association with attribution. These overstatements concern the paper's central motivation, not merely tone.

**Minimum repair:** use “recorded zero objective responses” and quantify precision or ability to exclude a prespecified rate. Say the decreasing observed zero-response frequency is compatible with the binomial's sample-size dependence; remove the claimed partition between arm size and agent effects and unsupported assertions about how reports interpret zeros. Preserve the explicit prohibition on inferring efficacy from stable disease.

### F6 — Figure 1 gives false plotted values and an incorrect classification legend

**Outgoing artifact:** Figure 1 and caption, manuscript lines 228–241; `endpoint-regime-map.svg`.

**Evidence:** I visually inspected the retained SVG render and independently decoded its coordinates against G3. Follicular lymphoma is stored at 77.8% and multiple myeloma at 80.0% (`endpoint-regime-map.json` lines 1058–1098), but both are drawn on the 60% grid line. `endpoint_regime_figure.py` lines 45 and 53–55 clamp y to 60 without an overflow symbol or caption disclosure. Also, all 16 undefined design comparisons are colored gray by the false/None branch at lines 125–126, while gray is labelled “at or above it” at line 164. The manuscript itself correctly separates undefined comparisons from valid ones.

**Consequence:** the figure misrepresents two numerical measurements and visually assigns undefined cases to the opposite substantive category. It does not match its claimed “each point ... its own measured numbers” interpretation.

**Minimum repair:** extend the response axis to cover all measurements or use explicitly labelled overflow markers. Give undefined comparisons a separate symbol/legend. State that the displayed accrual coordinate is the pooled scenario and clarify the selected EMC x-coordinate of 22 (the figure hard-codes it rather than representing both modern cohorts). Then regenerate the figure after resolving F1–F4.

### F7 — A letter is counted as a trial precedent, and the remedy taxonomy conflates endpoints with control designs

**Outgoing claim:** manuscript lines 552–585 and reference 14 at line 738.

**Evidence:** retained `endpoint-prior-art-inputs.json` lines 161–174 identifies PMID 25317882, the Ozdemir/Yazici/Zengin NEJM correspondence, as publication types “Letter” and “Comment,” with an empty abstract. Yet `endpoint-prior-art-audit.json` classifies it as a placebo-controlled trial precedent, and manuscript lines 568–570 cite it as one of two neuroendocrine-tumour trials. Matching its title/identifier is not verification that it is the trial report.

The retained abstracts of references 20–21 describe random assignment after a common lead-in to continuing treatment or placebo, a concurrent between-group comparison. Grouping these with GMI under “make each patient their own control” (lines 559, 571–572) misdescribes the design. Conversely, the family-A examples are themselves placebo-controlled trials. Thus the assertion that only family D addresses natural history (578–579) does not follow from this taxonomy. The retained GMI scoping review also describes heterogeneous and sometimes arbitrary usage; it does not establish that GMI removes the counterfactual problem.

Finally, the audit observes retrieved documents, not adoption rates. Its own non-systematic scope at 663–668 cannot support “undiffused” in the abstract or the claim that endorsed remedies do not reach other diseases (574–580).

**Consequence:** one source tier and its domain precedent are unsupported, control design is confused with endpoint definition, and diffusion is asserted without being measured. The numerical family/domain counts inherit those classifications.

**Minimum repair:** reclassify the letter and remove its trial-precedent claim unless an already verified primary trial source is substituted; update dependent counts rather than inventing a replacement identifier. Separate endpoint families from comparison designs. Describe the audit as examples of established alternatives, without claiming measured lack of diffusion or immediate transfer at no participant cost. This review did not begin a new literature search.

### F8 — The natural-history section draws magnitude and impossibility conclusions from unavailable evidence

**Outgoing claim:** manuscript lines 490–505, 524–528 and 537–539.

**Evidence:** the study explicitly has no usable natural-history arm. The result “4 of 25 have any control arm in this corpus” measures control-candidate availability, not the size of an untreated-response component. Therefore “The confound is largest exactly where it has never been measured” at 538–539 is unsupported. A single-arm response analysis need not assume untreated response is exactly zero (524–525); this manuscript's own design example uses a nonzero null. The assertion that an untreated arm “cannot produce” a 48.4% response at 499 is also stronger than the evidence permits and conflicts with the section's demonstration that untreated objective regression can occur. The prior-treatment timing evidence, not impossibility of spontaneous response, is the reason to exclude that arm.

The directional natural-history “bounds” at 490–493 additionally require assumptions about comparability, measurement time, and selection; progression eligibility alone does not establish a mathematical bound on a common untreated population.

**Minimum repair:** limit the 4/25 statement to availability in this selected corpus and leave confound magnitude unknown; say a single-arm inference requires an appropriate background/null rate. Explain the no-intervention-arm exclusion by its prior-treatment measurement timeline. Treat progression-based selection as a comparability concern, not a demonstrated upper/lower bound. Keep desmoid rates confined to desmoid disease and preserve the disclosed uncertainty about overlapping observational cohorts.

### F9 — Wilson intervals are labelled exact

**Outgoing claim:** manuscript lines 77–78 and 348–350 say the gap has an “exact interval”; lines 158–160 correctly identify the actual interval as Wilson. `orr_dcr_reread.py` lines 55–69 implement the Wilson score formula using z=1.96; its prose also calls this an “exact Wilson interval.”

**Consequence:** Wilson is a score interval, not an exact binomial confidence procedure. The identity `DCR - ORR = SD/n` is exact; that does not make its confidence coverage exact. This is a small repair but a real statistical terminology error in an analysis dominated by small samples.

**Minimum repair:** say “the identity is exact; uncertainty is represented by a 95% Wilson score interval.” Preserve Wilson unless there is a substantive reason to change interval methods; changing words alone requires no new statistical analysis. State that the ECDF does not display per-record intervals.

### F10 — The supplied scientific JSON still makes claims explicitly narrowed in the manuscript

**Outgoing claim:** manuscript lines 596–609 and 630–633 correctly distinguish the nominal 47 from a fixed-event n=46 sensitivity, leave the outcome unknown, and confine IMMUNOSARC II's source tier to the retained record. The linked JSON is itself a supplied scientific artifact (lines 608 and 711).

**Evidence:** `emc-endpoint-discordance.json` line 115 still says “no full paper exists”; line 134 describes “Dropping the unaccounted-for patient” and calls the headline “the conservative one.” This is inconsistent with the carefully limited current prose. No new source access or patient-identity inference is needed to observe the inconsistency.

**Minimum repair:** align the generator-owned explanatory strings with the accepted manuscript: retained conference-abstract evidence; fixed reported events with a denominator sensitivity; no identified or dropped patient; lower gap only under the specified sensitivity, not a general conservative bound. Regenerate that artifact in the authorized repair batch. Do not reopen the source-identity or missing-patient hunt.

## Reproducibility: verified wiring, incomplete review package, execution still unverified

This is separate from the invalid methods above. The flat 21-file package is **not a standalone reproducible deposit**:

- Four of the seven commands printed at manuscript lines 181–187 are absent from it: `endpoint_corpus.py`, `orr_dcr_reread.py`, `placebo_arm_calibration.py`, and `endpoint_prior_art_audit.py`.
- Required committed inputs are also absent: `endpoint-prior-art-inputs.json`, `placebo-arm-detail-inputs.json`, and `natural-history-inputs.json`. The prior-art producer explicitly reads the first; the calibration producer reads the latter two and otherwise loses their evidence.
- The main protocol points to a separate `lit-targets-xdisease-ctg-results.json` containing the 12 actual registry URLs; that file is absent from the package.
- The shell script expects the repository directory layout. Flattening basenames does not preserve that layout.

All these named files exist at the exact frozen revision and were extracted read-only to this review's `frozen-dependencies/`, with hashes. Thus package incompleteness is repairable deposit preparation, not evidence that the repository has lost the inputs. Manuscript lines 195–198 should nonetheless be corrected: all seven outputs do not derive solely from `endpoint-corpus-inputs.json`; several other committed inputs and companion artifacts are read.

The seven `--check` commands are statically present in frozen `.github/workflows/tests.yml` lines 204–210, and their order is consistent with the chain script. **I did not run them, the regeneration chain, a full test suite, or full preflight. I did not verify the latest CI run.** No claim of successful re-derivation follows from wiring. No `literature-cache` ref is present in this local repository, so the raw registry payloads were not independently checked against the extraction cache; their remote existence or loss was not adjudicated. Pre-fetch commitment chronology was also not independently established from original fetch receipts. The retained protocol's assertion is not independent chronology evidence.

For the eventual reproducible release, include the named dependencies in the right layout, pin the raw-cache revision or archive where available, and retain the actual authorized reproduction/preflight receipts. Methods should state the condition-inclusion thresholds of at least three response records and three accrual records, the n≤200 design search cap, and the operational query/parse inclusion rule. A claim of “every screened record” having a disposition (143–144) should be qualified: the supplied cache retains aggregate disposition counters, not an individual excluded-record ledger. The reporting census must be described as what this extraction rule recovered; raw-source reporting failure has not been independently established here.

## What independently checks out, within those limits

- All 21 package byte sequences match frozen Git objects, including the manuscript and all three SVGs.
- Across the retained 552 **records**, the count of trials is 138, the median exact SD fraction is 39.4056 percentage points, 194 records have gap ≥50 points, and 251 have zero CR+PR. All stored four-cell sums equal the stored denominator; F1 explains the limitation of that equality.
- The nominal EMC arithmetic is correct: 6/47=12.8%, 42/47=89.4%, and 36/47=76.6%. The fixed-event n=46 sensitivity gives 13.0%, 91.3%, and 78.3%, with the stated rounded Wilson intervals. The difference rounds to 1.7 points. This does not identify a missing patient or make either denominator an observed corrected cohort.
- At the nominal 12.8% rate, the zero-event n is 17. An independent exact binomial calculation gives n=79, rejection at ≥8 responses, α≈0.04377 and power≈0.80810 against p0=.05; using exact 6/47 still gives n=79. These are calculations under assumptions, not proof of accrual infeasibility. The nominal gap's empirical percentile is 88.9493%, rounding to 88.9. No n=46 percentile or design value was fabricated.
- The census's stored arithmetic closes: 2,851+1,563=4,414 records, 2,715+1,561=4,276, and 4,414−4,235=179. The 95.2% and pooled fractions are arithmetically consistent with the cache. This is not an independent raw-source validation of the extraction census.
- Figure 2's 1,104 ECDF polyline points match the 552 stored gap readings to coordinate rounding (maximum discrepancy 0.048 pixel); its numerical marks are consistent. Its “arms” label inherits F2 and its caption's exact-interval claim inherits F9.
- Figure 3's 174/147/93/48/90 record bands and 134/85/28/4/0 zero counts reproduce. Its expected values are 81.0016%, 61.0492%, 32.8223%, 11.5210%, and 0.5179% at p=.077. Rendered bars agree to SVG rounding. Its interpretation remains subject to F2 and F5.
- All three retained SVGs were rendered and visually inspected. The first Edge renderer attempt reported exit 0 before files were available; that initial receipt/log is preserved and is not labelled a complete rendering success. The deterministic bundled Sharp conversion subsequently produced all three PNGs with hashes. No scientific figure producer was invoked.

The careful current §8 prose, nominal/sensitivity distinction, source-tier qualification, prohibition on causal or therapeutic interpretation, and desmoid non-transfer statement are strengths to preserve. The third EMC cohort being n=2 is available in `D1.per_cohort.trabectedin_emc_subset`; adding that size and its source in the manuscript is an ordinary helpful clarification, not a scientific blocker or a permission trigger. Source heterogeneity and absence of untreated comparators are disclosed limits, not automatic reasons to reject a descriptive example.

## Merit, coherence and novelty

The potentially useful contribution is an auditable account of which posted response tables can be reconstructed and how much their SD category changes a response summary. The identity itself is elementary, and the binomial curves are standard calculations. Novelty therefore rests on the empirical corpus and reporting audit, which makes the unit/denominator defects central. The map's “uninformative diseases” framing is currently not supported; it can be narrowed to explicitly illustrative registration-label scenarios, or removed without losing the reporting question.

The prose is readable and unusually explicit about several limitations, but repeatedly moves from a valid restricted observation to a broader assertion: sample selection becomes a bound, historical achievement becomes capacity, zeros become no information, and absence of comparators becomes the largest confound. Those transitions, rather than lack of rhetorical caveats, need replacement. Existing alternatives can provide context, but the frozen retrieval does not establish a new theory of endpoints or measured diffusion failure.

## Ordinary deposit packaging and administrative limits

The non-submission editorial HTML comment is at **manuscript lines 38–51**, not the handoff's stated 44–56. Lines 53–56 are the actual ethics/funding/data declarations and should not be accidentally removed. Omit the comment from the deposit render; do not strip those declarations. ORCID absence is packaging, not a scientific finding or a new permission requirement. Resolve the repository-relative data/code links into a usable deposited package and identify the actual selected venue through the coordinator; this review assumes no medRxiv eligibility and chooses no alternative outlet.

Earlier test counts and lint status were read as prior reports, not rerun or adopted as global clearance. The reported 2,394 errors/270 warnings on baseline and changed trees establish matching totals only, not identity of errors. The reported citation inventory concerned autonomy artifacts, and the 13 source-type records were MISSING-cache cases rather than demonstrated MISMATCH. None of that clears the scientific findings above or publication gates.

## Review evidence and stop condition

Original review scripts and their structured results are retained here:

- `inspect_frozen.py`; `independent-input-hashes.json`; `additional-dependency-hashes.json`; `input-schemas.json`.
- `targeted_checks.py`; `additional-source-input-hashes.json`; `repeated-trial-arm-records.json`; `independent-arithmetic-results.json`; `figure-structure-and-labels.json`.
- `figure_and_methods_checks.py`; `figure-and-methods-results.json` (including the extra protocol hash and binomial calculations).
- `render_retained_figures.py`, its original renderer logs and `render-receipt.json`; `render_svg.js`, `sharp-render-receipt.json`, and all retained PNGs.
- Exact frozen dependencies under `frozen-dependencies/` and this report.

No scientific/source file was edited, no producer/full suite was run, no agent was spawned, no new research or source-identity hunt was started, no denied route was retried, and nothing was published. No task-owned Edge process remained at the final scoped process check. Review-model usage/elapsed-run telemetry was not available as a trusted tool measurement and is not invented here.

**Next required action:** one owner should adjudicate and repair these findings as a single batch, then obtain focused independent verification of the changed claims and affected dependencies. F1–F3 may require a materially revised corpus/analysis; simple wording edits cannot make the existing data meet the original one-arm/independent-denominator method. The final scientific review is complete with this adverse verdict; it is not a request to begin another unchanged whole-paper review.
