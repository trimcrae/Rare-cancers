# Root adjudication: biomarker-selected classes

Frozen scientific revision: `796fcdf0a7d751a8e74c6473f36d75e612cd167b`.
Main manuscript: 21,448 bytes, SHA256 `fe4f95abb1476c95cf60ea21a2570692328de0ada379f6c542329599b566c766`.

The required independent final review is complete. Root read the full 30,660-byte report and independently verified SHA256 `7396531d30f8ff7b3b283c748e359cb60b683fce0247b24eb748a1ab9f93de8e`. Root accepts its **not_supported_as_written / major_revision** verdict and all nine findings within the evidence limits below. This frozen version must not be released as a standalone four-negative/one-survivor therapeutic-class paper.

The blocker is scientific interpretation, not an arithmetic failure. The reviewer independently reproduced 16 group/platform and 86 relevant gene/platform comparisons and verified 54 retained Git copies. These checks bridge retained cached values to summary statistics; they do not establish the original raw-data collection pipeline, biological pathway activity, clinical selection validity or a therapeutic window.

## Accepted findings

1. **F01, P1:** body and metadata still report absent/unmet selecting states that the transcript instrument does not measure. The unique-survivor comparison applies inconsistent standards to unresolved biomarkers.
2. **F02, P1:** the observed genome-wide mixture is descriptive background, not a validated null or evidence strengthening negatives. Small t values do not establish equivalence or biological absence. The old statistics review's contrary inference is also rejected; history is retained, not treated as clearance.
3. **F03, P2:** full PRC2-core statistics include EZH2 and cannot be attributed to the remainder after EZH2 is excluded. Relative array measurements do not establish an absolute detection floor.
4. **F04, P2:** the frozen input cache retains the omitted SFT targeted-gene values. A bounded offline sensitivity is possible and was performed by the reviewer; a full enlarged genome-wide background was not regenerated. Neither source loss nor a need for a new fetch is established.
5. **F05, P2:** the guardian group mean is correct, and BCL2L2 does not invalidate that mean. Component reversals, MDM2, the second sensitiser mean and the limits of inferred priming still need coherent reporting.
6. **F06, P2:** effective denominators, coverage, missingness, comparator composition, array-SD meaning, normalization and exact reproduction dependencies are insufficiently specified. The inspected implementation uses samples, not genes, as the Welch comparison unit; no gene pseudoreplication finding is made.
7. **F07, P1:** a required high basal p53-output score and the general therapeutic-class selection framework are not supported by the cited evidence. Cancer-line lineage comparisons do not establish tumour-versus-normal safety or selectivity. Narrow unsupported targeted-agent, clinical-use and comparative-source claims without inventing regulatory verification.
8. **F08, P2:** orthogonal protein/functional measurements can change therapeutic interpretation while coexisting with the reported RNA observation; they are not necessarily falsifiers of that observation. Cellularity/confounding remains unresolved.
9. **F09, P2:** retrospective selection from a broader route pool and qualitative grading must be explicit. The five-class narrative is not established as prospective confirmatory selection or a validated ranking method.

## Hold and reopening condition

Park the present standalone exclusion/ranking claim. No unchanged whole-paper review, cosmetic hedge pass, new source hunt, new experiment, full producer chain or automatic rewrite is assigned by this adjudication.

One possible future reopening is an explicitly adjudicated descriptive companion or retrospective case study of transcript-based triage limits. It would need one coherent revision withdrawing unmeasured biological-state exclusions and the unique-survivor result; correcting the source/selection framework, component reporting and metadata; specifying denominators, coverage and methods; and either reporting the retained offline SFT sensitivity or accurately stating its scope. Any such revised objective must justify useful standalone or companion value. Then use focused verification of the actual changed claims and supporting tables, not a repeated review of unchanged evidence.

If validated class exclusion, pathway activity, apoptotic priming or a normal-tissue therapeutic window remains necessary to the intended contribution, the paper stays parked until evidence that actually measures that requirement exists. A new title or model is not changed evidence.

The five named original literature payloads not located by the review remain a scoped verification limit. This is not a finding of global source loss or fabricated citations; no current regulatory status is independently verified. Retain accurate primary-source support where available and withdraw unsupported claims. Do not upgrade metadata anchoring into claim verification.

## Same-cycle continuation and retention

The sole owner has already verified actual preparation of the corrected HLA paper: sixteen parent commands and a running 32-second test helper at the 17:06:44 UTC observation. Mortality's corrected frozen e218 package has entered its separate required independent final review. ATR's exact e218 PDF passed root visual inspection and its source/stamp checks; real release gates remain pending. Endpoint's earlier major scientific hold remains unchanged.

Preserve the biomarker frozen science, full final report, original scripts/results, source-support report, input manifests, process/failure notes and final integrity receipt. Transport the small reviewer-generated original evidence through the existing sole-owner route; the 54 already Git-bound source copies need not be shipped again. No reviewer script or producer should be re-executed to manufacture a receipt.

This is a paper-specific hold, not a program-wide blocker or a request for user action. No public preprint was completed by this adjudication.
