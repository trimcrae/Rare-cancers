# Execution notes and failure accounting

This is a contemporaneous record of the review process, not a reconstruction of missing historical science logs. Original tool responses remain in the review task's conversation. The preparatory failures below did not originally write dedicated stdout/stderr log files; this note does not pretend to be those original logs.

- The first complete frozen-tree listing exceeded the conversational output limit (the tool reported 8,877 output lines and truncation). It was only an inventory read. Subsequent targeted Git reads and the supporting agent's retained tree inventory supplied the needed paths. Truncation was not treated as absence of evidence.
- An early inline Python schema-inspection command omitted `encoding='utf-8'` on a JSON read. It exited 1 with `UnicodeDecodeError: 'charmap' codec can't decode byte 0x90 in position 29408: character maps to <undefined>`. No science check passed in that invocation. Later inspection/scripts explicitly used UTF-8; the failure was not rerun as a scientific producer.
- One native `git ls-tree` command was issued with the projectless workspace as cwd and printed `fatal: not a git repository (or any of the parent directories): .git`. The containing PowerShell invocation subsequently printed independent source excerpts and returned exit 0, so that overall exit is not a pass for the failed Git read. A subsequent isolated read used `C:/Projects/EMC-Research` and returned the four expected blob entries successfully.
- `inspect_evidence.py` produced an overlarge JSON inspection report. The full generated output is retained as `evidence-inspection.txt`; only its display in the conversation was truncated. No subsequent scientific conclusion relies on treating the truncated display as a complete absence search.
- A report-only `apply_patch` attempt failed verification because one proposed no-op context line was part of a longer paragraph. The corrected patch succeeded. This affected only the new review report, never a scientific input or the shared repository.
- The supporting agent's own startup failures and original-log limitations are retained in `claim-source-support/execution-notes.md`. Its originals and all its successful search inventories remain intact.

Successful scientific review checks:

- `extract_inputs.py` extracted 28 exact frozen Git blobs and verified all six assigned manuscript/source SHA256 values plus the external handoff and manuscript copy.
- `independent_checks.py` exited 0. It writes its full JSON and text results itself, and its terminal output reports 16 group and 86 readable-gene comparisons, all stored-rounding checks true, no failed arithmetic checks. Its input-to-summary arithmetic uses the standard library and does not run the producer/import chain. The SFT and module-difference calculations are bounded audit-only sensitivity calculations; they do not overwrite any scientific artifact.
- `source_locations.py` exited 0 and retained exact JSON-pointer line locations.
- A direct assigned-runtime `importlib.util.find_spec` check returned `pytest_installed: false`, `numpy_installed: true`. No pytest suite ran. No dependency installation was attempted.
- The final integrity script separately rereads every retained input against its frozen Git blob and inventories the complete review directory, including originals, scripts, findings and failures. Its report gives actual completion time, bytes and SHA256.

Python used: `C:/Users/mcrae/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe`.

No scientific-source edits, network retrievals, raw producer runs, full preflight, publication acts, Git index mutations or current-branch updates occurred in this review. No original evidence was deleted. Historical full-suite/style/gate results are attributed to the handoff and were not fabricated as new executions.
