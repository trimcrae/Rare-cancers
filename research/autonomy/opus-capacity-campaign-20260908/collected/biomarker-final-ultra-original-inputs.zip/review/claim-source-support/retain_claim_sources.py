"""Read-only source-preservation audit of one frozen Git tree; no producers/network."""
import hashlib, io, json, re, subprocess, tarfile, zipfile
from pathlib import Path

REPO = Path('C:/Projects/EMC-Research')
REV = '796fcdf0a7d751a8e74c6473f36d75e612cd167b'
OUT = Path(__file__).resolve().parent
def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])
def sha(b):
    return hashlib.sha256(b).hexdigest()
def save_json(name, obj):
    (OUT / name).write_text(json.dumps(obj, indent=2, ensure_ascii=False)+'\n', encoding='utf-8')

tree = []
for row in git('ls-tree', '-r', '-l', REV).decode().splitlines():
    prefix, name = row.split('\t', 1)
    mode, typ, blob, size = prefix.split()
    tree.append(dict(path=name, git_blob=blob, size=int(size)))
byname = {x['path']: x for x in tree}
save_json('frozen-tree-inventory.json', {'frozen_revision': REV, 'files': tree})
def retained_file(p):
    return OUT / 'blobs' / (byname[p]['git_blob']+''.join(Path(p).suffixes))

paths = [
 'AGENTS.md', 'CLAUDE.md', 'research/autonomy/OPERATING_PROTOCOL.md',
 '.claude/skills/paper-hardening/SKILL.md',
 'research/literature/biomarker-class-definitions-2026-08-09.json',
 'research/literature/lane-probe-metabolism-strategy.json',
 'research/literature/rt-lung-mets-probe.json',
 'research/literature/emc-prior-art-2026-08-09.json',
 'research/manuscripts/dependency/emc-biomarker-selected-classes.md',
 'research/manuscripts/citation-retraction-sweep.json',
 'research/modalities/census-route-expression-grading.json',
 'research/modalities/emc-expression-panels.json',
 'research/modalities/depmap-sarcoma-dependency.json',
 'research/modalities/depmap_sarcoma_dependency.py',
 'research/modalities/hemcss-label-priorart.json',
 'research/data/emc-clinical-registry.json',
 'research/autonomy/review-seats/PUB-BIOMARKER-DEP-20d33f3478fa34940552d26ea8ae05cdd7a23ad2-seat-citations-and-instruments.json',
 'research/autonomy/review-seats/PUB-BIOMARKER-DEP-20d33f3478fa34940552d26ea8ae05cdd7a23ad2-seat-hostile-referee.json',
 'research/autonomy/opus-capacity-campaign-20260908/paper-lane/BM1-executed-artifacts/ORIGINAL-CHILD-TRANSCRIPT-a57244381f049c766.jsonl',
 'research/autonomy/opus-capacity-campaign-20260908/paper-lane/VB1-executed-artifacts/ORIGINAL-CHILD-TRANSCRIPT-ace07625d540f307a.jsonl',
]
archives = [x['path'] for x in tree if x['path'].endswith(('.tar.gz', '.zip'))]
paths += archives
manifest = []
for p in paths:
    b = git('show', REV+':'+p)
    dest = retained_file(p)
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(b)
    copied = dest.read_bytes()
    manifest.append(dict(**byname[p], sha256=sha(b), retained_sha256=sha(copied), copy=str(dest.relative_to(OUT)), retained_bytes_match=(copied==b)))
save_json('git-blob-sha256-manifest.json', {'frozen_revision': REV, 'read_method':'git show REV:path -> exact binary bytes', 'files':manifest})

payloads = ['epmc_ass1_review.txt','epmc_bh3_profiling_letai.txt','epmc_mdm2_p53wt_selection.txt','epmc_polq_synthetic_lethal.txt','epmc_tazemetostat_es_trial.txt']
pmids = ['27735949','28122247','8440237','33035459','25642963','25642960','34179826','17692808','22230093']
patterns = payloads + pmids + ['biomarker-class-definitions-b-2026-08-09','PMC5840045','PMC413229','PMC3770266','PMC4415602','PMC4718306','PMC8224818','PMC5133958']
scan = []
for p in archives:
    b = retained_file(p).read_bytes()
    if p.endswith('.zip'):
        z = zipfile.ZipFile(io.BytesIO(b))
        members = [(n.filename, z.read(n)) for n in z.infolist() if not n.is_dir()]
    else:
        t = tarfile.open(fileobj=io.BytesIO(b), mode='r:gz')
        members = [(m.name,t.extractfile(m).read()) for m in t.getmembers() if m.isfile()]
    record = {'archive':p, 'git_blob':byname[p]['git_blob'], 'sha256':sha(b), 'members':[]}
    for n, data in members:
        text = data.decode('utf-8', errors='replace')
        terms = [v for v in patterns if v.lower() in text.lower() or v.lower() in n.lower()]
        row = {'member':n, 'bytes':len(data), 'sha256':sha(data), 'terms':terms}
        if terms:
            row['matches'] = [{'line':i,'excerpt':s[:500]} for i,s in enumerate(text.splitlines(),1) if any(v.lower() in s.lower() for v in patterns)]
        record['members'].append(row)
    scan.append(record)
save_json('frozen-archive-scan.json', {'frozen_revision':REV,'terms':patterns,'archives':scan})

search = subprocess.run(['git','-C',str(REPO),'grep','-n','-I','-E','|'.join(re.escape(x) for x in patterns), REV], capture_output=True)
(OUT/'frozen-text-source-search.txt').write_bytes(search.stdout)
save_json('source-search-scope.json', {'frozen_revision':REV,'git_grep_exit_code':search.returncode,'patterns':patterns, 'named_raw_payload_tree_paths': [x['path'] for x in tree if any(x['path'].endswith(p) for p in payloads)],'archives_scanned':archives,'exclusions':['Git history outside the specified frozen tree','Remote artifacts/URLs and untracked working-tree files','Git bundles: unrelated retained process-history artifacts; not opened','Standalone molecular/array/HGNC .gz inputs: not literature archives']})
print(json.dumps({'retained_files':len(manifest),'archives_scanned':len(scan),'archive_members':sum(len(a['members']) for a in scan),'archive_members_with_matches':[(a['archive'],m['member'],m['terms']) for a in scan for m in a['members'] if m['terms']]},indent=2))
