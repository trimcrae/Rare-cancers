from pathlib import Path
import hashlib, json, subprocess, datetime

ROOT=Path(__file__).resolve().parents[1]
REPO=Path('C:/Projects/EMC-Research')
REV='796fcdf0a7d751a8e74c6473f36d75e612cd167b'
FILES={
'AGENTS.md':None,
'CLAUDE.md':None,
'.claude/skills/paper-hardening/SKILL.md':None,
'.claude/skills/repo-gates/SKILL.md':None,
'research/autonomy/OPERATING_PROTOCOL.md':None,
'research/manuscripts/dependency/emc-biomarker-selected-classes.md':'fe4f95abb1476c95cf60ea21a2570692328de0ada379f6c542329599b566c766',
'research/modalities/emc-expression-panels.json':'123bd05a9f9f5d08a362df3bd51cdbb72c241b49712123aaf5c5ea914f336bd9',
'research/modalities/census-route-expression-grading.json':'5bc3c80c034dde7781394554aa3bc18888248ad4cf1aa0153e4c7e4d5e4f07a8',
'research/modalities/depmap-sarcoma-dependency.json':'d88bed62a80dcb51675f0f7a5a27771a6c1f732e977200d39fa389cb8dd27546',
'research/literature/biomarker-class-definitions-2026-08-09.json':'4cbd8b46adbd5954294b43c7b13718f9768a984b56662c3e06487504afeee69c',
'research/data/emc-clinical-registry.json':'6f3b31b352c29592a4657d64aff872a93cf65f280837096008e59ab82e502bdd',
}
def extract(paths):
    manifest_path=ROOT/'review/input-manifest.json'
    manifest=json.loads(manifest_path.read_text('utf-8')) if manifest_path.exists() else {'frozen_revision':REV,'inputs':[]}
    known={r['path']:r for r in manifest['inputs']}
    for name,expected in paths.items():
        b=subprocess.check_output(['git','show',f'{REV}:{name}'],cwd=REPO)
        out=ROOT/'inputs'/name; out.parent.mkdir(parents=True,exist_ok=True); out.write_bytes(b)
        sha=hashlib.sha256(b).hexdigest()
        if expected is not None: assert sha==expected,(name,sha,expected)
        blob=subprocess.check_output(['git','rev-parse',f'{REV}:{name}'],cwd=REPO,text=True).strip()
        known[name]={'path':name,'bytes':len(b),'sha256':sha,'git_blob':blob,'expected_sha256':expected,'expected_match':None if expected is None else sha==expected}
    manifest['inputs']=sorted(known.values(),key=lambda r:r['path']); manifest['last_extraction_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    manifest_path.write_text(json.dumps(manifest,indent=2)+'\n','utf-8')
    return manifest

if __name__=='__main__':
    import sys
    m=extract({p:None for p in sys.argv[1:]} if len(sys.argv)>1 else FILES)
    if len(sys.argv)==1:
        handoff=Path('C:/Users/mcrae/.codex/review-workspaces/opus-capacity-sprint-20260907/capacity-campaign-20260908/observations/796fcdf0/HANDOFF-biomarker-frozen-readiness.md')
        copy=Path('C:/Users/mcrae/.codex/review-workspaces/opus-capacity-sprint-20260907/capacity-campaign-20260908/observations/93232c6e/research/manuscripts/dependency/emc-biomarker-selected-classes.md')
        hb=handoff.read_bytes(); cb=copy.read_bytes()
        assert len(hb)==10872 and hashlib.sha256(hb).hexdigest()=='43250d51ced118ab5754727b8d342c5fc736e9480aa32186796104ddd2135f96'
        target=ROOT/'inputs/research/manuscripts/dependency/emc-biomarker-selected-classes.md'
        assert cb==target.read_bytes()
        (ROOT/'inputs/HANDOFF-biomarker-frozen-readiness.md').write_bytes(hb)
        (ROOT/'review/external-copy-verification.json').write_text(json.dumps({'handoff':{'source_path':str(handoff),'bytes':len(hb),'sha256':hashlib.sha256(hb).hexdigest()},'manuscript_copy':{'source_path':str(copy),'bytes':len(cb),'sha256':hashlib.sha256(cb).hexdigest(),'matches_frozen_git_bytes':True}},indent=2)+'\n','utf-8')
    print(json.dumps({'revision':REV,'extracted_file_count':len(m['inputs'])}))
