from pathlib import Path
import json,re,bisect
ROOT=Path(__file__).resolve().parents[1]
def locations(path, wanted):
    s=path.read_text('utf-8'); nl=[i for i,c in enumerate(s) if c=='\n']; dec=json.JSONDecoder(); results={}
    def ws(i):
        while i<len(s) and s[i].isspace():i+=1
        return i
    def parse(i,p):
        i=ws(i)
        if p in wanted:results[p]={'line':bisect.bisect_left(nl,i)+1,'offset':i}
        if s[i]=='{':
            i=ws(i+1)
            if s[i]=='}':return i+1
            while True:
                k,j=dec.raw_decode(s,i); i=ws(j); assert s[i]==':'; i=parse(i+1,p+'/'+k); i=ws(i)
                if s[i]=='}':return i+1
                assert s[i]==',';i=ws(i+1)
        if s[i]=='[':
            i=ws(i+1);n=0
            if s[i]==']':return i+1
            while True:
                i=parse(i,p+'/'+str(n));n+=1;i=ws(i)
                if s[i]==']':return i+1
                assert s[i]==',';i=ws(i+1)
        return dec.raw_decode(s,i)[1]
    parse(0,'');return results
e='research/modalities/emc-expression-panels.json'; inp='research/modalities/emc-expression-panels-inputs.json'
want={e:['/platforms','/gene_reads','/panels','/_limits']+['/gene_reads/'+g for g in ['BCL2L2','BCL2A1','MCL1','BCL2L1','MDM2','ZMAT3','PMAIP1','ASS1','ARID1A']]+['/panels/'+g for g in ['p53_mdm2_axis','apoptotic_dependency','chromatin_prc2_baf','ddr_mmej']]+['/platforms/'+m+'/genome_wide_null' for m in ['GSE24369_series_matrix.txt.gz','GSE4303-GPL3290_series_matrix.txt.gz']],inp:['/targets/GSE24369_series_matrix.txt.gz/'+x for x in ['samples','background_per_sample','genes/ASS1','genes/PMAIP1']], 'research/modalities/census-route-expression-grading.json':['/routes/'+g for g in ['RT-MDM2','RT-EZH2','RT-POLQ','RT-APOPTOSIS-DEP']],'research/modalities/depmap-sarcoma-dependency.json':['/data_source','/genes_by_group/Apoptotic guardians (BH3)'],'research/literature/biomarker-class-definitions-2026-08-09.json':['/citations/'+p for p in ['8440237','33035459','17692808','22230093','25642963','34179826']]}
out={p:locations(ROOT/'inputs'/p,set(ps)) for p,ps in want.items()}
(ROOT/'review/source-locations.json').write_text(json.dumps(out,indent=2)+'\n','utf-8');print(json.dumps(out,indent=2))
