from pathlib import Path
import hashlib,json,subprocess,datetime
ROOT=Path(__file__).resolve().parents[1]
REPO=Path('C:/Projects/EMC-Research'); REV='796fcdf0a7d751a8e74c6473f36d75e612cd167b'
def sha(b):return hashlib.sha256(b).hexdigest()
checks=[]
for r in json.loads((ROOT/'review/input-manifest.json').read_text('utf-8'))['inputs']:
    b=(ROOT/'inputs'/r['path']).read_bytes(); original=subprocess.check_output(['git','show',REV+':'+r['path']],cwd=REPO)
    checks.append({'path':r['path'],'retained_path':str((ROOT/'inputs'/r['path']).relative_to(ROOT)),'bytes':len(b),'sha256':sha(b),'matches_git_bytes':b==original,'matches_initial_manifest':sha(b)==r['sha256'] and len(b)==r['bytes']})
SUP=ROOT/'review/claim-source-support'
for r in json.loads((SUP/'git-blob-sha256-manifest.json').read_text('utf-8'))['files']:
    b=(SUP/r['copy']).read_bytes(); original=subprocess.check_output(['git','show',REV+':'+r['path']],cwd=REPO)
    checks.append({'path':r['path'],'retained_path':str((SUP/r['copy']).relative_to(ROOT)),'bytes':len(b),'sha256':sha(b),'matches_git_bytes':b==original,'matches_initial_manifest':sha(b)==r['sha256'] and len(b)==r['size']})
assert all(r['matches_git_bytes'] and r['matches_initial_manifest'] for r in checks)
hb=(ROOT/'inputs/HANDOFF-biomarker-frozen-readiness.md').read_bytes()
assert len(hb)==10872 and sha(hb)=='43250d51ced118ab5754727b8d342c5fc736e9480aa32186796104ddd2135f96'
ar=json.loads((ROOT/'review/independent-checks.json').read_text('utf-8'))
assert ar['summary']=={'n_group_comparisons':16,'n_readable_gene_comparisons':86,'all_original_rounding_checks_match':True,'failed_checks':[]}
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
report=ROOT/'review/final-scientific-review.md'
report_text=report.read_text('utf-8')
assert 'claim-source-support/claim-source-report.md' in report_text
assert report_text.count('### F')==9
assert report_text.count('— P1:')==3 and report_text.count('— P2:')==6
report.write_text(report_text+'\nReview completed (UTC): '+now+'\n','utf-8')
files=[]
for p in sorted(ROOT.rglob('*')):
    if not p.is_file() or p.name in ['final-integrity-receipt.json','final-integrity-console.txt']:continue
    b=p.read_bytes();files.append({'path':str(p.relative_to(ROOT)),'bytes':len(b),'sha256':sha(b)})
receipt={'frozen_revision':REV,'completed_utc':now,'verdict':'not_supported_as_written','recommendation':'major_revision','findings':{'P1':3,'P2':6},'report':{'path':str(report),'bytes':report.stat().st_size,'sha256':sha(report.read_bytes())},'all_retained_git_copies_match':True,'retained_git_copy_count':len(checks),'input_copy_checks':checks,'arithmetic_summary':ar['summary'],'handoff':{'bytes':len(hb),'sha256':sha(hb)},'files':files,'scope_limitations':['Not a blind review: handoff and historical objections supplied.','No full raw-data/probe-map/DepMap regeneration.','No new source retrieval; five named original literature payloads not found within scoped frozen-tree search.','No preflight/publication gate execution or clearance.','No manuscript/scientific-source/shared-repository edits.']}
(ROOT/'review/final-integrity-receipt.json').write_text(json.dumps(receipt,indent=2,ensure_ascii=True)+'\n','utf-8')
message=json.dumps({k:receipt[k] for k in ['completed_utc','verdict','findings','report','all_retained_git_copies_match','retained_git_copy_count','arithmetic_summary']},indent=2)
(ROOT/'review/final-integrity-console.txt').write_text(message+'\n','utf-8');print(message)
