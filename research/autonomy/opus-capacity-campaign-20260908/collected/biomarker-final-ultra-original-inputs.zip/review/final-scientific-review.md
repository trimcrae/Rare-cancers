# Independent final scientific review: biomarker-selected classes

Frozen revision: `796fcdf0a7d751a8e74c6473f36d75e612cd167b`.

Manuscript: `research/manuscripts/dependency/emc-biomarker-selected-classes.md`, 21,448 bytes, SHA256 `fe4f95abb1476c95cf60ea21a2570692328de0ada379f6c542329599b566c766`.

**Scientific verdict: `not_supported_as_written`; recommendation: `major_revision`. Do not release this frozen version as a standalone computational preprint.** The numerical summaries are reproducible from the retained input cache. The main deficiencies concern what those summaries measure and what negative conclusions they permit. This is an independent review of the present scientific content, not adoption of the historical statistics verdict and not a new formal blind-seat or publication-bar receipt. The reviewer was given the handoff and previous objections; the review is independent of authorship, but is not blind to that context. One bounded supporting agent checked retained claim-source material; this report adjudicates the findings as one batch.

The manuscript has a potentially useful descriptive contribution: auditable archival transcript contrasts, honest missing-probe accounting, and an explicit distinction between RNA observations and the assays needed to select a therapy. It does not presently demonstrate a validated method for excluding or ranking four biomarker-selected classes. A defensible revision could be a retrospective case study of the limits of transcript-based therapeutic triage, with ASS1 as a relative-expression observation and the remaining selecting states unresolved. If that narrower contribution is not useful enough for a standalone paper, park this manuscript and retain its tables/code as a companion analysis. Neither a mandatory wet-lab experiment nor another whole-paper review is the minimum repair.

## Review scope and integrity

All scientific inputs inspected here were extracted with `git show <frozen-revision>:<path>`, preserving exact Git bytes. No working-tree scientific file was used as evidence, modified, checked out, staged, fetched, published, or merged. The externally copied manuscript exactly equals its frozen Git blob. The provided handoff matches its stated 10,872 bytes and SHA256 `43250d51ced118ab5754727b8d342c5fc736e9480aa32186796104ddd2135f96`.

All five required source-artifact SHA256 values match the assignment. The source manifest records exact bytes, SHA256, and Git blob ID for each extracted dependency. The frozen operating protocol, AGENTS, CLAUDE, paper-hardening, repo-gates, and relevant publish-bar clauses were read. Historical reviews were retained unchanged and treated as evidence to check, not verdict authority.

The review used no new experiment, network source retrieval, paid compute, denied-route retry, or full producer/preflight run. `independent_checks.py` independently implements sample-level Welch arithmetic using the frozen rounded input cache; it does not import or execute the producers. It verifies 16 group-by-platform contrasts and 86 relevant readable gene-by-platform contrasts, including all components of the eight reported groups plus ASS1, the p53-axis genes and named proliferation controls. Every checked stored t, delta, df, and per-gene n agrees at the producer's rounding precision. This establishes the cache-to-summary arithmetic for that scope. It does not re-establish the original GEO fetch, probe annotations, whole-matrix normalization, or DepMap producer execution.

Line numbers below refer to the exact frozen files. `M` means `research/manuscripts/dependency/emc-biomarker-selected-classes.md`; `E` means `research/modalities/emc-expression-panels.json`; `I` means `research/modalities/emc-expression-panels-inputs.json`. Exact source-key locations are also retained in `source-locations.json`.

## Prioritized findings

P1 denotes a major scientific submission blocker affecting the central inference. P2 denotes a concrete correction needed before submission, with a narrower consequence. Maintenance and scope limitations are separated below. There are three P1 findings and six P2 findings; several can be resolved in the same compact revision.

### F01 — P1: the corrected summary ceiling is still violated by the central results

**Frozen locations:** M:53–58, 68–71, 153–164, 171–177, 186–210, 228–233; title/frontmatter M:3 and M:7. Sources: E:219264 (p53 panel), E:219624 (PRC2/SWI-SNF), E:220384 (repair panels), and the explicit instrument limits at E:551418.

The summary now says that no class is excluded, but immediately says that each selecting feature is readable in expression data (M:57). Section 2.3 says “Neither is there.” Section 2.4 says the alt-EJ half “is present,” the HR-deficient half “is not present,” the “combination is absent,” and the selection criterion “is not met.” These are statements about biological states, not merely about the observed signs of transcript-group means. The caveats that follow explicitly admit those states were not measured. M:231–233 uniquely leaves BH3-mimetics open because the instrument cannot answer its question; that same instrument limitation applies to the other classes. The metadata title still says “what the available expression data excludes” and `canonical_for` still describes class exclusions.

The valid distinction is between an observed RNA contrast and an unresolved biomarker, not between an absent biomarker with a weak caveat and an open fifth class. A module of LIG3/PARP1/XRCC1 with POLQ unreadable on GPL3290 does not establish active Polθ-mediated repair. A near-zero or positive between-group HR-transcript contrast does not provide a negative HRD result. The paper cannot simultaneously say that the selecting measurement was not made and report that it returned negative.

**Minimum repair:** replace the categorical result sentences and their metadata counterparts directly. State the transcript observations, then mark the biological selecting state unmeasured. Retain “unsupported” only for an explicitly named, prospectively justified RNA-proxy assumption; do not call the actual biomarker absent. Remove the unique-survivor comparison unless a defensible, consistent decision rule distinguishes BH3 from all other unmeasured states. A uniform class table should separate actual selecting assay, project RNA proxy, observed estimate, and unresolved question. If the four-negative/one-survivor result is essential to the intended paper, park it: these sources cannot establish it.

### F02 — P1: the background distribution does not strengthen negative evidence

**Frozen locations:** M:103–110, 157–158, 171–173, 201–208, 265–272. Sources: E:1414 and E:15470 (observed genome-wide t distributions); `research/modalities/emc_expression_panels.py`:1964–1978 and 2239–2262; historical statistics seat, `blockers[2]` and `_verdict_note`.

M:269 correctly states that the array-wide placement controls no error rate and contains real biology. M:270–271 then says this “makes the four negatives harder to overturn.” That inference does not follow. A broad observed distribution can reflect true between-histology biology, confounding, correlated measurements, technical effects, or their mixture. It is not a null distribution generated under the null hypothesis. It cannot establish calibration failure by itself, and it cannot make a low-powered or small t into evidence of equivalence or biological absence. Comparing the genome-wide distribution of single-gene t statistics with a particular correlated gene-set mean is not a calibrated gene-set test either.

The old statistics seat overreached when it called the observed mixture a demonstrated anticonservative reference distribution and claimed a wider null strengthens the negatives. The manuscript inherited the latter mistake. I reject that part of the historical objection rather than using it as clearance. The stored tails and t values are useful descriptive context; they are neither corrected p values nor tests of absence. NOXA's GPL3290 observed tail is 66/14,403 = 0.00458, so it is also wrong to erase that relatively extreme single-platform observation merely because t near 2 is common elsewhere.

“Flat” is derived from the producer's |t|<2 readability convention, but M never defines it. A t cutoff combines effect size and sampling uncertainty; it is not a biological low-expression threshold or an equivalence bound. No confidence interval or prespecified equivalence margin is reported. For example, the HR means have deltas −0.04384 and +0.26582 array-SD units with SE 0.07648 and 0.25678; these do not establish HR-pathway normality.

**Minimum repair:** delete the sentence that strengthens the negatives. Call the genome-wide distribution an observed background, explicitly limit its use to descriptive ranking, define any retained “flat” convention, and print effect sizes with uncertainty. Use “no demonstrated RNA difference under this exploratory analysis” where appropriate. Do not require FDR or an equivalence analysis merely to manufacture a negative; if the paper wants an inferential absence claim, it needs a defensible estimand, null/interval method and equivalence margin that are currently absent. Otherwise keep the paper descriptive.

### F03 — P2: the quoted PRC2 statistics are attributed to the wrong gene set

**Frozen locations:** M:171–173. Sources: E:219624, `panels.chromatin_prc2_baf.groups.prc2_core`; producer `emc_expression_panels.py`:1981–2016.

The t values −0.22 and 1.71 belong to the full PRC2-core mean, including EZH2. The sentence attributes them to “the rest of PRC2” after separating EZH2 out. This old arithmetic-seat objection remains unfixed. Independently reproduced full-core values are t=−0.216174 and 1.714101. The retained memberships are EZH2/EED/SUZ12/RBBP4 on GPL6244 and EZH2/EED/RBBP4 on GPL3290; SUZ12 is unreadable on the latter. These are not EZH2-excluded estimates.

The adjoining “no SWI/SNF … anywhere near a floor” claim also lacks a defined or measured detection floor. A contrast near zero is not a floor measurement. GPL3290 values are two-colour ratios, and that array's transcript-ratio percentile is not absolute abundance. The artifact explicitly says so. ARID1A's GPL3290 ratio percentile of 0.1825 does not prove low abundance either, so I do not replace one invalid absolute reading with another.

**Minimum repair:** name the full scored PRC2 core correctly and disclose 4/4 versus 3/4 coverage. Replace the floor claim with the measured relative-expression observations and the statement that protein loss/detection status is unmeasured. No new computation is needed.

### F04 — P2: the manuscript incorrectly says the omitted-SFT check requires a re-fetch

**Frozen locations:** M:93–101. Sources: I:6472 (42 sample annotations), I:6686 (42 background summaries), I:208826 (ASS1 values), I:101064 (PMAIP1 values); `emc_expression_panels.py`:1647–1665 and 1932–1934; `emc_atr_vulnerability.py`:1608–1611.

The disclosure of the seven exclusions is a real improvement. However, the assertion that the five SFT samples' effect is unknown because answering it requires a re-fetch is false for the reported targeted genes/groups. The output `gene_reads.per_sample` keeps only the 35 used records, but the frozen input cache keeps all 42 samples, their background means/SDs and every retained target gene's 42 values. The distinction between output and input was missed by the old arithmetic review and then repeated in M.

I recomputed a bounded audit-only sensitivity including GSM600963–GSM600967 as comparators, leaving the two pooled references out. The original results remain preserved. Representative changes are:

| GPL6244 measure | original delta / t, 6 vs 29 | including SFT delta / t, 6 vs 34 |
|---|---:|---:|
| ASS1 | +0.478686 / 4.429139 | +0.430143 / 3.810488 |
| p53 output mean | −0.179614 / −2.202613 | −0.187202 / −2.335166 |
| alt-EJ mean | +0.086991 / 2.422910 | +0.086024 / 2.496730 |
| guardian mean | −0.258960 / −4.567516 | −0.236684 / −4.295305 |
| sensitiser mean | −0.013367 / −0.167942 | +0.019981 / +0.249890 |

The other principal group directions also remain unchanged; the full table is retained in `independent-checks.json`. This does not validate the biology, but the omitted comparators do not reverse the principal descriptive group directions in this limited check. A genome-wide background recalculation for the enlarged comparator would still require data beyond these reduced target-gene rows; this audit does not claim to have regenerated that background.

**Minimum repair:** identify the available input cache and report the bounded SFT sensitivity, or accurately state that it was not examined rather than inaccessible. Keep the original comparator analysis distinct from the sensitivity result. Name the actual histologies in both comparator arms and make clear that selection came from the legacy annotation classifier. No raw-data re-fetch is needed for this targeted repair.

### F05 — P2: group-level summaries hide material component heterogeneity

**Frozen locations:** M:157–158 and 218–231. Sources: E:46962 (BCL2L2), E:45703 (BCL2A1), E:136419 (MDM2), E:216073 (ZMAT3), E:219443 (apoptotic group membership/scores). Independent complete component table: `independent-checks.txt`.

The guardian-group arithmetic is correct: deltas −0.25896/−0.40967 and t=−4.56752/−2.53833. Thus **BCL2L2 does not refute the explicitly stated group mean**. The problem is the “negative and clean” synthesis and what is inferred from it. On GPL6244 BCL2L2 is higher (delta +0.12305, t=2.90829), and BCL2A1 is also directionally higher (+0.03704, t=0.50641). Only three of five guardians have negative component contrasts there. On GPL3290 all five component deltas are negative, but several t values are small. MCL1 and BCL2L1 are indeed lower on both platforms; that checked statement should remain.

The analogous “axis genes themselves are flat” wording refers at best to their mean; MDM2 individually is lower on GPL6244 (delta −0.25657, t=−3.33671). The p53-output list is also heterogeneous; on GPL3290 GADD45A, BBC3, and RPS27L have positive contrasts, while ZMAT3 has t=−6.70449. A low average of a curated list is not evidence that every component or the functioning pathway is quiet.

NOXA's weak GPL6244 statistic is now honestly printed, and this corrects the old cross-platform overstatement. However, M prints the sensitiser-group mean only on GPL6244, leaving out GPL3290 (+0.29231, t=2.15997). On GPL6244 BCL2L11 and BIK move down (t=−2.57484 and −2.10536), despite NOXA moving slightly up. The priming claim at M:228–231 remains an interpretation that is compatible with multiple biological states, not demonstrated by the average guardian transcript and one sensitiser.

**Minimum repair:** say “the mean of the five-gene list is lower,” report the BCL2L2 reversal and the other directional exception, report both sensitiser means, and distinguish the p53-axis mean from MDM2 individually. Label priming as one hypothesis requiring functional measurement. A compact component table is sufficient; no additional full analysis is necessary.

### F06 — P2: methods and denominators are insufficient for a standalone reanalysis

**Frozen locations:** M:88–110, 124–130, 186–197, 222–226, 284–299. Sources: `emc_expression_panels.py`:1467–1502, 1657–1665, 1908–2016; E:551418; frozen input cache and `independent-checks.json`.

The unit of analysis is correctly the sample, not the gene: each sample receives a mean over available gene z values, followed by a Welch comparison across samples. There is no gene-level pseudoreplication in the checked implementation. But that implementation is not adequately specified in M. The paper omits probe-to-symbol/collapse rules, the formula and units of within-sample standardization, missing-value handling, group membership/coverage, effective per-gene n, and the exact input/code path needed to reproduce its values.

On GPL3290 NOXA uses 10 EMC versus **5** comparators, and MKI67 uses **9** versus 6. RAD51 uses 8 versus 3 and PALB2 10 versus 4. Platform-level membership differs: p53 output 5/6 versus 6/6; PRC2 4/4 versus 3/4; alt-EJ 4/4 versus 3/4; HR 5/5 versus 4/5. Missing values change even the per-sample list within a platform: two GPL3290 comparator HR scores average only two of the five requested genes. The global three-gene group floor is not a per-sample floor. These are interpretable exploratory choices if disclosed; they cannot be hidden behind “16 tumours.”

The GPL3290 comparator metadata also mix DFSP/CRH/mRNA with GIST/UHR/Total RNA, whereas the EMC samples carry CRH/mRNA. The paper's table currently prints only “6” for that comparator. This is a design limitation confounded with histology; it is not proven to drive the observed contrasts. Earlier source-seat subgroup checks did not implicate it for ASS1/NOXA, so I do not call those results artifacts on that basis.

**Minimum repair:** add a compact methods/data supplement containing exact per-platform gene lists, effective n, delta, SE or clearly defined uncertainty, t/df, missingness policy and comparator composition. Explain that an “array SD” is the SD across probes within a sample, not a gene-specific between-patient standardized effect size, and that GPL3290 is a ratio platform. Link the frozen producer and input cache in availability, including the imported Welch/classifier dependencies and a bounded reproduction command. Clearly separate cached-score reproducibility from the unrerun raw-data collection pipeline.

### F07 — P1: the therapeutic selection framework and selectivity language exceed their sources

**Frozen locations:** M:45–58, 140–155, 168–184, 214–216, 118–134, 235–237. Sources: `research/literature/biomarker-class-definitions-2026-08-09.json`:59, 70, 92, 103; `research/modalities/depmap-sarcoma-dependency.json`:3 and 167; retained-source supporting report under `claim-source-support/`.

The most consequential unsupported definition is that the MDM2-inhibitor class “needs” an axis that is already transcriptionally live. PMID 8440237 establishes that wild-type p53 can induce MDM2 expression; that feedback relationship does not establish a required high pretreatment p53-output score relative to other sarcomas. Lower relative output in these archival expression measurements therefore does not falsify a validated selecting feature. The “quiet-genome argument” supposedly predicting the opposite is not specified or directly sourced in M. It may be a program hypothesis, but must be labelled and evidenced as such rather than treated as a class requirement.

The general claim that all five classes are “given” on their described molecular state conflates mechanistic/preclinical rationale, biomarker-enriched trial cohorts, and an approved indication. The retained Polθ papers support HRD-related vulnerability; they do not establish this four-gene alt-EJ-high/five-gene HR-low expression rule as a clinically validated selection instrument. The cited EZH2 study concerns an INI1/SMARCB1-selected epithelioid-sarcoma cohort; it should be described as that study, not used to establish a universal class rule or current regulatory-label status without the corresponding source.

The DepMap evidence is from cancer lines. MCL1 dependency is 83.5% of 91 screened sarcoma lines versus 69.6% in the rest of the cancer-line panel; BCL2L1 is 75.8% versus 85.4%. These support broad dependency among the sampled sarcomas and different relative lineage patterns for the two genes. A high sarcoma fraction alone does not show lack of a tumour-versus-normal therapeutic window. The artifact's “selectivity” is explicitly `rest_mean - sarcoma_mean`, not normal-tissue safety. “Near-universal” should not substitute for the reported 76–84% fractions.

M:46 also says EMC “has no targeted agent.” Retained literature includes a primary pazopanib phase-2 report and distinguishes the absence of a clinically validated agent directly targeting NR4A3 from the broader targeted-agent category. The current sentence loses that distinction. The exact retained record is `research/literature/rt-lung-mets-probe.json`:344–353 and 1978–1987, with corroborating trial metadata at `research/data/emc-clinical-registry.json`:914–934. The supporting check also confirms that M:140–142's unnecessary “closest published setting” comparison between the two ASS1 papers is not established; remove that comparison while retaining the ASS1-deficiency rationale. Likewise, a simple statement that protein loss cannot be excluded from normal RNA is sufficient without the unsupported frequency qualifier “frequently post-transcriptional” at M:176.

**Minimum repair:** explicitly distinguish class-defining clinical evidence from mechanistic or exploratory selection arguments, remove the claimed basal-p53-output requirement unless a retained source actually validates it, and narrow the no-targeted-agent statement to the supported direct-fusion/NR4A3-targeting proposition. State DepMap denominators, fractions and reference population; limit its inference to the sampled cancer-line lineages. No new literature hunt is necessary to remove unsupported wording. The nine PMID identifiers are anchored, but anchoring is not claim verification; retained full original payloads were not located in the reviewed frozen-tree scope (see limitations below).

### F08 — P2: the falsifier table tests different claims from those stated

**Frozen locations:** M:252–261, in tension with M:247–248.

F1 and F3 pair a measured transcript statement with protein IHC. Protein loss can coexist with the stated RNA observation; it would change a therapeutic interpretation, not falsify the transcript measurement. F4 similarly proposes HRD behind normal transcript, which is compatible with the claimed RNA observation. F5 and F6 require a third series to reverse a direction, but the paper disclaims generalization beyond these 16 tumours; a new cohort does not make the first cohort's point estimate false. F7 resolves an unknown rather than refuting a factual claim. F8 still labels “none … is a proliferation or cellularity artefact” as a claim even though no cell-composition analysis establishes that. MKI67's difference is now disclosed correctly, but flat MKI67 would not establish equal cellularity or remove other confounding.

**Minimum repair:** rename the table to “assays that could change the therapeutic interpretation,” or specify separately the RNA result, its external generalization, and the functional hypothesis being tested. Do not present orthogonal measurements as contradictions of compatible observations. Mark F8's confound status unresolved and avoid treating its control as a binary validation of cell composition.

### F09 — P2: the retrospective selection and grading rule are not stated

**Frozen locations:** M:53–71 and 103–115. Sources: `research/modalities/census-route-expression-grading.json` header and its 16 `routes`; E `panels` (156 emitted curated group-by-platform scores); producer `emc_expression_panels.py`:2251–2253.

The paper narrates five questions and four graded negatives without explaining why these five classes were selected from the 16 graded routes, or that the route grading followed already-available expression results. The producer's statement that some reads were specified in advance is not a preregistration of this manuscript's five-class selection or its ranking of negatives. The “strongest/weak/weakest” scheme has no operational rule connecting assay validity, direction, precision, and clinical evidence. It should not be presented as an established methodological result merely because the narrative lists its limitations carefully.

**Minimum repair:** state the retrospective scope, source denominator and substantive rule for choosing these five classes. Label the strength labels as qualitative program judgments, or replace them with an explicit table of what each assay can and cannot infer. Do not imply confirmatory hypothesis testing or unbiased discovery selection. This is compatible with a useful descriptive preprint but materially changes the current methodological claim.

## What was verified or improved, and what should not be reopened

- The primary manuscript and all five required sources match their assigned SHA256 values. The final integrity receipt verifies retained copies against exact Git blobs, not just against an earlier manuscript hash.
- The independent calculations reproduce all 16 checked group/platform statistics and 86 readable gene/platform contrasts at stored rounding precision. ASS1 is directionally higher on both platforms, its GPL6244 mean array percentile is 0.9152, and its contrast is not reversed in the bounded SFT check. Its protein/functional state remains unknown.
- The reported POLQ missing probe on GPL3290 and its weak GPL6244 reading (delta +0.04459, t=0.30894; array percentile 0.2066) are now correct. Every readable alt-EJ member has a positive delta, but the module is not a validated functional readout.
- NOXA now has both platform statistics and is explicitly a one-platform observation. The GPL3290 signal is relatively extreme in the stored genome-wide distribution; its nonreplication and functional interpretation remain limitations.
- The direct arithmetic difference between alt-EJ and NHEJ means is delta +0.09578, t=2.40164 on GPL6244, and +0.23600, t=1.44017 on GPL3290. Different apparent significance of the two separate modules does not establish pathway specificity. These audit-only contrasts do not establish a new validated specificity test. The NHEJ wording should be folded into F01's correction; the added broader-specificity caveat alone does not rescue “specific against NHEJ” on both platforms.
- MKI67 is correctly disclosed as differing on GPL3290, and the three other named proliferation statistics match. This is an unresolved control concern, not proof that all GPL3290 results are artifacts.
- The old unrestricted existence/novelty assertions have been materially narrowed. The description of other unread series is appropriately scoped to the reader, and the public records are not described as newly recruited or newly sampled.
- The manuscript disclaims EMC efficacy, safety and clinical readiness, and truthfully states that there was no drug exposure in this analysis. It does analyze public human tumour records. The declarations no longer invent an ethics-not-required determination. This review does not make such a determination either.
- No EMC dependency result is present in the analyzed dependency panel. The disputed identity of H-EMC-SS is not adjudicated here; its label/fusion-status sentence needs a direct link to the actual qualified identity record, not an implied attribution to the aggregate DepMap JSON.

## Operational release gates, kept separate from science

No publication action is authorized by this report. The frozen handoff reports no full preflight receipt, an explicit-path style pass without inclusion in `lint_style.TARGETS`, ten automatic pinned prose bindings, and a repository systems-check result of 2,394 errors/271 warnings. Those are retained historical measurements, not checks executed by this reviewer and not a scientific verdict. The frozen `publish_bar.py`:622–677 requires a full candidate-bound log/receipt; its clauses also require relevant independent review evidence and buildability. I inspected those requirements but did not evaluate or alter the bar, generate a blind-seat record, or infer that any clause passed.

The publication registry row for `PUB-BIOMARKER-DEP` still describes four selecting features as absent and the useful output as classes ruled out. That release-facing metadata must be reconciled with any repaired scientific claim. Broad repository lint/style coverage and additional prose guards are maintenance unless they cause a concrete release requirement to fail; missing guards are not reasons to rerun otherwise correct science.

## Reproducibility and source limitations

The exact manuscript, five primary retained artifacts, input cache, relevant producers/import dependencies, tests/workflow, policies and historical reviews are preserved under `inputs/`. The input manifest does not assert that a copied artifact was originally generated by the named code; the independent arithmetic only bridges the specific retained cache values to the reported summary statistics. Full raw series matrices, original probe-collapse values, complete per-symbol data for a new genome-wide comparator background, and original DepMap matrices were not regenerated or independently verified. Existing tests were inspected but not run: pytest is not installed in the assigned runtime, and no installation or substitute pass claim was made. The standalone arithmetic script uses the standard library and does not require pytest.

The supporting source check did not locate the five specifically named original `epmc_*.txt` payloads in the frozen tracked-tree/retained-archive scope it examined. It did retain exact citation-anchor metadata and relevant other stored literature records. That is a scoped retention/verification limit, not proof of global source loss, citation fabrication, or absence outside this Git tree. No current regulatory claim was independently verified online. Detailed source matches and limits are in `claim-source-support/claim-source-report.md`.

Preparatory tool failures are recorded in `review-process-notes.md`; none are represented as passed checks. A large inspection log was retained in full even where the conversational display truncated it. No failures or scientific originals were deleted or replaced.

The bounded next step is one batched revision addressing F01–F09, followed by focused verification of the changed claims, their table values and dependencies. If the revised objective still requires validated class exclusion, pathway activity, priming, or a normal-tissue therapeutic window, the correct outcome is to park those claims as unresolved. Release checks remain a separate coordinator responsibility.

Review completed (UTC): 2026-09-08T17:06:11.852842+00:00
