from pathlib import Path
import json, subprocess
ROOT=Path(__file__).resolve().parents[1]
def j(p):return json.loads((ROOT/'inputs'/p).read_text('utf-8'))
def dump(v):print(json.dumps(v,indent=2,ensure_ascii=True))
e=j('research/modalities/emc-expression-panels.json')
dump({'platforms':e['platforms'],'limits':e['_limits']})
for k in ['p53_mdm2_axis','apoptotic_dependency','chromatin_prc2_baf','ddr_mmej','arginine_auxotrophy']:
    dump({k:e['panels'][k]})
for n in ['census-route-expression-grading','depmap-sarcoma-dependency']:
    d=j('research/modalities/'+n+'.json')
    dump({n:{k:(list(v)[:25] if isinstance(v,dict) else str(v)[:500]) for k,v in d.items()}})
files=subprocess.check_output(['git','ls-tree','-r','--name-only','796fcdf0a7d751a8e74c6473f36d75e612cd167b'],cwd='C:/Projects/EMC-Research',text=True).splitlines()
dump({'candidate_paths':[p for p in files if any(q in p for q in ['biomarker','expression_panel','expression_dataset','census_route_expression','depmap_sarcoma','class-definitions','20d33f3'])]})
