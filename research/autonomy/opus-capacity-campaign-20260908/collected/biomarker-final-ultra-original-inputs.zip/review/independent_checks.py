"""Read-only deterministic arithmetic audit. No producer imports, fetches, or source edits."""
from pathlib import Path
import json, math, statistics, datetime, hashlib, importlib.util
ROOT=Path(__file__).resolve().parents[1]
def read(p):return json.loads((ROOT/'inputs'/p).read_text('utf-8'))
e=read('research/modalities/emc-expression-panels.json')
inp=read('research/modalities/emc-expression-panels-inputs.json')
group_keys={'p53_mdm2_axis':['p53_transcriptional_output'], 'chromatin_prc2_baf':['prc2_core','swi_snf_tumour_suppressors'], 'ddr_mmej':['alt_ej_module','homologous_recombination','nhej_contrast'], 'apoptotic_dependency':['anti_apoptotic_the_druggable_ones','bh3_only_sensitisers']}
allgenes=sorted(set(['ASS1','MKI67','PCNA','TOP2A','MCM2','TP53','MDM2','MDM4']+[g for p,groups in group_keys.items() for gr in groups for g in e['panels'][p]['groups'][gr]['genes_requested']]))
def welch(a,b):
    a=[x for x in a if x is not None]; b=[x for x in b if x is not None]
    n,m=len(a),len(b); va=statistics.variance(a)/n; vb=statistics.variance(b)/m
    se=math.sqrt(va+vb); d=statistics.mean(a)-statistics.mean(b); df=(va+vb)**2/(va**2/(n-1)+vb**2/(m-1))
    return {'n_a':n,'n_b':m,'mean_a':statistics.mean(a),'mean_b':statistics.mean(b),'delta':d,'se':se,'t':d/se,'df':df}
def zrow(tgt,g):
    return [None if v is None or bg is None else (v-bg['mean'])/max(1e-9,bg['sd']) for v,bg in zip(tgt['genes'][g]['values'],tgt['background_per_sample'])]
def mean_available(xs):
    xs=[x for x in xs if x is not None]
    return statistics.mean(xs) if xs else None
out={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Independent arithmetic from frozen rounded input cache, not raw matrix/probe-map regeneration. SFT sensitivity is audit-only, not replacement scientific artifact. No multiplicity-adjusted or equivalence inference.','platforms':{},'group_checks':[],'gene_checks':[],'sft_sensitivity':[],'direct_module_difference_checks':[]}
for mf,tgt in inp['targets'].items():
    plat=e['platforms'][mf]; labels={r['gsm']:r['class'] for r in plat['sample_annotations_verbatim']}
    a=[i for i,s in enumerate(tgt['samples']) if s['gsm'] in plat['EMC_gsms']]
    b=[i for i,s in enumerate(tgt['samples']) if s['gsm'] in plat['comparator_gsms']]
    sft=[i for i,s in enumerate(tgt['samples']) if 'solitary fibrous tumor' in s['annotation_verbatim'].lower()]
    summaries={}
    out['platforms'][mf]={'n_input_samples':tgt['n_samples'],'n_input_backgrounds':len(tgt['background_per_sample']),'retained_sample_annotations':tgt['samples'],'class_counts':plat['class_counts'],'sft_indices':sft,'all_wanted_gene_values_include_all_samples':all(len(r['values'])==tgt['n_samples'] for r in tgt['genes'].values()),'value_kind':tgt['value_kind'],'null_symbols':plat['genome_wide_null']['n_symbols_scored'],'null_quantiles':plat['genome_wide_null']['t_distribution']}
    for p,groups in group_keys.items():
        for gr in groups:
            entry=e['panels'][p]['groups'][gr]['per_platform'][mf]; genes=entry['genes_readable']; rows=[zrow(tgt,g) for g in genes]
            values=[mean_available([row[i] for row in rows]) for i in range(tgt['n_samples'])]
            summaries[gr]=values
            w=welch([values[i] for i in a],[values[i] for i in b]); orig=entry['score']
            checks={'t_3dp':round(w['t'],3)==orig['t'],'delta_4dp':round(w['delta'],4)==orig['delta_a_minus_b'],'df_1dp':round(w['df'],1)==orig['df']}
            r={'platform':tgt['platform'],'panel':p,'group':gr,'requested':e['panels'][p]['groups'][gr]['genes_requested'],'readable':genes,'missing':entry['genes_not_readable'],'sample_member_counts':{tgt['samples'][i]['gsm']:sum(row[i] is not None for row in rows) for i in a+b},'stored':orig,'recomputed':w,'checks':checks}
            out['group_checks'].append(r)
            if sft:out['sft_sensitivity'].append({'type':'group','name':gr,'old':w,'including_SFT':welch([values[i] for i in a],[values[i] for i in b+sft])})
    for g in allgenes:
        gr=e['gene_reads'][g][mf]
        if not gr['readable']:
            out['gene_checks'].append({'platform':tgt['platform'],'gene':g,'readable':False}); continue
        z=[None if x is None else round(x,4) for x in zrow(tgt,g)]
        w=welch([z[i] for i in a],[z[i] for i in b]); orig=gr.get('welch_EMC_vs_comparator')
        if orig is None:continue
        checks={'t_3dp':round(w['t'],3)==orig['t'],'delta_4dp':round(w['delta'],4)==orig['delta_a_minus_b'],'df_1dp':round(w['df'],1)==orig['df'],'n_matches':(w['n_a'],w['n_b'])==(gr['n_EMC_with_a_value'],gr['n_comparator_with_a_value'])}
        out['gene_checks'].append({'platform':tgt['platform'],'gene':g,'readable':True,'stored':orig,'recomputed':w,'array_percentile_EMC':gr['EMC']['mean_array_percentile'],'n_probes':gr['n_probes_mapping'],'background_placement':plat['genome_wide_null']['placed_wanted_genes'].get(g),'checks':checks})
        if sft and g in ['ASS1','PMAIP1','POLQ','MKI67','BCL2L2']:out['sft_sensitivity'].append({'type':'gene','name':g,'old':w,'including_SFT':welch([z[i] for i in a],[z[i] for i in b+sft])})
    for other in ['nhej_contrast','homologous_recombination']:
        vals=[None if x is None or y is None else x-y for x,y in zip(summaries['alt_ej_module'],summaries[other])]
        out['direct_module_difference_checks'].append({'platform':tgt['platform'],'contrast':'alt_ej_module minus '+other,'recomputed':welch([vals[i] for i in a],[vals[i] for i in b]),'interpretation':'Audit of comparison of effects, not a validated pathway-specificity test.'})
out['summary']={'n_group_comparisons':len(out['group_checks']),'n_readable_gene_comparisons':sum(r.get('readable',False) for r in out['gene_checks']),'all_original_rounding_checks_match':all(all(r['checks'].values()) for r in out['group_checks']+out['gene_checks'] if 'checks' in r)}
out['summary']['failed_checks']=[r for r in out['group_checks']+out['gene_checks'] if 'checks' in r and not all(r['checks'].values())]
(ROOT/'review/independent-checks.json').write_text(json.dumps(out,indent=2,ensure_ascii=True)+'\n','utf-8')
lines=['Independent arithmetic from retained frozen cache','No raw-probe/mapping regeneration or network activity.',json.dumps(out['summary']), '\nGROUPS (platform, group, coverage, n, delta, SE, t, df):']
for r in out['group_checks']:
    w=r['recomputed']; lines.append(f"{r['platform']} {r['group']} {len(r['readable'])}/{len(r['requested'])} {w['n_a']}/{w['n_b']} d={w['delta']:.6f} se={w['se']:.6f} t={w['t']:.6f} df={w['df']:.3f}")
lines.append('\nGENES (platform, gene, n, delta, t, percentile):')
for r in out['gene_checks']:
    if not r['readable']:lines.append(f"{r['platform']} {r['gene']} UNREADABLE"); continue
    w=r['recomputed']; lines.append(f"{r['platform']} {r['gene']} {w['n_a']}/{w['n_b']} d={w['delta']:.6f} t={w['t']:.6f} pct={r['array_percentile_EMC']}")
lines.append('\nSFT sensitivity (old -> including five SFT; original values preserved):')
for r in out['sft_sensitivity']:
    old,new=r['old'],r['including_SFT']; lines.append(f"{r['name']} d {old['delta']:.6f} -> {new['delta']:.6f}; t {old['t']:.6f} -> {new['t']:.6f}")
lines.append('\nDirect differences of module effects:')
lines.extend(json.dumps(r) for r in out['direct_module_difference_checks'])
text='\n'.join(lines)+'\n'; (ROOT/'review/independent-checks.txt').write_text(text,'utf-8');print(text)
